# Inputs and workflow records still required

This list separates code found in the supplied directories from the records needed to reproduce final figures and manuscript values. A missing item does not imply that the analysis was not run; it means the item was not established by this code curation.

| Step | Highest-priority missing record |
|---|---|
| Grass phylogeny | Author-supplied final 88-core ROADIES job and configuration are included. Still need the 97-genome assembly/accession list, production log and output tree hashes; confirm treePL final config and rate-tree hashes. |
| Genome-wide synteny | User-confirmed 3 × 93 GeneTribe comparisons; still need definitive pairwise job list and reference orientation, chromosome/assembly identifiers, versions, block retention filters and final block table. |
| Whole-genome alignment | The existing-tree driver supplies the ROAST guide topology; reusable subflows now cover Fig. 2A observed coverage and Fig. 2B cumulative depth for three references. Still need the exact final guide tree, focal YAML/Snakefile version, MAF hashes, maize/goatgrass query lists, Fig. 2A assembly and BED provenance for Fig. 2B. The historical depth script weights BED rows; the manuscript says eligible reference sites, so verify that rows are one-base intervals or use base-weighted counts. The GERP neutral tree is estimated separately. |
| GERP constraint | GERP-category overlap, pie plotting and the author-supplied bamboo all-site/CDS histogram are included. Still need neutral-rate model/tree and GERP++ output hashes, coordinate masks, exact window definitions, the three histogram input TSV hashes, curated `ped.constrain.tsv`, the generator for `all_gt2_CDS.tsv`, and proof that genomic categories are disjoint or assigned by explicit priority before interpreting pie fractions. The histogram's final figure assembly must be reconciled with the current Fig. 3A/Fig. 4A captions. |
| Population SNP filtering | Teosinte BWA/GATK source jobs were recovered; bamboo fastp→BWA→Picard run evidence, final sample metadata/exclusions, KING result, depth/missingness decisions and final VCF hashes remain needed. |
| Deleterious annotation | Final SnpEff/SIFT databases and versions; GERP and SIFT join keys; reference versus derived allele convention; rare-bin and callable-genome denominators; panel statistics. |
| ROH/FROH/burden | Three author-supplied final scripts now provide gap100/kb100/window-missing5 ROH calling and FROH calculation. Still need final `.hom`/FROH output hashes, confirmation of `--homozyg-het 1` versus PLINK default, the exact Lauto files and the Fig. 6/S8 sample-table joins. Earlier gap100/kb100/window-missing10 scripts remain alternate runs. |
| Syntenic-gene comparisons | Final gene-class input, 5,108 matched-group table and gene-level metrics; two missing SNP records' treatment; every Fig. 7/S9/S10 bracket's test row; plotted point definition. |

## Source selection still requiring author review

- Several recovered files represent reruns or alternate implementations. Hash-suffixed filenames preserve distinct content. Select the exact final run from logs and output hashes before presenting a command sequence as definitive.
- Historical directories contain both LSF and SLURM jobs. A scheduler-specific wrapper and environment lockfile should be added only after the final run configuration is identified.
- The manuscript master retains figures S1–S10 and provisional U1–U3; confirm final numbering before adding figure-specific entry points.
- The current code package includes source scripts and a manifest, but no large genomic input data. Add stable repository accessions and license/usage information when available.
