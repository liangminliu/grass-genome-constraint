# Whole-genome alignment

Methods: three independent reference-coordinate alignments, LAST pairwise alignment, Kent chain/net conversion, then ROAST/MULTIZ multiple alignment. Results: Fig. 2 and Table S1.

| Order | Selected script | Role |
|---|---|---|
| 1 | `selected/prepare_existing_tree_config.py` | use a supplied ROADIES tree, prune tips outside the configured panel and write a separate guide-tree config |
| 2 | `selected/run_msa_with_existing_tree.sh` | corrected `align` → `roast` → `call_conservation` entry point for an existing msa_pipeline checkout |
| 3 | `selected/align.smk`, `selected/chain_and_net.smk`, `selected/roast.smk` | LAST, chain/net and ROAST rules |
| 4 | `selected/maf2bedcov.py` | alignment coverage support |
| 5 | `selected/coverage/` | reusable `mafPairCoverage`/Fig. 2A bar plot and BED-depth/Fig. 2B curve for the three references |

The author supplied a three-step SLURM driver (`align`, `roast`, `call_conservation`) with `config/96sp_config.yaml`. Its pasted text contained Markdown escapes, duplicate output redirection in `roast`, and no explicit existing-tree input. The release entry point accepts a working msa_pipeline checkout, its species-specific YAML and an existing ROADIES Newick. It creates `config/release_existing_tree.yaml` with `speciesTree` set to the pruned, branch-length-free topology. A 97-tip tree can be supplied; the helper retains exactly the configured reference and query tips (94 for the current focal panels) and rejects missing or duplicate tips. This guide topology feeds ROAST. `call_conservation.smk` independently fits the neutral tree from fourfold-site alignments for GERP; it does not substitute the ROADIES tree for that estimate.

From a Linux environment with the original `workflow/Snakefile`, run `selected/run_msa_with_existing_tree.sh WORKDIR CONFIG GUIDE_TREE all` for all three stages. Use `roast` (the default) when pairwise alignment is already complete, then `conservation` after the multiple alignment. The runner does not use `-R` to force completed pairwise jobs. It has not been run on the study datasets, and the definitive guide-tree path, final species configuration, environment and MAF hashes still need recording. Check the original Snakefile's config precedence and installed Snakemake version before HPC submission.

The Fig. 2A coverage subflow begins after each `roast.maf` is available. It uses one parameterized job for all three focal references instead of duplicating the script; the supplied 93-row bamboo query/subfamily list is in `../../metadata/94sp.pop.list`. See `selected/coverage/README.md` for sample commands and the source-list caveat.

See `SCRIPT_INDEX.tsv` for every recovered file and its source.
