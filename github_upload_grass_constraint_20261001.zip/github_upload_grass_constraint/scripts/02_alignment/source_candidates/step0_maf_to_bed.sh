#!/bin/bash
#SBATCH --job-name=maf2bed
#SBATCH --partition=parallel
#SBATCH --nodes=1
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=1
#SBATCH --array=0-8
#SBATCH --output=logs/maf2bed_%A_%a.out
#SBATCH --error=logs/maf2bed_%A_%a.err

set -euo pipefail

############################################
# Parameters
############################################
MAF_FILE="Atau.Aspe.Telo.roast.maf"
REF_SPECIES="Atau"
TEMP_DIR="temp_chromosomes"
LOG_DIR="logs"

############################################
# Prepare directories
############################################
mkdir -p "$TEMP_DIR" "$LOG_DIR"

############################################
# Detect chromosomes from MAF (once per job)
############################################
# Important: must be deterministic & identical across array tasks
mapfile -t CHROMS < <(
  grep "^s ${REF_SPECIES}\." "$MAF_FILE" \
    | awk '{print $2}' \
    | sed "s/^${REF_SPECIES}\.//" \
    | sort -u
)

NCHR=${#CHROMS[@]}

if [ "$SLURM_ARRAY_TASK_ID" -ge "$NCHR" ]; then
  echo "[INFO] Task ID ${SLURM_ARRAY_TASK_ID} exceeds chromosome count (${NCHR}), exiting."
  exit 0
fi

CHROM="${CHROMS[$SLURM_ARRAY_TASK_ID]}"
OUT_BED="${TEMP_DIR}/${CHROM}.bed"

############################################
# Run maf_to_bed
############################################
echo "[INFO] Job ${SLURM_JOB_ID}, task ${SLURM_ARRAY_TASK_ID}"
echo "[INFO] Processing chromosome: ${CHROM}"
echo "[INFO] MAF: ${MAF_FILE}"
echo "[INFO] Reference species: ${REF_SPECIES}"

./maf_to_bed.py \
  -i "$MAF_FILE" \
  -r "$REF_SPECIES" \
  -c "$CHROM" \
  > "$OUT_BED"

############################################
# Post-check
############################################
if [ ! -s "$OUT_BED" ]; then
  echo "[WARN] Empty BED produced for ${CHROM}, removing file."
  rm -f "$OUT_BED"
  exit 0
fi

echo "[INFO] BED generated for ${CHROM}"
echo "[INFO] Lines: $(wc -l < "$OUT_BED")"
echo "[INFO] File size: $(du -h "$OUT_BED" | cut -f1)"

echo "[DONE] ${CHROM}"
