# 文件：plot_grouped_coverage_final.R
library(ggplot2)
library(dplyr)
library(scales)

# 数据准备部分保持不变
class_data <- read.table("94sp.pop.list", header=F, col.names=c("Species", "Subfamily"))
cov_data <- read.delim("sorted_coverage.tsv", header=T)
plot_data <- class_data %>% 
  left_join(cov_data, by="Species") %>%
  mutate(Species = factor(Species, levels=unique(class_data$Species)))

subfamily_colors <- c(
  "Bambusoideae" = "#1f77b4", 
  "Oryzoideae" = "#ff7f0e",
  "Pooideae" = "#2ca02c",
  "Arundinoideae" = "#d62728",
  "Chloridoideae" = "#9467bd",
  "Panicoideae" = "#8c564b",
  "Anomochlooideae" = "#e377c2",
  "Pharoideae" = "#7f7f7f"
)

# 更新绘图主体
ggplot(plot_data, aes(x=Species, y=ObsCoverage, fill=Subfamily)) +
  geom_col(width=0.7, color=NA) +
  scale_fill_manual(values=subfamily_colors) +
  scale_y_continuous(expand=c(0,0), 
                     limits=c(0,80),  # 设置Y轴最大80%
                     breaks=seq(0,80,20),
                     labels=percent_format(scale=1)) +
  labs(title="Comparative Coverage by Subfamily",
       y="Observed Coverage (%)") +
  theme(
    # 坐标轴样式
    axis.line = element_line(color="black", linewidth=0.3),
    axis.ticks.x = element_line(color="black", linewidth=0.3),
    axis.ticks.length.x = unit(0.5, "mm"),  # 向外延伸的刻度线
    axis.text.x = element_text(angle=90, vjust=0.5, hjust=1, 
                               size=5, color="black"),
    
    # 网格线设置
    panel.grid.major.y = element_line(color="grey90", linewidth=0.2),
    panel.grid.minor.y = element_line(color="grey95", linewidth=0.1),
    
    # 面板边框
    panel.border = element_rect(color="black", fill=NA, linewidth=0.5),
    
    # 其他主题设置保持不变
    panel.background = element_rect(fill="white", colour=NA),
    plot.background = element_rect(fill="white", colour="black", linewidth=0.5),
    legend.key.size = unit(3, "mm"),
    legend.text = element_text(size=6),
    # ... 其他theme参数保持原样
  ) +
  guides(fill=guide_legend(ncol=2))

ggsave("final_group_coverage.pdf", width=180, height=100, units="mm", dpi=300)