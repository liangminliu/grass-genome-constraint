#!/bin/bash
#SBATCH --job-name=maf_to_bed
#SBATCH --cpus-per-task=40
#SBATCH --output=maf_to_bed_%j.out
#SBATCH --error=maf_to_bed_%j.err
#SBATCH --partition=parallel

# Script to convert MAF to BED format and sort the results
# 日期：2025-10-10

# 设置变量
MAF_FILE="roast.maf.gz"
REF_SPECIES="ped"  # 参考物种，必须是MAF文件中存在的物种
OUTPUT_BED="roast.wga.bed"
OUTPUT_BED_GZ="roast.wga.bed.gz"
TEMP_DIR="temp_chromosomes"

# 染色体列表（根据您之前提供的数据）
CHROMOSOMES=(
    "Ped04D" "Ped01D" "Ped03D" "Ped01C" "Ped09X" "Ped02D" "Ped03C" 
    "Ped11D" "Ped06C" "Ped06D" "Ped07D" "Ped08D" "Ped09C" "Ped05D" 
    "Ped07C" "Ped02C" "Ped04C" "Ped10C" "Ped08C" "Ped12C" "Ped05C" 
    "Ped12D" "Ped11C" "Ped10D"
)

# 记录开始时间
echo "Job started at: $(date)"
echo "Input MAF file: $MAF_FILE"
echo "Reference species: $REF_SPECIES"
echo "Number of chromosomes to process: ${#CHROMOSOMES[@]}"
echo "Chromosomes: ${CHROMOSOMES[*]}"

# 错误处理函数
error_exit() {
    echo "Error: $1" >&2
    echo "Job failed at: $(date)" >&2
    exit 1
}


# 3. 创建临时目录
echo "Step 1: Creating temporary directory..."
mkdir -p "$TEMP_DIR" || error_exit "Failed to create temporary directory"


#gzip -c /gpfs/hpc/home/kib_unit/lidezhu/liuliangmin/2.msa/84sp_ped/94sp_ped_results/roast/roast.maf > roast.maf.gz

# 4. 对每个染色体运行maf_to_bed.py
echo "Step 2: Converting MAF to BED for each chromosome..."
SUCCESSFUL_CHROMS=()
FAILED_CHROMS=()

for CHROM in "${CHROMOSOMES[@]}"; do
    echo "Processing chromosome: $CHROM"
    CHROM_BED="$TEMP_DIR/${CHROM}.bed"
    
    # 运行maf_to_bed.py转换（使用正确的参数格式）
   ./maf_to_bed.py \
        -i "$MAF_FILE" \
        -r "$REF_SPECIES" \
        -c "$CHROM" > "$CHROM_BED" 2>> maf_to_bed_chrom_errors.log
    
    # 检查转换是否成功
    if [ $? -eq 0 ]; then
        # 检查输出文件是否为空
        if [ -s "$CHROM_BED" ]; then
            echo "✓ Chromosome $CHROM converted successfully"
            SUCCESSFUL_CHROMS+=("$CHROM")
            
            # 显示染色体文件信息
            echo "  File size: $(du -h $CHROM_BED | cut -f1), Lines: $(wc -l < $CHROM_BED)"
            
            # 显示前2行作为验证
            echo "  First 2 lines:"
            head -n 2 "$CHROM_BED" | sed 's/^/    /'
        else
            echo "⚠ Chromosome $CHROM produced empty output, removing file"
            rm -f "$CHROM_BED"
            FAILED_CHROMS+=("$CHROM")
        fi
    else
        echo "✗ Chromosome $CHROM conversion failed"
        rm -f "$CHROM_BED"
        FAILED_CHROMS+=("$CHROM")
    fi
done

# 5. 检查是否有成功的转换
echo "Step 3: Summary of chromosome processing:"
echo "  Successful: ${#SUCCESSFUL_CHROMS[@]} chromosomes"
echo "  Failed: ${#FAILED_CHROMS[@]} chromosomes"

if [ ${#SUCCESSFUL_CHROMS[@]} -eq 0 ]; then
    error_exit "No chromosomes were successfully converted"
fi

# 6. 合并所有成功的染色体BED文件
echo "Step 4: Merging successful chromosome BED files..."
# 创建合并文件
cat "$TEMP_DIR"/*.bed > "$OUTPUT_BED.unsorted" || error_exit "Failed to merge BED files"

# 7. 对合并的BED文件进行排序
echo "Step 5: Sorting BED file..."
sort -k1,1 -k2,2n "$OUTPUT_BED.unsorted" > "$OUTPUT_BED" || error_exit "Failed to sort BED file"

# 8. 可选：压缩和索引（如果需要）
echo "Step 6: Compressing and indexing BED file..."
# 压缩BED文件
bgzip -c "$OUTPUT_BED" > "$OUTPUT_BED_GZ" || echo "Warning: bgzip compression failed, continuing with uncompressed file"

# 如果压缩成功，创建tabix索引
if [ -f "$OUTPUT_BED_GZ" ]; then
    tabix -p bed "$OUTPUT_BED_GZ" || echo "Warning: tabix indexing failed"
    echo "Compressed and indexed file created: $OUTPUT_BED_GZ"
fi

# 9. 清理临时文件
echo "Step 7: Cleaning up temporary files..."
rm -f "$OUTPUT_BED.unsorted"
rm -rf "$TEMP_DIR"

# 10. 验证最终输出
echo "Step 8: Validating final output..."
if [ ! -s "$OUTPUT_BED" ]; then
    error_exit "Final BED file is empty"
fi

# 记录结束时间和文件信息
echo "Job finished successfully at: $(date)"
echo "Output file created: $OUTPUT_BED"
if [ -f "$OUTPUT_BED_GZ" ]; then
    echo "Compressed file created: $OUTPUT_BED_GZ"
fi
echo "Final file size: $(du -h $OUTPUT_BED | cut -f1)"
echo "Total lines in final BED: $(wc -l < $OUTPUT_BED)"

# 显示染色体统计
echo "Chromosome distribution in final BED file:"
cut -f1 "$OUTPUT_BED" | sort | uniq -c | sort -k1,1nr

# 显示前几行输出作为验证
echo "First 3 lines of sorted BED file:"
head -n 3 "$OUTPUT_BED"

# 显示处理统计
echo "Processing statistics:"
echo "  Total chromosomes attempted: ${#CHROMOSOMES[@]}"
echo "  Successfully processed: ${#SUCCESSFUL_CHROMS[@]}"
echo "  Failed to process: ${#FAILED_CHROMS[@]}"

if [ ${#FAILED_CHROMS[@]} -gt 0 ]; then
    echo "  Failed chromosomes: ${FAILED_CHROMS[*]}"
fi

echo "All steps completed successfully!"

# 11. 显示WGAbed格式说明
echo ""
echo "WGAbed format description:"
echo "Column 0: chromosome - The chromosome in the reference species genome"
echo "Column 1: start position - 0-based start position for the site in the reference species genome"
echo "Column 2: end position - 0-based end position (end of range) in the reference species genome"
echo "Column 3: strand - The strand for the reference species sequence"
echo "Column 4: species - A comma delimited list of species in the alignment"
echo "Column 5: aligned chromosomes - A comma delimited list of chromosomes aligned at the position for each species"
echo "Column 6: aligned positions - 0-based positions for all species"
echo "Column 7: sequences - The nucleotides aligned at the position in each species"
echo "Column 8: strands - The strands for the nucleotides listed in the sequences column"
echo "Column 9: score - The score for the MAF alignment block the position is in"

exit 0