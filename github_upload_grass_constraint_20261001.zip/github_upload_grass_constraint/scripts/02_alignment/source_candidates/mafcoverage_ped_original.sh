#!/bin/bash
#SBATCH --job-name=maf_coverage     # 作业名称
#SBATCH --output=logs/coverage_%A_%a.out  # 标准输出日志
#SBATCH --error=logs/coverage_%A_%a.err   # 错误日志
#SBATCH --array=1-94               # 创建94个数组任务
#SBATCH --ntasks=1                 # 每个任务单进程
#SBATCH --cpus-per-task=1          # 每个任务1核
#SBATCH --time=02:00:00            # 最大运行时间


# File: submit_coverage.sbatch
# 设置关键路径
MAF_FILE="./roast.maf"
SPECIES_LIST="94sp.list"
REF_SPECIES="ped*"

# 根据数组索引获取目标物种
TARGET_SPECIES=$(sed -n "${SLURM_ARRAY_TASK_ID}p" $SPECIES_LIST)
TARGET="${TARGET_SPECIES}*"  # 添加通配符

# 执行覆盖度计算
echo "Processing ${TARGET_SPECIES} (Task ${SLURM_ARRAY_TASK_ID})"
mafPairCoverage \
  --maf $MAF_FILE \
  --seq1 $REF_SPECIES \
  --seq2 $TARGET \
  --bin_length 5000 > mafPairCoverage_results/${TARGET_SPECIES}.tsv 2> logs/${TARGET_SPECIES}.log

# 检查执行状态
if [ $? -eq 0 ]; then
  echo "${TARGET_SPECIES} completed successfully"
else
  echo "${TARGET_SPECIES} failed with exit code $?"
  exit 1
fi