#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import pandas as pd
import matplotlib.pyplot as plt

# =====================================================
# Global style (keep consistent with your reference)
# =====================================================
plt.rcParams['font.family'] = 'Arial'

# =====================================================
# Input files
# =====================================================
files = {
    "P.edulis": {
        "file": "subgenome_coverage_values.tsv",
        "col": "All"
    },
    "Z.mays": {
        "file": "Zmay_coverage_values_all.tsv",
        "col": "All"
    },
    "A.tauschii": {
        "file": "Atau_coverage_values_all.tsv",
        "col": "All"
    }
}

# Line styles (publication-safe grayscale)
styles = {
    "P.edulis": dict(color="#404040", marker="o"),
    "Z.mays": dict(color="#6A6A6A", marker="s"),
    "A.tauschii": dict(color="#9A9A9A", marker="^")
}

# =====================================================
# Read data
# =====================================================
data = {}

for sp, info in files.items():
    df = pd.read_csv(info["file"], sep="\t")
    df.columns = df.columns.str.strip()
    data[sp] = df[["k", info["col"]]]

# =====================================================
# Plot
# =====================================================
plt.figure(figsize=(10, 6))

for sp in ["P.edulis", "Z.mays", "A.tauschii"]:
    df = data[sp]
    plt.plot(
        df["k"],
        df.iloc[:, 1],
        linestyle='-',
        linewidth=1,
        marker=styles[sp]["marker"],
        markersize=3,
        color=styles[sp]["color"],
        alpha=0.9,
        label=sp
    )

# =====================================================
# Axes & grid
# =====================================================
plt.xlabel("Minimum Number of Aligned Species (k)", fontsize=14)
plt.ylabel("Cumulative Alignment Proportion (%)", fontsize=14)

max_k = max(df["k"].max() for df in data.values())
xticks = list(range(10, int(max_k) + 1, 10))
plt.xticks(xticks)

plt.ylim(0, 100)
plt.grid(True, linestyle=":", alpha=0.3)

# =====================================================
# Legend
# =====================================================
plt.legend(
    frameon=False,
    fontsize=12,
    loc="upper right"
)

plt.tight_layout()

# =====================================================
# Output
# =====================================================
out_pdf = "three_species_alignment_coverage.pdf"
plt.savefig(out_pdf, dpi=300, bbox_inches="tight")
plt.show()

print(f"Figure saved to {out_pdf}")
