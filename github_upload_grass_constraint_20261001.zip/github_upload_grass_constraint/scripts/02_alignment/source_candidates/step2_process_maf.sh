#!/bin/bash
#SBATCH --job-name=maf_processing
#SBATCH --output=maf_processing_%j.out
#SBATCH --error=maf_processing_%j.err
#SBATCH --nodes=1
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=40

# 步骤1：VCF转BED（坐标转换）
echo "步骤1：坐标转换"
#awk '{print $1"\t"$2+1"\t"$3+1}' 63sp.filtered.bi-allelic.snp.renamed.bed > 63sp.bed

# 步骤2：提取外类群等位基因
echo "步骤2：提取MAF区域"
#/gpfs/hpc/home/kib_unit/lidezhu/biosoftware/mafsInRegion 63sp.bed outgroup.maf roast.maf

# 步骤3：格式转换
# 步骤3：按比对块处理MAF文件
echo "步骤3：按比对块处理MAF数据"

awk '
BEGIN {
    ped_allele = ""
    alu_allele = "N"
    hca_allele = "N"
    block_count = 0
}

/^a/ {
    if (ped_allele != "") {
        print ped_allele "\t" alu_allele "\t" hca_allele
    }
    ped_allele = ""
    alu_allele = "N"
    hca_allele = "N"
    block_count++
}

/^s/ {
    if ($2 == "ped.Ped01C") {
        ped_allele = $7
    }
    else if ($2 == "Alu.Alu06C") {
        alu_allele = $7
    }
    else if ($2 == "Hca.Hca01C") {
        hca_allele = $7
    }
}

END {
    if (ped_allele != "") {
        print ped_allele "\t" alu_allele "\t" hca_allele
    }
    print "处理了 " block_count " 个比对块" > "/dev/stderr"
}
' outgroup.maf > outgroup.allele

echo "处理完成！输出文件：outgroup.allele"
echo "格式：ped等位基因\tAlu等位基因\tHca等位基因"
echo "缺失数据用'N'表示"