#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import glob
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

plt.rcParams['font.family'] = 'Arial'

# 1. 收集所有 .bed 文件
bed_files = sorted(glob.glob('*.bed'))
if not bed_files:
    raise SystemExit("Error: 当前目录下未找到任何 .bed 文件")

print("Found bed files:", bed_files)

# 2. 读取所有文件中的 k 值（假设 k 在第 6 列，跳过 header）
all_k = []
for fn in bed_files:
    df = pd.read_csv(fn,
                     sep='\t',
                     usecols=[5],
                     names=['k'],
                     header=None,
                     skiprows=1)
    all_k.extend(df['k'].tolist())

if len(all_k) == 0:
    raise SystemExit("Error: 没有在任何 .bed 文件中读到 k 值")

# 3. 计算累计百分比函数
def cumulative_pct(arr):
    s = pd.Series(arr)
    total = len(s)
    max_k = int(s.max())
    pct = np.array([s.ge(k).sum() / total * 100
                    for k in range(1, max_k + 1)])
    return pct, max_k

p_all, max_k = cumulative_pct(all_k)

# 4. 构建 DataFrame 并保存中间结果
ks = np.arange(1, max_k + 1)
df_cov = pd.DataFrame({'k': ks, 'All': p_all})
df_cov.to_csv('coverage_values_all.tsv', sep='\t', index=False)
print("Saved intermediate coverage values to coverage_values_all.tsv")

# 5. 作图
plt.figure(figsize=(10, 6))
plt.plot(ks, df_cov['All'],
         linestyle='-',
         linewidth=1,
         marker='o',
         markersize=3,
         color='#404040',
         alpha=0.9)

plt.xlabel('Minimum Number of Aligned Species (k)', fontsize=14)
plt.ylabel('Cumulative Alignment Proportion (%)', fontsize=14)

# 设置 x 轴刻度：每 10 一档
xt = list(range(10, max_k, 10))
plt.xticks(xt)

plt.ylim(0, 100)
plt.grid(True, linestyle=':', alpha=0.3)
# 不显示图例，故删除 plt.legend(...) 

plt.tight_layout()
out_pdf = 'all_chromosomes_coverage_no_legend.pdf'
plt.savefig(out_pdf, dpi=300, bbox_inches='tight')
print(f"Figure saved to {out_pdf}")
plt.show()

# 6. 输出检查信息
print(f"Total segments: {len(all_k)}")
print(f"Maximum k: {max_k}")