#!/bin/bash
# 数据提取脚本：extract_coverage.sh

# 初始化结果文件
echo -e "Species\tObsCoverage" > all_species_coverage.tsv

# 遍历所有结果文件
for f in mafPairCoverage_results/*.tsv; do
  # 提取物种名称
  species=$(basename ${f%.tsv})
  
  # 提取ped*行的ObsCoverage值（第6列）
  obs_cov=$(awk '/^[[:space:]]+ped\*/ {printf "%.4f", $6*100}' $f)
  
  # 写入汇总文件
  echo -e "$species\t$obs_cov" >> all_species_coverage.tsv
done

# 排序数据
sort -t$'\t' -k2,2n all_species_coverage.tsv > sorted_coverage.tsv