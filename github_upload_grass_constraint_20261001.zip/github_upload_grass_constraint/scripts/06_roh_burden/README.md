# ROH, FROH and individual burden

Methods: PLINK v1.9 ROH, minimum 100 kb and 50 SNPs; four ROH length classes; FROH equals total ROH length divided by an explicitly supplied species reference length. Individual GERP >4 burden uses ALT dosage, with 0/1/2 contributions; associations with FROH use two-sided Pearson correlations. Results: Fig. 6, S8 and Tables S3/S6.

| Order | Selected script | Role |
|---|---|---|
| 1 | `selected/ped/run_roh_froh.sh`, `selected/teosinte/run_roh_froh.sh`, `selected/atau/run_roh_froh.sh` | author-supplied final species ROH calling, four-class assignment and FROH calculation |
| 2 | `selected/figure_revision/prepare_inputs.py`, `selected/figure_revision/recompute_and_plot.R` | corrected Fig. 6/S8 preparation from final tables |
| 3 | `selected/01_compute_Ped_GERP_fullgenome.py`, `selected/01_compute_Teosinte_GERP_unpolarized.py`, `selected/03_calc_GERP_burden_ROH.py` | separate individual burden candidate calculations |

The three newly supplied final scripts reuse filtered VCF/PLINK data, call PLINK ROH, classify segments, and compute total and class-specific FROH from `Lauto.from_filtered_SNPs.tsv`. Bamboo can construct that denominator from the first-to-last filtered SNP span on chromosomes 1–24; the other two scripts require an existing denominator file. *A. tauschii* excludes `BW_01192` by default, producing the intended 140-sample analysis from the 141-sample input if that ID is present. The scripts require `plink`, `bcftools` for bamboo and Python/pandas. Their HPC `WORKDIR` must be set for another installation. They were supplied as final calculation scripts by the author; their outputs were not rerun here.

**Executed command parameters in all three supplied scripts:** `--homozyg-kb 100`, `--homozyg-gap 100`, `--homozyg-window-missing 5`, `--homozyg-snp 50`, `--homozyg-density 50`, `--homozyg-window-snp 50`, `--homozyg-window-het 1`, and `--homozyg-window-threshold 0.05`. The pasted originals contain stale `gap1000` comments/output tags despite executing gap100; cleaned release copies correct those labels and remove redundant deletion of old ROH outputs. Originals remain unchanged in `source_candidates/*_user_supplied_original.txt`. The new scripts do not explicitly pass `--homozyg-het 1`, which is stated in Methods; confirm the PLINK default or final log before asserting exact parameter equivalence. Earlier window-missing-10 scripts remain under `source_candidates/` as alternate runs. The corrected Fig. 6/S8 scripts begin from final individual tables and do not rerun VCF/PLINK.

See `SCRIPT_INDEX.tsv` for every recovered file and its source.
