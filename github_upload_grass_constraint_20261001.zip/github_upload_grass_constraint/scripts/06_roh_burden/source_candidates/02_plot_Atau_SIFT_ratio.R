#!/usr/bin/env Rscript

suppressPackageStartupMessages({
  library(ggplot2)
  library(patchwork)
  library(scales)
})

args <- commandArgs(trailingOnly = TRUE)

if (length(args) < 2) {
  stop(
    "Usage:\n",
    "Rscript 02_plot_Atau_SIFT_ratio.R <RESULT_DIR> <PREFIX> [exclude_samples|none] [sift_cutoff]\n"
  )
}

RESULT_DIR <- args[1]
PREFIX <- args[2]
EXCLUDE_RAW <- ifelse(length(args) >= 3, args[3], "none")
SIFT_CUTOFF <- ifelse(length(args) >= 4, as.numeric(args[4]), 0.05)
if (is.na(SIFT_CUTOFF)) SIFT_CUTOFF <- 0.05

EXCLUDE_SAMPLES <- character(0)
if (!tolower(EXCLUDE_RAW) %in% c("none", "null", "na", "")) {
  EXCLUDE_SAMPLES <- unlist(strsplit(EXCLUDE_RAW, "[,; ]+"))
  EXCLUDE_SAMPLES <- EXCLUDE_SAMPLES[EXCLUDE_SAMPLES != ""]
}

FILE_SITE_AF <- file.path(RESULT_DIR, paste0(PREFIX, ".site_AF.tsv"))
FILE_SAMPLE  <- file.path(RESULT_DIR, paste0(PREFIX, ".per_sample_burden.tsv"))

read_tsv <- function(file) {
  if (!file.exists(file)) stop("[ERROR] Missing file: ", file)

  if (requireNamespace("data.table", quietly = TRUE)) {
    df <- data.table::fread(
      file,
      sep = "\t",
      header = TRUE,
      data.table = FALSE,
      quote = "",
      showProgress = FALSE
    )
  } else {
    df <- read.delim(
      file,
      header = TRUE,
      sep = "\t",
      quote = "",
      comment.char = "",
      check.names = FALSE,
      stringsAsFactors = FALSE
    )
  }

  names(df) <- trimws(names(df))
  df
}

need_cols <- function(df, cols, label) {
  miss <- setdiff(cols, names(df))
  if (length(miss) > 0) {
    stop(
      "[ERROR] Missing columns in ", label, ": ",
      paste(miss, collapse = ", "),
      "\n[HEADER] ", paste(names(df), collapse = " | ")
    )
  }
}

as_num <- function(x) {
  if (is.numeric(x)) return(as.numeric(x))
  x <- gsub(",", "", as.character(x))
  x <- gsub("%", "", x)
  suppressWarnings(as.numeric(x))
}

safe_ratio <- function(num, den) {
  num <- as_num(num)
  den <- as_num(den)
  out <- rep(NA_real_, length(num))
  ok <- is.finite(num) & is.finite(den) & den > 0
  out[ok] <- num[ok] / den[ok]
  out
}

fmt_p <- function(p) {
  if (!is.finite(p)) return("p = NA")
  if (p < 0.001) return("p < 0.001")
  paste0("p = ", formatC(p, format = "f", digits = 3))
}

cor_stats <- function(df, x, y, method = "spearman") {
  xx <- as_num(df[[x]])
  yy <- as_num(df[[y]])
  ok <- is.finite(xx) & is.finite(yy)

  if (sum(ok) < 4 || length(unique(xx[ok])) < 2 || length(unique(yy[ok])) < 2) {
    return(data.frame(n = sum(ok), rho = NA_real_, p_value = NA_real_))
  }

  ct <- suppressWarnings(cor.test(xx[ok], yy[ok], method = method, exact = FALSE))
  data.frame(n = sum(ok), rho = unname(ct$estimate), p_value = ct$p.value)
}

theme_ref <- function(base_size = 9.5) {
  theme_classic(base_size = base_size) +
    theme(
      axis.text = element_text(color = "black", size = base_size),
      axis.title = element_text(color = "black", size = base_size + 0.5),
      axis.line = element_line(linewidth = 0.35, color = "grey45"),
      axis.ticks = element_line(linewidth = 0.3, color = "grey45"),
      panel.grid.major.y = element_line(linewidth = 0.25, color = "grey92"),
      panel.grid.major.x = element_blank(),
      panel.grid.minor = element_blank(),
      plot.title = element_text(hjust = 0.5, face = "bold", size = base_size + 2),
      plot.subtitle = element_text(hjust = 0.5, face = "bold", size = base_size + 1),
      plot.tag = element_text(face = "bold", size = base_size + 2),
      plot.tag.position = c(0.01, 0.99),
      legend.title = element_blank(),
      legend.background = element_blank(),
      legend.key.size = unit(0.35, "cm"),
      legend.text = element_text(size = base_size - 1),
      plot.margin = margin(4, 5, 4, 5)
    )
}

save_pdf_png <- function(plot, stem, width, height) {
  pdf_file <- file.path(RESULT_DIR, paste0(PREFIX, ".", stem, ".pdf"))
  png_file <- file.path(RESULT_DIR, paste0(PREFIX, ".", stem, ".png"))

  pdf_dev <- if (capabilities("cairo")) grDevices::cairo_pdf else grDevices::pdf

  ggsave(pdf_file, plot, width = width, height = height, units = "in", device = pdf_dev)
  ggsave(png_file, plot, width = width, height = height, units = "in", dpi = 600)

  message("[WRITE] ", pdf_file)
  message("[WRITE] ", png_file)
}

# ============================================================
# Colors
# ============================================================
COL_SYN    <- "#D0D0D0"
COL_TOL    <- "#DCEAF6"
COL_DEL    <- "#5A8DB8"

COL_TOTAL  <- "#DCEAF6"
COL_HOM    <- "#4F81BD"
COL_HET    <- "#A8C9E8"

COL_HET2   <- "#4F81BD"
COL_HOM2   <- "#D9796B"

COL_ROH    <- "#E0A34A"
COL_NONROH <- "#8172B2"

# ============================================================
# Load data
# ============================================================
message("[INFO] Load: ", FILE_SITE_AF)
message("[INFO] Load: ", FILE_SAMPLE)

site_af <- read_tsv(FILE_SITE_AF)
sample_burden <- read_tsv(FILE_SAMPLE)

need_cols(site_af, c("AF", "class_label"), "site_AF.tsv")
need_cols(
  sample_burden,
  c(
    "sample", "FROH", "region", "variant_class", "class_label",
    "called_sites", "alt_dosage", "het_loci", "hom_alt_loci"
  ),
  "per_sample_burden.tsv"
)

site_af$AF <- as_num(site_af$AF)
site_af <- site_af[is.finite(site_af$AF), , drop = FALSE]
site_af$AF <- pmax(0, pmin(1, site_af$AF))

sample_burden <- sample_burden[!sample_burden$sample %in% EXCLUDE_SAMPLES, , drop = FALSE]
sample_burden$FROH <- as_num(sample_burden$FROH)
sample_burden$called_sites <- as_num(sample_burden$called_sites)
sample_burden$alt_dosage <- as_num(sample_burden$alt_dosage)
sample_burden$het_loci <- as_num(sample_burden$het_loci)
sample_burden$hom_alt_loci <- as_num(sample_burden$hom_alt_loci)

# ============================================================
# A: AF spectrum
# ============================================================
make_af_summary <- function(df, class_map, class_levels, binwidth = 0.05) {
  df$class_plot <- class_map[df$class_label]
  df <- df[!is.na(df$class_plot), , drop = FALSE]
  df$class_plot <- factor(df$class_plot, levels = class_levels)

  n_bins <- round(1 / binwidth)
  df$bin_i <- floor(df$AF / binwidth + 1e-10)
  df$bin_i[df$AF >= 1] <- n_bins - 1
  df$bin_i <- pmax(0, pmin(df$bin_i, n_bins - 1))

  tab <- aggregate(
    list(n = rep(1, nrow(df))),
    by = list(class_plot = df$class_plot, bin_i = df$bin_i),
    FUN = sum
  )
  tab$percentage <- ave(tab$n, tab$class_plot, FUN = function(z) 100 * z / sum(z))

  grid <- expand.grid(
    class_plot = factor(class_levels, levels = class_levels),
    bin_i = 0:(n_bins - 1)
  )

  out <- merge(
    grid,
    tab[, c("class_plot", "bin_i", "percentage")],
    by = c("class_plot", "bin_i"),
    all.x = TRUE,
    sort = FALSE
  )

  out$percentage[is.na(out$percentage)] <- 0
  out$class_id <- as.numeric(out$class_plot) - 1
  k <- length(class_levels)
  out$bin_left <- out$bin_i * binwidth
  out$xmin <- out$bin_left + out$class_id * binwidth / k
  out$xmax <- out$bin_left + (out$class_id + 1) * binwidth / k
  out
}

plot_af <- function(af_sum, fill_values, title_text, tag_text = NULL) {
  # 关键修改：让柱子离 X 轴有一段距离
  y_gap <- 2

  ggplot(af_sum) +
    geom_rect(
      aes(xmin = xmin, xmax = xmax, ymin = 0, ymax = percentage, fill = class_plot),
      colour = NA
    ) +
    scale_fill_manual(values = fill_values, drop = FALSE) +
    scale_x_continuous(
      breaks = seq(0, 1, 0.25),
      limits = c(-0.02, 1),
      expand = c(0, 0)
    ) +
    scale_y_continuous(
      breaks = seq(0, 80, 20),
      limits = c(-y_gap, 72),
      expand = c(0, 0)
    ) +
    coord_cartesian(clip = "off") +
    labs(
      title = title_text,
      tag = tag_text,
      x = "ALT allele frequency",
      y = "Percentage of SNPs"
    ) +
    theme_ref(9.5) +
    theme(
      legend.position = c(0.77, 0.92),
      legend.justification = c(0.5, 1),
      legend.direction = "horizontal",
      legend.text = element_text(size = 8),
      plot.title = element_text(hjust = 0.5, face = "plain", size = 12)
    )
}

class_map_main <- c(
  "Tolerated nonsynonymous" = "Tolerated\nnonsynonymous",
  "Deleterious nonsynonymous" = "Deleterious\nnonsynonymous"
)

af_main <- make_af_summary(
  site_af,
  class_map = class_map_main,
  class_levels = c("Tolerated\nnonsynonymous", "Deleterious\nnonsynonymous"),
  binwidth = 0.05
)

pA <- plot_af(
  af_main,
  fill_values = c(
    "Tolerated\nnonsynonymous" = COL_TOL,
    "Deleterious\nnonsynonymous" = COL_DEL
  ),
  title_text = "Deleterious vs tolerated",
  tag_text = "A"
)

class_map_sup <- c(
  "Synonymous" = "Synonymous",
  "Tolerated nonsynonymous" = "Tolerated\nnonsynonymous",
  "Deleterious nonsynonymous" = "Deleterious\nnonsynonymous"
)

af_sup <- make_af_summary(
  site_af,
  class_map = class_map_sup,
  class_levels = c("Synonymous", "Tolerated\nnonsynonymous", "Deleterious\nnonsynonymous"),
  binwidth = 0.05
)

pA_sup <- plot_af(
  af_sup,
  fill_values = c(
    "Synonymous" = COL_SYN,
    "Tolerated\nnonsynonymous" = COL_TOL,
    "Deleterious\nnonsynonymous" = COL_DEL
  ),
  title_text = "Synonymous, tolerated and deleterious",
  tag_text = NULL
)

# ============================================================
# Wide table by class and region
# ============================================================
make_class_df <- function(dat, region_name, class_name, prefix) {
  x <- dat[
    dat$region == region_name & dat$class_label == class_name,
    c("sample", "FROH", "called_sites", "alt_dosage", "het_loci", "hom_alt_loci"),
    drop = FALSE
  ]

  names(x)[names(x) == "called_sites"] <- paste0(prefix, "_called_sites")
  names(x)[names(x) == "alt_dosage"] <- paste0(prefix, "_total")
  names(x)[names(x) == "het_loci"] <- paste0(prefix, "_het")
  names(x)[names(x) == "hom_alt_loci"] <- paste0(prefix, "_hom")

  x
}

merge3 <- function(a, b, c) {
  x <- merge(a, b, by = c("sample", "FROH"), all = TRUE)
  x <- merge(x, c, by = c("sample", "FROH"), all = TRUE)
  x
}

ALL <- merge3(
  make_class_df(sample_burden, "ALL", "Synonymous", "syn"),
  make_class_df(sample_burden, "ALL", "Tolerated nonsynonymous", "tol"),
  make_class_df(sample_burden, "ALL", "Deleterious nonsynonymous", "del")
)

ROH <- merge3(
  make_class_df(sample_burden, "ROH", "Synonymous", "syn"),
  make_class_df(sample_burden, "ROH", "Tolerated nonsynonymous", "tol"),
  make_class_df(sample_burden, "ROH", "Deleterious nonsynonymous", "del")
)

NONROH <- merge3(
  make_class_df(sample_burden, "Non-ROH", "Synonymous", "syn"),
  make_class_df(sample_burden, "Non-ROH", "Tolerated nonsynonymous", "tol"),
  make_class_df(sample_burden, "Non-ROH", "Deleterious nonsynonymous", "del")
)

count_cols <- grep("_(called_sites|total|het|hom)$", names(ALL), value = TRUE)
for (cc in count_cols) ALL[[cc]][is.na(ALL[[cc]])] <- 0

count_cols <- grep("_(called_sites|total|het|hom)$", names(ROH), value = TRUE)
for (cc in count_cols) ROH[[cc]][is.na(ROH[[cc]])] <- 0

count_cols <- grep("_(called_sites|total|het|hom)$", names(NONROH), value = TRUE)
for (cc in count_cols) NONROH[[cc]][is.na(NONROH[[cc]])] <- 0

ALL$del_load_total <- safe_ratio(ALL$del_total, ALL$del_called_sites)
ALL$del_load_hom <- safe_ratio(ALL$del_hom, ALL$del_called_sites)
ALL$del_load_het <- safe_ratio(ALL$del_het, ALL$del_called_sites)

ALL$del_syn_ratio_het <- safe_ratio(ALL$del_het, ALL$syn_het)
ALL$del_syn_ratio_hom <- safe_ratio(ALL$del_hom, ALL$syn_hom)
ALL$tol_syn_ratio_het <- safe_ratio(ALL$tol_het, ALL$syn_het)
ALL$tol_syn_ratio_hom <- safe_ratio(ALL$tol_hom, ALL$syn_hom)

ROH$del_syn_ratio_hom <- safe_ratio(ROH$del_hom, ROH$syn_hom)
ROH$tol_syn_ratio_hom <- safe_ratio(ROH$tol_hom, ROH$syn_hom)

NONROH$del_syn_ratio_hom <- safe_ratio(NONROH$del_hom, NONROH$syn_hom)
NONROH$tol_syn_ratio_hom <- safe_ratio(NONROH$tol_hom, NONROH$syn_hom)

# ============================================================
# B/C histograms
# ============================================================
make_hist_panel <- function(df, xcol, tag_text, title_txt, fill_col, line_col) {
  x <- as_num(df[[xcol]])
  x <- x[is.finite(x)]
  med <- stats::median(x, na.rm = TRUE)
  n0 <- sum(x == 0, na.rm = TRUE)
  nall <- length(x)

  ggplot(data.frame(x = x), aes(x = x)) +
    geom_histogram(fill = fill_col, colour = "grey55", bins = 20, linewidth = 0.25) +
    geom_vline(xintercept = med, linetype = "dashed", colour = line_col, linewidth = 0.55) +
    annotate(
      "text",
      x = Inf,
      y = Inf,
      label = paste0("median = ", format(round(med), big.mark = ","), "\nzero = ", n0, "/", nall),
      hjust = 1.05,
      vjust = 1.1,
      size = 3.0
    ) +
    labs(
      tag = tag_text,
      title = title_txt,
      x = paste0("Number of deleterious loci (SIFT < ", SIFT_CUTOFF, ")"),
      y = "Number of individuals"
    ) +
    theme_ref(9.5) +
    theme(
      plot.title = element_text(hjust = 0.5, face = "bold", size = 12)
    )
}

pB <- make_hist_panel(ALL, "del_het", "B", "Heterozygotes", COL_TOL, COL_TOL)
pC <- make_hist_panel(ALL, "del_hom", "C", "Homozygotes", COL_DEL, COL_DEL)

# ============================================================
# D/E scatter with total/hom/het
# ============================================================
make_multiline_scatter <- function(df, ycols, ylabels, colors, tag_text, title_txt, ylab_txt) {
  dd <- do.call(rbind, lapply(seq_along(ycols), function(i) {
    data.frame(
      sample = df$sample,
      FROH = df$FROH,
      value = as_num(df[[ycols[i]]]),
      series = ylabels[i],
      stringsAsFactors = FALSE
    )
  }))

  dd <- dd[is.finite(dd$FROH) & is.finite(dd$value), , drop = FALSE]
  dd$series <- factor(dd$series, levels = ylabels)

  p <- ggplot(dd, aes(x = FROH, y = value, colour = series)) +
    geom_point(size = 1.6, alpha = 0.82) +
    geom_smooth(method = "lm", se = FALSE, linewidth = 0.7) +
    scale_colour_manual(values = setNames(colors, ylabels), drop = FALSE) +
    labs(
      tag = tag_text,
      title = title_txt,
      x = expression(F[ROH]),
      y = ylab_txt
    ) +
    theme_ref(9.5) +
    theme(
      legend.position = c(0.55, 1.02),
      legend.justification = c(0.5, 1),
      legend.direction = "horizontal",
      legend.text = element_text(size = 8),
      plot.title = element_text(hjust = 0.5, face = "plain", size = 11)
    )

  ann <- lapply(seq_along(ycols), function(i) {
    st <- cor_stats(df, "FROH", ycols[i])
    data.frame(
      label = paste0(ylabels[i], ": ", fmt_p(st$p_value)),
      x = min(df$FROH, na.rm = TRUE),
      y = max(dd$value, na.rm = TRUE) * (0.94 - (i - 1) * 0.07),
      col = colors[i],
      stringsAsFactors = FALSE
    )
  })
  ann <- do.call(rbind, ann)

  p +
    geom_text(
      data = ann,
      aes(x = x, y = y, label = label),
      inherit.aes = FALSE,
      hjust = 0,
      vjust = 1,
      size = 3.0,
      colour = ann$col
    )
}

pD <- make_multiline_scatter(
  ALL,
  ycols = c("del_total", "del_hom", "del_het"),
  ylabels = c("Total", "Homozygous", "Heterozygous"),
  colors = c(COL_TOTAL, COL_HOM, COL_HET),
  tag_text = "D",
  title_txt = "SIFT deleterious counts",
  ylab_txt = "Count"
)

pE <- make_multiline_scatter(
  ALL,
  ycols = c("del_load_total", "del_load_hom", "del_load_het"),
  ylabels = c("Total", "Homozygous", "Heterozygous"),
  colors = c(COL_TOTAL, COL_HOM, COL_HET),
  tag_text = "E",
  title_txt = "Standardized deleterious load",
  ylab_txt = "Load"
)

# ============================================================
# F/G ratios: het vs hom
# ============================================================
make_ratio_panel <- function(df, y_het, y_hom, tag_text, title_txt, show_y = TRUE) {
  long <- rbind(
    data.frame(sample = df$sample, FROH = df$FROH, value = as_num(df[[y_het]]), series = "Heterozygotes"),
    data.frame(sample = df$sample, FROH = df$FROH, value = as_num(df[[y_hom]]), series = "Homozygotes")
  )

  long <- long[is.finite(long$FROH) & is.finite(long$value), , drop = FALSE]
  long$series <- factor(long$series, levels = c("Heterozygotes", "Homozygotes"))

  cols <- c("Heterozygotes" = COL_HET2, "Homozygotes" = COL_HOM2)

  p <- ggplot(long, aes(x = FROH, y = value, colour = series)) +
    geom_point(size = 1.7, alpha = 0.88) +
    geom_smooth(method = "lm", se = FALSE, linewidth = 0.65, linetype = "dashed") +
    scale_colour_manual(values = cols, drop = FALSE) +
    labs(
      tag = tag_text,
      title = title_txt,
      x = expression(F[ROH]),
      y = ifelse(show_y, "Nonsynonymous / synonymous ratio", "")
    ) +
    theme_ref(9.5) +
    theme(
      legend.position = c(0.58, 1.03),
      legend.justification = c(0.5, 1),
      legend.direction = "horizontal",
      legend.text = element_text(size = 8),
      plot.title = element_text(hjust = 0.5, face = "bold", size = 11)
    )

  st_het <- cor_stats(df, "FROH", y_het)
  st_hom <- cor_stats(df, "FROH", y_hom)

  ymax <- max(long$value, na.rm = TRUE)
  xmin <- min(long$FROH, na.rm = TRUE)

  p +
    annotate(
      "text",
      x = xmin,
      y = ymax * 0.96,
      label = fmt_p(st_het$p_value),
      colour = cols["Heterozygotes"],
      hjust = 0,
      vjust = 1,
      size = 3.0
    ) +
    annotate(
      "text",
      x = xmin,
      y = ymax * 0.87,
      label = fmt_p(st_hom$p_value),
      colour = cols["Homozygotes"],
      hjust = 0,
      vjust = 1,
      size = 3.0
    )
}

pF <- make_ratio_panel(
  ALL,
  "del_syn_ratio_het",
  "del_syn_ratio_hom",
  "F",
  "Deleterious/Synonymous",
  TRUE
)

pG <- make_ratio_panel(
  ALL,
  "tol_syn_ratio_het",
  "tol_syn_ratio_hom",
  "G",
  "Tolerated/Synonymous",
  TRUE
)

# ============================================================
# H: ROH vs Non-ROH
# ============================================================
H1 <- rbind(
  data.frame(sample = ROH$sample, FROH = ROH$FROH, value = ROH$del_syn_ratio_hom, region = "ROH"),
  data.frame(sample = NONROH$sample, FROH = NONROH$FROH, value = NONROH$del_syn_ratio_hom, region = "Non-ROH")
)

H2 <- rbind(
  data.frame(sample = ROH$sample, FROH = ROH$FROH, value = ROH$tol_syn_ratio_hom, region = "ROH"),
  data.frame(sample = NONROH$sample, FROH = NONROH$FROH, value = NONROH$tol_syn_ratio_hom, region = "Non-ROH")
)

H1 <- H1[is.finite(H1$FROH) & is.finite(H1$value), , drop = FALSE]
H2 <- H2[is.finite(H2$FROH) & is.finite(H2$value), , drop = FALSE]

make_region_panel <- function(df, title_txt, tag_text = NULL, show_y = TRUE) {
  cols <- c("Non-ROH" = COL_NONROH, "ROH" = COL_ROH)

  p <- ggplot(df, aes(x = FROH, y = value, colour = region)) +
    geom_point(size = 1.6, alpha = 0.88) +
    geom_smooth(method = "lm", se = FALSE, linewidth = 0.65, linetype = "dashed") +
    scale_colour_manual(values = cols, drop = FALSE) +
    labs(
      tag = tag_text,
      title = title_txt,
      x = expression(F[ROH]),
      y = ifelse(show_y, "Nonsynonymous / synonymous ratio", "")
    ) +
    theme_ref(9.2) +
    theme(
      legend.position = "none",
      plot.title = element_text(hjust = 0.5, face = "bold", size = 10.5)
    )

  st_non <- cor_stats(df[df$region == "Non-ROH", , drop = FALSE], "FROH", "value")
  st_roh <- cor_stats(df[df$region == "ROH", , drop = FALSE], "FROH", "value")

  ymax <- max(df$value, na.rm = TRUE)
  xmin <- min(df$FROH, na.rm = TRUE)

  p +
    annotate(
      "text",
      x = xmin,
      y = ymax * 0.96,
      label = fmt_p(st_non$p_value),
      colour = cols["Non-ROH"],
      hjust = 0,
      vjust = 1,
      size = 3.0
    ) +
    annotate(
      "text",
      x = xmin,
      y = ymax * 0.87,
      label = fmt_p(st_roh$p_value),
      colour = cols["ROH"],
      hjust = 0,
      vjust = 1,
      size = 3.0
    )
}

pH1 <- make_region_panel(H1, "Deleterious/Synonymous", "H", TRUE)
pH2 <- make_region_panel(H2, "Tolerated/Synonymous", NULL, FALSE)

legend_H <- ggplot(
  data.frame(
    x = c(1, 2),
    y = c(1, 1),
    region = factor(c("Non-ROH", "ROH"), levels = c("Non-ROH", "ROH"))
  ),
  aes(x = x, y = y, colour = region)
) +
  geom_point(size = 2.2) +
  scale_colour_manual(values = c("Non-ROH" = COL_NONROH, "ROH" = COL_ROH)) +
  theme_void() +
  theme(
    legend.position = "top",
    legend.title = element_blank(),
    legend.text = element_text(size = 8),
    legend.direction = "horizontal",
    plot.margin = margin(0, 0, -6, 0)
  )

pH_body <- pH1 | pH2

pH <- legend_H / pH_body +
  plot_layout(heights = c(0.10, 1)) +
  plot_annotation(
    title = "Homozygous nonsynonymous/synonymous ratios"
  ) &
  theme(
    plot.title = element_text(hjust = 0.5, face = "bold", size = 11)
  )

# ============================================================
# Save individual panels
# ============================================================
save_pdf_png(pA, "FigA_main_two_classes", 6.10, 2.75)
save_pdf_png(pA_sup, "FigS1A_three_classes", 6.10, 2.75)
save_pdf_png(pB, "FigB_heterozygotes_hist", 2.85, 2.75)
save_pdf_png(pC, "FigC_homozygotes_hist", 2.85, 2.75)
save_pdf_png(pD, "FigD_deleterious_counts", 6.10, 2.85)
save_pdf_png(pE, "FigE_standardized_load", 6.10, 2.85)
save_pdf_png(pF, "FigF_deleterious_synonymous_ratio", 2.90, 2.90)
save_pdf_png(pG, "FigG_tolerated_synonymous_ratio", 2.90, 2.90)
save_pdf_png(pH, "FigH_region_homozygous_ratios", 6.10, 2.90)

# ============================================================
# Combined figure
# ============================================================
top_row <- pA + pB + pC +
  plot_layout(widths = c(2.35, 1.0, 1.0))

mid_row <- pD + pE +
  plot_layout(widths = c(1.0, 1.0))

bot_row <- pF + pG + pH +
  plot_layout(widths = c(1.0, 1.0, 2.35))

combined <- top_row / mid_row / bot_row +
  plot_layout(heights = c(0.92, 1.00, 1.06)) &
  theme(plot.margin = margin(3, 3, 3, 3))

save_pdf_png(combined, "FigMain_A_to_H_reference_layout", 12.40, 10.10)

# supplementary A
save_pdf_png(pA_sup, "FigS1A_AF_three_classes_reference_layout", 6.10, 2.75)

# ============================================================
# Statistics
# ============================================================
stats_out <- rbind(
  cbind(panel = "D_total", cor_stats(ALL, "FROH", "del_total")),
  cbind(panel = "D_hom", cor_stats(ALL, "FROH", "del_hom")),
  cbind(panel = "D_het", cor_stats(ALL, "FROH", "del_het")),
  cbind(panel = "E_total", cor_stats(ALL, "FROH", "del_load_total")),
  cbind(panel = "E_hom", cor_stats(ALL, "FROH", "del_load_hom")),
  cbind(panel = "E_het", cor_stats(ALL, "FROH", "del_load_het")),
  cbind(panel = "F_het", cor_stats(ALL, "FROH", "del_syn_ratio_het")),
  cbind(panel = "F_hom", cor_stats(ALL, "FROH", "del_syn_ratio_hom")),
  cbind(panel = "G_het", cor_stats(ALL, "FROH", "tol_syn_ratio_het")),
  cbind(panel = "G_hom", cor_stats(ALL, "FROH", "tol_syn_ratio_hom")),
  cbind(panel = "H_del_nonROH", cor_stats(H1[H1$region == "Non-ROH", , drop = FALSE], "FROH", "value")),
  cbind(panel = "H_del_ROH", cor_stats(H1[H1$region == "ROH", , drop = FALSE], "FROH", "value")),
  cbind(panel = "H_tol_nonROH", cor_stats(H2[H2$region == "Non-ROH", , drop = FALSE], "FROH", "value")),
  cbind(panel = "H_tol_ROH", cor_stats(H2[H2$region == "ROH", , drop = FALSE], "FROH", "value"))
)

write.table(
  stats_out,
  file = file.path(RESULT_DIR, paste0(PREFIX, ".plot_stats_reference_layout.tsv")),
  sep = "\t",
  quote = FALSE,
  row.names = FALSE
)

message("[DONE] Reference-layout plotting finished.")
