#!/usr/bin/env Rscript

suppressPackageStartupMessages({
  library(ggplot2)
  library(patchwork)
})

args <- commandArgs(trailingOnly = TRUE)

if (length(args) < 3) {
  stop(
    "Usage:\n",
    "Rscript 05_plot_Ped_GERP4_vs_Ho.R <heterozygosity.tsv> <GERP4_burden.tsv> <out_prefix> [mode] [remove_samples] [drop_regex]\n\n",
    "Example:\n",
    "Rscript 05_plot_Ped_GERP4_vs_Ho.R Ped63.individual_heterozygosity.tsv plot_BC_GERP4_burden.tsv out/Ped.GERP4_vs_Ho unpolarized NONE NONE\n"
  )
}

hetero_file <- args[1]
burden_file <- args[2]
out_prefix  <- args[3]

mode_keep <- ifelse(length(args) >= 4, args[4], "unpolarized")
remove_arg <- ifelse(length(args) >= 5, args[5], "NONE")
drop_regex <- ifelse(length(args) >= 6, args[6], "NONE")

out_dir <- dirname(out_prefix)
dir.create(out_dir, recursive = TRUE, showWarnings = FALSE)

read_tsv <- function(x) {
  read.delim(
    x,
    sep = "\t",
    header = TRUE,
    stringsAsFactors = FALSE,
    check.names = FALSE,
    comment.char = "",
    quote = ""
  )
}

to_num <- function(x) {
  suppressWarnings(as.numeric(gsub(",", "", as.character(x))))
}

find_col <- function(df, candidates, required = TRUE) {
  hit <- candidates[candidates %in% colnames(df)]
  if (length(hit) > 0) return(hit[1])
  if (required) {
    stop("Cannot find required column. Candidates: ", paste(candidates, collapse = ", "))
  }
  return(NA_character_)
}

safe_cor <- function(x, y, method = "pearson") {
  ok <- is.finite(x) & is.finite(y)
  x <- x[ok]
  y <- y[ok]

  if (length(x) < 3 || length(unique(x)) < 2 || length(unique(y)) < 2) {
    return(c(r = NA_real_, p = NA_real_))
  }

  ct <- suppressWarnings(cor.test(x, y, method = method, exact = FALSE))
  return(c(r = unname(ct$estimate), p = ct$p.value))
}

fmt_p <- function(p) {
  ifelse(
    is.na(p),
    "P = NA",
    ifelse(
      p < 2.2e-16,
      "P < 2.2e-16",
      paste0("P = ", formatC(p, format = "e", digits = 2))
    )
  )
}

fmt_r <- function(r) {
  ifelse(is.na(r), "R = NA", paste0("R = ", sprintf("%.2f", r)))
}

label_count <- function(x) {
  format(round(x, 0), big.mark = ",", scientific = FALSE, trim = TRUE)
}

label_rate <- function(x) {
  sprintf("%.3f", x)
}

# -----------------------------
# 1. Read heterozygosity table
# -----------------------------
het <- read_tsv(hetero_file)

sample_col_het <- find_col(het, c("IID", "sample", "Sample", "ID", "id"))
ho_col <- find_col(het, c("Ho_individual", "Ho", "heterozygosity", "Heterozygosity"))

het2 <- data.frame(
  sample = as.character(het[[sample_col_het]]),
  Ho_individual = to_num(het[[ho_col]]),
  stringsAsFactors = FALSE
)

het2 <- het2[is.finite(het2$Ho_individual), ]
het2 <- het2[!duplicated(het2$sample), ]

# -----------------------------
# 2. Read GERP burden table
# -----------------------------
bur <- read_tsv(burden_file)

if ("mode" %in% colnames(bur)) {
  bur <- bur[bur$mode == mode_keep, , drop = FALSE]
  if (nrow(bur) == 0) {
    stop("No rows left after mode filtering: ", mode_keep)
  }
}

sample_col_bur <- find_col(bur, c("sample", "IID", "Sample", "ID", "id"))
component_col <- find_col(bur, c("component", "Component"))
count_col <- find_col(bur, c("value_count", "count", "Count"))
called_col <- find_col(bur, c("called_sites", "n_called_sites", "called"), required = FALSE)
rate_col <- find_col(bur, c("value_rate", "rate", "Rate"), required = FALSE)

bur$sample <- as.character(bur[[sample_col_bur]])

cc <- tolower(as.character(bur[[component_col]]))
cc[cc %in% c("homozygous", "homo", "hom")] <- "hom"
cc[cc %in% c("heterozygous", "hetero", "het")] <- "het"
cc[cc %in% c("carrier_all", "all", "total", "carrierall")] <- "carrier_all"

bur$component_std <- cc
bur$value_count <- to_num(bur[[count_col]])

if (!is.na(called_col)) {
  bur$called_sites <- to_num(bur[[called_col]])
} else {
  bur$called_sites <- NA_real_
}

if (!is.na(rate_col)) {
  bur$value_rate <- to_num(bur[[rate_col]])
} else {
  if (all(is.na(bur$called_sites))) {
    stop("No value_rate column and no called_sites column. Cannot calculate standardized load.")
  }
  bur$value_rate <- bur$value_count / bur$called_sites
}

keep_comp <- c("carrier_all", "hom", "het")
bur2 <- bur[bur$component_std %in% keep_comp, c(
  "sample", "component_std", "value_count", "value_rate", "called_sites"
)]

# -----------------------------
# 3. Merge Ho and GERP burden
# -----------------------------
dat <- merge(bur2, het2, by = "sample", all = FALSE)

if (nrow(dat) == 0) {
  stop("No overlapping samples between heterozygosity file and GERP burden file.")
}

# Optional exact sample removal:
# Example fifth argument: "PE01225437,ABC001"
if (remove_arg != "NONE" && nzchar(remove_arg)) {
  remove_samples <- unlist(strsplit(remove_arg, ","))
  remove_samples <- trimws(remove_samples)
  dat <- dat[!dat$sample %in% remove_samples, , drop = FALSE]
}

# Optional regex removal:
# Example sixth argument: "^PE"
if (drop_regex != "NONE" && nzchar(drop_regex)) {
  dat <- dat[!grepl(drop_regex, dat$sample), , drop = FALSE]
}

label_map <- c(
  carrier_all = "Total",
  hom = "Homozygous",
  het = "Heterozygous"
)

dat$component_label <- label_map[dat$component_std]
dat$component_label <- factor(
  dat$component_label,
  levels = c("Total", "Homozygous", "Heterozygous")
)

dat <- dat[
  is.finite(dat$Ho_individual) &
    is.finite(dat$value_count) &
    is.finite(dat$value_rate),
]

if (nrow(dat) == 0) {
  stop("No valid data points after filtering.")
}

# -----------------------------
# 4. Correlation statistics
# -----------------------------
make_stats <- function(df, ycol, yname) {
  out <- lapply(levels(df$component_label), function(cl) {
    sub <- df[df$component_label == cl, , drop = FALSE]
    y <- sub[[ycol]]
    x <- sub$Ho_individual
    ok <- is.finite(x) & is.finite(y)

    pc <- safe_cor(x, y, method = "pearson")
    sp <- safe_cor(x, y, method = "spearman")

    data.frame(
      mode = mode_keep,
      y_metric = yname,
      component = cl,
      n = sum(ok),
      pearson_R = pc["r"],
      pearson_P = pc["p"],
      spearman_rho = sp["r"],
      spearman_P = sp["p"],
      stringsAsFactors = FALSE
    )
  })

  do.call(rbind, out)
}

stat_count <- make_stats(dat, "value_count", "count")
stat_rate  <- make_stats(dat, "value_rate", "standardized_rate")

stat_all <- rbind(stat_count, stat_rate)

stat_all$pearson_FDR_BH <- ave(
  stat_all$pearson_P,
  stat_all$y_metric,
  FUN = function(p) p.adjust(p, method = "BH")
)

stat_all$spearman_FDR_BH <- ave(
  stat_all$spearman_P,
  stat_all$y_metric,
  FUN = function(p) p.adjust(p, method = "BH")
)

write.table(
  dat[order(dat$sample, dat$component_label), ],
  paste0(out_prefix, ".merged_Ho_GERP4.tsv"),
  sep = "\t",
  quote = FALSE,
  row.names = FALSE
)

write.table(
  stat_all,
  paste0(out_prefix, ".correlation_summary.tsv"),
  sep = "\t",
  quote = FALSE,
  row.names = FALSE
)

# -----------------------------
# 5. Plot functions
# -----------------------------
cols <- c(
  Total = "#D8DDF2",
  Homozygous = "#4E5FB6",
  Heterozygous = "#8E9BE0"
)

make_label_df <- function(df, stats_df) {
  xr <- range(df$Ho_individual, finite = TRUE)
  yr <- range(df$Y, finite = TRUE)

  x_span <- diff(xr)
  y_span <- diff(yr)

  x_lab <- xr[1] + 0.045 * x_span

  offset <- c(
    Total = 0.030,
    Homozygous = -0.020,
    Heterozygous = 0.025
  ) * y_span

  labs <- lapply(levels(df$component_label), function(cl) {
    sub <- df[df$component_label == cl, , drop = FALSE]
    st <- stats_df[stats_df$component == cl, , drop = FALSE]

    y_lab <- median(sub$Y, na.rm = TRUE)

    ok <- is.finite(sub$Ho_individual) & is.finite(sub$Y)
    if (sum(ok) >= 3 && length(unique(sub$Ho_individual[ok])) >= 2) {
      tmp <- data.frame(
        x = sub$Ho_individual[ok],
        y = sub$Y[ok]
      )
      fit <- lm(y ~ x, data = tmp)
      y_lab <- as.numeric(predict(fit, newdata = data.frame(x = x_lab)))
    }

    y_lab <- y_lab + offset[cl]
    y_lab <- max(min(y_lab, yr[2] - 0.03 * y_span), yr[1] + 0.03 * y_span)

    data.frame(
      component_label = factor(cl, levels = levels(df$component_label)),
      x = x_lab,
      y = y_lab,
      label = paste0(
        cl, ": ",
        fmt_r(st$pearson_R[1]),
        "; ",
        fmt_p(st$pearson_P[1])
      ),
      stringsAsFactors = FALSE
    )
  })

  do.call(rbind, labs)
}

plot_one <- function(df, ycol, stats_df, title, ylab, y_label_fun) {
  pd <- df
  pd$Y <- pd[[ycol]]

  lab_df <- make_label_df(pd, stats_df)

  ggplot(
    pd,
    aes(
      x = Ho_individual,
      y = Y,
      color = component_label
    )
  ) +
    geom_point(size = 1.45, alpha = 0.38) +
    geom_smooth(
      method = "lm",
      formula = y ~ x,
      se = FALSE,
      linewidth = 0.75
    ) +
    geom_text(
      data = lab_df,
      aes(
        x = x,
        y = y,
        label = label,
        color = component_label
      ),
      inherit.aes = FALSE,
      hjust = 0,
      vjust = 0.5,
      size = 2.55,
      fontface = "bold"
    ) +
    scale_color_manual(
      values = cols,
      breaks = c("Total", "Homozygous", "Heterozygous")
    ) +
    scale_x_continuous(
      expand = expansion(mult = c(0.055, 0.055))
    ) +
    scale_y_continuous(
      labels = y_label_fun,
      expand = expansion(mult = c(0.075, 0.105))
    ) +
    labs(
      title = title,
      x = "Ho_individual",
      y = ylab,
      color = NULL
    ) +
    theme_classic(base_size = 8) +
    theme(
      plot.title = element_text(hjust = 0.5, size = 9, face = "plain"),
      axis.title = element_text(size = 8),
      axis.text = element_text(size = 7, color = "black"),
      axis.line = element_line(linewidth = 0.35, color = "grey35"),
      axis.ticks = element_line(linewidth = 0.3, color = "grey35"),
      panel.grid.major = element_line(linewidth = 0.22, color = "grey92"),
      panel.grid.minor = element_blank(),
      legend.position = "top",
      legend.justification = "center",
      legend.direction = "horizontal",
      legend.key.width = unit(7, "mm"),
      legend.key.height = unit(3, "mm"),
      legend.text = element_text(size = 6.8),
      plot.margin = margin(4, 6, 4, 6)
    )
}

p_count <- plot_one(
  dat,
  ycol = "value_count",
  stats_df = stat_count,
  title = "GERP>4 counts",
  ylab = "Count",
  y_label_fun = label_count
)

p_rate <- plot_one(
  dat,
  ycol = "value_rate",
  stats_df = stat_rate,
  title = "Standardized GERP>4 load",
  ylab = "Load",
  y_label_fun = label_rate
)

combined <- p_count + p_rate +
  plot_layout(ncol = 2, guides = "collect") +
  plot_annotation(tag_levels = list(c("C", "D"))) &
  theme(
    legend.position = "top",
    legend.justification = "center",
    plot.tag = element_text(size = 10, face = "bold")
  )

ggsave(
  paste0(out_prefix, ".panel_CD.pdf"),
  combined,
  width = 7.6,
  height = 2.45,
  useDingbats = FALSE
)

ggsave(
  paste0(out_prefix, ".panel_CD.png"),
  combined,
  width = 7.6,
  height = 2.45,
  dpi = 600
)

ggsave(
  paste0(out_prefix, ".C_GERP4_count_vs_Ho.pdf"),
  p_count,
  width = 3.8,
  height = 2.35,
  useDingbats = FALSE
)

ggsave(
  paste0(out_prefix, ".D_GERP4_rate_vs_Ho.pdf"),
  p_rate,
  width = 3.8,
  height = 2.35,
  useDingbats = FALSE
)

message("[OK] merged table: ", paste0(out_prefix, ".merged_Ho_GERP4.tsv"))
message("[OK] correlation summary: ", paste0(out_prefix, ".correlation_summary.tsv"))
message("[OK] combined figure PDF: ", paste0(out_prefix, ".panel_CD.pdf"))
message("[OK] combined figure PNG: ", paste0(out_prefix, ".panel_CD.png"))
