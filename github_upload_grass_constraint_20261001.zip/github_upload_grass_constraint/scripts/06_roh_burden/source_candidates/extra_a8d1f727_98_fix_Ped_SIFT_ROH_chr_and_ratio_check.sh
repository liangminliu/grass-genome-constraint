#!/usr/bin/env bash
set -euo pipefail

WORKDIR="/gpfs/hpc/home/kib_unit/lidezhu/liuliangmin/6.pop/05.FROH"
OUTROOT="Ped_SIFT_polar_unpolar_pipeline"

cd "${WORKDIR}"

RUN_SH="${OUTROOT}/scripts/00_run_Ped_SIFT_polar_unpolar.sh"
CALC_PY="${OUTROOT}/scripts/calc_Ped_SIFT_polar_unpolar.py"
PLOT_R="${OUTROOT}/scripts/01_plot_PedALL_SIFT_two_layers.R"

PER_SAMPLE="${OUTROOT}/04_summary/Ped_SIFT.PedC_PedD_PedALL.per_sample_burden.tsv"
SITE_AF="${OUTROOT}/04_summary/Ped_SIFT.PedC_PedD.site_AF.tsv.gz"
FIG_DIR="${OUTROOT}/05_figures"

mkdir -p "${OUTROOT}/logs"

ts=$(date +%Y%m%d_%H%M%S)

echo "============================================================"
echo "[INFO] Backup original scripts"
echo "============================================================"

for f in "${RUN_SH}" "${CALC_PY}" "${PLOT_R}"; do
    if [[ -s "${f}" ]]; then
        cp -f "${f}" "${f}.bak.${ts}"
        echo "[BACKUP] ${f}.bak.${ts}"
    else
        echo "[WARN] Missing script before patch: ${f}"
    fi
done

echo
echo "============================================================"
echo "[CHECK 1] Raw ROH chromosome examples"
echo "============================================================"

ROH_SEG="ROH_pipeline/Ped/04_froh/plink_kb100_gap1000_winmiss5/ROH.segments.plink.ge100000.minSNP50.kb100_gap1000_winmiss5.classified.tsv"

if [[ -s "${ROH_SEG}" ]]; then
    awk -F'\t' '
    NR==1{
      for(i=1;i<=NF;i++) h[$i]=i
      chr_col=h["chr"]
      if(chr_col=="") chr_col=h["CHR"]
      if(chr_col=="") chr_col=h["chrom"]
      print "[INFO] ROH chr column =", chr_col
      next
    }
    NR>1 && chr_col>0{
      print $(chr_col)
      n++
      if(n>=20) exit
    }' "${ROH_SEG}" | sort | uniq -c
else
    echo "[ERROR] Cannot find ROH segment file: ${ROH_SEG}" >&2
    exit 1
fi

echo
echo "============================================================"
echo "[CHECK 2] Site table chromosome examples before fix"
echo "============================================================"

if [[ -s "${SITE_AF}" ]]; then
    zcat "${SITE_AF}" | awk -F'\t' '
    NR==1{
      for(i=1;i<=NF;i++) h[$i]=i
      next
    }
    NR>1{
      print $(h["chrom"])
      n++
      if(n>=20) exit
    }' | sort | uniq -c
else
    echo "[WARN] Site AF table not found before rerun: ${SITE_AF}"
fi

echo
echo "============================================================"
echo "[PATCH 1] Patch calculation script and 00_run script: map ROH chr by chrom_map"
echo "============================================================"

python3 - <<'PY'
from pathlib import Path

targets = [
    Path("Ped_SIFT_polar_unpolar_pipeline/scripts/00_run_Ped_SIFT_polar_unpolar.sh"),
    Path("Ped_SIFT_polar_unpolar_pipeline/scripts/calc_Ped_SIFT_polar_unpolar.py"),
]

for path in targets:
    if not path.exists():
        print(f"[WARN] Skip missing {path}")
        continue

    text = path.read_text()

    # 1. read_roh(path) -> read_roh(path, chrom_map=None)
    text = text.replace(
        "def read_roh(path):",
        "def read_roh(path, chrom_map=None):"
    )

    # 2. Add chrom mapping inside read_roh after chrom = a[chr_col]
    old = '''            chrom = a[chr_col]
            try:
                s = int(float(a[start_col]))'''
    new = '''            chrom = a[chr_col]
            if chrom_map is not None:
                chrom = map_chrom(chrom, chrom_map)
            try:
                s = int(float(a[start_col]))'''

    if old in text and new not in text:
        text = text.replace(old, new)

    # Some previous versions may have slightly different indentation or variable names.
    old2 = '''            chrom = row[chr_col]

            try:
                s = int(float(row[start_col]))'''
    new2 = '''            chrom = row[chr_col]
            if chrom_map is not None:
                chrom = map_chrom(chrom, chrom_map)

            try:
                s = int(float(row[start_col]))'''

    if old2 in text and new2 not in text:
        text = text.replace(old2, new2)

    # 3. main: roh_idx = read_roh(args.roh) -> read_roh(args.roh, chrom_map)
    text = text.replace(
        "roh_idx = read_roh(args.roh)",
        "roh_idx = read_roh(args.roh, chrom_map)"
    )

    # Avoid duplicated replacement
    text = text.replace(
        "roh_idx = read_roh(args.roh, chrom_map, chrom_map)",
        "roh_idx = read_roh(args.roh, chrom_map)"
    )

    path.write_text(text)
    print(f"[PATCHED] {path}")
PY

echo
echo "============================================================"
echo "[PATCH 2] Patch plotting script: safe p-label table"
echo "============================================================"

python3 - <<'PY'
from pathlib import Path

path = Path("Ped_SIFT_polar_unpolar_pipeline/scripts/01_plot_PedALL_SIFT_two_layers.R")

if not path.exists():
    raise SystemExit(f"[ERROR] Cannot find {path}")

text = path.read_text()

start_key = "make_p_labels <- function"
end_key = "pretty_binwidth <- function"

start = text.find(start_key)
end = text.find(end_key, start)

if start < 0 or end < 0:
    raise SystemExit("[ERROR] Cannot locate make_p_labels() block in R script.")

safe_func = r'''
make_p_labels <- function(df, xcol, ycol, group_col) {
  empty_out <- tibble(
    group = character(),
    x = numeric(),
    y = numeric(),
    label = character()
  )

  if (!all(c(xcol, ycol, group_col) %in% colnames(df))) {
    return(empty_out)
  }

  d <- df %>%
    filter(
      !is.na(.data[[xcol]]),
      !is.na(.data[[ycol]]),
      !is.na(.data[[group_col]])
    )

  if (nrow(d) == 0) {
    return(empty_out)
  }

  groups <- unique(d[[group_col]])

  yr <- range(d[[ycol]], na.rm = TRUE)
  xr <- range(d[[xcol]], na.rm = TRUE)

  if (!all(is.finite(yr)) || !all(is.finite(xr))) {
    return(empty_out)
  }

  y_span <- diff(yr)
  if (!is.finite(y_span) || y_span == 0) y_span <- 1

  x_span <- diff(xr)
  if (!is.finite(x_span) || x_span == 0) x_span <- 1

  x_pos <- xr[1] + 0.02 * x_span

  bind_rows(lapply(seq_along(groups), function(i) {
    g <- groups[i]
    sub <- d[d[[group_col]] == g, , drop = FALSE]
    p <- get_lm_p(sub, xcol, ycol)

    tibble(
      group = as.character(g),
      x = x_pos,
      y = yr[2] - (i - 1) * 0.085 * y_span,
      label = paste0(g, ": ", fmt_p(p))
    )
  }))
}

'''.lstrip()

text = text[:start] + safe_func + text[end:]
path.write_text(text)

print(f"[PATCHED] {path}")
PY

echo
echo "============================================================"
echo "[STEP 1] Re-run SIFT burden calculation"
echo "============================================================"

bash "${RUN_SH}" \
  > "${OUTROOT}/logs/98_rerun_calculation_after_ROH_chr_fix.out" \
  2> "${OUTROOT}/logs/98_rerun_calculation_after_ROH_chr_fix.err"

echo "[INFO] Calculation log:"
echo "${OUTROOT}/logs/98_rerun_calculation_after_ROH_chr_fix.out"
echo "${OUTROOT}/logs/98_rerun_calculation_after_ROH_chr_fix.err"

echo
echo "============================================================"
echo "[CHECK 3] PedALL ROH/nonROH called sites after fix"
echo "============================================================"

awk -F'\t' '
NR==1{
  for(i=1;i<=NF;i++) h[$i]=i
  next
}
$(h["subgenome"])=="PedALL"{
  key=$(h["layer"])"\t"$(h["variant_class"])"\t"$(h["region"])
  n[key]++
  sites[key]+=$(h["n_called_sites"])
  alleles[key]+=$(h["called_alleles"])
  ac[key]+=$(h["allele_count"])
}
END{
  print "layer\tvariant_class\tregion\tn_samples_sum_rows\tsum_called_sites\tsum_called_alleles\tsum_allele_count"
  for(k in sites){
    print k"\t"n[k]"\t"sites[k]"\t"alleles[k]"\t"ac[k]
  }
}' "${PER_SAMPLE}" | sort

echo
echo "============================================================"
echo "[STEP 2] Re-run visualization"
echo "============================================================"

Rscript "${PLOT_R}" \
  "${PER_SAMPLE}" \
  "${SITE_AF}" \
  "${FIG_DIR}" \
  > "${OUTROOT}/logs/98_rerun_plot_after_ROH_chr_fix.out" \
  2> "${OUTROOT}/logs/98_rerun_plot_after_ROH_chr_fix.err"

echo "[INFO] Plot log:"
echo "${OUTROOT}/logs/98_rerun_plot_after_ROH_chr_fix.out"
echo "${OUTROOT}/logs/98_rerun_plot_after_ROH_chr_fix.err"

echo
echo "============================================================"
echo "[CHECK 4] Ratio NA / zero / valid counts"
echo "============================================================"

for d in 01_unpolarized_ALT 02_polarized_derived; do
    echo
    echo "[DIR] ${FIG_DIR}/${d}"

    ratio_all="${FIG_DIR}/${d}/PedALL.sample_ratio.ALL.tsv"
    ratio_roh="${FIG_DIR}/${d}/PedALL.sample_ratio.ROH_nonROH.tsv"

    if [[ -s "${ratio_all}" ]]; then
        echo "[ALL ratio]"
        awk -F'\t' '
        NR==1{
          for(i=1;i<=NF;i++) h[$i]=i
          next
        }
        NR>1{
          n++
          cols["del_syn_hom"]=h["del_syn_hom"]
          cols["del_syn_het"]=h["del_syn_het"]
          cols["tol_syn_hom"]=h["tol_syn_hom"]
          cols["tol_syn_het"]=h["tol_syn_het"]

          for(c in cols){
            v=$(cols[c])
            if(v=="NA" || v=="") na[c]++
            else if(v+0==0) zero[c]++
            else ok[c]++
          }
        }
        END{
          print "metric\tvalid_nonzero\tzero\tNA"
          for(c in cols){
            print c"\t"ok[c]+0"\t"zero[c]+0"\t"na[c]+0
          }
        }' "${ratio_all}"
    else
        echo "[WARN] Missing ${ratio_all}"
    fi

    if [[ -s "${ratio_roh}" ]]; then
        echo "[ROH/nonROH ratio]"
        awk -F'\t' '
        NR==1{
          for(i=1;i<=NF;i++) h[$i]=i
          next
        }
        NR>1{
          region=$(h["region_label"])
          n[region]++
          v1=$(h["del_syn_allele"])
          v2=$(h["tol_syn_allele"])

          if(v1=="NA" || v1=="") na1[region]++
          else if(v1+0==0) zero1[region]++
          else ok1[region]++

          if(v2=="NA" || v2=="") na2[region]++
          else if(v2+0==0) zero2[region]++
          else ok2[region]++
        }
        END{
          print "region\tmetric\tvalid_nonzero\tzero\tNA\tn_rows"
          for(r in n){
            print r"\tdel_syn_allele\t"ok1[r]+0"\t"zero1[r]+0"\t"na1[r]+0"\t"n[r]
            print r"\ttol_syn_allele\t"ok2[r]+0"\t"zero2[r]+0"\t"na2[r]+0"\t"n[r]
          }
        }' "${ratio_roh}"
    else
        echo "[WARN] Missing ${ratio_roh}"
    fi
done

echo
echo "============================================================"
echo "[DONE] Fix completed."
echo
echo "[Main figures]"
echo "${FIG_DIR}/01_unpolarized_ALT/PedALL.SIFT.A_H.combined.pdf"
echo "${FIG_DIR}/02_polarized_derived/PedALL.SIFT.A_H.combined.pdf"
echo
echo "[Important check]"
echo "If ROH sum_called_sites is still 0, sample IDs or chromosome IDs between ROH and VCF are still mismatched."
echo "If ratio NA is high but ROH called_sites is nonzero, missing red/orange points are ratio denominator = 0/NA, not true zero."
echo "============================================================"
