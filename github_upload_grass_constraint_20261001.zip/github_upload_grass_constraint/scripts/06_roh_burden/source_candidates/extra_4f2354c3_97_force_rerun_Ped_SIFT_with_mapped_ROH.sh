#!/usr/bin/env bash
#SBATCH --job-name=forceROH
#SBATCH --output=Ped_SIFT_polar_unpolar_pipeline/logs/97_force_recalc_mapped_ROH.out
#SBATCH --error=Ped_SIFT_polar_unpolar_pipelinelogs/97_force_recalc_mapped_ROH.err
#SBATCH --cpus-per-task=1

set -euo pipefail

WORKDIR="/gpfs/hpc/home/kib_unit/lidezhu/liuliangmin/6.pop/05.FROH"
OUTROOT="Ped_SIFT_polar_unpolar_pipeline"

cd "${WORKDIR}"

CALC_PY="${OUTROOT}/scripts/calc_Ped_SIFT_polar_unpolar.py"
PLOT_R="${OUTROOT}/scripts/01_plot_PedALL_SIFT_two_layers.R"

SIFT_C="PedC_subgenome_complete_SIFTpredictions.vcf"
SIFT_D="PedD_subgenome_complete_SIFTpredictions.vcf"
CHROM_MAP="chrom_map.txt"
ANCESTRAL_BED="Ped_GERP_fullgenome_pipeline/00_ancestral_index/ped_all.ancestral.bed.gz"

ROH_SEG="ROH_pipeline/Ped/04_froh/plink_kb100_gap1000_winmiss5/ROH.segments.plink.ge100000.minSNP50.kb100_gap1000_winmiss5.classified.tsv"

SUMMARY_DIR="${OUTROOT}/04_summary"
FIG_DIR="${OUTROOT}/05_figures"
LOG_DIR="${OUTROOT}/logs"

mkdir -p "${SUMMARY_DIR}" "${FIG_DIR}" "${LOG_DIR}"

for f in "${CALC_PY}" "${PLOT_R}" "${SIFT_C}" "${SIFT_D}" "${CHROM_MAP}" "${ANCESTRAL_BED}" "${ANCESTRAL_BED}.tbi" "${ROH_SEG}"; do
    if [[ ! -s "${f}" ]]; then
        echo "[ERROR] Missing required file: ${f}" >&2
        exit 1
    fi
done

###############################################################################
# 1. Auto-detect FROH file
###############################################################################

FROH_FILE="NA"

for f in \
    "ROH_pipeline/Ped/04_froh/plink_kb100_gap1000_winmiss5/FROH.final.plink.kb100_gap1000_winmiss5.tsv" \
    "ROH_pipeline/Ped/04_froh/plink_kb100_gap1000_winmiss5/FROH.final.plink.local3.tsv" \
    "ROH_pipeline/Ped/04_froh/plink_kb100_gap1000_winmiss5/FROH.final.plink.tsv" \
    "ROH_pipeline/Ped/04_froh/plink/FROH.final.plink.local3.tsv" \
    "ROH_pipeline/Ped/04_froh/plink/FROH.final.plink.tsv"
do
    if [[ -s "${f}" ]]; then
        FROH_FILE="${f}"
        break
    fi
done

echo "[INFO] FROH_FILE = ${FROH_FILE}"

###############################################################################
# 2. Backup and patch calculation script
###############################################################################

ts=$(date +%Y%m%d_%H%M%S)
cp -f "${CALC_PY}" "${CALC_PY}.bak.forceROH.${ts}"

python3 - <<'PY'
from pathlib import Path
import re

path = Path("Ped_SIFT_polar_unpolar_pipeline/scripts/calc_Ped_SIFT_polar_unpolar.py")
text = path.read_text()

# 1) Ensure read_roh accepts chrom_map
text = text.replace(
    "def read_roh(path):",
    "def read_roh(path, chrom_map=None):"
)

# 2) Insert chromosome mapping inside read_roh after chrom is read
patterns = [
    (
        '''            chrom = a[chr_col]
            try:
                s = int(float(a[start_col]))''',
        '''            chrom = a[chr_col]
            if chrom_map is not None:
                chrom = map_chrom(chrom, chrom_map)
            try:
                s = int(float(a[start_col]))'''
    ),
    (
        '''            chrom = row[chr_col]
            try:
                s = int(float(row[start_col]))''',
        '''            chrom = row[chr_col]
            if chrom_map is not None:
                chrom = map_chrom(chrom, chrom_map)
            try:
                s = int(float(row[start_col]))'''
    ),
    (
        '''            chrom = row[chr_col]

            try:
                s = int(float(row[start_col]))''',
        '''            chrom = row[chr_col]
            if chrom_map is not None:
                chrom = map_chrom(chrom, chrom_map)

            try:
                s = int(float(row[start_col]))'''
    )
]

for old, new in patterns:
    if old in text and new not in text:
        text = text.replace(old, new)

# 3) Ensure main calls read_roh(args.roh, chrom_map)
text = re.sub(
    r"roh_idx\s*=\s*read_roh\(args\.roh(?:,\s*chrom_map)?\)",
    "roh_idx = read_roh(args.roh, chrom_map)",
    text
)

# 4) Add a small diagnostic after read_roh if not present
diag_old = "roh_idx = read_roh(args.roh, chrom_map)"
diag_new = '''roh_idx = read_roh(args.roh, chrom_map)

    # Diagnostic: report mapped ROH chromosomes and intervals
    n_roh_samples = len(roh_idx)
    n_roh_chroms = sum(len(roh_idx[s]) for s in roh_idx)
    n_roh_intervals = 0
    roh_chrom_preview = []
    for _s in list(roh_idx.keys())[:3]:
        for _c in list(roh_idx[_s].keys())[:5]:
            _starts, _ends = roh_idx[_s][_c]
            n_roh_intervals += len(_starts)
            roh_chrom_preview.append(_c)
    sys.stderr.write(f"[DEBUG] ROH samples = {n_roh_samples}\\n")
    sys.stderr.write(f"[DEBUG] ROH sample-chrom pairs = {n_roh_chroms}\\n")
    sys.stderr.write(f"[DEBUG] ROH preview chroms = {sorted(set(roh_chrom_preview))[:10]}\\n")'''

if "[DEBUG] ROH samples" not in text:
    text = text.replace(diag_old, diag_new, 1)

path.write_text(text)
print("[INFO] Patched:", path)
PY

echo
echo "============================================================"
echo "[CHECK] Patched calculation script around read_roh"
echo "============================================================"

grep -n "def read_roh\|chrom = map_chrom(chrom, chrom_map)\|roh_idx = read_roh" "${CALC_PY}" || true

###############################################################################
# 3. Run direct calculation, bypassing 00_run script
###############################################################################

echo
echo "============================================================"
echo "[STEP 1] Recalculate Ped SIFT burden with mapped ROH chromosomes"
echo "============================================================"

python3 "${CALC_PY}" \
    --sift-c "${SIFT_C}" \
    --sift-d "${SIFT_D}" \
    --chrom-map "${CHROM_MAP}" \
    --ancestral-bed "${ANCESTRAL_BED}" \
    --roh "${ROH_SEG}" \
    --froh "${FROH_FILE}" \
    --out-prefix "${SUMMARY_DIR}/Ped_SIFT" \
    > "${LOG_DIR}/97_force_recalc_mapped_ROH.out" \
    2> "${LOG_DIR}/97_force_recalc_mapped_ROH.err"

echo "[INFO] Calculation logs:"
echo "  ${LOG_DIR}/97_force_recalc_mapped_ROH.out"
echo "  ${LOG_DIR}/97_force_recalc_mapped_ROH.err"

tail -n 20 "${LOG_DIR}/97_force_recalc_mapped_ROH.err" || true

PER_SAMPLE="${SUMMARY_DIR}/Ped_SIFT.PedC_PedD_PedALL.per_sample_burden.tsv"
SITE_AF="${SUMMARY_DIR}/Ped_SIFT.PedC_PedD.site_AF.tsv.gz"

###############################################################################
# 4. Check whether ROH now has called sites
###############################################################################

echo
echo "============================================================"
echo "[CHECK] PedALL ROH/nonROH called sites after forced rerun"
echo "============================================================"

awk -F'\t' '
NR==1{
  for(i=1;i<=NF;i++) h[$i]=i
  next
}
$(h["subgenome"])=="PedALL"{
  key=$(h["layer"])"\t"$(h["variant_class"])"\t"$(h["region"])
  n[key]++
  sites[key]+=$(h["n_called_sites"])
  alleles[key]+=$(h["called_alleles"])
  ac[key]+=$(h["allele_count"])
}
END{
  print "layer\tvariant_class\tregion\tn_rows\tsum_called_sites\tsum_called_alleles\tsum_allele_count"
  for(k in sites){
    print k"\t"n[k]"\t"sites[k]"\t"alleles[k]"\t"ac[k]
  }
}' "${PER_SAMPLE}" | sort

###############################################################################
# 5. If ROH is still zero, run direct coordinate-overlap diagnostic
###############################################################################

echo
echo "============================================================"
echo "[DIAG] Direct coordinate overlap check: site_AF ALL rows vs MS_330 ROH"
echo "============================================================"

python3 - <<'PY'
import gzip
import bisect
from collections import defaultdict

chrom_map_file = "chrom_map.txt"
roh_file = "ROH_pipeline/Ped/04_froh/plink_kb100_gap1000_winmiss5/ROH.segments.plink.ge100000.minSNP50.kb100_gap1000_winmiss5.classified.tsv"
site_file = "Ped_SIFT_polar_unpolar_pipeline/04_summary/Ped_SIFT.PedC_PedD.site_AF.tsv.gz"
target_sample = "MS_330"

mp = {}
with open(chrom_map_file) as f:
    for line in f:
        if not line.strip() or line.startswith("#"):
            continue
        a = line.split()
        if len(a) >= 2:
            mp[a[0]] = a[1]
            mp["chr" + a[0]] = a[1]
            mp[a[1]] = a[1]

def map_chrom(c):
    return mp.get(c, mp.get(c.replace("chr", ""), c))

roh = defaultdict(list)

with open(roh_file) as f:
    header = f.readline().rstrip("\n").split("\t")
    h = {x:i for i,x in enumerate(header)}
    for line in f:
        a = line.rstrip("\n").split("\t")
        if a[h["sample"]] != target_sample:
            continue
        chrom = map_chrom(a[h["chr"]])
        s = int(float(a[h["start_bp"]]))
        e = int(float(a[h["end_bp"]]))
        if e < s:
            s, e = e, s
        roh[chrom].append((s, e))

idx = {}
for c, ivs in roh.items():
    ivs = sorted(ivs)
    merged = []
    for s, e in ivs:
        if not merged or s > merged[-1][1] + 1:
            merged.append([s, e])
        else:
            merged[-1][1] = max(merged[-1][1], e)
    starts = [x[0] for x in merged]
    ends = [x[1] for x in merged]
    idx[c] = (starts, ends)

def in_roh(chrom, pos):
    if chrom not in idx:
        return False
    starts, ends = idx[chrom]
    i = bisect.bisect_right(starts, pos) - 1
    return i >= 0 and ends[i] >= pos

print("[DIAG] target_sample =", target_sample)
print("[DIAG] mapped ROH chroms first 20 =", sorted(idx.keys())[:20])
print("[DIAG] number of mapped ROH chroms =", len(idx))
print("[DIAG] number of merged ROH intervals =", sum(len(idx[c][0]) for c in idx))

n_all = 0
n_overlap = 0
seen = set()

with gzip.open(site_file, "rt") as f:
    header = f.readline().rstrip("\n").split("\t")
    h = {x:i for i,x in enumerate(header)}

    for line in f:
        a = line.rstrip("\n").split("\t")
        if a[h["region"]] != "ALL":
            continue

        key = (a[h["subgenome"]], a[h["variant_class"]], a[h["layer"]], a[h["chrom"]], a[h["pos"]])
        if key in seen:
            continue
        seen.add(key)

        chrom = a[h["chrom"]]
        pos = int(a[h["pos"]])
        n_all += 1

        if in_roh(chrom, pos):
            n_overlap += 1

print("[DIAG] unique ALL site rows checked =", n_all)
print("[DIAG] sites overlapping MS_330 mapped ROH =", n_overlap)
PY

###############################################################################
# 6. Replot
###############################################################################

echo
echo "============================================================"
echo "[STEP 2] Replot two-layer figures"
echo "============================================================"

Rscript "${PLOT_R}" \
  "${PER_SAMPLE}" \
  "${SITE_AF}" \
  "${FIG_DIR}" \
  > "${LOG_DIR}/97_force_replot_mapped_ROH.out" \
  2> "${LOG_DIR}/97_force_replot_mapped_ROH.err"

echo "[INFO] Plot logs:"
echo "  ${LOG_DIR}/97_force_replot_mapped_ROH.out"
echo "  ${LOG_DIR}/97_force_replot_mapped_ROH.err"

###############################################################################
# 7. Check ratio NA/zero/valid
###############################################################################

echo
echo "============================================================"
echo "[CHECK] Ratio valid / zero / NA counts"
echo "============================================================"

for d in 01_unpolarized_ALT 02_polarized_derived; do
    echo
    echo "[DIR] ${FIG_DIR}/${d}"

    ratio_all="${FIG_DIR}/${d}/PedALL.sample_ratio.ALL.tsv"
    ratio_roh="${FIG_DIR}/${d}/PedALL.sample_ratio.ROH_nonROH.tsv"

    if [[ -s "${ratio_all}" ]]; then
        echo "[ALL ratio]"
        awk -F'\t' '
        NR==1{
          for(i=1;i<=NF;i++) h[$i]=i
          next
        }
        NR>1{
          n++
          split("del_syn_hom del_syn_het tol_syn_hom tol_syn_het", cols, " ")
          for(i in cols){
            c=cols[i]
            v=$(h[c])
            if(v=="NA" || v=="") na[c]++
            else if(v+0==0) zero[c]++
            else ok[c]++
          }
        }
        END{
          print "metric\tvalid_nonzero\tzero\tNA"
          split("del_syn_hom del_syn_het tol_syn_hom tol_syn_het", cols, " ")
          for(i in cols){
            c=cols[i]
            print c"\t"ok[c]+0"\t"zero[c]+0"\t"na[c]+0
          }
        }' "${ratio_all}"
    fi

    if [[ -s "${ratio_roh}" ]]; then
        echo "[ROH/nonROH ratio]"
        awk -F'\t' '
        NR==1{
          for(i=1;i<=NF;i++) h[$i]=i
          next
        }
        NR>1{
          region=$(h["region_label"])
          n[region]++

          v1=$(h["del_syn_allele"])
          v2=$(h["tol_syn_allele"])

          if(v1=="NA" || v1=="") na1[region]++
          else if(v1+0==0) zero1[region]++
          else ok1[region]++

          if(v2=="NA" || v2=="") na2[region]++
          else if(v2+0==0) zero2[region]++
          else ok2[region]++
        }
        END{
          print "region\tmetric\tvalid_nonzero\tzero\tNA\tn_rows"
          for(r in n){
            print r"\tdel_syn_allele\t"ok1[r]+0"\t"zero1[r]+0"\t"na1[r]+0"\t"n[r]
            print r"\ttol_syn_allele\t"ok2[r]+0"\t"zero2[r]+0"\t"na2[r]+0"\t"n[r]
          }
        }' "${ratio_roh}"
    fi
done

echo
echo "============================================================"
echo "[DONE] Forced ROH-mapped recalculation and plotting finished."
echo
echo "[Main figures]"
echo "${FIG_DIR}/01_unpolarized_ALT/PedALL.SIFT.A_H.combined.pdf"
echo "${FIG_DIR}/02_polarized_derived/PedALL.SIFT.A_H.combined.pdf"
echo
echo "[Important]"
echo "If ROH rows now have sum_called_sites > 0, H plot ROH results are valid."
echo "If ROH rows are still absent or zero but [DIAG] overlap > 0, send me the tail of 97_force_recalc_mapped_ROH.err."
echo "If [DIAG] overlap = 0, the ROH coordinates and SIFT VCF coordinates are not on the same chromosome-coordinate system."
echo "============================================================"
