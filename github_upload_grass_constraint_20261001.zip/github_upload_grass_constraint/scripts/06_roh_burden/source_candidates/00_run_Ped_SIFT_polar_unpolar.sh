#!/usr/bin/env bash
set -euo pipefail

###############################################################################
# Final Ped full-genome SIFT burden pipeline
#
# Outputs:
#   1. unpolarized ALT dosage
#   2. polarized derived dosage
#
# Critical:
#   ROH chr IDs are numeric 1-24.
#   VCF / ancestral BED chr IDs are Ped04D/Ped01D/...
#   Therefore ROH chr IDs are mapped using chrom_map.txt.
###############################################################################

cd /gpfs/hpc/home/kib_unit/lidezhu/liuliangmin/6.pop/05.FROH

OUTROOT="Ped_SIFT_polar_unpolar_pipeline"
SCRIPT_DIR="${OUTROOT}/scripts"
LOG_DIR="${OUTROOT}/logs"
SUMMARY_DIR="${OUTROOT}/04_summary"

mkdir -p "${SCRIPT_DIR}" "${LOG_DIR}" "${SUMMARY_DIR}"

SIFT_C="PedC_subgenome_complete_SIFTpredictions.vcf"
SIFT_D="PedD_subgenome_complete_SIFTpredictions.vcf"
CHROM_MAP="chrom_map.txt"

ANCESTRAL_BED="Ped_GERP_fullgenome_pipeline/00_ancestral_index/ped_all.ancestral.bed.gz"

ROH_SEG="ROH_pipeline/Ped/04_froh/plink_kb100_gap1000_winmiss5/ROH.segments.plink.ge100000.minSNP50.kb100_gap1000_winmiss5.classified.tsv"

###############################################################################
# Auto-detect FROH file
###############################################################################

FROH_FILE="NA"

for f in \
    "ROH_pipeline/Ped/04_froh/plink_kb100_gap1000_winmiss5/FROH.final.plink.kb100_gap1000_winmiss5.tsv" \
    "ROH_pipeline/Ped/04_froh/plink_kb100_gap1000_winmiss5/FROH.final.plink.local3.tsv" \
    "ROH_pipeline/Ped/04_froh/plink_kb100_gap1000_winmiss5/FROH.final.plink.tsv" \
    "ROH_pipeline/Ped/04_froh/plink/FROH.final.plink.local3.tsv" \
    "ROH_pipeline/Ped/04_froh/plink/FROH.final.plink.tsv"
do
    if [[ -s "${f}" ]]; then
        FROH_FILE="${f}"
        break
    fi
done

echo "[INFO] FROH_FILE = ${FROH_FILE}"

for f in "${SIFT_C}" "${SIFT_D}" "${CHROM_MAP}" "${ANCESTRAL_BED}" "${ANCESTRAL_BED}.tbi" "${ROH_SEG}"; do
    if [[ ! -s "${f}" ]]; then
        echo "[ERROR] Missing required file: ${f}" >&2
        exit 1
    fi
done

cat > "${SCRIPT_DIR}/calc_Ped_SIFT_polar_unpolar.py" <<'PY'
#!/usr/bin/env python3
import argparse
import bisect
import gzip
import os
import re
import sys
from collections import defaultdict, Counter

try:
    import pysam
except ImportError:
    sys.stderr.write("[ERROR] pysam is required. Please install pysam in current conda env.\n")
    sys.exit(1)

###############################################################################
# I/O
###############################################################################

def open_text(path):
    if path == "NA":
        return None
    if path.endswith(".gz"):
        return gzip.open(path, "rt")
    return open(path, "r")

def open_write(path):
    if path.endswith(".gz"):
        return gzip.open(path, "wt")
    return open(path, "w")

###############################################################################
# Chromosome mapping
###############################################################################

def read_chrom_map(path):
    mp = {}
    with open(path) as f:
        for line in f:
            if not line.strip() or line.startswith("#"):
                continue
            a = line.strip().split()
            if len(a) < 2:
                continue
            old, new = a[0], a[1]
            mp[old] = new
            mp["chr" + old] = new
            mp[new] = new
    return mp

def map_chrom(chrom, mp):
    if chrom in mp:
        return mp[chrom]
    if chrom.startswith("chr") and chrom[3:] in mp:
        return mp[chrom[3:]]
    return chrom

###############################################################################
# Column helpers
###############################################################################

def pick_col(header, candidates, contains=None):
    lower = {h.lower(): i for i, h in enumerate(header)}
    for c in candidates:
        if c.lower() in lower:
            return lower[c.lower()]
    if contains:
        for i, h in enumerate(header):
            hl = h.lower()
            if any(x in hl for x in contains):
                return i
    return None

###############################################################################
# ROH and FROH
###############################################################################

def merge_intervals(intervals):
    if not intervals:
        return []
    intervals = sorted(intervals)
    out = [list(intervals[0])]
    for s, e in intervals[1:]:
        if s <= out[-1][1] + 1:
            out[-1][1] = max(out[-1][1], e)
        else:
            out.append([s, e])
    return [(s, e) for s, e in out]

def read_roh(path, chrom_map):
    """
    Read per-sample ROH segments.

    Important:
    ROH chr can be numeric 1-24.
    It is converted to Ped chromosome ID using chrom_map.
    """
    roh = defaultdict(lambda: defaultdict(list))

    with open_text(path) as f:
        header = f.readline().rstrip("\n").split("\t")

        sample_col = pick_col(header, ["sample", "IID", "iid"], contains=["sample", "iid"])
        chr_col    = pick_col(header, ["chr", "CHR", "chrom", "chromosome"], contains=["chr", "chrom"])
        start_col  = pick_col(header, ["start_bp", "start", "POS1", "bp1"], contains=["start", "pos1"])
        end_col    = pick_col(header, ["end_bp", "end", "POS2", "bp2"], contains=["end", "pos2"])

        if None in (sample_col, chr_col, start_col, end_col):
            raise RuntimeError("Cannot detect columns in ROH file. Need sample/IID, chr, start_bp, end_bp.")

        sys.stderr.write(f"[DEBUG] ROH column sample = {sample_col + 1}\n")
        sys.stderr.write(f"[DEBUG] ROH column chr    = {chr_col + 1}\n")
        sys.stderr.write(f"[DEBUG] ROH column start  = {start_col + 1}\n")
        sys.stderr.write(f"[DEBUG] ROH column end    = {end_col + 1}\n")

        preview = []

        for line in f:
            if not line.strip():
                continue
            a = line.rstrip("\n").split("\t")
            if len(a) <= max(sample_col, chr_col, start_col, end_col):
                continue

            sample = a[sample_col]
            raw_chrom = a[chr_col]
            chrom = map_chrom(raw_chrom, chrom_map)

            if len(preview) < 10:
                preview.append((raw_chrom, chrom))

            try:
                s = int(float(a[start_col]))
                e = int(float(a[end_col]))
            except ValueError:
                continue

            if e < s:
                s, e = e, s

            roh[sample][chrom].append((s, e))

    idx = {}
    for sample in roh:
        idx[sample] = {}
        for chrom in roh[sample]:
            merged = merge_intervals(roh[sample][chrom])
            starts = [x[0] for x in merged]
            ends = [x[1] for x in merged]
            idx[sample][chrom] = (starts, ends)

    sys.stderr.write("[DEBUG] ROH chr mapping preview:\n")
    for raw_chrom, mapped_chrom in preview:
        sys.stderr.write(f"[DEBUG]   {raw_chrom} -> {mapped_chrom}\n")

    sys.stderr.write(f"[DEBUG] ROH samples = {len(idx)}\n")
    sys.stderr.write(f"[DEBUG] ROH sample-chrom pairs = {sum(len(idx[s]) for s in idx)}\n")
    sys.stderr.write(f"[DEBUG] ROH intervals after merge = {sum(len(idx[s][c][0]) for s in idx for c in idx[s])}\n")

    return idx

def is_in_roh(roh_idx, sample, chrom, pos):
    if sample not in roh_idx:
        return False
    if chrom not in roh_idx[sample]:
        return False

    starts, ends = roh_idx[sample][chrom]
    i = bisect.bisect_right(starts, pos) - 1
    if i < 0:
        return False
    return ends[i] >= pos

def read_froh(path):
    if path == "NA":
        return {}

    if not os.path.exists(path) or os.path.getsize(path) == 0:
        return {}

    out = {}

    with open_text(path) as f:
        header = f.readline().rstrip("\n").split("\t")
        sample_col = pick_col(header, ["sample", "IID", "iid"], contains=["sample", "iid"])
        froh_col = pick_col(header, ["FROH", "F_ROH", "froh"], contains=["froh"])

        if sample_col is None or froh_col is None:
            sys.stderr.write("[WARN] Could not detect sample/FROH columns in FROH file.\n")
            return {}

        for line in f:
            if not line.strip():
                continue
            a = line.rstrip("\n").split("\t")
            if len(a) <= max(sample_col, froh_col):
                continue
            out[a[sample_col]] = a[froh_col]

    sys.stderr.write(f"[DEBUG] FROH samples = {len(out)}\n")
    return out

###############################################################################
# Ancestral allele
###############################################################################

def parse_ancestral(cols):
    for x in cols[3:]:
        y = x.strip().upper()

        if y in {"A", "C", "G", "T"}:
            return y

        m = re.search(r"(?:AA|ANC|ANCESTRAL)[=:]([ACGT])\b", y)
        if m:
            return m.group(1)

    return None

def get_ancestral(tabix, chrom, pos):
    pos0 = pos - 1
    try:
        it = tabix.fetch(chrom, pos0, pos)
    except Exception:
        return None

    for line in it:
        if not line.strip() or line.startswith("#"):
            continue
        cols = line.rstrip("\n").split("\t")
        if len(cols) < 4:
            continue

        try:
            s = int(cols[1])
            e = int(cols[2])
        except ValueError:
            continue

        if s <= pos0 < e:
            return parse_ancestral(cols)

    return None

###############################################################################
# SIFT classification
###############################################################################

def extract_sift_scores(info):
    scores = []
    for field in info.split(";"):
        if "sift" not in field.lower():
            continue

        nums = re.findall(
            r"(?<![A-Za-z0-9_.])(?:0(?:\.\d+)?|1(?:\.0+)?|\.\d+)(?![A-Za-z0-9_.])",
            field
        )

        for x in nums:
            try:
                v = float(x)
            except Exception:
                continue
            if 0.0 <= v <= 1.0:
                scores.append(v)

    return scores

def classify_sift(info):
    low = info.lower()

    has_syn = (
        "synonymous_variant" in low
        or re.search(r"\bsynonymous\b", low) is not None
    )

    has_nonsyn = (
        "nonsynonymous" in low
        or "non_synonymous" in low
        or "missense" in low
    )

    # Synonymous first, but only when it is not mixed with nonsynonymous/missense.
    if has_syn and not has_nonsyn:
        return "SIFT_synonymous"

    scores = extract_sift_scores(info)

    if scores:
        if min(scores) < 0.05:
            return "SIFT_lt0.05"
        else:
            return "SIFT_tolerated"

    if re.search(r"(deleterious|damaging)", low):
        return "SIFT_lt0.05"

    if re.search(r"(tolerated|benign)", low):
        return "SIFT_tolerated"

    return None

###############################################################################
# Counters
###############################################################################

def init_counter():
    return {
        "n_called_sites": 0,
        "called_alleles": 0,
        "allele_count": 0,
        "hom_count": 0,
        "het_count": 0,
        "partial_count": 0,
        "zero_count": 0,
    }

def add_count(c, dosage, ploidy):
    c["n_called_sites"] += 1
    c["called_alleles"] += ploidy
    c["allele_count"] += dosage

    if dosage == 0:
        c["zero_count"] += 1
    elif dosage == ploidy:
        c["hom_count"] += 1
    elif 0 < dosage < ploidy:
        c["het_count"] += 1
        c["partial_count"] += 1
    else:
        c["partial_count"] += 1

def rates(c):
    nsite = c["n_called_sites"]
    nallele = c["called_alleles"]

    allele_rate = c["allele_count"] / nallele if nallele else "NA"
    hom_rate = c["hom_count"] / nsite if nsite else "NA"
    het_rate = c["het_count"] / nsite if nsite else "NA"
    load05 = c["hom_count"] + 0.5 * c["het_count"]
    load05_per_site = load05 / nsite if nsite else "NA"

    return allele_rate, hom_rate, het_rate, load05, load05_per_site

def fmt(x):
    if x == "NA" or x is None:
        return "NA"
    if isinstance(x, float):
        return f"{x:.10g}"
    return str(x)

def parse_gt(sample_field, gt_index):
    a = sample_field.split(":")
    if gt_index >= len(a):
        return None

    gt = a[gt_index]

    if gt in {".", "./.", ".|."}:
        return None

    sep = "/" if "/" in gt else "|"
    alleles = gt.split(sep)

    out = []
    for x in alleles:
        if x == ".":
            return None
        try:
            out.append(int(x))
        except Exception:
            return None

    return out

###############################################################################
# VCF processing
###############################################################################

def process_vcf(vcf_path, subgenome, chrom_map, ancestral, roh_idx, sample_acc, site_out, stats):
    with open_text(vcf_path) as f:
        samples = None

        for line in f:
            if not line.strip():
                continue

            if line.startswith("##"):
                continue

            if line.startswith("#CHROM"):
                header = line.rstrip("\n").split("\t")
                samples = header[9:]
                stats[(subgenome, "n_samples")] = len(samples)
                continue

            if line.startswith("#"):
                continue

            if samples is None:
                continue

            a = line.rstrip("\n").split("\t")
            if len(a) < 10:
                stats[(subgenome, "malformed_records")] += 1
                continue

            chrom0, pos_s, vid, ref, alt, qual, flt, info, fmt_field = a[:9]
            sample_fields = a[9:]

            chrom = map_chrom(chrom0, chrom_map)

            try:
                pos = int(pos_s)
            except ValueError:
                stats[(subgenome, "bad_position")] += 1
                continue

            ref = ref.upper()
            alt = alt.upper()

            if "," in alt or len(ref) != 1 or len(alt) != 1:
                stats[(subgenome, "non_biallelic_or_non_snp")] += 1
                continue

            if ref not in {"A", "C", "G", "T"} or alt not in {"A", "C", "G", "T"}:
                stats[(subgenome, "non_acgt")] += 1
                continue

            variant_class = classify_sift(info)

            if variant_class is None:
                stats[(subgenome, "unknown_sift_class")] += 1
                continue

            stats[(subgenome, variant_class)] += 1

            fmt_keys = fmt_field.split(":")
            if "GT" not in fmt_keys:
                stats[(subgenome, "no_GT_field")] += 1
                continue

            gt_index = fmt_keys.index("GT")

            aa = get_ancestral(ancestral, chrom, pos)
            if aa:
                aa = aa.upper()

            polar_mode = None
            derived_allele = None

            if aa == ref:
                polar_mode = "ALT_DERIVED"
                derived_allele = alt
                stats[(subgenome, "polarized_sites")] += 1
            elif aa == alt:
                polar_mode = "REF_DERIVED"
                derived_allele = ref
                stats[(subgenome, "polarized_sites")] += 1
            else:
                stats[(subgenome, "not_polarized_sites")] += 1

            site_counters = {}

            for layer in ["unpolarized_alt", "polarized_derived"]:
                if layer == "polarized_derived" and polar_mode is None:
                    continue
                for region in ["ALL", "ROH", "nonROH"]:
                    site_counters[(layer, region)] = init_counter()

            for sample, sf in zip(samples, sample_fields):
                gt = parse_gt(sf, gt_index)

                if gt is None:
                    continue

                # This pipeline is for biallelic SNPs.
                if any(x > 1 for x in gt):
                    continue

                ploidy = len(gt)
                if ploidy == 0:
                    continue

                alt_dosage = sum(1 for x in gt if x == 1)
                region = "ROH" if is_in_roh(roh_idx, sample, chrom, pos) else "nonROH"

                # Layer 1: unpolarized ALT dosage.
                for rg in ["ALL", region]:
                    add_count(
                        sample_acc[(sample, subgenome, variant_class, "unpolarized_alt", rg)],
                        alt_dosage,
                        ploidy
                    )
                    add_count(site_counters[("unpolarized_alt", rg)], alt_dosage, ploidy)

                # Layer 2: polarized derived dosage.
                if polar_mode is not None:
                    if polar_mode == "ALT_DERIVED":
                        derived_dosage = alt_dosage
                    else:
                        derived_dosage = ploidy - alt_dosage

                    for rg in ["ALL", region]:
                        add_count(
                            sample_acc[(sample, subgenome, variant_class, "polarized_derived", rg)],
                            derived_dosage,
                            ploidy
                        )
                        add_count(site_counters[("polarized_derived", rg)], derived_dosage, ploidy)

            for layer in ["unpolarized_alt", "polarized_derived"]:
                if layer == "polarized_derived" and polar_mode is None:
                    continue

                target = alt if layer == "unpolarized_alt" else derived_allele

                for rg in ["ALL", "ROH", "nonROH"]:
                    c = site_counters.get((layer, rg))
                    if c is None or c["called_alleles"] == 0:
                        continue

                    ar, hr, her, load05, load05ps = rates(c)

                    row = [
                        subgenome,
                        variant_class,
                        layer,
                        rg,
                        chrom,
                        str(pos),
                        ref,
                        alt,
                        aa if aa else ".",
                        target if target else ".",
                        str(c["n_called_sites"]),
                        str(c["called_alleles"]),
                        str(c["allele_count"]),
                        str(c["hom_count"]),
                        str(c["het_count"]),
                        str(c["partial_count"]),
                        str(c["zero_count"]),
                        fmt(ar),
                        fmt(hr),
                        fmt(her),
                    ]

                    site_out.write("\t".join(row) + "\n")

###############################################################################
# PedALL merging
###############################################################################

def make_pedall(sample_acc):
    new_items = {}

    for key, c in sample_acc.items():
        sample, subgenome, variant_class, layer, region = key

        if subgenome not in {"PedC", "PedD"}:
            continue

        key2 = (sample, "PedALL", variant_class, layer, region)

        if key2 not in new_items:
            new_items[key2] = init_counter()

        for k in new_items[key2]:
            new_items[key2][k] += c[k]

    for k, v in new_items.items():
        sample_acc[k] = v

def write_roh_check(roh_idx, out_path):
    with open(out_path, "w") as out:
        out.write("sample\tmapped_chrom\tn_intervals\n")
        for sample in sorted(roh_idx):
            for chrom in sorted(roh_idx[sample]):
                starts, ends = roh_idx[sample][chrom]
                out.write(f"{sample}\t{chrom}\t{len(starts)}\n")

###############################################################################
# Main
###############################################################################

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--sift-c", required=True)
    ap.add_argument("--sift-d", required=True)
    ap.add_argument("--chrom-map", required=True)
    ap.add_argument("--ancestral-bed", required=True)
    ap.add_argument("--roh", required=True)
    ap.add_argument("--froh", required=True)
    ap.add_argument("--out-prefix", required=True)
    args = ap.parse_args()

    chrom_map = read_chrom_map(args.chrom_map)
    ancestral = pysam.TabixFile(args.ancestral_bed)

    roh_idx = read_roh(args.roh, chrom_map)
    froh = read_froh(args.froh)

    sample_acc = defaultdict(init_counter)
    stats = Counter()

    site_path = args.out_prefix + ".PedC_PedD.site_AF.tsv.gz"
    sample_path = args.out_prefix + ".PedC_PedD_PedALL.per_sample_burden.tsv"
    stats_path = args.out_prefix + ".classification_stats.tsv"
    roh_check_path = args.out_prefix + ".ROH_mapping_check.tsv"

    write_roh_check(roh_idx, roh_check_path)

    site_out = open_write(site_path)

    site_header = [
        "subgenome",
        "variant_class",
        "layer",
        "region",
        "chrom",
        "pos",
        "ref",
        "alt",
        "ancestral_allele",
        "target_allele",
        "n_called_samples",
        "called_alleles",
        "allele_count",
        "hom_count",
        "het_count",
        "partial_count",
        "zero_count",
        "allele_rate",
        "hom_loci_rate",
        "het_loci_rate",
    ]
    site_out.write("\t".join(site_header) + "\n")

    process_vcf(args.sift_c, "PedC", chrom_map, ancestral, roh_idx, sample_acc, site_out, stats)
    process_vcf(args.sift_d, "PedD", chrom_map, ancestral, roh_idx, sample_acc, site_out, stats)

    site_out.close()

    make_pedall(sample_acc)

    with open(sample_path, "w") as out:
        header = [
            "sample",
            "subgenome",
            "variant_class",
            "layer",
            "region",
            "n_called_sites",
            "called_alleles",
            "allele_count",
            "hom_count",
            "het_count",
            "partial_count",
            "zero_count",
            "allele_rate",
            "hom_loci_rate",
            "het_loci_rate",
            "load_0.5",
            "load_0.5_per_site",
            "FROH",
        ]

        out.write("\t".join(header) + "\n")

        for key in sorted(sample_acc):
            sample, subgenome, variant_class, layer, region = key
            c = sample_acc[key]
            ar, hr, her, load05, load05ps = rates(c)

            row = [
                sample,
                subgenome,
                variant_class,
                layer,
                region,
                str(c["n_called_sites"]),
                str(c["called_alleles"]),
                str(c["allele_count"]),
                str(c["hom_count"]),
                str(c["het_count"]),
                str(c["partial_count"]),
                str(c["zero_count"]),
                fmt(ar),
                fmt(hr),
                fmt(her),
                fmt(load05),
                fmt(load05ps),
                froh.get(sample, "NA"),
            ]

            out.write("\t".join(row) + "\n")

    with open(stats_path, "w") as out:
        out.write("subgenome\tmetric\tcount\n")
        for (sg, metric), count in sorted(stats.items()):
            out.write(f"{sg}\t{metric}\t{count}\n")

    sys.stderr.write(f"[INFO] Wrote: {sample_path}\n")
    sys.stderr.write(f"[INFO] Wrote: {site_path}\n")
    sys.stderr.write(f"[INFO] Wrote: {stats_path}\n")
    sys.stderr.write(f"[INFO] Wrote: {roh_check_path}\n")

if __name__ == "__main__":
    main()
PY

chmod +x "${SCRIPT_DIR}/calc_Ped_SIFT_polar_unpolar.py"

python3 "${SCRIPT_DIR}/calc_Ped_SIFT_polar_unpolar.py" \
    --sift-c "${SIFT_C}" \
    --sift-d "${SIFT_D}" \
    --chrom-map "${CHROM_MAP}" \
    --ancestral-bed "${ANCESTRAL_BED}" \
    --roh "${ROH_SEG}" \
    --froh "${FROH_FILE}" \
    --out-prefix "${SUMMARY_DIR}/Ped_SIFT" \
    > "${LOG_DIR}/00_run_Ped_SIFT_polar_unpolar.out" \
    2> "${LOG_DIR}/00_run_Ped_SIFT_polar_unpolar.err"

echo "============================================================"
echo "[DONE] Ped SIFT burden calculation finished."
echo ""
echo "[Output]"
echo "${SUMMARY_DIR}/Ped_SIFT.PedC_PedD_PedALL.per_sample_burden.tsv"
echo "${SUMMARY_DIR}/Ped_SIFT.PedC_PedD.site_AF.tsv.gz"
echo "${SUMMARY_DIR}/Ped_SIFT.classification_stats.tsv"
echo "${SUMMARY_DIR}/Ped_SIFT.ROH_mapping_check.tsv"
echo ""
echo "[Log]"
echo "${LOG_DIR}/00_run_Ped_SIFT_polar_unpolar.err"
echo ""
echo "[Check ROH rows]"
echo "awk -F'\\t' '\$2==\"PedALL\"{print \$4,\$3,\$5,\$6}' ${SUMMARY_DIR}/Ped_SIFT.PedC_PedD_PedALL.per_sample_burden.tsv | sort | uniq -c"
echo "============================================================"
