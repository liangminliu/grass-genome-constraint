#!/usr/bin/env bash
set -euo pipefail

export SPECIES="Atau"

export WORKDIR="/gpfs/hpc/home/kib_unit/lidezhu/liuliangmin/6.pop/05.FROH"

# SIFT4G annotated VCF
export SIFT_VCF="/gpfs/hpc/home/kib_unit/lidezhu/liuliangmin/2.msa/Atau_msa/pop/04_SIFT/SIFI_annotator/SIFT4G_results/141sp.filtered.bi-allelic.snp_SIFTpredictions.vcf"

# PLINK ROH/FROH version: kb100 + gap1000 + winmiss5 + no BW_01192
export FROH_DIR="${WORKDIR}/ROH_pipeline/Atau/04_froh/plink_kb100_gap1000_winmiss5_noBW01192"

export FROH_FILE="${FROH_DIR}/FROH.final.plink.kb100_gap1000_winmiss5_noBW01192.tsv"

export ROH_SEG_FILE="${FROH_DIR}/ROH.segments.plink.ge100000.minSNP50.kb100_gap1000_winmiss5_noBW01192.classified.tsv"

export LAUTO_FILE="${WORKDIR}/ROH_pipeline/Atau/04_froh/Lauto.from_filtered_SNPs.tsv"

export OUTDIR="${WORKDIR}/Atau_SIFT_ratio_updated/results"
export LOGDIR="${WORKDIR}/Atau_SIFT_ratio_updated/logs"
export PREFIX="Atau_SIFT3_plinkROH_kb100_gap1000_winmiss5_noBW01192"

export SIFT_CUTOFF="0.05"

# 这个样本已经在 PLINK 结果中去掉，但这里保留，防止表格中还有残留
export EXCLUDE_SAMPLES="BW_01192"

export ALLELE_MODE="alt"
export ALLOW_SIFT_WITHOUT_EFFECT="1"

export AF_BINWIDTH="0.05"
export FIG_DPI="600"

mkdir -p "${OUTDIR}" "${LOGDIR}"
