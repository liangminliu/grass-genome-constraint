#!/usr/bin/env bash
set -euo pipefail

# ============================================================
# Teosinte GERP burden workflow: UNPOLARIZED ONLY
#
# This workflow uses raw ALT allele dosage:
#   0/0 -> 0
#   0/1 -> 1
#   1/1 -> 2
#
# No ancestral allele file is used.
# No derived allele polarization is performed.
# ============================================================

# Run from:
# /gpfs/hpc/home/kib_unit/lidezhu/liuliangmin/6.pop/05.FROH

BASE="Teosinte_GERP_unpolarized_pipeline"
SCRIPT_DIR="${BASE}/scripts"
TABLE_DIR="${BASE}/01_tables"
LOG_DIR="${BASE}/logs"
VCF_FIX_DIR="${BASE}/00_vcf_fix"

mkdir -p "${TABLE_DIR}" "${LOG_DIR}" "${VCF_FIX_DIR}"

# -----------------------------
# Input VCFs
# -----------------------------
GT4_SRC="${GT4_SRC:-Teosinte_merged_gt4_snps.vcf.gz}"
LT0_SRC="${LT0_SRC:-GERP_neutral/Teosinte/03_vcf/Teosinte_merged_lt0_snps.vcf.gz}"

# If GERP > 4 file is stored under GERP_neutral/Teosinte/03_vcf, use it automatically.
if [[ ! -s "${GT4_SRC}" && -s "GERP_neutral/Teosinte/03_vcf/Teosinte_merged_gt4_snps.vcf.gz" ]]; then
  GT4_SRC="GERP_neutral/Teosinte/03_vcf/Teosinte_merged_gt4_snps.vcf.gz"
fi

# -----------------------------
# ROH / FROH input
# -----------------------------
FROH_FILE="${FROH_FILE:-ROH_pipeline/Teosinte/04_froh/plink_kb100_gap1000_winmiss5/FROH.final.plink.kb100_gap1000_winmiss5.tsv}"

ROH_SEG_FILE="${ROH_SEG_FILE:-ROH_pipeline/Teosinte/04_froh/plink_kb100_gap1000_winmiss5/ROH.segments.plink.ge100000.minSNP50.kb100_gap1000_winmiss5.classified.tsv}"

# -----------------------------
# Fixed local VCFs
# -----------------------------
GT4_VCF="${VCF_FIX_DIR}/Teosinte_merged_gt4_snps.rebgzip.vcf.gz"
LT0_VCF="${VCF_FIX_DIR}/Teosinte_merged_lt0_snps.rebgzip.vcf.gz"

# -----------------------------
# Environment checks
# -----------------------------
for x in python3 bgzip tabix zcat; do
  command -v "${x}" >/dev/null || {
    echo "[ERROR] ${x} not found" >&2
    exit 1
  }
done

python3 - <<'PY'
try:
    import pysam
except Exception:
    raise SystemExit("[ERROR] Python package pysam is required. Install with: conda install -c bioconda pysam")
PY

# -----------------------------
# Input checks
# -----------------------------
for f in "${GT4_SRC}" "${LT0_SRC}" "${FROH_FILE}" "${ROH_SEG_FILE}"; do
  if [[ ! -s "${f}" ]]; then
    echo "[ERROR] Missing input file: ${f}" >&2
    exit 1
  fi
done

echo "[INFO] GT4_SRC      = ${GT4_SRC}"
echo "[INFO] LT0_SRC      = ${LT0_SRC}"
echo "[INFO] FROH_FILE    = ${FROH_FILE}"
echo "[INFO] ROH_SEG_FILE = ${ROH_SEG_FILE}"

# -----------------------------
# Function: rebuild clean bgzip VCF
# -----------------------------
fix_vcf() {
  local src="$1"
  local out="$2"
  local log="$3"

  echo "[INFO] Re-bgzip and index:"
  echo "[INFO]   source = ${src}"
  echo "[INFO]   output = ${out}"

  rm -f "${out}" "${out}.tbi" "${out}.csi"

  zcat -f "${src}" | bgzip -@ 4 -c > "${out}"
  tabix -f -p vcf "${out}"

  bgzip -t "${out}" 2> "${log}" || {
    echo "[ERROR] bgzip test failed: ${out}" >&2
    cat "${log}" >&2
    exit 1
  }

  if grep -q "EOF marker is absent" "${log}"; then
    echo "[ERROR] BGZF EOF marker is absent after rebuilding: ${out}" >&2
    cat "${log}" >&2
    exit 1
  fi

  if [[ ! -s "${out}.tbi" && ! -s "${out}.csi" ]]; then
    echo "[ERROR] Missing tabix index: ${out}" >&2
    exit 1
  fi
}

# -----------------------------
# Step 1. Clean and index VCFs
# -----------------------------
fix_vcf "${GT4_SRC}" "${GT4_VCF}" "${LOG_DIR}/Teosinte_gt4.bgzip_check.log"
fix_vcf "${LT0_SRC}" "${LT0_VCF}" "${LOG_DIR}/Teosinte_lt0.bgzip_check.log"

# -----------------------------
# Step 2. Remove old tables
# -----------------------------
rm -f "${TABLE_DIR}"/*.tsv

# -----------------------------
# Step 3. Compute unpolarized ALT burden
# -----------------------------
python3 "${SCRIPT_DIR}/01_compute_Teosinte_GERP_unpolarized.py" \
  --vcf "GERP4:Teosinte_gt4:${GT4_VCF}" \
  --vcf "GERP_lt0:Teosinte_lt0:${LT0_VCF}" \
  --froh "${FROH_FILE}" \
  --roh "${ROH_SEG_FILE}" \
  --outdir "${TABLE_DIR}" \
  --chrom-normalize auto \
  > "${LOG_DIR}/01_compute.stdout.log" \
  2> "${LOG_DIR}/01_compute.stderr.log"

# -----------------------------
# Step 4. Required output checks
# -----------------------------
required=(
  "Teosinte_GERP.site_AF.tsv"
  "plot_A_site_spectrum.tsv"
  "Teosinte_GERP.per_sample_burden.tsv"
  "plot_BC_GERP4_burden.tsv"
  "plot_DE_GERP4_over_lt0_ratio.tsv"
  "plot_F_ROH_nonROH_burden.tsv"
  "plot_GH_ROH_nonROH_ratio.tsv"
  "Teosinte_GERP.diagnostics.tsv"
)

for x in "${required[@]}"; do
  if [[ ! -s "${TABLE_DIR}/${x}" ]]; then
    echo "[ERROR] Expected output missing: ${TABLE_DIR}/${x}" >&2
    echo "[ERROR] Check log: ${LOG_DIR}/01_compute.stderr.log" >&2
    exit 1
  fi
done

echo "[INFO] Output tables:"
ls -lh "${TABLE_DIR}"/*.tsv

echo "[INFO] Diagnostics:"
cat "${TABLE_DIR}/Teosinte_GERP.diagnostics.tsv"

echo "[DONE] Teosinte unpolarized GERP burden tables written to ${TABLE_DIR}"
