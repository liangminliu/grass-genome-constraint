#!/usr/bin/env bash
set -euo pipefail

BASE="${BASE:-Ped_GERP_fullgenome_pipeline}"
SCRIPT_DIR="${SCRIPT_DIR:-${BASE}/scripts}"
OUT_DIR="${OUT_DIR:-${BASE}/04_Ped_ROH_FROH}"

FROH_FILE="${FROH_FILE:-ROH_pipeline/Ped/04_froh/plink_kb100_gap1000_winmiss5/FROH.final.plink.kb100_gap1000_winmiss5.tsv}"
ROH_SEG_FILE="${ROH_SEG_FILE:-ROH_pipeline/Ped/04_froh/plink_kb100_gap1000_winmiss5/ROH.segments.plink.ge100000.minSNP50.kb100_gap1000_winmiss5.classified.tsv}"
RAW_VCF="${RAW_VCF:-extracted_63sp_chr.vcf.gz}"
CHR_MAP="${CHR_MAP:-${BASE}/00_inputs/chrom_map.txt}"

CHR_SIZE="${OUT_DIR}/00_inputs/Ped.chrom_sizes.tsv"
TABLE_PREFIX="${OUT_DIR}/01_tables/Ped_ROH_FROH"
PLOT_PREFIX="${OUT_DIR}/02_plots/Ped_ROH_FROH"

MIN_ROH_BP="${MIN_ROH_BP:-100000}"
FREQ_ROH_BP="${FREQ_ROH_BP:-100000}"        # D 图: >=100 kb
LANDSCAPE_ROH_BP="${LANDSCAPE_ROH_BP:-100000}"
WINDOW_BP="${WINDOW_BP:-1000000}"           # D 图窗口: 1 Mb
REPRESENTATIVE_N="${REPRESENTATIVE_N:-5}"
EXCLUDE_SAMPLES="${EXCLUDE_SAMPLES:-none}"
SPECIES_LABEL="${SPECIES_LABEL:-Phyllostachys edulis}"

mkdir -p "${OUT_DIR}/00_inputs" "${OUT_DIR}/01_tables" "${OUT_DIR}/02_plots" "${OUT_DIR}/logs"

echo "============================================================"
echo "[INFO] Ped ROH/FROH visualization"
echo "[INFO] BASE              = ${BASE}"
echo "[INFO] SCRIPT_DIR        = ${SCRIPT_DIR}"
echo "[INFO] OUT_DIR           = ${OUT_DIR}"
echo "[INFO] FROH_FILE         = ${FROH_FILE}"
echo "[INFO] ROH_SEG_FILE      = ${ROH_SEG_FILE}"
echo "[INFO] RAW_VCF           = ${RAW_VCF}"
echo "[INFO] CHR_MAP           = ${CHR_MAP}"
echo "[INFO] CHR_SIZE          = ${CHR_SIZE}"
echo "[INFO] TABLE_PREFIX      = ${TABLE_PREFIX}"
echo "[INFO] PLOT_PREFIX       = ${PLOT_PREFIX}"
echo "[INFO] MIN_ROH_BP        = ${MIN_ROH_BP}"
echo "[INFO] FREQ_ROH_BP       = ${FREQ_ROH_BP}"
echo "[INFO] LANDSCAPE_ROH_BP  = ${LANDSCAPE_ROH_BP}"
echo "[INFO] WINDOW_BP         = ${WINDOW_BP}"
echo "[INFO] REPRESENTATIVE_N  = ${REPRESENTATIVE_N}"
echo "[INFO] EXCLUDE_SAMPLES   = ${EXCLUDE_SAMPLES}"
echo "============================================================"

if [[ ! -s "${FROH_FILE}" ]]; then
  echo "[ERROR] FROH file not found: ${FROH_FILE}" >&2
  exit 1
fi

if [[ ! -s "${ROH_SEG_FILE}" ]]; then
  echo "[ERROR] ROH segment file not found: ${ROH_SEG_FILE}" >&2
  exit 1
fi

if [[ ! -s "${CHR_MAP}" ]]; then
  echo "[ERROR] chrom_map.txt not found: ${CHR_MAP}" >&2
  echo "[ERROR] Please create ${CHR_MAP} first." >&2
  exit 1
fi

if [[ -s "${RAW_VCF}" ]]; then
  echo "[INFO] Build chromosome-size table from bcftools index -s: ${RAW_VCF}"
  bcftools index -s "${RAW_VCF}" | \
    awk 'BEGIN{OFS="\t"; print "chr","start_bp","end_bp","Lauto_bp"} {print $1,1,$2,$2}' \
    > "${CHR_SIZE}"
else
  echo "[ERROR] RAW_VCF not found: ${RAW_VCF}" >&2
  exit 1
fi

python3 "${SCRIPT_DIR}/01_prepare_Ped_ROH_FROH_tables.py" \
  --froh "${FROH_FILE}" \
  --roh "${ROH_SEG_FILE}" \
  --lauto "${CHR_SIZE}" \
  --chrom-map "${CHR_MAP}" \
  --out-prefix "${TABLE_PREFIX}" \
  --exclude-samples "${EXCLUDE_SAMPLES}" \
  --min-roh-bp "${MIN_ROH_BP}" \
  --freq-roh-bp "${FREQ_ROH_BP}" \
  --landscape-roh-bp "${LANDSCAPE_ROH_BP}" \
  --window-bp "${WINDOW_BP}" \
  --representative-n "${REPRESENTATIVE_N}"

Rscript "${SCRIPT_DIR}/02_plot_Ped_ROH_FROH_final.R" \
  "${TABLE_PREFIX}" \
  "${PLOT_PREFIX}" \
  "${SPECIES_LABEL}"

echo "[DONE] All Ped ROH/FROH tables and plots finished."