#!/usr/bin/env bash
set -euo pipefail

## =========================================================
## Input VCFs
## =========================================================
export PEDC_SIFT_VCF="PedC_subgenome_complete_SIFTpredictions.vcf"
export PEDD_SIFT_VCF="PedD_subgenome_complete_SIFTpredictions.vcf"

## =========================================================
## PLINK ROH/FROH results
## =========================================================
export FROH_FILE="ROH_pipeline/Ped/04_froh/plink/FROH.final.plink.local3.tsv"
export ROH_SEG_FILE="ROH_pipeline/Ped/04_froh/plink/ROH.segments.plink.ge100000.minSNP50.classified.tsv"

## =========================================================
## Optional chromosome map
## If VCF chromosome names and ROH chromosome names do not match,
## create a two-column file:
##   VCF_chrom<TAB>ROH_chrom
##
## Example:
##   Ped01C  1
##   Ped02C  2
##
## Empty means using automatic aliases.
## =========================================================
export CHROM_MAP=""

## =========================================================
## Output directories
## =========================================================
export ROOT="Ped_SIFT_ratio_pipeline"

export PED_OUTDIR="${ROOT}/results/Ped_complete"
export PEDC_OUTDIR="${ROOT}/results/Ped_subgenome/pedC"
export PEDD_OUTDIR="${ROOT}/results/Ped_subgenome/pedD"
export LOGDIR="${ROOT}/logs"

## =========================================================
## Output prefixes
## =========================================================
export PED_PREFIX="Ped_SIFT_plinkROH"
export PEDC_PREFIX="pedC_SIFT_plinkROH"
export PEDD_PREFIX="pedD_SIFT_plinkROH"

## =========================================================
## Parameters
## =========================================================
export SIFT_CUTOFF="0.05"

## Example: export EXCLUDE_SAMPLES="sample1,sample2"
export EXCLUDE_SAMPLES="none"

## Keep compatible with previous command line.
## This version mainly uses SIFTINFO directly.
export ALLOW_SIFT_WITHOUT_EFFECT="0"
