#!/usr/bin/env Rscript

suppressPackageStartupMessages({
  library(readr)
  library(dplyr)
  library(tidyr)
  library(ggplot2)
  library(patchwork)
  library(scales)
})

args <- commandArgs(trailingOnly = TRUE)

if (length(args) < 2) {
  stop("Usage:
Rscript 02_plot_Teosinte_GERP_unpolarized_AH.R <table_dir> <out_prefix> [af_binwidth]

Example:
Rscript Teosinte_GERP_unpolarized_pipeline/scripts/02_plot_Teosinte_GERP_unpolarized_AH.R \
  Teosinte_GERP_unpolarized_pipeline/01_tables \
  Teosinte_GERP_unpolarized_pipeline/03_plots/Teosinte_GERP_unpolarized \
  0.025
")
}

table_dir <- args[1]
out_prefix <- args[2]
af_binwidth <- ifelse(length(args) >= 3, as.numeric(args[3]), 0.025)

dir.create(dirname(out_prefix), recursive = TRUE, showWarnings = FALSE)

read_tsv2 <- function(x) {
  read_tsv(
    file.path(table_dir, x),
    show_col_types = FALSE,
    progress = FALSE,
    na = c("NA", "NaN", "nan", "")
  )
}

to_num <- function(df) {
  df %>%
    mutate(across(everything(), ~ suppressWarnings(type.convert(.x, as.is = TRUE))))
}

save_both <- function(plot, prefix, width, height) {
  pdf_file <- paste0(prefix, ".pdf")
  png_file <- paste0(prefix, ".png")
  pdf_dev <- if (capabilities("cairo")) grDevices::cairo_pdf else grDevices::pdf
  ggsave(pdf_file, plot, width = width, height = height, units = "in", device = pdf_dev)
  ggsave(png_file, plot, width = width, height = height, units = "in", dpi = 600)
  message("[WRITE] ", pdf_file)
  message("[WRITE] ", png_file)
}

theme_pub <- function(base_size = 12) {
  theme_classic(base_size = base_size) +
    theme(
      text = element_text(color = "grey15"),
      axis.text = element_text(color = "grey25", size = base_size),
      axis.title = element_text(color = "grey10", size = base_size + 1),
      axis.line = element_line(color = "grey30", linewidth = 0.45),
      axis.ticks = element_line(color = "grey30", linewidth = 0.35),
      panel.grid.major.y = element_line(color = "grey90", linewidth = 0.34),
      panel.grid.major.x = element_blank(),
      panel.grid.minor = element_blank(),
      plot.title = element_text(hjust = 0.5, face = "plain", size = base_size + 1),
      plot.subtitle = element_text(hjust = 0, color = "grey35", size = base_size),
      plot.tag = element_text(face = "bold", size = base_size + 5),
      legend.title = element_blank(),
      legend.key = element_blank(),
      legend.position = "top",
      legend.text = element_text(size = base_size - 1),
      strip.background = element_rect(fill = "white", color = "grey25", linewidth = 0.45),
      strip.text = element_text(face = "bold", size = base_size - 1),
      plot.margin = margin(5, 5, 5, 5)
    )
}

fmt_p <- function(p) {
  if (!is.finite(p)) return("p = NA")
  if (p < 0.001) return("p < 0.001")
  paste0("p = ", formatC(p, format = "f", digits = 3))
}

lm_p <- function(x, y) {
  ok <- is.finite(x) & is.finite(y)
  x <- x[ok]
  y <- y[ok]
  if (length(x) < 4) return(NA_real_)
  if (length(unique(x)) < 2 || length(unique(y)) < 2) return(NA_real_)
  fit <- try(lm(y ~ x), silent = TRUE)
  if (inherits(fit, "try-error")) return(NA_real_)
  coef(summary(fit))[2, 4]
}

safe_paired_wilcox <- function(nonroh, roh) {
  ok <- is.finite(nonroh) & is.finite(roh)
  if (sum(ok) < 4) return(NA_real_)
  suppressWarnings(wilcox.test(nonroh[ok], roh[ok], paired = TRUE)$p.value)
}

p_stars <- function(p) {
  if (!is.finite(p)) return("NA")
  if (p < 0.001) return("***")
  if (p < 0.01) return("**")
  if (p < 0.05) return("*")
  "ns"
}

nice_y_top <- function(x) {
  if (!is.finite(x) || x <= 0) return(1)
  if (x <= 1) return(ceiling(x * 10) / 10)
  if (x <= 5) return(ceiling(x))
  if (x <= 10) return(ceiling(x))
  if (x <= 50) return(ceiling(x / 5) * 5)
  if (x <= 100) return(ceiling(x / 10) * 10)
  if (x <= 1000) return(ceiling(x / 50) * 50)
  if (x <= 10000) return(ceiling(x / 500) * 500)
  if (x <= 100000) return(ceiling(x / 5000) * 5000)
  ceiling(x / 10000) * 10000
}

nice_x_step <- function(xmax) {
  if (!is.finite(xmax) || xmax <= 0) return(100)
  if (xmax <= 1000) return(100)
  if (xmax <= 5000) return(500)
  if (xmax <= 20000) return(2000)
  if (xmax <= 50000) return(5000)
  if (xmax <= 150000) return(25000)
  if (xmax <= 400000) return(50000)
  if (xmax <= 800000) return(100000)
  200000
}

# -----------------------------
# Colors
# -----------------------------
col_gt4 <- "#4E8A83"
col_het <- "#B6D2CD"
col_hom <- "#2E6F73"
col_total <- "#DDEDEA"

col_nonroh <- "#8D78C9"
col_roh <- "#E3A857"
col_gerpneg <- "#B7B7B7"

comp_cols <- c(
  "Total" = col_total,
  "Homozygous" = col_hom,
  "Heterozygous" = col_het
)

region_cols <- c(
  "Non-ROH" = col_nonroh,
  "ROH" = col_roh
)

allele_label <- "ALT alleles"

# -----------------------------
# Read tables
# -----------------------------
site <- read_tsv2("Teosinte_GERP.site_AF.tsv") %>%
  to_num() %>%
  mutate(
    variant_class = recode(
      as.character(variant_class),
      "GERP4" = "GERP > 4",
      "GERP_lt0" = "GERP < 0"
    ),
    AF = as.numeric(target_af)
  ) %>%
  filter(is.finite(AF), AF >= 0, AF <= 1)

bc <- read_tsv2("plot_BC_GERP4_burden.tsv") %>%
  to_num() %>%
  mutate(
    sample = as.character(sample),
    FROH = as.numeric(FROH),
    value_count = as.numeric(value_count),
    value_rate = as.numeric(value_rate)
  ) %>%
  filter(is.finite(FROH))

ratio_all_in <- read_tsv2("plot_DE_GERP4_over_lt0_ratio.tsv") %>%
  to_num() %>%
  mutate(
    sample = as.character(sample),
    FROH = as.numeric(FROH),
    ratio_rate = as.numeric(ratio_rate)
  ) %>%
  filter(is.finite(FROH), is.finite(ratio_rate))

roh_ratio_in <- read_tsv2("plot_GH_ROH_nonROH_ratio.tsv") %>%
  to_num() %>%
  mutate(
    sample = as.character(sample),
    FROH = as.numeric(FROH),
    ratio_rate = as.numeric(ratio_rate),
    region = recode(as.character(region), "nonROH" = "Non-ROH", "ROH" = "ROH")
  ) %>%
  filter(is.finite(FROH), is.finite(ratio_rate))

# =========================================================
# A. AF histogram
# =========================================================

make_af_table <- function(df, classes, bw) {
  nbin <- round(1 / bw)

  grid <- expand_grid(
    variant_class = classes,
    bin_i = 0:(nbin - 1)
  )

  tab <- df %>%
    filter(variant_class %in% classes) %>%
    mutate(bin_i = pmin(nbin - 1, pmax(0, floor(AF / bw)))) %>%
    count(variant_class, bin_i, name = "n") %>%
    group_by(variant_class) %>%
    mutate(pct = 100 * n / sum(n)) %>%
    ungroup()

  grid %>%
    left_join(tab, by = c("variant_class", "bin_i")) %>%
    mutate(
      n = replace_na(n, 0),
      pct = replace_na(pct, 0),
      xmin = bin_i * bw,
      xmax = (bin_i + 1) * bw,
      xmid = (xmin + xmax) / 2
    )
}

af_gt4 <- make_af_table(site, c("GERP > 4"), af_binwidth)
ymax_A <- nice_y_top(max(af_gt4$pct, na.rm = TRUE))

pA <- ggplot(af_gt4) +
  geom_rect(
    aes(xmin = xmin, xmax = xmax, ymin = 0, ymax = pct),
    fill = col_gt4,
    colour = "black",
    linewidth = 0.12
  ) +
  scale_x_continuous(
    limits = c(-af_binwidth * 0.65, 1 + af_binwidth * 0.30),
    breaks = c(0, 0.25, 0.50, 0.75, 1.00),
    labels = number_format(accuracy = 0.01),
    expand = c(0, 0)
  ) +
  scale_y_continuous(
    limits = c(-0.035 * ymax_A, ymax_A),
    breaks = pretty(c(0, ymax_A), n = 5),
    expand = c(0, 0)
  ) +
  labs(
    title = "GERP > 4",
    x = "Allele frequency",
    y = "Percentage of SNPs"
  ) +
  theme_pub(12) +
  theme(
    legend.position = "none",
    plot.title = element_text(hjust = 0.5, size = 13)
  )

# Supplementary AF: GERP < 0 and GERP > 4
# Updated:
#   - side-by-side bars within each AF bin
#   - no overlap between GERP < 0 and GERP > 4
#   - bars touch each other within the same AF bin
#   - keep small distance from x/y axes, same style as panel A

af_both <- make_af_table(site, c("GERP < 0", "GERP > 4"), af_binwidth)
ymax_AF2 <- nice_y_top(max(af_both$pct, na.rm = TRUE))

af_both_plot <- af_both %>%
  mutate(
    variant_class = factor(variant_class, levels = c("GERP < 0", "GERP > 4")),
    grp_id = ifelse(variant_class == "GERP < 0", 1, 2),
    bar_w  = af_binwidth * 0.50,
    xmin2  = xmin + (grp_id - 1) * bar_w,
    xmax2  = xmin + grp_id * bar_w
  )

pAF_supp <- ggplot(af_both_plot) +
  geom_rect(
    aes(xmin = xmin2, xmax = xmax2, ymin = 0, ymax = pct, fill = variant_class),
    colour = NA,
    alpha = 0.92
  ) +
  scale_fill_manual(
    values = c("GERP < 0" = col_gerpneg, "GERP > 4" = col_gt4),
    breaks = c("GERP < 0", "GERP > 4")
  ) +
  scale_x_continuous(
    limits = c(-af_binwidth * 0.65, 1 + af_binwidth * 0.30),
    breaks = c(0, 0.25, 0.50, 0.75, 1.00),
    labels = number_format(accuracy = 0.01),
    expand = c(0, 0)
  ) +
  scale_y_continuous(
    limits = c(-0.035 * ymax_AF2, ymax_AF2),
    breaks = pretty(c(0, ymax_AF2), n = 6),
    expand = c(0, 0)
  ) +
  labs(
    title = "GERP < 0 and GERP > 4",
    x = "Allele frequency",
    y = "Percentage of SNPs"
  ) +
  theme_pub(12) +
  theme(
    legend.position = c(0.80, 0.93),
    legend.direction = "horizontal",
    legend.background = element_blank(),
    legend.key.width = grid::unit(0.50, "cm"),
    legend.key.height = grid::unit(0.35, "cm"),
    plot.title = element_text(hjust = 0.5, size = 13)
  )


# =========================================================
# B. Hom / Het count distribution
# Reference-style version:
#   - Homozygous on the left, Heterozygous on the right
#   - pseudo axis break in the middle
#   - no overlap
#   - visual bar width matched to panel A
# =========================================================

b_raw <- bc %>%
  filter(component %in% c("het", "hom")) %>%
  transmute(
    sample,
    group = recode(component, "hom" = "Homozygous", "het" = "Heterozygous"),
    value = value_count
  ) %>%
  filter(is.finite(value)) %>%
  mutate(group = factor(group, levels = c("Homozygous", "Heterozygous")))

b_hom <- b_raw %>% filter(group == "Homozygous")
b_het <- b_raw %>% filter(group == "Heterozygous")

# ---------------------------------------------------------
# Target bar width:
# Make B bars visually similar to A.
# A uses round(1 / af_binwidth) bars over the full x-span.
# ---------------------------------------------------------
b_all_min <- min(b_raw$value, na.rm = TRUE)
b_all_max <- max(b_raw$value, na.rm = TRUE)
b_all_span <- b_all_max - b_all_min

nbar_target <- max(20, round(1 / af_binwidth))
bar_w_target <- b_all_span / nbar_target

make_hist_table <- function(df, bar_w) {
  vmin <- floor(min(df$value, na.rm = TRUE) / bar_w) * bar_w
  vmax <- ceiling(max(df$value, na.rm = TRUE) / bar_w) * bar_w
  breaks <- seq(vmin, vmax + bar_w, by = bar_w)

  out <- df %>%
    mutate(
      bin_id = pmin(
        length(breaks) - 1,
        pmax(1, findInterval(value, breaks, rightmost.closed = TRUE))
      ),
      xmin = breaks[bin_id],
      xmax = breaks[bin_id + 1]
    ) %>%
    count(group, bin_id, xmin, xmax, name = "count") %>%
    complete(
      bin_id = seq_len(length(breaks) - 1),
      fill = list(count = 0)
    ) %>%
    mutate(
      group = unique(df$group)[1],
      xmin = ifelse(is.na(xmin), breaks[bin_id], xmin),
      xmax = ifelse(is.na(xmax), breaks[bin_id + 1], xmax),
      xmid = (xmin + xmax) / 2
    )

  out
}

hom_hist <- make_hist_table(b_hom, bar_w_target)
het_hist <- make_hist_table(b_het, bar_w_target)

# ---------------------------------------------------------
# Build a pseudo broken x-axis:
# left segment = Homozygous range
# right segment = Heterozygous range
# ---------------------------------------------------------
left_min  <- min(hom_hist$xmin, na.rm = TRUE)
left_max  <- max(hom_hist$xmax, na.rm = TRUE)
right_min <- min(het_hist$xmin, na.rm = TRUE)
right_max <- max(het_hist$xmax, na.rm = TRUE)

left_span  <- left_max - left_min
right_span <- right_max - right_min

gap_span <- left_span * 0.14
right_offset <- left_span + gap_span

transform_left <- function(x)  x - left_min
transform_right <- function(x) (x - right_min) + right_offset

hom_hist <- hom_hist %>%
  mutate(
    xmin_plot = transform_left(xmin),
    xmax_plot = transform_left(xmax),
    xmid_plot = transform_left(xmid)
  )

het_hist <- het_hist %>%
  mutate(
    xmin_plot = transform_right(xmin),
    xmax_plot = transform_right(xmax),
    xmid_plot = transform_right(xmid)
  )

# ---------------------------------------------------------
# Medians
# ---------------------------------------------------------
b_med <- b_raw %>%
  group_by(group) %>%
  summarise(
    med = median(value, na.rm = TRUE),
    .groups = "drop"
  ) %>%
  mutate(
    xintercept = case_when(
      group == "Homozygous" ~ transform_left(med),
      group == "Heterozygous" ~ transform_right(med),
      TRUE ~ NA_real_
    )
  )

# ---------------------------------------------------------
# Y scale
# ---------------------------------------------------------
b_ymax <- nice_y_top(max(c(hom_hist$count, het_hist$count), na.rm = TRUE))

b_med <- b_med %>%
  mutate(
    y = case_when(
      group == "Homozygous" ~ b_ymax * 0.82,
      group == "Heterozygous" ~ b_ymax * 0.70,
      TRUE ~ b_ymax * 0.76
    ),
    x = case_when(
      group == "Homozygous" ~ pmin(xintercept + left_span * 0.12, transform_left(left_max) * 0.93),
      group == "Heterozygous" ~ pmin(xintercept + right_span * 0.12, transform_right(right_max) * 0.98),
      TRUE ~ xintercept
    ),
    label = paste0("median = ", comma(round(med)))
  )

# ---------------------------------------------------------
# Ticks
# ---------------------------------------------------------
make_ticks <- function(vmin, vmax, n = 4) {
  pretty(c(vmin, vmax), n = n)
}

ticks_left <- make_ticks(left_min, left_max, n = 4)
ticks_left <- ticks_left[ticks_left >= left_min & ticks_left <= left_max]

ticks_right <- make_ticks(right_min, right_max, n = 5)
ticks_right <- ticks_right[ticks_right >= right_min & ticks_right <= right_max]

tick_df <- bind_rows(
  tibble(
    label_value = ticks_left,
    x = transform_left(ticks_left),
    label = comma(round(ticks_left))
  ),
  tibble(
    label_value = ticks_right,
    x = transform_right(ticks_right),
    label = comma(round(ticks_right))
  )
)

# ---------------------------------------------------------
# Group labels
# ---------------------------------------------------------
group_label_df <- tibble(
  x = c(transform_left((left_min + left_max) / 2),
        transform_right((right_min + right_max) / 2)),
  y = c(b_ymax * 0.97, b_ymax * 0.97),
  label = c("Homozygotes", "Heterozygotes")
)

# pseudo axis break marks
break_x <- left_span + gap_span / 2

pB <- ggplot() +
  geom_rect(
    data = hom_hist,
    aes(xmin = xmin_plot, xmax = xmax_plot, ymin = 0, ymax = count),
    fill = col_hom,
    colour = "grey35",
    linewidth = 0.12,
    alpha = 0.94
  ) +
  geom_rect(
    data = het_hist,
    aes(xmin = xmin_plot, xmax = xmax_plot, ymin = 0, ymax = count),
    fill = col_het,
    colour = "grey35",
    linewidth = 0.12,
    alpha = 0.94
  ) +
  geom_vline(
    data = b_med,
    aes(xintercept = xintercept, colour = group),
    linetype = 2,
    linewidth = 0.60,
    show.legend = FALSE
  ) +
  geom_text(
    data = b_med,
    aes(x = x, y = y, label = label, colour = group),
    hjust = 0,
    size = 3.0,
    fontface = "bold",
    show.legend = FALSE
  ) +
  geom_text(
    data = group_label_df,
    aes(x = x, y = y, label = label),
    fontface = "bold",
    size = 3.3,
    colour = "grey10"
  ) +
  annotate("segment",
           x = break_x - left_span * 0.018, xend = break_x - left_span * 0.006,
           y = -b_ymax * 0.012, yend =  b_ymax * 0.012,
           linewidth = 0.55, colour = "grey25") +
  annotate("segment",
           x = break_x + left_span * 0.006, xend = break_x + left_span * 0.018,
           y = -b_ymax * 0.012, yend =  b_ymax * 0.012,
           linewidth = 0.55, colour = "grey25") +
  scale_colour_manual(values = c("Homozygous" = col_hom, "Heterozygous" = col_het)) +
  scale_x_continuous(
    limits = c(-left_span * 0.08, transform_right(right_max) + right_span * 0.05),
    breaks = tick_df$x,
    labels = tick_df$label,
    expand = c(0, 0)
  ) +
  scale_y_continuous(
    limits = c(-0.035 * b_ymax, b_ymax),
    breaks = pretty(c(0, b_ymax), n = 6),
    expand = c(0, 0)
  ) +
  labs(
    title = "GERP > 4",
    x = "Number of loci",
    y = "Number of individuals"
  ) +
  theme_pub(12) +
  theme(
    legend.position = c(0.52, 0.96),
    legend.direction = "horizontal",
    legend.background = element_blank(),
    legend.key.width = grid::unit(0.55, "cm"),
    legend.key.height = grid::unit(0.40, "cm"),
    legend.text = element_text(size = 10),
    plot.title = element_text(face = "bold", hjust = 0.5, size = 14),
    axis.text.x = element_text(size = 9)
  ) +
  guides(
    colour = "none",
    fill = "none"
  ) +
  annotate("rect", xmin = Inf, xmax = Inf, ymin = Inf, ymax = Inf, alpha = 0)

# add legend manually through invisible points
pB <- pB +
  geom_point(
    data = tibble(group = factor(c("Homozygous", "Heterozygous"),
                                 levels = c("Homozygous", "Heterozygous")),
                  x = NA_real_, y = NA_real_),
    aes(x = x, y = y, fill = group),
    shape = 22, size = 5, colour = "grey35", stroke = 0.25,
    inherit.aes = FALSE
  ) +
  scale_fill_manual(values = c("Homozygous" = col_hom, "Heterozygous" = col_het))


# =========================================================
# C/D. Counts and standardized load vs FROH
# =========================================================

make_three_component <- function(df, mode = c("count", "load")) {
  mode <- match.arg(mode)

  if (mode == "count") {
    bind_rows(
      df %>% filter(component == "allele_count") %>% transmute(sample, FROH, component = "Total", value = value_count),
      df %>% filter(component == "hom") %>% transmute(sample, FROH, component = "Homozygous", value = value_count),
      df %>% filter(component == "het") %>% transmute(sample, FROH, component = "Heterozygous", value = value_count)
    )
  } else {
    bind_rows(
      df %>% filter(component == "allele_count") %>% transmute(sample, FROH, component = "Total", value = value_rate),
      df %>% filter(component == "hom") %>% transmute(sample, FROH, component = "Homozygous", value = value_rate),
      df %>% filter(component == "het") %>% transmute(sample, FROH, component = "Heterozygous", value = value_rate)
    )
  }
}

plot_scatter_three <- function(dat, title_lab, y_lab, y_comma = FALSE, label_frac = c(0.96, 0.78, 0.08)) {
  dat <- dat %>%
    mutate(component = factor(component, levels = c("Total", "Homozygous", "Heterozygous"))) %>%
    filter(is.finite(FROH), is.finite(value))

  ptab <- dat %>%
    group_by(component) %>%
    summarise(p = lm_p(FROH, value), .groups = "drop") %>%
    mutate(label = paste0(component, ": ", vapply(p, fmt_p, character(1))))

  ymin <- min(dat$value, na.rm = TRUE)
  ymax <- max(dat$value, na.rm = TRUE)
  span <- ymax - ymin
  if (!is.finite(span) || span <= 0) span <- max(abs(ymax), 1)

  ptab <- ptab %>%
    mutate(
      x = min(dat$FROH, na.rm = TRUE) + 0.025 * diff(range(dat$FROH, na.rm = TRUE)),
      y = ymin + span * label_frac[as.integer(component)]
    )

  g <- ggplot(dat, aes(x = FROH, y = value, colour = component, fill = component)) +
    geom_point(size = 1.20, alpha = 0.78) +
    geom_smooth(method = "lm", se = TRUE, linewidth = 0.56, alpha = 0.10) +
    geom_text(
      data = ptab,
      aes(x = x, y = y, label = label, colour = component),
      inherit.aes = FALSE,
      hjust = 0,
      size = 2.9,
      fontface = "bold"
    ) +
    scale_colour_manual(values = comp_cols) +
    scale_fill_manual(values = comp_cols) +
    scale_x_continuous(expand = expansion(mult = c(0.05, 0.05))) +
    labs(title = title_lab, x = expression(F[ROH]), y = y_lab) +
    theme_pub(12) +
    theme(
      legend.position = c(0.55, 0.98),
      legend.justification = c(0.5, 1),
      legend.direction = "horizontal",
      legend.text = element_text(size = 8),
      plot.title = element_text(hjust = 0.5, size = 12)
    )

  if (y_comma) {
    g <- g + scale_y_continuous(labels = comma, expand = expansion(mult = c(0.04, 0.12)))
  } else {
    g <- g + scale_y_continuous(labels = number_format(accuracy = 0.001), expand = expansion(mult = c(0.04, 0.12)))
  }

  g
}

pC <- plot_scatter_three(
  make_three_component(bc, "count"),
  title_lab = "GERP > 4 counts",
  y_lab = "Count",
  y_comma = TRUE,
  label_frac = c(0.96, 0.50, 0.06)
)

pD <- plot_scatter_three(
  make_three_component(bc, "load"),
  title_lab = "Standardized GERP > 4 load",
  y_lab = "Load",
  y_comma = FALSE,
  label_frac = c(0.95, 0.88, 0.06)
)

# =========================================================
# E/F/H. Ratio scatter plots
# =========================================================

plot_ratio_scatter <- function(dat, title_lab, colour_map, group_col = "region", label_fracs = NULL) {
  dat <- dat %>%
    filter(is.finite(FROH), is.finite(ratio)) %>%
    mutate(plot_group = factor(as.character(.data[[group_col]]), levels = names(colour_map)))

  ptab <- dat %>%
    group_by(plot_group) %>%
    summarise(p = lm_p(FROH, ratio), .groups = "drop") %>%
    mutate(label = paste0(plot_group, ": ", vapply(p, fmt_p, character(1))))

  ymin <- min(dat$ratio, na.rm = TRUE)
  ymax <- max(dat$ratio, na.rm = TRUE)
  span <- ymax - ymin
  if (!is.finite(span) || span <= 0) span <- max(abs(ymax), 1)

  if (is.null(label_fracs)) {
    label_fracs <- seq(0.90, 0.72, length.out = nrow(ptab))
  }

  ptab <- ptab %>%
    mutate(
      x = min(dat$FROH, na.rm = TRUE) + 0.025 * diff(range(dat$FROH, na.rm = TRUE)),
      y = ymin + span * label_fracs[seq_len(n())]
    )

  ggplot(dat, aes(x = FROH, y = ratio, colour = plot_group, fill = plot_group)) +
    geom_point(size = 1.20, alpha = 0.78) +
    geom_smooth(method = "lm", se = TRUE, linewidth = 0.56, alpha = 0.10, linetype = 2) +
    geom_text(
      data = ptab,
      aes(x = x, y = y, label = label, colour = plot_group),
      inherit.aes = FALSE,
      hjust = 0,
      size = 2.9,
      fontface = "bold"
    ) +
    scale_colour_manual(values = colour_map, drop = FALSE) +
    scale_fill_manual(values = colour_map, drop = FALSE) +
    scale_x_continuous(expand = expansion(mult = c(0.05, 0.05))) +
    scale_y_continuous(expand = expansion(mult = c(0.06, 0.14))) +
    labs(title = title_lab, x = expression(F[ROH]), y = "GERP > 4 / GERP < 0 ratio") +
    theme_pub(12) +
    theme(
      legend.position = c(0.38, 0.98),
      legend.justification = c(0.5, 1),
      legend.direction = "horizontal",
      legend.text = element_text(size = 8),
      plot.title = element_text(hjust = 0.5, size = 12)
    )
}

ratio_all <- ratio_all_in %>%
  filter(state %in% c("het", "hom")) %>%
  mutate(
    component = recode(state, "het" = "Heterozygotes", "hom" = "Homozygotes"),
    component = factor(component, levels = c("Heterozygotes", "Homozygotes")),
    ratio = ratio_rate
  )

pE <- plot_ratio_scatter(
  ratio_all,
  title_lab = "GERP > 4 / GERP < 0",
  colour_map = c("Heterozygotes" = col_het, "Homozygotes" = col_hom),
  group_col = "component",
  label_fracs = c(0.86, 0.22)
)

ratio_hom_region <- roh_ratio_in %>%
  filter(state == "hom", region %in% c("Non-ROH", "ROH")) %>%
  mutate(
    region = factor(region, levels = c("Non-ROH", "ROH")),
    ratio = ratio_rate
  )

pF <- plot_ratio_scatter(
  ratio_hom_region,
  title_lab = "Homozygous GERP > 4 / GERP < 0 ratio",
  colour_map = region_cols,
  group_col = "region",
  label_fracs = c(0.90, 0.74)
)

ratio_alt_region <- roh_ratio_in %>%
  filter(state == "allele_count", region %in% c("Non-ROH", "ROH")) %>%
  mutate(
    region = factor(region, levels = c("Non-ROH", "ROH")),
    ratio = ratio_rate
  )

pH <- plot_ratio_scatter(
  ratio_alt_region,
  title_lab = paste0(allele_label, " GERP > 4 / GERP < 0 ratio inside and outside ROH"),
  colour_map = region_cols,
  group_col = "region",
  label_fracs = c(0.90, 0.74)
)

# =========================================================
# G. Boxplot ROH vs Non-ROH
# =========================================================

ratio_box <- roh_ratio_in %>%
  filter(state %in% c("het", "hom", "allele_count"),
         region %in% c("Non-ROH", "ROH")) %>%
  mutate(
    component = recode(
      state,
      "het" = "Heterozygotes",
      "hom" = "Homozygotes",
      "allele_count" = allele_label
    ),
    component = factor(component, levels = c("Heterozygotes", "Homozygotes", allele_label)),
    region = factor(region, levels = c("Non-ROH", "ROH")),
    ratio = ratio_rate
  )

box_stat <- ratio_box %>%
  select(sample, component, region, ratio) %>%
  pivot_wider(names_from = region, values_from = ratio) %>%
  group_by(component) %>%
  summarise(
    p = safe_paired_wilcox(`Non-ROH`, ROH),
    ymax = max(c(`Non-ROH`, ROH), na.rm = TRUE),
    .groups = "drop"
  ) %>%
  mutate(
    stars = vapply(p, p_stars, character(1)),
    p_label = vapply(p, fmt_p, character(1)),
    label = paste0(stars, "\n", p_label),
    y_bracket = ymax * 1.075,
    y_text = ymax * 1.125
  )

pG <- ggplot(ratio_box, aes(x = region, y = ratio, colour = region, fill = region)) +
  geom_boxplot(width = 0.50, outlier.shape = NA, alpha = 0.22, linewidth = 0.65) +
  geom_jitter(width = 0.12, size = 1.20, alpha = 0.70) +
  geom_segment(
    data = box_stat,
    aes(x = 1, xend = 2, y = y_bracket, yend = y_bracket),
    inherit.aes = FALSE,
    colour = "black",
    linewidth = 0.45
  ) +
  geom_segment(
    data = box_stat,
    aes(x = 1, xend = 1, y = y_bracket * 0.993, yend = y_bracket),
    inherit.aes = FALSE,
    colour = "black",
    linewidth = 0.45
  ) +
  geom_segment(
    data = box_stat,
    aes(x = 2, xend = 2, y = y_bracket * 0.993, yend = y_bracket),
    inherit.aes = FALSE,
    colour = "black",
    linewidth = 0.45
  ) +
  geom_text(
    data = box_stat,
    aes(x = 1.5, y = y_text, label = label),
    inherit.aes = FALSE,
    size = 2.8,
    fontface = "bold",
    colour = "grey20"
  ) +
  facet_wrap(~ component, scales = "free_y", nrow = 1) +
  scale_colour_manual(values = region_cols) +
  scale_fill_manual(values = region_cols) +
  scale_y_continuous(expand = expansion(mult = c(0.05, 0.22))) +
  labs(
    title = "GERP > 4 / GERP < 0 ratio in ROH and Non-ROH",
    x = NULL,
    y = "GERP > 4 / GERP < 0 ratio"
  ) +
  theme_pub(12) +
  theme(
    legend.position = "none",
    strip.text = element_text(face = "bold", size = 10),
    axis.text.x = element_text(angle = 25, hjust = 1),
    plot.title = element_text(hjust = 0.5, size = 12)
  )

# =========================================================
# Combine and save
# =========================================================

main_plot <- (
  pA | pB | pC
) / (
  pD | pE | pF
) / (
  pG | pH | plot_spacer()
) +
  plot_layout(
    widths = c(1, 1, 1),
    heights = c(1, 1, 1)
  ) +
  plot_annotation(tag_levels = "A") &
  theme(
    plot.tag = element_text(face = "bold", size = 16),
    plot.tag.position = c(0.01, 0.98)
  )

compact_plot <- (
  pA | pB | pC
) / (
  pD | pE | pF
) +
  plot_layout(
    widths = c(1, 1, 1),
    heights = c(1, 1)
  ) +
  plot_annotation(tag_levels = "A") &
  theme(
    plot.tag = element_text(face = "bold", size = 16),
    plot.tag.position = c(0.01, 0.98)
  )

single_w <- 5.3
single_h <- 3.5

save_both(pA, paste0(out_prefix, ".FigA_AF_GERPgt4"), single_w, single_h)
save_both(pAF_supp, paste0(out_prefix, ".FigS_AF_GERPneg_GERPgt4"), single_w, single_h)
save_both(pB, paste0(out_prefix, ".FigB_HetHom_sharedX_GERPgt4"), single_w, single_h)
save_both(pC, paste0(out_prefix, ".FigC_counts_vs_FROH_GERPgt4"), single_w, single_h)
save_both(pD, paste0(out_prefix, ".FigD_load_vs_FROH_GERPgt4"), single_w, single_h)
save_both(pE, paste0(out_prefix, ".FigE_ratio_ALL_HetHom_vs_FROH"), single_w, single_h)
save_both(pF, paste0(out_prefix, ".FigF_homo_ratio_ROH_nonROH_vs_FROH"), single_w, single_h)
save_both(pG, paste0(out_prefix, ".FigG_ratio_boxplot_ROH_nonROH_bracket"), single_w, single_h)
save_both(pH, paste0(out_prefix, ".FigH_alt_ratio_ROH_nonROH_vs_FROH"), single_w, single_h)

save_both(main_plot, paste0(out_prefix, ".A_H.equal_size_three_columns"), 15.9, 10.5)
save_both(compact_plot, paste0(out_prefix, ".A_F.equal_size_three_columns_compact"), 15.9, 7.0)

# Compatibility name
save_both(main_plot, paste0(out_prefix, ".A_H"), 15.9, 10.5)

message("[DONE] Teosinte unpolarized GERP visualization finished.")
