#!/bin/bash
#SBATCH --job-name=ROH_FROH_pipeline
#SBATCH --partition=parallel
#SBATCH --nodes=1
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=20
#SBATCH --mem=80G
#SBATCH --time=24:00:00
#SBATCH --output=logs/ROH_FROH.%j.out
#SBATCH --error=logs/ROH_FROH.%j.err

set -euo pipefail

echo ">>> SCRIPT PATH: $(realpath "$0")"

############################################
# 0. 输入与输出
############################################
VCF="141sp.filtered.bi-allelic.snp.vcf.gz"
SAMPLES="samples.list"

OUTDIR="ROH_FROH_pipeline"
mkdir -p "${OUTDIR}"/{logs,step1_snp_density,step2_Lgenome,step4_roh}
cd "${OUTDIR}"

############################################
# Step 1. SNP 密度统计
############################################
echo ">>> Step 1: SNP density"

bcftools index -f "../${VCF}"

bcftools query -f '%CHROM\t%POS\n' "../${VCF}" \
  > step1_snp_density/snp.pos.tsv

awk 'BEGIN{OFS="\t"} {print $1,$2-1,$2}' \
  step1_snp_density/snp.pos.tsv \
> step1_snp_density/snp.pos.bed

awk 'BEGIN{OFS="\t"}
{
  if($1==c) print $1,p,$2,$2-p
  c=$1; p=$2
}' step1_snp_density/snp.pos.tsv \
> step1_snp_density/snp.distance.tsv

############################################
# Step 1c. 50kb SNP 密度
############################################
awk 'BEGIN{OFS="\t"} {if($2>max[$1]) max[$1]=$2}
END{for(c in max) print c,max[c]}' \
step1_snp_density/snp.pos.tsv \
| sort -k1,1 \
> step1_snp_density/genome.length.tsv

bedtools makewindows \
  -g step1_snp_density/genome.length.tsv \
  -w 50000 \
> step1_snp_density/genome.50kb.windows.bed

bedtools intersect \
  -a step1_snp_density/genome.50kb.windows.bed \
  -b step1_snp_density/snp.pos.bed \
  -c \
> step1_snp_density/snp_density_50kb.tsv

############################################
# Step 2. Lgenome
############################################
awk '$4>=1{sum+=50000}
END{print sum}' \
step1_snp_density/snp_density_50kb.tsv \
> step2_Lgenome/Lgenome.bp.txt

LGENOME=$(cat step2_Lgenome/Lgenome.bp.txt)
echo ">>> Lgenome = ${LGENOME} bp"

############################################
# Step 4. ROH（关键修复区）
############################################
echo ">>> Step 4: ROH calling"

# VCF → PLINK
plink \
  --vcf "../${VCF}" \
  --double-id \
  --allow-extra-chr \
  --make-bed \
  --out step4_roh/roh.input

############################################
# 构建 keep 文件（单列 samples.list → 两列）
############################################
KEEP_FILE="$(pwd)/step4_roh/samples.keep"
echo ">>> Building keep file: ${KEEP_FILE}"

awk '
BEGIN{OFS="\t"}
{
  gsub(/\r/,"")
  if($0!="" && $0!~/^#/) print $1,$1
}' "../${SAMPLES}" \
| sort -u \
> "${KEEP_FILE}"

echo ">>> keep head:"
head -n 5 "${KEEP_FILE}"

############################################
# fam / keep 一致性检查（必须通过）
############################################
awk '{print $1,$2}' step4_roh/roh.input.fam | sort > step4_roh/fam.id
sort "${KEEP_FILE}" > step4_roh/keep.id

COMMON=$(comm -12 step4_roh/fam.id step4_roh/keep.id | wc -l)
echo ">>> keep ∩ fam = ${COMMON}"

if [[ "${COMMON}" -eq 0 ]]; then
  echo "ERROR: keep 与 fam 无交集" >&2
  echo "fam head:" >&2
  head -n 5 step4_roh/roh.input.fam >&2
  echo "keep head:" >&2
  head -n 5 "${KEEP_FILE}" >&2
  exit 1
fi

############################################
# 样本筛选（注意：只用 KEEP_FILE）
############################################
plink \
  --bfile step4_roh/roh.input \
  --keep "${KEEP_FILE}" \
  --allow-extra-chr \
  --make-bed \
  --out step4_roh/roh.keep

############################################
# ROH 调用
############################################
plink \
  --bfile step4_roh/roh.keep \
  --allow-extra-chr \
  --homozyg \
  --homozyg-snp 50 \
  --homozyg-window-snp 50 \
  --homozyg-density 50 \
  --homozyg-gap 100 \
  --homozyg-kb 500 \
  --homozyg-window-het 1 \
  --homozyg-window-missing 5 \
  --homozyg-window-threshold 0.05 \
  --out step4_roh/roh.results

############################################
# Step 5. FROH
############################################
awk -v L="${LGENOME}" 'BEGIN{OFS="\t"}
NR==1{print "FID","IID","N_ROH","S_ROH_bp","FROH";next}
{
  S=$4*1000
  print $1,$2,$3,S,S/L
}' step4_roh/roh.results.hom.indiv \
> FROH.per_individual.tsv

echo ">>> FINISHED SUCCESSFULLY"
echo ">>> Output: $(pwd)/FROH.per_individual.tsv"
