#!/usr/bin/env bash

set -euo pipefail

# ============================================================
# Ped genome-wide GERP deleterious burden workflow
#
# Two modes:
#   1) unpolarized: raw ALT allele dosage
#   2) polarized: derived allele dosage using ancestral allele BED
#
# Important:
#   GERP < 0 VCF is copied from the original file and re-bgzipped
#   to fix missing BGZF EOF marker.
#
# ROH input:
#   Use standardized classified ROH table.
#
# Chromosome map:
#   ROH chr number -> VCF/ancestral chromosome ID.
# ============================================================

# -----------------------------
# Working directory assumption
# -----------------------------
# Run this script from:
# /gpfs/hpc/home/kib_unit/lidezhu/liuliangmin/6.pop/05.FROH

# ---- input VCFs: GERP > 4 ----
PEDC_GERP4="pedC_gt4_snps.vcf.gz"
PEDD_GERP4="pedD_gt4_snps.vcf.gz"

# ---- original source VCF for GERP < 0 ----
# This can be a symlink or a real file; cp -L will dereference the symlink.
PED_LT0_SRC="GERP_neutral/Ped/03_vcf/Ped_merged_lt0_snps.vcf.gz"

# ---- fixed local GERP < 0 VCF ----
VCF_FIX_DIR="Ped_GERP_fullgenome_pipeline/00_vcf_fix"
PED_LT0_RAW_COPY="${VCF_FIX_DIR}/Ped_merged_lt0_snps.source.copy.vcf.gz"
PED_LT0="${VCF_FIX_DIR}/Ped_merged_lt0_snps.rebgzip.vcf.gz"

# ---- raw ancestral allele BED: chrom start0 end0 AA ----
RAW_ANCESTRAL_BED="ped_all.ancestral.bed"

# ---- indexed ancestral BED generated directly from raw BED, no sorting ----
ANCESTRAL_DIR="Ped_GERP_fullgenome_pipeline/00_ancestral_index"
ANCESTRAL_BED="${ANCESTRAL_DIR}/ped_all.ancestral.bed.gz"

# ---- chromosome map: ROH_chr VCF_chr ----
CHROM_MAP="chrom_map.txt"

# ---- FROH / ROH from kb100 gap1000 winmiss5 PLINK result ----
FROH_FILE="ROH_pipeline/Ped/04_froh/plink_kb100_gap1000_winmiss5/FROH.final.plink.kb100_gap1000_winmiss5.tsv"

ROH_SEG_FILE="ROH_pipeline/Ped/04_froh/plink_kb100_gap1000_winmiss5/ROH.segments.plink.ge100000.minSNP50.kb100_gap1000_winmiss5.classified.tsv"

# ---- output ----
OUTDIR="Ped_GERP_fullgenome_pipeline/01_tables"
LOGDIR="Ped_GERP_fullgenome_pipeline/logs"

mkdir -p "${OUTDIR}" "${LOGDIR}" "${ANCESTRAL_DIR}" "${VCF_FIX_DIR}"

# ============================================================
# Environment check
# ============================================================

command -v python3 >/dev/null || {
  echo "[ERROR] python3 not found" >&2
  exit 1
}

command -v bgzip >/dev/null || {
  echo "[ERROR] bgzip not found" >&2
  exit 1
}

command -v tabix >/dev/null || {
  echo "[ERROR] tabix not found" >&2
  exit 1
}

command -v zcat >/dev/null || {
  echo "[ERROR] zcat not found" >&2
  exit 1
}

python3 - <<'PY'
try:
    import pysam
except Exception:
    raise SystemExit('[ERROR] Python package pysam is required. Install with: conda install -c bioconda pysam')
PY

# ============================================================
# Input checks
# ============================================================

for f in "${PEDC_GERP4}" "${PEDD_GERP4}" "${PED_LT0_SRC}" "${RAW_ANCESTRAL_BED}" "${CHROM_MAP}" "${FROH_FILE}" "${ROH_SEG_FILE}"; do
  if [[ ! -s "${f}" ]]; then
    echo "[ERROR] Missing input file: ${f}" >&2
    exit 1
  fi
done

echo "[INFO] Input files:"
echo "[INFO]   PEDC_GERP4     = ${PEDC_GERP4}"
echo "[INFO]   PEDD_GERP4     = ${PEDD_GERP4}"
echo "[INFO]   PED_LT0_SRC    = ${PED_LT0_SRC}"
echo "[INFO]   RAW_ANCESTRAL  = ${RAW_ANCESTRAL_BED}"
echo "[INFO]   CHROM_MAP      = ${CHROM_MAP}"
echo "[INFO]   FROH_FILE      = ${FROH_FILE}"
echo "[INFO]   ROH_SEG_FILE   = ${ROH_SEG_FILE}"

# ============================================================
# Step 1. Fix GERP < 0 VCF
# ============================================================
# The original Ped_merged_lt0_snps.vcf.gz may lack BGZF EOF marker.
# We dereference/copy it and re-bgzip into a clean local VCF.
# ============================================================

echo "[INFO] Rebuilding GERP < 0 VCF with proper BGZF EOF marker"
echo "[INFO]   source: ${PED_LT0_SRC}"
echo "[INFO]   copy  : ${PED_LT0_RAW_COPY}"
echo "[INFO]   fixed : ${PED_LT0}"

rm -f "${PED_LT0_RAW_COPY}" \
      "${PED_LT0}" \
      "${PED_LT0}.tbi" \
      "${PED_LT0}.csi"

# cp -L dereferences symlink and copies the real file content.
cp -L "${PED_LT0_SRC}" "${PED_LT0_RAW_COPY}"

# Re-bgzip to create a clean BGZF VCF.
zcat "${PED_LT0_RAW_COPY}" \
  | bgzip -@ 4 -c \
  > "${PED_LT0}"

# Index fixed VCF.
tabix -f -p vcf "${PED_LT0}"

# Strict check: no EOF-marker warning allowed.
LT0_CHECK_LOG="${LOGDIR}/Ped_merged_lt0_snps.rebgzip.bgzip_check.log"
bgzip -t "${PED_LT0}" 2> "${LT0_CHECK_LOG}" || {
  echo "[ERROR] bgzip test failed for fixed GERP < 0 VCF: ${PED_LT0}" >&2
  cat "${LT0_CHECK_LOG}" >&2
  exit 1
}

if grep -q "EOF marker is absent" "${LT0_CHECK_LOG}"; then
  echo "[ERROR] Fixed GERP < 0 VCF still lacks BGZF EOF marker: ${PED_LT0}" >&2
  cat "${LT0_CHECK_LOG}" >&2
  exit 1
fi

if [[ ! -s "${PED_LT0}.tbi" && ! -s "${PED_LT0}.csi" ]]; then
  echo "[ERROR] Missing tabix index for fixed GERP < 0 VCF: ${PED_LT0}" >&2
  exit 1
fi

echo "[INFO] Fixed GERP < 0 VCF ready:"
ls -lh "${PED_LT0}" "${PED_LT0}.tbi"

# ============================================================
# Step 2. Build ancestral BED index directly, no sorting
# ============================================================
# Assumption: ped_all.ancestral.bed is already sorted by chrom/start.
# ============================================================

echo "[INFO] Build ancestral BED index directly from raw BED, no sorting"
echo "[INFO]   input : ${RAW_ANCESTRAL_BED}"
echo "[INFO]   output: ${ANCESTRAL_BED}"

#rm -f "${ANCESTRAL_BED}" "${ANCESTRAL_BED}.tbi" "${ANCESTRAL_BED}.csi"

#bgzip -@ 4 -c "${RAW_ANCESTRAL_BED}" > "${ANCESTRAL_BED}"

#tabix -p bed "${ANCESTRAL_BED}"

if [[ ! -s "${ANCESTRAL_BED}" || ! -s "${ANCESTRAL_BED}.tbi" ]]; then
  echo "[ERROR] Failed to create indexed ancestral BED: ${ANCESTRAL_BED}" >&2
  exit 1
fi

echo "[INFO] Indexed ancestral BED ready:"
ls -lh "${ANCESTRAL_BED}" "${ANCESTRAL_BED}.tbi"

# ============================================================
# Step 3. Check/index GERP > 4 VCFs
# ============================================================

for vcf in "${PEDC_GERP4}" "${PEDD_GERP4}"; do
  echo "[INFO] checking GERP > 4 VCF: ${vcf}"

  CHECK_LOG="${LOGDIR}/$(basename "${vcf}").bgzip_check.log"

  bgzip -t "${vcf}" 2> "${CHECK_LOG}" || {
    echo "[ERROR] bgzip test failed: ${vcf}" >&2
    cat "${CHECK_LOG}" >&2
    exit 1
  }

  if grep -q "EOF marker is absent" "${CHECK_LOG}"; then
    echo "[ERROR] BGZF EOF marker is absent: ${vcf}" >&2
    cat "${CHECK_LOG}" >&2
    exit 1
  fi

  if [[ ! -s "${vcf}.tbi" && ! -s "${vcf}.csi" ]]; then
    echo "[INFO] indexing ${vcf}"
    tabix -f -p vcf "${vcf}"
  fi
done

# ============================================================
# Step 4. Remove old incomplete tables
# ============================================================

rm -f "${OUTDIR}"/*.tsv

# ============================================================
# Step 5. Run calculation
# ============================================================

echo "[INFO] Running Ped GERP full-genome burden calculation"

python3 Ped_GERP_fullgenome_pipeline/scripts/01_compute_Ped_GERP_fullgenome.py \
  --vcf "GERP4:PedC:${PEDC_GERP4}" \
  --vcf "GERP4:PedD:${PEDD_GERP4}" \
  --vcf "GERP_lt0:Ped_lt0:${PED_LT0}" \
  --ancestral-bed "${ANCESTRAL_BED}" \
  --froh "${FROH_FILE}" \
  --roh "${ROH_SEG_FILE}" \
  --chrom-map "${CHROM_MAP}" \
  --outdir "${OUTDIR}" \
  --chrom-normalize auto \
  > "${LOGDIR}/01_compute.stdout.log" \
  2> "${LOGDIR}/01_compute.stderr.log"

# ============================================================
# Step 6. Required output checks
# ============================================================

required=(
  "Ped_GERP.site_AF.tsv"
  "plot_A_site_spectrum.tsv"
  "Ped_GERP.per_sample_burden.tsv"
  "plot_BC_GERP4_burden.tsv"
  "plot_DE_GERP4_over_lt0_ratio.tsv"
  "plot_F_ROH_nonROH_burden.tsv"
  "plot_GH_ROH_nonROH_ratio.tsv"
  "Ped_GERP.diagnostics.tsv"
)

for x in "${required[@]}"; do
  if [[ ! -s "${OUTDIR}/${x}" ]]; then
    echo "[ERROR] Expected output missing: ${OUTDIR}/${x}" >&2
    echo "[ERROR] Check log: ${LOGDIR}/01_compute.stderr.log" >&2
    exit 1
  fi
done

echo "[INFO] Output files:"
ls -lh "${OUTDIR}"/*.tsv

echo "[INFO] Diagnostics:"
cat "${OUTDIR}/Ped_GERP.diagnostics.tsv"

echo "[DONE] Results written to ${OUTDIR}"
