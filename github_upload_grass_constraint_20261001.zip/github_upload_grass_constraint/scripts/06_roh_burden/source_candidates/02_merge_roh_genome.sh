#!/usr/bin/env bash
## SBATCH --job-name=merge_roh_genome
## SBATCH --partition=parallel
## SBATCH --nodes=1
## SBATCH --ntasks=1
## SBATCH --cpus-per-task=2
## SBATCH --output=logs/merge_roh_genome.%j.out
## SBATCH --error=logs/merge_roh_genome.%j.err

set -euo pipefail

OUTDIR="ROH_pipeline"
IN_DIR="${OUTDIR}/03_froh"
OUT="${OUTDIR}/03_froh/ROH.genome.sum.tsv"

echo -e "FID\tIID\tS_ROH_bp_genome" > "${OUT}"

awk 'BEGIN{OFS="\t"}
{
  key=$1"\t"$2
  sum[key]+=$3
}
END{
  for(k in sum) print k, sum[k]
}' ${IN_DIR}/*.roh_sum.bp.tsv \
| sort -k1,1 -k2,2 \
>> "${OUT}"
