#!/usr/bin/env Rscript

suppressPackageStartupMessages({
  library(tidyverse)
  library(patchwork)
})

args <- commandArgs(trailingOnly = TRUE)

if (length(args) < 4) {
  stop("Usage: Rscript 02_plot_Teosinte_SIFT_ratio.R per_sample_burden.tsv per_sample_region_burden.tsv FROH.merge.tsv out_prefix")
}

burden_file <- args[1]
region_file <- args[2]
froh_file   <- args[3]
out_prefix  <- args[4]

message("[INFO] burden_file = ", burden_file)
message("[INFO] region_file = ", region_file)
message("[INFO] froh_file   = ", froh_file)
message("[INFO] out_prefix  = ", out_prefix)

burden <- read_tsv(burden_file, show_col_types = FALSE)
region <- read_tsv(region_file, show_col_types = FALSE)
froh   <- read_tsv(froh_file, show_col_types = FALSE)

theme_pub <- function(base_size = 12) {
  theme_classic(base_size = base_size) +
    theme(
      axis.line = element_line(linewidth = 0.45, colour = "black"),
      axis.ticks = element_line(linewidth = 0.4, colour = "black"),
      axis.text = element_text(colour = "black"),
      axis.title = element_text(colour = "black"),
      plot.title = element_text(face = "bold", hjust = 0),
      legend.title = element_blank(),
      legend.position = "top",
      strip.background = element_blank(),
      strip.text = element_text(face = "bold")
    )
}

col_main <- "#3C5488FF"
col_het  <- "#00A087FF"
col_hom  <- "#E64B35FF"
col_roh  <- "#E64B35FF"
col_non  <- "#4DBBD5FF"

del <- burden %>%
  filter(variant_class == "SIFT_deleterious") %>%
  mutate(sample = as.character(sample)) %>%
  arrange(alt_allele_rate) %>%
  mutate(sample = factor(sample, levels = sample))

pA <- ggplot(del, aes(x = sample, y = alt_allele_rate)) +
  geom_col(width = 0.82, fill = col_main, colour = "black", linewidth = 0.15) +
  scale_y_continuous(expand = expansion(mult = c(0.02, 0.08))) +
  labs(
    title = "A",
    x = NULL,
    y = "SIFT deleterious ALT allele rate"
  ) +
  theme_pub(11) +
  theme(
    axis.text.x = element_blank(),
    axis.ticks.x = element_blank()
  )

het_hom <- del %>%
  select(sample, het_loci_rate, hom_alt_loci_rate) %>%
  pivot_longer(
    cols = c(het_loci_rate, hom_alt_loci_rate),
    names_to = "component",
    values_to = "rate"
  ) %>%
  mutate(
    component = recode(
      component,
      het_loci_rate = "Heterozygous ALT",
      hom_alt_loci_rate = "Homozygous ALT"
    )
  )

pB <- ggplot(het_hom, aes(x = sample, y = rate, fill = component)) +
  geom_col(
    position = position_dodge(width = 0.82),
    width = 0.72,
    colour = "black",
    linewidth = 0.12
  ) +
  scale_fill_manual(values = c(
    "Heterozygous ALT" = col_het,
    "Homozygous ALT" = col_hom
  )) +
  scale_y_continuous(expand = expansion(mult = c(0.02, 0.08))) +
  labs(
    title = "B",
    x = NULL,
    y = "Loci rate"
  ) +
  theme_pub(11) +
  theme(
    axis.text.x = element_blank(),
    axis.ticks.x = element_blank()
  )

reg_del <- region %>%
  filter(variant_class == "SIFT_deleterious") %>%
  mutate(
    region = factor(region, levels = c("nonROH", "ROH")),
    sample = as.character(sample)
  )

pC <- ggplot(reg_del, aes(x = region, y = alt_allele_rate, fill = region)) +
  geom_boxplot(width = 0.55, outlier.size = 0.8, linewidth = 0.35) +
  geom_jitter(width = 0.12, size = 1.2, alpha = 0.75) +
  scale_fill_manual(values = c("nonROH" = col_non, "ROH" = col_roh)) +
  scale_y_continuous(expand = expansion(mult = c(0.04, 0.10))) +
  labs(
    title = "C",
    x = NULL,
    y = "ALT allele rate"
  ) +
  theme_pub(12)

pD <- ggplot(froh, aes(x = FROH, y = hom_alt_loci_rate)) +
  geom_point(size = 2, alpha = 0.85, colour = col_hom) +
  geom_smooth(method = "lm", se = TRUE, linewidth = 0.55, colour = "black") +
  scale_x_continuous(expand = expansion(mult = c(0.05, 0.08))) +
  scale_y_continuous(expand = expansion(mult = c(0.05, 0.10))) +
  labs(
    title = "D",
    x = expression(F[ROH]),
    y = "Homozygous deleterious loci rate"
  ) +
  theme_pub(12)

pE <- ggplot(froh, aes(x = FROH, y = alt_allele_rate)) +
  geom_point(size = 2, alpha = 0.85, colour = col_main) +
  geom_smooth(method = "lm", se = TRUE, linewidth = 0.55, colour = "black") +
  scale_x_continuous(expand = expansion(mult = c(0.05, 0.08))) +
  scale_y_continuous(expand = expansion(mult = c(0.05, 0.10))) +
  labs(
    title = "E",
    x = expression(F[ROH]),
    y = "SIFT deleterious ALT allele rate"
  ) +
  theme_pub(12)

cor_hom <- suppressWarnings(cor.test(froh$FROH, froh$hom_alt_loci_rate, method = "spearman"))
cor_alt <- suppressWarnings(cor.test(froh$FROH, froh$alt_allele_rate, method = "spearman"))

cor_tab <- tibble(
  comparison = c(
    "FROH_vs_homozygous_deleterious_loci_rate",
    "FROH_vs_SIFT_deleterious_ALT_allele_rate"
  ),
  method = "Spearman",
  rho = c(unname(cor_hom$estimate), unname(cor_alt$estimate)),
  p_value = c(cor_hom$p.value, cor_alt$p.value)
)

write_tsv(cor_tab, paste0(out_prefix, ".correlation.tsv"))

combined <- (pA / pB) | (pC / pD / pE)

ggsave(
  paste0(out_prefix, "_A_burden_bar.pdf"),
  pA,
  width = 7.5,
  height = 3.2
)

ggsave(
  paste0(out_prefix, "_B_het_hom_bar.pdf"),
  pB,
  width = 7.5,
  height = 3.2
)

ggsave(
  paste0(out_prefix, "_C_ROH_nonROH_box.pdf"),
  pC,
  width = 3.8,
  height = 3.8
)

ggsave(
  paste0(out_prefix, "_D_FROH_hom_correlation.pdf"),
  pD,
  width = 4.2,
  height = 3.8
)

ggsave(
  paste0(out_prefix, "_E_FROH_alt_correlation.pdf"),
  pE,
  width = 4.2,
  height = 3.8
)

ggsave(
  paste0(out_prefix, "_final.combined.pdf"),
  combined,
  width = 12,
  height = 7.2
)

ggsave(
  paste0(out_prefix, "_final.combined.png"),
  combined,
  width = 12,
  height = 7.2,
  dpi = 400
)

message("[DONE] Plotting finished.")