#!/usr/bin/env bash
#SBATCH --job-name=calc_FROH
#SBATCH --partition=parallel
#SBATCH --nodes=1
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=20
#SBATCH --mem=40G
#SBATCH --time=12:00:00
#SBATCH --output=logs/calc_FROH.%j.out
#SBATCH --error=logs/calc_FROH.%j.err
set -euo pipefail

LGENOME=$(cat Lgenome.24chr.bp.txt)

awk -v L="${LGENOME}" 'BEGIN{OFS="\t"}
NR==1{
  print "FID","IID","S_ROH_bp","Lgenome_bp","FROH"
  next
}
{
  printf "%s\t%s\t%.0f\t%.0f\t%.6f\n",
         $1,$2,$3,L,$3/L
}' ROH_pipeline/03_froh/ROH.genome.sum.tsv \
> ROH_pipeline/03_froh/FROH.final.tsv
