#!/bin/bash
#SBATCH --job-name=ROH_FROH_maize
#SBATCH --partition=parallel
#SBATCH --nodes=1
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=20
#SBATCH --mem=80G
#SBATCH --time=24:00:00
#SBATCH --output=logs/ROH_FROH_maize.%j.out
#SBATCH --error=logs/ROH_FROH_maize.%j.err

set -euo pipefail

############################################
# 0. 输入文件
############################################

VCF="63sp.filtered.bi-allelic.snp.renamed.vcf.gz"
SAMPLES_ALL="samples.list"

NSAMPLE=60
SEED=2024

OUTDIR="ROH_FROH_maize"
mkdir -p "${OUTDIR}"/{logs,step1_snp_density,step2_Lgenome,step4_roh}
cd "${OUTDIR}"

############################################
# Step 0. 随机抽取 60 个样品（可复现）
############################################

echo ">>> Step 0: Randomly sampling ${NSAMPLE} individuals"

shuf --random-source=<(yes ${SEED}) ../${SAMPLES_ALL} \
  | head -n ${NSAMPLE} \
  > samples.${NSAMPLE}.list

############################################
# Step 1. SNP 密度统计（全基因组）
############################################

echo ">>> Step 1: SNP density (genome-wide)"

bcftools index -f "../${VCF}"

bcftools query -f '%CHROM\t%POS\n' "../${VCF}" \
  > step1_snp_density/snp.pos.tsv

# SNP → BED（0-based）
awk 'BEGIN{OFS="\t"} $2>0 {print $1,$2-1,$2}' \
step1_snp_density/snp.pos.tsv \
> step1_snp_density/snp.pos.bed

# 相邻 SNP gap
awk 'BEGIN{OFS="\t"}
{
  if ($1==c) print $1,p,$2,$2-p
  c=$1; p=$2
}' step1_snp_density/snp.pos.tsv \
> step1_snp_density/snp.distance.tsv

############################################
# Step 1a. SNP gap 统计
############################################

awk '{print $4}' step1_snp_density/snp.distance.tsv \
| sort -n \
> step1_snp_density/snp_gap.sorted.txt

awk '
{a[NR]=$1; sum+=$1}
END{
  if(NR==0){print "NA";exit}
  min=a[1]; max=a[NR]; mean=sum/NR
  if(NR%2) med=a[(NR+1)/2]
  else med=(a[NR/2]+a[NR/2+1])/2
  printf "min\t%.0f\nmedian\t%.0f\nmean\t%.2f\nmax\t%.0f\n",min,med,mean,max
}' step1_snp_density/snp_gap.sorted.txt \
> step1_snp_density/snp_gap.summary.txt

############################################
# Step 1b. gap ≤ 50 kb 的比例
############################################

awk '$4<=50000{ok++}{tot++}
END{
  if(tot==0) printf "Fraction_gap_le_50kb\tNA\n"
  else printf "Fraction_gap_le_50kb\t%.4f\n", ok/tot
}' step1_snp_density/snp.distance.tsv \
> step1_snp_density/snp_gap_fraction.txt

############################################
# Step 1c. 50 kb 窗口 SNP 密度（关键修复）
############################################
# 正确取每条染色体最大 POS 作为长度
awk 'BEGIN{OFS="\t"} {if($2>max[$1]) max[$1]=$2}
END{for(c in max) print c,max[c]}' \
step1_snp_density/snp.pos.tsv \
| sort -k1,1 \
> step1_snp_density/genome.length.tsv

bedtools makewindows \
  -g step1_snp_density/genome.length.tsv \
  -w 50000 \
> step1_snp_density/genome.50kb.windows.bed

bedtools intersect \
  -a step1_snp_density/genome.50kb.windows.bed \
  -b step1_snp_density/snp.pos.bed \
  -c \
> step1_snp_density/snp_density_50kb.tsv

awk '$4<1{low++}{tot++}
END{
  if(tot==0) printf "Fraction_windows_lt_1SNP\tNA\n"
  else printf "Fraction_windows_lt_1SNP\t%.4f\n", low/tot
}' step1_snp_density/snp_density_50kb.tsv \
> step1_snp_density/window_low_density.txt

############################################
# Step 2. 计算 Lgenome
############################################

echo ">>> Step 2: Calculating Lgenome"

awk '$4>=1{sum+=50000}
END{printf "%.0f\n", sum}' \
step1_snp_density/snp_density_50kb.tsv \
> step2_Lgenome/Lgenome.bp.txt

LGENOME=$(cat step2_Lgenome/Lgenome.bp.txt)
echo ">>> Lgenome = ${LGENOME} bp"

############################################
# Step 3. ROH 参数合理性判断
############################################

awk '
$4<=50000{ok++}{tot++}
END{
  if(tot==0){ print "ROH_parameters: NA"; exit }
  frac=ok/tot
  if(frac>=0.8) print "ROH_parameters: SAFE"
  else if(frac>=0.6) print "ROH_parameters: ACCEPTABLE"
  else print "ROH_parameters: TOO_STRICT"
}' step1_snp_density/snp.distance.tsv \
> step2_Lgenome/ROH_parameter_check.txt

############################################
# Step 4. ROH 计算（关键：keep 文件修复）
############################################

echo ">>> Step 4: ROH calling with PLINK (n=${NSAMPLE})"

# VCF → PLINK（FID=IID=样本名）
plink \
  --vcf "../${VCF}" \
  --double-id \
  --allow-extra-chr \
  --make-bed \
  --out step4_roh/roh.input

# 构建合规 keep（两列：FID IID）
awk '{print $1,$1}' samples.${NSAMPLE}.list \
> step4_roh/samples.keep

# 校验 keep 与 fam 是否匹配
awk '{print $1,$2}' step4_roh/roh.input.fam | sort > step4_roh/fam.id
sort step4_roh/samples.keep > step4_roh/keep.id

COMMON=$(comm -12 step4_roh/fam.id step4_roh/keep.id | wc -l)
echo ">>> keep–fam intersection = ${COMMON}"

if [[ "${COMMON}" -eq 0 ]]; then
  echo "ERROR: samples.keep does not match VCF sample IDs" >&2
  echo "Check samples.list vs VCF header" >&2
  exit 1
fi

plink \
  --bfile step4_roh/roh.input \
  --keep step4_roh/samples.keep \
  --allow-extra-chr \
  --make-bed \
  --out step4_roh/roh.keep

plink \
  --bfile step4_roh/roh.keep \
  --allow-extra-chr \
  --homozyg \
  --homozyg-snp 50 \
  --homozyg-window-snp 50 \
  --homozyg-density 50 \
  --homozyg-gap 100 \
  --homozyg-kb 500 \
  --homozyg-window-het 1 \
  --homozyg-window-missing 5 \
  --homozyg-window-threshold 0.05 \
  --out step4_roh/roh.results

############################################
# Step 5. 计算 FROH
############################################

echo ">>> Step 5: Calculating FROH"

awk -v L="${LGENOME}" 'BEGIN{OFS="\t"}
NR==1{
  print "FID","IID","N_ROH","S_ROH_bp","FROH"
  next
}
{
  S=$4*1000
  printf "%s\t%s\t%d\t%.0f\t%.6f\n", $1,$2,$3,S,S/L
}' step4_roh/roh.results.hom.indiv \
> FROH.maize.per_individual.tsv

echo ">>> ROH–FROH maize pipeline finished successfully."
echo ">>> Output: ${OUTDIR}/FROH.maize.per_individual.tsv"
