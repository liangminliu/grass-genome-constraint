#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import argparse
import gzip
import re
from collections import defaultdict
import pandas as pd

try:
    import pysam
except ImportError:
    raise SystemExit("[ERROR] pysam is required. Please install it with: conda install -c bioconda pysam")


def parse_args():
    p = argparse.ArgumentParser(
        description="Calculate Teosinte SIFT deleterious ALT burden with ROH/FROH."
    )
    p.add_argument("--vcf", required=True)
    p.add_argument("--roh", required=True)
    p.add_argument("--froh", required=True)
    p.add_argument("--species", default="Teosinte")
    p.add_argument("--sift-cutoff", type=float, default=0.05)
    p.add_argument("--out-prefix", required=True)
    return p.parse_args()


def safe_float(x):
    try:
        return float(x)
    except Exception:
        return None


def extract_sift_scores_from_info(info_dict):
    """
    Try to extract SIFT scores from common SIFT4G / snpEff-like VCF annotations.

    Supported patterns include:
    - INFO/SIFT=0.03
    - INFO/SIFTINFO=...0.03...
    - ANN field containing SIFT or score-like values
    - any INFO string containing SIFT and numeric score
    """
    scores = []

    for key in info_dict.keys():
        val = info_dict.get(key)

        if val is None:
            continue

        if key.upper() in {"SIFT", "SIFTSCORE", "SIFT_SCORE"}:
            if isinstance(val, (tuple, list)):
                for v in val:
                    f = safe_float(v)
                    if f is not None:
                        scores.append(f)
            else:
                f = safe_float(val)
                if f is not None:
                    scores.append(f)

        text = ""
        if isinstance(val, (tuple, list)):
            text = ",".join(map(str, val))
        else:
            text = str(val)

        if "SIFT" in key.upper() or "SIFT" in text.upper():
            nums = re.findall(r"(?<![A-Za-z0-9.])(?:0?\.\d+|1\.0+|0|1)(?![A-Za-z0-9.])", text)
            for n in nums:
                f = safe_float(n)
                if f is not None and 0 <= f <= 1:
                    scores.append(f)

    return scores


def extract_annotation_class(info_dict):
    """
    Extract rough variant class.
    Used mainly to identify synonymous variants if available.
    """
    texts = []
    for key in info_dict.keys():
        val = info_dict.get(key)
        if val is None:
            continue
        if isinstance(val, (tuple, list)):
            texts.extend(map(str, val))
        else:
            texts.append(str(val))

    joined = "|".join(texts).lower()

    if "synonymous_variant" in joined or "synonymous" in joined:
        return "synonymous"
    if "missense_variant" in joined or "missense" in joined or "nonsynonymous" in joined:
        return "missense"
    return "unknown"


def gt_to_alt_dosage(gt):
    """
    Diploid unpolarized ALT allele dosage.
    0/0 -> 0
    0/1 -> 1
    1/1 -> 2
    missing -> None
    """
    if gt is None:
        return None
    if len(gt) != 2:
        return None
    if gt[0] is None or gt[1] is None:
        return None
    if gt[0] not in (0, 1) or gt[1] not in (0, 1):
        return None
    return int(gt[0]) + int(gt[1])


def read_roh_intervals(path):
    """
    Return:
      roh_dict[sample][chrom] = list of (start, end)
    """
    df = pd.read_csv(path, sep="\t")

    cols = {c.lower(): c for c in df.columns}

    sample_col = None
    for x in ["sample", "iid", "id"]:
        if x in cols:
            sample_col = cols[x]
            break

    chr_col = None
    for x in ["chr", "chrom", "chromosome"]:
        if x in cols:
            chr_col = cols[x]
            break

    start_col = None
    for x in ["start_bp", "pos1", "start", "bp1"]:
        if x in cols:
            start_col = cols[x]
            break

    end_col = None
    for x in ["end_bp", "pos2", "end", "bp2"]:
        if x in cols:
            end_col = cols[x]
            break

    if sample_col is None or chr_col is None or start_col is None or end_col is None:
        raise RuntimeError(
            f"Cannot detect ROH columns in {path}. "
            f"Need sample/IID, chr, start_bp, end_bp-like columns."
        )

    roh = defaultdict(lambda: defaultdict(list))

    for _, r in df.iterrows():
        s = str(r[sample_col])
        c = str(r[chr_col])
        try:
            st = int(r[start_col])
            en = int(r[end_col])
        except Exception:
            continue
        if en < st:
            st, en = en, st
        roh[s][c].append((st, en))

    for s in roh:
        for c in roh[s]:
            roh[s][c].sort()

    return roh


def in_intervals(pos, intervals):
    """
    Simple interval membership check.
    For large files, this can be optimized with pointers, but this is robust.
    """
    if not intervals:
        return False

    left = 0
    right = len(intervals) - 1

    while left <= right:
        mid = (left + right) // 2
        st, en = intervals[mid]
        if st <= pos <= en:
            return True
        elif pos < st:
            right = mid - 1
        else:
            left = mid + 1

    return False


def init_counter():
    return {
        "called_sites": 0,
        "called_alleles": 0,
        "alt_allele_count": 0,
        "het_loci": 0,
        "hom_alt_loci": 0,
    }


def update_counter(d, dosage):
    d["called_sites"] += 1
    d["called_alleles"] += 2
    d["alt_allele_count"] += dosage
    if dosage == 1:
        d["het_loci"] += 1
    elif dosage == 2:
        d["hom_alt_loci"] += 1


def add_rates(df):
    df["alt_allele_rate"] = df["alt_allele_count"] / df["called_alleles"].replace(0, pd.NA)
    df["het_loci_rate"] = df["het_loci"] / df["called_sites"].replace(0, pd.NA)
    df["hom_alt_loci_rate"] = df["hom_alt_loci"] / df["called_sites"].replace(0, pd.NA)
    return df


def read_froh(path):
    df = pd.read_csv(path, sep="\t")
    cols = {c.lower(): c for c in df.columns}

    sample_col = None
    for x in ["sample", "iid", "id"]:
        if x in cols:
            sample_col = cols[x]
            break

    froh_col = None
    for x in ["froh", "f_roh", "froh_total", "froh_all"]:
        if x in cols:
            froh_col = cols[x]
            break

    if sample_col is None or froh_col is None:
        raise RuntimeError(
            f"Cannot detect sample/FROH columns in {path}. "
            f"Need sample/IID and FROH-like columns."
        )

    out = df[[sample_col, froh_col]].copy()
    out.columns = ["sample", "FROH"]
    return out


def main():
    args = parse_args()

    print(f"[INFO] Reading ROH intervals: {args.roh}")
    roh = read_roh_intervals(args.roh)

    print(f"[INFO] Reading VCF: {args.vcf}")
    vcf = pysam.VariantFile(args.vcf)
    samples = list(vcf.header.samples)
    print(f"[INFO] VCF samples: {len(samples)}")

    site_rows = []

    total = defaultdict(init_counter)
    deleterious = defaultdict(init_counter)
    synonymous = defaultdict(init_counter)

    region_counter = defaultdict(init_counter)
    # key = (sample, variant_class, region)

    n_sites_total = 0
    n_sites_del = 0
    n_sites_syn = 0

    for rec in vcf:
        n_sites_total += 1

        if len(rec.alleles) != 2:
            continue

        chrom = str(rec.chrom)
        pos = int(rec.pos)
        ref = rec.ref
        alt = rec.alts[0] if rec.alts else None

        scores = extract_sift_scores_from_info(rec.info)
        annotation_class = extract_annotation_class(rec.info)

        is_del = False
        min_sift = None

        if scores:
            min_sift = min(scores)
            if min_sift < args.sift_cutoff:
                is_del = True

        if is_del:
            variant_class = "SIFT_deleterious"
            n_sites_del += 1
        elif annotation_class == "synonymous":
            variant_class = "synonymous"
            n_sites_syn += 1
        else:
            continue

        site_rows.append({
            "chrom": chrom,
            "pos": pos,
            "ref": ref,
            "alt": alt,
            "variant_class": variant_class,
            "min_sift": min_sift if min_sift is not None else "NA",
            "annotation_class": annotation_class,
        })

        for s in samples:
            gt = rec.samples[s].get("GT")
            dosage = gt_to_alt_dosage(gt)
            if dosage is None:
                continue

            update_counter(total[s], dosage)

            if variant_class == "SIFT_deleterious":
                update_counter(deleterious[s], dosage)
            elif variant_class == "synonymous":
                update_counter(synonymous[s], dosage)

            region = "ROH" if in_intervals(pos, roh.get(s, {}).get(chrom, [])) else "nonROH"
            update_counter(region_counter[(s, variant_class, region)], dosage)

    print(f"[INFO] Scanned VCF sites: {n_sites_total}")
    print(f"[INFO] SIFT deleterious sites: {n_sites_del}")
    print(f"[INFO] Synonymous sites: {n_sites_syn}")

    site_df = pd.DataFrame(site_rows)
    site_out = args.out_prefix + ".site_class.tsv"
    site_df.to_csv(site_out, sep="\t", index=False)
    print(f"[OUT] {site_out}")

    burden_rows = []
    for s in samples:
        for cls, dic in [
            ("SIFT_deleterious", deleterious[s]),
            ("synonymous", synonymous[s]),
            ("all_used", total[s]),
        ]:
            row = {"species": args.species, "sample": s, "variant_class": cls}
            row.update(dic)
            burden_rows.append(row)

    burden_df = pd.DataFrame(burden_rows)
    burden_df = add_rates(burden_df)

    burden_out = args.out_prefix + ".per_sample_burden.tsv"
    burden_df.to_csv(burden_out, sep="\t", index=False)
    print(f"[OUT] {burden_out}")

    region_rows = []
    for (s, cls, region), dic in region_counter.items():
        row = {
            "species": args.species,
            "sample": s,
            "variant_class": cls,
            "region": region,
        }
        row.update(dic)
        region_rows.append(row)

    region_df = pd.DataFrame(region_rows)
    region_df = add_rates(region_df)

    region_out = args.out_prefix + ".per_sample_region_burden.tsv"
    region_df.to_csv(region_out, sep="\t", index=False)
    print(f"[OUT] {region_out}")

    froh_df = read_froh(args.froh)

    del_df = burden_df[burden_df["variant_class"] == "SIFT_deleterious"].copy()
    merge_df = del_df.merge(froh_df, on="sample", how="left")

    merge_out = args.out_prefix + ".FROH.merge.tsv"
    merge_df.to_csv(merge_out, sep="\t", index=False)
    print(f"[OUT] {merge_out}")

    print("[DONE] Calculation finished.")


if __name__ == "__main__":
    main()