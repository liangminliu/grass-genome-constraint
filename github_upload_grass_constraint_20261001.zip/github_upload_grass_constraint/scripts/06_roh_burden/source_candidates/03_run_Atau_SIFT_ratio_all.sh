#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "${SCRIPT_DIR}/00_config_Atau_SIFT_ratio.sh"

mkdir -p "${OUTDIR}" "${LOGDIR}"

LOG="${LOGDIR}/${PREFIX}.$(date +%Y%m%d_%H%M%S).log"
exec > >(tee "${LOG}") 2>&1

echo "============================================================"
echo "[INFO] Atau SIFT + FROH ratio pipeline"
echo "[INFO] Start time    = $(date)"
echo "[INFO] SCRIPT_DIR    = ${SCRIPT_DIR}"
echo "[INFO] SIFT_VCF      = ${SIFT_VCF}"
echo "[INFO] FROH_FILE     = ${FROH_FILE}"
echo "[INFO] ROH_SEG_FILE  = ${ROH_SEG_FILE}"
echo "[INFO] LAUTO_FILE    = ${LAUTO_FILE}"
echo "[INFO] OUTDIR        = ${OUTDIR}"
echo "[INFO] PREFIX        = ${PREFIX}"
echo "[INFO] SIFT_CUTOFF   = ${SIFT_CUTOFF}"
echo "[INFO] EXCLUDE       = ${EXCLUDE_SAMPLES}"
echo "[INFO] ALLOW_SIFT_WITHOUT_EFFECT = ${ALLOW_SIFT_WITHOUT_EFFECT:-0}"
echo "============================================================"

echo "[STEP 1] Check programs"
for x in python3 Rscript; do
  if command -v "$x" >/dev/null 2>&1; then
    echo "[OK] $x = $(command -v "$x")"
  else
    echo "[ERROR] Required program not found: $x"
    exit 1
  fi
done

echo "[STEP 2] Check input files"

if [[ ! -s "${SIFT_VCF}" ]]; then
  echo "[ERROR] Missing or empty SIFT_VCF:"
  echo "        ${SIFT_VCF}"
  exit 1
else
  ls -lh "${SIFT_VCF}"
fi

if [[ ! -s "${FROH_FILE}" ]]; then
  echo "[ERROR] Missing or empty FROH_FILE:"
  echo "        ${FROH_FILE}"
  exit 1
else
  ls -lh "${FROH_FILE}"
fi

if [[ -z "${ROH_SEG_FILE}" ]]; then
  echo "[ERROR] ROH_SEG_FILE is empty."
  echo "[INFO] Available files in FROH_DIR:"
  ls -lh "${FROH_DIR}" || true
  exit 1
fi

if [[ ! -s "${ROH_SEG_FILE}" ]]; then
  echo "[ERROR] Missing or empty ROH_SEG_FILE:"
  echo "        ${ROH_SEG_FILE}"
  echo "[INFO] Available files in FROH_DIR:"
  ls -lh "${FROH_DIR}" || true
  exit 1
else
  ls -lh "${ROH_SEG_FILE}"
fi

if [[ -n "${LAUTO_FILE:-}" && -s "${LAUTO_FILE}" ]]; then
  ls -lh "${LAUTO_FILE}"
else
  echo "[WARN] LAUTO_FILE missing or empty, continue without using it:"
  echo "       ${LAUTO_FILE}"
fi

echo "[STEP 3] Check table headers"
echo "[INFO] FROH header:"
head -n 3 "${FROH_FILE}" || true

echo "[INFO] ROH segment header:"
head -n 3 "${ROH_SEG_FILE}" || true

echo "[STEP 4] Check scripts"
if [[ ! -s "${SCRIPT_DIR}/01_calc_Atau_SIFT_ratio.py" ]]; then
  echo "[ERROR] Missing Python script:"
  echo "        ${SCRIPT_DIR}/01_calc_Atau_SIFT_ratio.py"
  exit 1
fi

if [[ ! -s "${SCRIPT_DIR}/02_plot_Atau_SIFT_ratio.R" ]]; then
  echo "[ERROR] Missing R script:"
  echo "        ${SCRIPT_DIR}/02_plot_Atau_SIFT_ratio.R"
  exit 1
fi

echo "[OK] Python script:"
ls -lh "${SCRIPT_DIR}/01_calc_Atau_SIFT_ratio.py"

echo "[OK] R script:"
ls -lh "${SCRIPT_DIR}/02_plot_Atau_SIFT_ratio.R"

ALLOW_FLAG=""
if [[ "${ALLOW_SIFT_WITHOUT_EFFECT:-0}" == "1" ]]; then
  ALLOW_FLAG="--allow-sift-without-effect"
fi

echo "[STEP 5] Run Python calculation"
set -x
python3 -u "${SCRIPT_DIR}/01_calc_Atau_SIFT_ratio.py" \
  --vcf "${SIFT_VCF}" \
  --froh "${FROH_FILE}" \
  --roh "${ROH_SEG_FILE}" \
  --lauto "${LAUTO_FILE}" \
  --out-prefix "${OUTDIR}/${PREFIX}" \
  --sift-cutoff "${SIFT_CUTOFF}" \
  --exclude-samples "${EXCLUDE_SAMPLES}" \
  ${ALLOW_FLAG}
set +x

echo "[STEP 6] Check Python output tables"
for f in \
  "${OUTDIR}/${PREFIX}.site_AF.tsv" \
  "${OUTDIR}/${PREFIX}.classified_sites.tsv" \
  "${OUTDIR}/${PREFIX}.per_sample_burden.tsv" \
  "${OUTDIR}/${PREFIX}.ratio_metrics.tsv" \
  "${OUTDIR}/${PREFIX}.Fig2_hom_het_counts.long.tsv" \
  "${OUTDIR}/${PREFIX}.Fig2b_FROH_deleterious_counts.long.tsv" \
  "${OUTDIR}/${PREFIX}.Fig2c_FROH_deleterious_load.long.tsv"
do
  if [[ ! -s "$f" ]]; then
    echo "[ERROR] Expected output missing or empty:"
    echo "        $f"
    exit 1
  else
    ls -lh "$f"
  fi
done

echo "[STEP 7] Run R plotting"
set -x
Rscript "${SCRIPT_DIR}/02_plot_Atau_SIFT_ratio.R" \
  "${OUTDIR}" \
  "${PREFIX}" \
  "${EXCLUDE_SAMPLES}" \
  "${SIFT_CUTOFF}"
set +x

echo "[STEP 8] Final output files"
ls -lh "${OUTDIR}/${PREFIX}"*

echo "[DONE] Finished successfully: $(date)"
