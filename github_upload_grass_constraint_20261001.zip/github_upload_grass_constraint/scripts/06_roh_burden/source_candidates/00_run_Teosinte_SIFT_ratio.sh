#!/usr/bin/env bash
#SBATCH --job-name=Teosinte_SIFT
#SBATCH --output=Teosinte_SIFT_ratio_pipeline/logs/Teosinte_SIFT.%j.out
#SBATCH --error=Teosinte_SIFT_ratio_pipeline/logs/Teosinte_SIFT.%j.err
#SBATCH --cpus-per-task=1

set -euo pipefail

# ============================================================
# Teosinte SIFT deleterious burden + ROH/FROH visualization
# Direct streaming version:
#   Read original .vcf.gz using zcat inside Python.
#   No BGZF conversion, no tabix, no pysam.
# ============================================================

SPECIES="Teosinte"

BASE="Teosinte_SIFT_ratio_pipeline"
SCRIPT_DIR="${BASE}/scripts"
TABLE_DIR="${BASE}/01_tables"
PLOT_DIR="${BASE}/02_plots"
LOG_DIR="${BASE}/logs"

mkdir -p "${SCRIPT_DIR}" "${TABLE_DIR}" "${PLOT_DIR}" "${LOG_DIR}"

RAW_VCF="/gpfs/hpc/home/kib_unit/lidezhu/liuliangmin/2.msa/Zmay/Zmay_v5_results/GERP_output/03.deletrious/04.SIFT/SIFT4G_results/all.filtered.bi-allelic.miss0.5.snp_SIFTpredictions.vcf.gz"

ROH_SEG="ROH_pipeline/Teosinte/04_froh/plink_kb100_gap1000_winmiss5/ROH.segments.plink.ge100000.minSNP50.kb100_gap1000_winmiss5.classified.tsv"

FROH_FILE="ROH_pipeline/Teosinte/04_froh/plink_kb100_gap1000_winmiss5/FROH.final.plink.kb100_gap1000_winmiss5.tsv"

OUT_PREFIX="${TABLE_DIR}/${SPECIES}.SIFT"

echo "============================================================"
echo "[INFO] Species    = ${SPECIES}"
echo "[INFO] RAW_VCF    = ${RAW_VCF}"
echo "[INFO] ROH_SEG    = ${ROH_SEG}"
echo "[INFO] FROH_FILE  = ${FROH_FILE}"
echo "[INFO] OUT_PREFIX = ${OUT_PREFIX}"
echo "============================================================"

for cmd in zcat python3 Rscript; do
  if ! command -v "${cmd}" >/dev/null 2>&1; then
    echo "[ERROR] Required command not found: ${cmd}" >&2
    exit 1
  fi
done

if [[ ! -s "${RAW_VCF}" ]]; then
  echo "[ERROR] RAW_VCF not found or empty:" >&2
  echo "        ${RAW_VCF}" >&2
  exit 1
fi

if [[ ! -s "${ROH_SEG}" ]]; then
  echo "[ERROR] ROH segment file not found:" >&2
  echo "        ${ROH_SEG}" >&2
  exit 1
fi

if [[ ! -s "${FROH_FILE}" ]]; then
  echo "[ERROR] FROH file not found:" >&2
  echo "        ${FROH_FILE}" >&2
  exit 1
fi

echo "[INFO] Running direct streaming SIFT calculation..."

python3 "${SCRIPT_DIR}/01_calc_Teosinte_SIFT_ROH_stream.py" \
  --vcf "${RAW_VCF}" \
  --roh "${ROH_SEG}" \
  --froh "${FROH_FILE}" \
  --species "${SPECIES}" \
  --sift-cutoff 0.05 \
  --out-prefix "${OUT_PREFIX}" \
  > "${LOG_DIR}/01_calc_${SPECIES}_SIFT_ROH.stream.log" \
  2> "${LOG_DIR}/01_calc_${SPECIES}_SIFT_ROH.stream.err"

echo "[INFO] Python direct streaming calculation finished."

echo "[INFO] Running R plotting..."

Rscript "${SCRIPT_DIR}/02_plot_Teosinte_SIFT_ratio.R" \
  "${TABLE_DIR}/${SPECIES}.SIFT.per_sample_burden.tsv" \
  "${TABLE_DIR}/${SPECIES}.SIFT.per_sample_region_burden.tsv" \
  "${TABLE_DIR}/${SPECIES}.SIFT.FROH.merge.tsv" \
  "${PLOT_DIR}/${SPECIES}_SIFT" \
  > "${LOG_DIR}/02_plot_${SPECIES}_SIFT.log" \
  2> "${LOG_DIR}/02_plot_${SPECIES}_SIFT.err"

echo "============================================================"
echo "[DONE] Teosinte SIFT direct-read pipeline finished."
echo "[OUT] Tables: ${TABLE_DIR}"
echo "[OUT] Plots : ${PLOT_DIR}"
echo "[LOG] Logs  : ${LOG_DIR}"
echo "============================================================"
