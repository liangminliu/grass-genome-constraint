#!/usr/bin/env bash
set -euo pipefail

BASE="${BASE:-Teosinte_GERP_fullgenome_pipeline}"
SCRIPT_DIR="${SCRIPT_DIR:-${BASE}/scripts}"
OUT_DIR="${OUT_DIR:-${BASE}/04_Teosinte_ROH_FROH}"

FROH_FILE="${FROH_FILE:-ROH_pipeline/Teosinte/04_froh/plink_kb100_gap1000_winmiss5/FROH.final.plink.kb100_gap1000_winmiss5.tsv}"
ROH_SEG_FILE="${ROH_SEG_FILE:-ROH_pipeline/Teosinte/04_froh/plink_kb100_gap1000_winmiss5/ROH.segments.plink.ge100000.minSNP50.kb100_gap1000_winmiss5.classified.tsv}"
RAW_VCF="${RAW_VCF:-all.filtered.bi-allelic.miss0.5.snp.vcf.gz}"

CHR_MAP="${CHR_MAP:-${OUT_DIR}/00_inputs/Teosinte.chrom_map.txt}"
CHR_SIZE="${OUT_DIR}/00_inputs/Teosinte.chrom_sizes.tsv"

TABLE_PREFIX="${OUT_DIR}/01_tables/Teosinte_ROH_FROH"
PLOT_PREFIX="${OUT_DIR}/02_plots/Teosinte_ROH_FROH"

MIN_ROH_BP="${MIN_ROH_BP:-100000}"
FREQ_ROH_BP="${FREQ_ROH_BP:-100000}"          # D 图：ROH >= 100 kb
LANDSCAPE_ROH_BP="${LANDSCAPE_ROH_BP:-100000}" # E 图：ROH >= 100 kb
WINDOW_BP="${WINDOW_BP:-1000000}"             # D 图：1 Mb window
REPRESENTATIVE_N="${REPRESENTATIVE_N:-5}"
EXCLUDE_SAMPLES="${EXCLUDE_SAMPLES:-none}"
SPECIES_LABEL="${SPECIES_LABEL:-Teosinte}"

mkdir -p "${SCRIPT_DIR}" "${OUT_DIR}/00_inputs" "${OUT_DIR}/01_tables" "${OUT_DIR}/02_plots" "${OUT_DIR}/logs"

LOG_FILE="${OUT_DIR}/logs/Teosinte.ROH_FROH.visualization.$(date +%Y%m%d_%H%M%S).log"

{
echo "============================================================"
echo "[INFO] Teosinte ROH/FROH visualization"
echo "[INFO] BASE              = ${BASE}"
echo "[INFO] SCRIPT_DIR        = ${SCRIPT_DIR}"
echo "[INFO] OUT_DIR           = ${OUT_DIR}"
echo "[INFO] FROH_FILE         = ${FROH_FILE}"
echo "[INFO] ROH_SEG_FILE      = ${ROH_SEG_FILE}"
echo "[INFO] RAW_VCF           = ${RAW_VCF}"
echo "[INFO] CHR_MAP           = ${CHR_MAP}"
echo "[INFO] CHR_SIZE          = ${CHR_SIZE}"
echo "[INFO] TABLE_PREFIX      = ${TABLE_PREFIX}"
echo "[INFO] PLOT_PREFIX       = ${PLOT_PREFIX}"
echo "[INFO] MIN_ROH_BP        = ${MIN_ROH_BP}"
echo "[INFO] FREQ_ROH_BP       = ${FREQ_ROH_BP}"
echo "[INFO] LANDSCAPE_ROH_BP  = ${LANDSCAPE_ROH_BP}"
echo "[INFO] WINDOW_BP         = ${WINDOW_BP}"
echo "[INFO] REPRESENTATIVE_N  = ${REPRESENTATIVE_N}"
echo "[INFO] EXCLUDE_SAMPLES   = ${EXCLUDE_SAMPLES}"
echo "[INFO] SPECIES_LABEL     = ${SPECIES_LABEL}"
echo "============================================================"

if [[ ! -s "${FROH_FILE}" ]]; then
  echo "[ERROR] FROH file not found: ${FROH_FILE}" >&2
  exit 1
fi

if [[ ! -s "${ROH_SEG_FILE}" ]]; then
  echo "[ERROR] ROH segment file not found: ${ROH_SEG_FILE}" >&2
  exit 1
fi

if [[ ! -s "${RAW_VCF}" ]]; then
  echo "[ERROR] RAW_VCF not found: ${RAW_VCF}" >&2
  exit 1
fi

if ! command -v bcftools >/dev/null 2>&1; then
  echo "[ERROR] bcftools not found in PATH" >&2
  exit 1
fi

if ! command -v python3 >/dev/null 2>&1; then
  echo "[ERROR] python3 not found in PATH" >&2
  exit 1
fi

if ! command -v Rscript >/dev/null 2>&1; then
  echo "[ERROR] Rscript not found in PATH" >&2
  exit 1
fi

if [[ ! -s "${RAW_VCF}.tbi" && ! -s "${RAW_VCF}.csi" ]]; then
  echo "[INFO] VCF index not found. Creating tabix index..."
  bcftools index -t "${RAW_VCF}" || bcftools index "${RAW_VCF}"
fi

echo "[INFO] Build chromosome-size table from bcftools index -s: ${RAW_VCF}"
bcftools index -s "${RAW_VCF}" | \
  awk 'BEGIN{OFS="\t"; print "chr","start_bp","end_bp","Lauto_bp"} {print $1,1,$2,$2}' \
  > "${CHR_SIZE}"

if [[ ! -s "${CHR_MAP}" ]]; then
  echo "[INFO] CHR_MAP not found. Auto-create no-renaming chromosome map: ${CHR_MAP}"
  awk 'BEGIN{OFS="\t"} NR>1{print $1,$1}' "${CHR_SIZE}" > "${CHR_MAP}"
fi

echo "[INFO] Prepare Teosinte ROH/FROH tables..."
python3 "${SCRIPT_DIR}/01_prepare_Teosinte_ROH_FROH_tables.py" \
  --froh "${FROH_FILE}" \
  --roh "${ROH_SEG_FILE}" \
  --lauto "${CHR_SIZE}" \
  --chrom-map "${CHR_MAP}" \
  --out-prefix "${TABLE_PREFIX}" \
  --exclude-samples "${EXCLUDE_SAMPLES}" \
  --min-roh-bp "${MIN_ROH_BP}" \
  --freq-roh-bp "${FREQ_ROH_BP}" \
  --landscape-roh-bp "${LANDSCAPE_ROH_BP}" \
  --window-bp "${WINDOW_BP}" \
  --representative-n "${REPRESENTATIVE_N}"

echo "[INFO] Plot Teosinte ROH/FROH figures..."
Rscript "${SCRIPT_DIR}/02_plot_Teosinte_ROH_FROH_final.R" \
  "${TABLE_PREFIX}" \
  "${PLOT_PREFIX}" \
  "${SPECIES_LABEL}"

echo "[DONE] All Teosinte ROH/FROH tables and plots finished."
echo "[DONE] Output directory: ${OUT_DIR}"
} 2>&1 | tee "${LOG_FILE}"