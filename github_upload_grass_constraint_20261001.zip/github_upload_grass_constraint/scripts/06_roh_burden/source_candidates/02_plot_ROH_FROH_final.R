#!/usr/bin/env Rscript

suppressPackageStartupMessages({
  library(readr)
  library(dplyr)
  library(ggplot2)
  library(patchwork)
  library(scales)
  library(tidyr)
})

args <- commandArgs(trailingOnly = TRUE)

if (length(args) < 3) {
  stop("Usage:
Rscript 02_plot_ROH_FROH_final.R <table_prefix> <out_prefix> <species_label>
")
}

table_prefix <- args[1]
out_prefix   <- args[2]
species_label <- args[3]

dir.create(dirname(out_prefix), recursive = TRUE, showWarnings = FALSE)

read_table <- function(x) read_tsv(x, show_col_types = FALSE, progress = FALSE)

froh        <- read_table(paste0(table_prefix, ".froh.tsv"))
chr_info    <- read_table(paste0(table_prefix, ".chr_info.tsv"))
roh         <- read_table(paste0(table_prefix, ".roh_segments.clean.tsv"))
by_class    <- read_table(paste0(table_prefix, ".cumulative_by_class.tsv"))
freq        <- read_table(paste0(table_prefix, ".ROH_frequency.5Mb.tsv"))
rep_samples <- read_table(paste0(table_prefix, ".representative_samples.tsv"))
land        <- read_table(paste0(table_prefix, ".representative_ROH.tsv"))

class_levels <- c("100–250 kb", "250–500 kb", "500 kb–1 Mb", ">1 Mb")
by_class$roh_class <- factor(by_class$roh_class, levels = class_levels)

chr_info <- chr_info %>%
  mutate(
    center = offset + chr_len / 2,
    xmin   = offset,
    xmax   = offset + chr_len,
    bg_key = ifelse(chr_index %% 2 == 1, "bg_odd", "bg_even"),
    seg_key = ifelse(chr_index %% 2 == 1, "seg_odd", "seg_even")
  )

chr_label <- function(x) gsub("D$", "", x)

theme_old <- function(base_size = 10) {
  theme_classic(base_size = base_size) +
    theme(
      text = element_text(color = "grey15"),
      axis.text = element_text(color = "grey25"),
      axis.title = element_text(color = "grey10"),
      axis.line = element_line(color = "grey30", linewidth = 0.42),
      axis.ticks = element_line(color = "grey30", linewidth = 0.35),
      panel.grid.major.y = element_line(color = "grey90", linewidth = 0.28),
      panel.grid.major.x = element_blank(),
      panel.grid.minor = element_blank(),
      plot.title = element_text(hjust = 0.0, face = "bold", size = base_size + 3),
      plot.subtitle = element_text(hjust = 0.0, color = "grey35", size = base_size),
      plot.tag = element_text(face = "bold", size = base_size + 6),
      legend.title = element_blank(),
      legend.key = element_blank()
    )
}

save_both <- function(plot, prefix, width, height) {
  pdf_file <- paste0(prefix, ".pdf")
  png_file <- paste0(prefix, ".png")
  pdf_dev <- if (capabilities("cairo")) grDevices::cairo_pdf else grDevices::pdf
  ggsave(pdf_file, plot, width = width, height = height, units = "in", device = pdf_dev)
  ggsave(png_file, plot, width = width, height = height, units = "in", dpi = 600)
  message("[WRITE] ", pdf_file)
  message("[WRITE] ", png_file)
}

nice_x_top <- function(x) {
  if (!is.finite(x) || x <= 0) return(1)
  if (x <= 1) return(ceiling(x * 10) / 10)
  if (x <= 10) return(ceiling(x))
  if (x <= 100) return(ceiling(x / 5) * 5)
  ceiling(x / 10) * 10
}

## 配色：背景调淡，E 图块更明显
col_hist_fill   <- "#C9CEC1"
col_hist_border <- "#737A6E"
col_mean        <- "#4B78A8"
col_median      <- "grey45"
col_roh_freq    <- "#1F5D9D"

fill_values <- c(
  bg_odd  = "#F7F7F7",
  bg_even = "#EFEFEF",
  seg_odd = "#88C1BF",   # 青绿色块
  seg_even = "#777777"   # 深灰色块
)

baseline_col <- "#D0D0D0"

## A. FROH distribution
froh_mean   <- mean(froh$FROH, na.rm = TRUE)
froh_median <- median(froh$FROH, na.rm = TRUE)

pA <- ggplot(froh, aes(x = FROH)) +
  geom_histogram(
    bins = 22,
    fill = col_hist_fill,
    colour = col_hist_border,
    linewidth = 0.35
  ) +
  geom_vline(xintercept = froh_mean, colour = col_mean, linewidth = 0.5) +
  geom_vline(xintercept = froh_median, colour = col_median, linetype = 2, linewidth = 0.45) +
  annotate(
    "text",
    x = froh_mean + 0.01,
    y = Inf,
    label = paste0("mean = ", round(froh_mean, 2)),
    hjust = 0,
    vjust = 1.8,
    size = 2.8,
    colour = col_mean
  ) +
  labs(
    title = "Genome-wide FROH distribution",
    subtitle = paste0(species_label, ", n = ", nrow(froh)),
    x = expression(F[ROH]),
    y = "Number of individuals",
    tag = "A"
  ) +
  theme_old(10)

## B. cumulative FROH contribution
mean_cum <- by_class %>%
  group_by(roh_class) %>%
  summarise(cumulative_FROH = mean(cumulative_FROH, na.rm = TRUE), .groups = "drop")

pB <- ggplot(by_class, aes(x = roh_class, y = cumulative_FROH, group = sample)) +
  geom_line(colour = "grey60", alpha = 0.35, linewidth = 0.35) +
  geom_point(colour = "grey55", alpha = 0.35, size = 0.7) +
  geom_line(
    data = mean_cum,
    aes(x = roh_class, y = cumulative_FROH, group = 1),
    inherit.aes = FALSE,
    colour = "black",
    linewidth = 0.8
  ) +
  geom_point(
    data = mean_cum,
    aes(x = roh_class, y = cumulative_FROH),
    inherit.aes = FALSE,
    colour = "black",
    size = 1.6
  ) +
  labs(
    title = "Cumulative FROH contribution by ROH length",
    subtitle = "ROH classes: 100–250 kb, 250–500 kb, 500 kb–1 Mb, >1 Mb",
    x = "ROH length class",
    y = expression("Cumulative " * F[ROH]),
    tag = "B"
  ) +
  theme_old(10) +
  theme(axis.text.x = element_text(angle = 18, hjust = 1))

## C. ROH length distribution
mean_len   <- mean(roh$length_Mb, na.rm = TRUE)
median_len <- median(roh$length_Mb, na.rm = TRUE)
min_len    <- min(roh$length_Mb, na.rm = TRUE)
max_len    <- max(roh$length_Mb, na.rm = TRUE)

pC <- ggplot(roh, aes(x = length_Mb)) +
  geom_histogram(
    bins = 80,
    fill = col_hist_fill,
    colour = col_hist_border,
    linewidth = 0.2
  ) +
  geom_vline(xintercept = mean_len, colour = col_mean, linewidth = 0.5) +
  geom_vline(xintercept = median_len, colour = col_median, linetype = 2, linewidth = 0.4) +
  annotate(
    "text",
    x = mean_len + 0.03,
    y = Inf,
    label = paste0("mean = ", round(mean_len, 2), " Mb"),
    hjust = 0,
    vjust = 1.7,
    size = 2.8,
    colour = col_mean
  ) +
  scale_x_continuous(
    limits = c(0, nice_x_top(max_len)),
    expand = expansion(mult = c(0.01, 0.02))
  ) +
  scale_y_continuous(labels = comma) +
  labs(
    title = "ROH length distribution",
    subtitle = paste0("ROH segments ≥100 kb; observed range = ",
                      round(min_len, 3), "–", round(max_len, 3), " Mb"),
    x = "ROH length (Mb)",
    y = "Number of ROH segments",
    tag = "C"
  ) +
  theme_old(10)

## D. >1 Mb long ROH frequency
pD <- ggplot() +
  geom_rect(
    data = chr_info,
    aes(xmin = xmin, xmax = xmax, ymin = -Inf, ymax = Inf, fill = bg_key),
    inherit.aes = FALSE,
    colour = NA,
    alpha = 1
  ) +
  geom_line(
    data = freq,
    aes(x = x, y = roh_frequency),
    colour = col_roh_freq,
    linewidth = 0.5
  ) +
  scale_fill_manual(values = fill_values, guide = "none") +
  scale_x_continuous(
    breaks = chr_info$center,
    labels = chr_label(chr_info$chr),
    expand = c(0.01, 0.01)
  ) +
  scale_y_continuous(
    labels = percent_format(accuracy = 1),
    limits = c(0, 1),
    expand = c(0, 0)
  ) +
  labs(
    title = "Genome-wide frequency of long ROH",
    subtitle = "ROH segments >1 Mb; window size = 5 Mb",
    x = "Chromosome",
    y = "Frequency of individuals with long ROH",
    tag = "D"
  ) +
  theme_old(10)

## E. representative landscape
## 关键修复：
## 1) 先画浅灰色轨道
## 2) 再用 geom_rect 画 ROH 小块（不是 geom_segment）
## 3) 提高块高度，使视觉接近示意图
## 4) 背景调淡

rep_df <- rep_samples %>%
  arrange(sample_rank) %>%
  mutate(
    y = rev(seq_len(n())),
    xmin_all = min(chr_info$xmin),
    xmax_all = max(chr_info$xmax)
  )

land2 <- land %>%
  left_join(rep_df %>% select(sample, y), by = "sample") %>%
  left_join(chr_info %>% select(chr, seg_key), by = "chr") %>%
  mutate(
    ymin = y - 0.19,
    ymax = y + 0.19
  )

baseline_df <- rep_df %>%
  mutate(
    ymin = y - 0.028,
    ymax = y + 0.028
  )

pE <- ggplot() +
  geom_rect(
    data = chr_info,
    aes(xmin = xmin, xmax = xmax, ymin = -Inf, ymax = Inf, fill = bg_key),
    inherit.aes = FALSE,
    colour = NA,
    alpha = 1
  ) +
  geom_rect(
    data = baseline_df,
    aes(xmin = xmin_all, xmax = xmax_all, ymin = ymin, ymax = ymax),
    inherit.aes = FALSE,
    fill = baseline_col,
    colour = NA,
    alpha = 0.95
  ) +
  geom_rect(
    data = land2,
    aes(xmin = xstart, xmax = xend, ymin = ymin, ymax = ymax, fill = seg_key),
    inherit.aes = FALSE,
    colour = NA,
    alpha = 0.95
  ) +
  scale_fill_manual(values = fill_values, guide = "none") +
  scale_x_continuous(
    breaks = chr_info$center,
    labels = chr_label(chr_info$chr),
    expand = c(0.01, 0.01)
  ) +
  scale_y_continuous(
    breaks = rep_df$y,
    labels = rep_df$sample,
    expand = expansion(mult = c(0.03, 0.03))
  ) +
  labs(
    title = "Representative individual ROH landscape",
    subtitle = "ROH segments ≥100 kb; five most inbred individuals are shown above and five least inbred individuals below",
    x = "Chromosome",
    y = "Individuals",
    tag = "E"
  ) +
  theme_old(10) +
  theme(
    panel.grid.major.y = element_blank(),
    axis.text.y = element_text(size = 8, colour = "grey25"),
    axis.title.y = element_text(size = 11),
    plot.title = element_text(size = 14, face = "bold"),
    plot.subtitle = element_text(size = 10.5, colour = "grey35")
  )

combined <- (pA | pB) / (pC | pD) / pE +
  plot_layout(heights = c(1, 1, 1.30)) +
  plot_annotation(tag_levels = NULL) &
  theme(plot.tag = element_text(face = "bold", size = 14))

save_both(pA, paste0(out_prefix, ".FigA_FROH_distribution"), 5.2, 3.5)
save_both(pB, paste0(out_prefix, ".FigB_cumulative_FROH_contribution"), 5.4, 3.5)
save_both(pC, paste0(out_prefix, ".FigC_ROH_length_distribution"), 5.2, 3.5)
save_both(pD, paste0(out_prefix, ".FigD_genomewide_longROH_frequency_gt1Mb"), 5.4, 3.5)
save_both(pE, paste0(out_prefix, ".FigE_representative_ROH_landscape_ge100kb"), 13.5, 5.0)
save_both(combined, paste0(out_prefix, ".00_main_ROH_FROH_final_Dgt1Mb_Ege100kb"), 11.8, 12.4)

message("[DONE] ROH/FROH final plots generated. D uses ROH >1 Mb; E uses all ROH >=100 kb.")