#!/usr/bin/env python3
# -*- coding: utf-8 -*-

from __future__ import annotations

import argparse
import csv
import gzip
import hashlib
import math
import os
import re
import sys
from bisect import bisect_left
from collections import Counter, defaultdict
from typing import Any, Dict, List, Optional, Tuple

try:
    import pysam
except ImportError:
    sys.stderr.write("[ERROR] pysam is required. Install with: mamba install -c bioconda pysam\n")
    raise


VARIANT_CLASSES = ["SYNONYMOUS", "NONSYN_TOLERATED", "NONSYN_DELETERIOUS"]
REGIONS = ["ALL", "ROH", "Non-ROH"]

CLASS_LABEL = {
    "SYNONYMOUS": "Synonymous",
    "NONSYN_TOLERATED": "Tolerated nonsynonymous",
    "NONSYN_DELETERIOUS": "Deleterious nonsynonymous",
}


def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(
        description="Calculate SIFTINFO-based burden and ROH/Non-ROH metrics for Ped."
    )

    p.add_argument("--vcf", required=True, action="append",
                   help="Use label=path. Can be repeated, e.g. pedC=file.vcf --vcf pedD=file.vcf")
    p.add_argument("--froh", required=True)
    p.add_argument("--roh", required=True)
    p.add_argument("--out-prefix", required=True)
    p.add_argument("--species-label", default="Ped")
    p.add_argument("--sift-cutoff", type=float, default=0.05)
    p.add_argument("--exclude-samples", default="")
    p.add_argument("--allow-sift-without-effect", action="store_true")
    p.add_argument("--max-sites", type=int, default=0)
    p.add_argument("--write-unclassified-examples", type=int, default=100)
    p.add_argument("--chrom-map", default="",
                   help="Optional two-column map: VCF_chrom<TAB>ROH_chrom")

    return p.parse_args()


def smart_open(path: str, mode: str = "rt"):
    if path.endswith(".gz"):
        return gzip.open(path, mode)
    return open(path, mode)


def parse_vcf_specs(specs: List[str]) -> List[Tuple[str, str]]:
    out = []

    for i, sp in enumerate(specs, 1):
        if "=" in sp:
            label, path = sp.split("=", 1)
        else:
            label, path = f"VCF{i}", sp

        label = label.strip()
        path = path.strip()

        if not os.path.exists(path):
            raise FileNotFoundError(f"Missing VCF: {path}")

        out.append((label, path))

    return out


def find_invalid_simple_meta_headers(path: str) -> int:
    n = 0
    with smart_open(path, "rt") as f:
        for line in f:
            if line.startswith("#CHROM"):
                break
            if line.startswith("##") and re.match(r"^##[A-Za-z0-9_.-]+:\s*", line):
                n += 1
    return n


def sanitize_vcf_header_if_needed(path: str, cache_dir: str) -> str:
    bad_n = find_invalid_simple_meta_headers(path)

    if bad_n == 0:
        return path

    os.makedirs(cache_dir, exist_ok=True)

    base = os.path.basename(path)
    if base.endswith(".gz"):
        base = base[:-3]

    digest = hashlib.md5(os.path.abspath(path).encode("utf-8")).hexdigest()[:10]
    fixed = os.path.join(cache_dir, f"{base}.{digest}.header_fixed.vcf")

    if os.path.exists(fixed) and os.path.getsize(fixed) > 0:
        if os.path.getmtime(fixed) >= os.path.getmtime(path):
            sys.stderr.write(f"[INFO] Reusing header-fixed VCF: {fixed}\n")
            return fixed

    sys.stderr.write(
        f"[WARN] Found {bad_n} non-standard VCF header line(s) in {path}; "
        f"writing htslib-compatible copy: {fixed}\n"
    )

    with smart_open(path, "rt") as fin, open(fixed, "wt") as fout:
        for line in fin:
            if line.startswith("##"):
                m = re.match(r"^(##[A-Za-z0-9_.-]+):\s*(.*?)(\r?\n)?$", line)
                if m:
                    newline = m.group(3) if m.group(3) is not None else "\n"
                    fout.write(f"{m.group(1)}={m.group(2)}{newline}")
                else:
                    fout.write(line)
            else:
                fout.write(line)

    return fixed


def common_cache_dir_from_out_prefix(out_prefix: str) -> str:
    out_dir = os.path.abspath(os.path.dirname(out_prefix) or ".")
    parts = out_dir.split(os.sep)

    if "results" in parts:
        idx = parts.index("results")
        root = os.sep.join(parts[:idx]) if idx > 0 else os.sep
    else:
        root = out_dir

    return os.path.join(root, "work", "vcf_header_fixed")


def prepare_vcf_specs(vcf_specs: List[Tuple[str, str]], out_prefix: str) -> List[Tuple[str, str]]:
    cache_dir = common_cache_dir_from_out_prefix(out_prefix)
    out = []

    for label, path in vcf_specs:
        out.append((label, sanitize_vcf_header_if_needed(path, cache_dir)))

    return out


def split_exclude(raw: str) -> set:
    if raw is None:
        return set()

    return {
        x for x in re.split(r"[,;\s]+", raw.strip())
        if x and x.lower() not in {"none", "na", "null"}
    }


def read_tsv_dicts(path: str) -> List[Dict[str, str]]:
    with smart_open(path, "rt") as f:
        first = f.readline()

        if not first:
            return []

        sep = "\t" if "\t" in first else None
        f.seek(0)

        if sep == "\t":
            return list(csv.DictReader(f, delimiter="\t"))

        header = re.split(r"\s+", first.strip())
        out = []

        for line in f:
            if not line.strip():
                continue
            vals = re.split(r"\s+", line.strip())
            if len(vals) < len(header):
                continue
            out.append(dict(zip(header, vals)))

        return out


def as_float(x: Any) -> Optional[float]:
    try:
        if x is None or x == "":
            return None
        v = float(str(x).replace(",", ""))
        if math.isfinite(v):
            return v
    except Exception:
        pass

    return None


def read_froh(path: str, exclude: set) -> Dict[str, Dict[str, float]]:
    rows = read_tsv_dicts(path)

    if not rows:
        raise RuntimeError(f"Empty FROH file: {path}")

    cols = set(rows[0].keys())

    if "Sample" in cols:
        sample_col = "Sample"
    elif "IID" in cols:
        sample_col = "IID"
    elif "sample" in cols:
        sample_col = "sample"
    else:
        raise RuntimeError("FROH file must contain Sample/IID/sample column.")

    if "FROH" in cols:
        froh_col = "FROH"
    elif "FROH_refGenome" in cols:
        froh_col = "FROH_refGenome"
    else:
        raise RuntimeError("FROH file must contain FROH or FROH_refGenome column.")

    numeric_cols = [
        "N_ROH", "S_ROH_bp", "Lauto_bp", "FROH", "FROH_refGenome",
        "FROH_local_short", "FROH_local_medium", "FROH_local_long",
        "N_local_short", "N_local_medium", "N_local_long",
        "S_local_short_bp", "S_local_medium_bp", "S_local_long_bp",
        "Contribution_local_short", "Contribution_local_medium", "Contribution_local_long",
    ]

    out = {}

    for r in rows:
        s = str(r.get(sample_col, "")).strip()

        if not s or s in exclude:
            continue

        f = as_float(r.get(froh_col))
        if f is None:
            continue

        rec = {"FROH": f}

        for k in numeric_cols:
            if k in r:
                val = as_float(r.get(k))
                if val is not None:
                    rec[k] = val

        out[s] = rec

    if not out:
        raise RuntimeError("No samples left after reading FROH/exclusions.")

    return out


def canonical_chrom(chrom: str) -> str:
    c = str(chrom).strip()

    if c.lower().startswith("chr"):
        c = c[3:]

    return c


def chrom_aliases(chrom: str) -> List[str]:
    c = canonical_chrom(chrom)
    aliases = [c]

    m = re.match(r"^Ped0*([0-9]+)([A-Za-z])?$", c, re.I)
    if m:
        n = str(int(m.group(1)))
        sub = m.group(2)
        aliases.append(n)
        if sub:
            aliases.append(n + sub.upper())
            aliases.append(f"{int(n):02d}{sub.upper()}")

    m = re.match(r"^0*([0-9]+)([A-Za-z])?$", c)
    if m:
        n = str(int(m.group(1)))
        sub = m.group(2)
        aliases.append(n)
        if sub:
            aliases.append(n + sub.upper())
            aliases.append(f"{int(n):02d}{sub.upper()}")

    out = []
    seen = set()

    for x in aliases:
        if x not in seen:
            out.append(x)
            seen.add(x)

    return out


def read_chrom_map(path: str) -> Dict[str, str]:
    if not path:
        return {}

    if not os.path.exists(path):
        raise FileNotFoundError(f"Missing chromosome map: {path}")

    cmap = {}

    with smart_open(path, "rt") as f:
        for line in f:
            if not line.strip() or line.startswith("#"):
                continue

            x = re.split(r"\s+", line.strip())
            if len(x) < 2:
                continue

            cmap[canonical_chrom(x[0])] = canonical_chrom(x[1])

    return cmap


def lookup_chrom_keys(vcf_chrom: str, chrom_map: Dict[str, str]) -> List[str]:
    c = canonical_chrom(vcf_chrom)

    keys = []

    if c in chrom_map:
        keys.append(chrom_map[c])

    keys.extend(chrom_aliases(c))

    out = []
    seen = set()

    for k in keys:
        if k not in seen:
            out.append(k)
            seen.add(k)

    return out



def pick_col(cols, candidates, label, path):
    """
    Pick the first matched column name from candidates.
    Matching is case-sensitive first, then lower-case insensitive.
    """
    colset = set(cols)

    for c in candidates:
        if c in colset:
            return c

    lower_map = {c.lower(): c for c in cols}
    for c in candidates:
        if c.lower() in lower_map:
            return lower_map[c.lower()]

    raise RuntimeError(
        f"{label} column not found in {path}. "
        f"Accepted names: {candidates}. "
        f"Actual columns: {list(cols)}"
    )


def read_roh_segments(path: str, include_samples: set) -> Dict[str, Dict[str, Tuple[List[int], List[int]]]]:
    """
    Read PLINK ROH segment table.

    Compatible column names:
      sample: Sample / sample / IID / iid / FID
      chrom : Chrom / chrom / chr / CHR
      start : Start / start / start_bp / BP1 / bp1
      end   : End / end / end_bp / BP2 / bp2

    Your current file header:
      FID IID sample chr snp1 snp2 start_bp end_bp length_bp ...
    is supported by this function.
    """
    rows = read_tsv_dicts(path)

    if not rows:
        raise RuntimeError(f"Empty ROH segment file: {path}")

    cols = list(rows[0].keys())

    sample_col = pick_col(
        cols,
        ["Sample", "sample", "IID", "iid", "FID", "fid"],
        "sample",
        path
    )

    chrom_col = pick_col(
        cols,
        ["Chrom", "chrom", "chr", "CHR"],
        "chromosome",
        path
    )

    start_col = pick_col(
        cols,
        ["Start", "start", "start_bp", "START_BP", "BP1", "bp1", "pos1", "POS1"],
        "start",
        path
    )

    end_col = pick_col(
        cols,
        ["End", "end", "end_bp", "END_BP", "BP2", "bp2", "pos2", "POS2"],
        "end",
        path
    )

    sys.stderr.write(
        "[INFO] ROH columns used: "
        f"sample={sample_col}, chrom={chrom_col}, start={start_col}, end={end_col}\n"
    )

    raw = defaultdict(lambda: defaultdict(list))
    n_raw = 0
    n_skip_sample = 0
    n_skip_coord = 0

    for r in rows:
        s = str(r.get(sample_col, "")).strip()

        if not s:
            n_skip_sample += 1
            continue

        if s not in include_samples:
            n_skip_sample += 1
            continue

        chrom_raw = canonical_chrom(r.get(chrom_col, ""))

        st = as_float(r.get(start_col))
        en = as_float(r.get(end_col))

        if st is None or en is None:
            n_skip_coord += 1
            continue

        st_i = int(st)
        en_i = int(en)

        if en_i < st_i:
            st_i, en_i = en_i, st_i

        # Store multiple aliases, so VCF Ped01C/Ped01D can match ROH chr=1.
        for c in chrom_aliases(chrom_raw):
            raw[s][c].append((st_i, en_i))

        n_raw += 1

    merged = defaultdict(dict)

    for s, byc in raw.items():
        for c, intervals in byc.items():
            intervals.sort()

            m = []

            for st, en in intervals:
                if not m or st > m[-1][1] + 1:
                    m.append([st, en])
                else:
                    m[-1][1] = max(m[-1][1], en)

            starts = [x[0] for x in m]
            ends = [x[1] for x in m]

            merged[s][c] = (starts, ends)

    sys.stderr.write(
        f"[INFO] Loaded ROH intervals for {len(merged)} samples; "
        f"kept raw segments = {n_raw}; "
        f"skipped_by_sample = {n_skip_sample}; "
        f"skipped_by_coord = {n_skip_coord}\n"
    )

    return merged



def in_roh(
    roh_idx: Dict[str, Dict[str, Tuple[List[int], List[int]]]],
    sample: str,
    chrom: str,
    pos: int,
    chrom_map: Dict[str, str]
) -> bool:

    if sample not in roh_idx:
        return False

    for c in lookup_chrom_keys(chrom, chrom_map):
        item = roh_idx.get(sample, {}).get(c)

        if item is None:
            continue

        starts, ends = item
        i = bisect_left(ends, pos)

        if i < len(starts) and starts[i] <= pos <= ends[i]:
            return True

    return False


def parse_siftinfo_entries(record: Any) -> List[List[str]]:
    if "SIFTINFO" not in record.info:
        return []

    try:
        vals = record.info.get("SIFTINFO")
    except Exception:
        return []

    if vals is None:
        return []

    if isinstance(vals, (tuple, list)):
        raw_vals = [str(x) for x in vals if x is not None]
    else:
        raw_vals = [str(vals)]

    entries = []

    for raw in raw_vals:
        raw = raw.strip()

        if raw.startswith("SIFTINFO="):
            raw = raw.split("=", 1)[1]

        for item in raw.split(","):
            item = item.strip()
            if not item:
                continue

            parts = item.split("|")

            if len(parts) >= 13:
                entries.append(parts)

    return entries


def classify_variant(
    record: Any,
    cutoff: float,
    allow_sift_without_effect: bool = False
) -> Tuple[str, Optional[float], str, str]:

    entries = parse_siftinfo_entries(record)

    if not entries:
        return "UNCLASSIFIED", None, "NA", "missing_SIFTINFO"

    nonsyn_hits = []
    syn_hits = []

    for parts in entries:
        effect = parts[5].strip().upper() if len(parts) > 5 else ""
        score_raw = parts[8].strip() if len(parts) > 8 else ""
        pred = parts[12].strip().upper() if len(parts) > 12 else "NA"

        score = as_float(score_raw)

        rec = {
            "effect": effect,
            "score": score,
            "pred": pred,
            "raw": "|".join(parts),
        }

        if effect in {"NONSYNONYMOUS", "MISSENSE"}:
            nonsyn_hits.append(rec)
        elif effect == "SYNONYMOUS":
            syn_hits.append(rec)

    if nonsyn_hits:
        for h in nonsyn_hits:
            if h["score"] is not None and h["score"] <= cutoff:
                return (
                    "NONSYN_DELETERIOUS",
                    h["score"],
                    h["pred"],
                    "SIFTINFO_nonsyn_sift_le_cutoff"
                )

        for h in nonsyn_hits:
            if h["score"] is None and h["pred"] == "DELETERIOUS":
                return (
                    "NONSYN_DELETERIOUS",
                    h["score"],
                    h["pred"],
                    "SIFTINFO_nonsyn_pred_deleterious"
                )

        h = nonsyn_hits[0]
        return (
            "NONSYN_TOLERATED",
            h["score"],
            h["pred"],
            "SIFTINFO_nonsyn_tolerated"
        )

    if syn_hits:
        h = syn_hits[0]
        return (
            "SYNONYMOUS",
            h["score"],
            h["pred"],
            "SIFTINFO_synonymous"
        )

    return "UNCLASSIFIED", None, "NA", "SIFTINFO_no_syn_or_nonsyn"


def add_counter(counter: Counter, called_alleles: int, dosage_alt: int, ploidy: int) -> None:
    counter["n_called_sites"] += 1
    counter["called_alleles"] += called_alleles
    counter["alt_allele_count"] += dosage_alt

    if dosage_alt == ploidy and ploidy > 0:
        counter["hom_loci"] += 1
        counter["hom_alt_alleles"] += dosage_alt
    elif 0 < dosage_alt < ploidy:
        counter["het_loci"] += 1
        counter["het_alt_alleles"] += dosage_alt


def init_counts(samples: List[str]) -> Dict[str, Dict[str, Dict[str, Counter]]]:
    return {
        s: {
            cls: {region: Counter() for region in REGIONS}
            for cls in VARIANT_CLASSES
        }
        for s in samples
    }


def format_float(x: Any) -> str:
    if x is None:
        return "NA"

    try:
        xf = float(x)
        if not math.isfinite(xf):
            return "NA"
        return f"{xf:.10g}"
    except Exception:
        return "NA"


def safe_ratio(num: float, den: float) -> Optional[float]:
    try:
        if den is None or den <= 0:
            return None
        return float(num) / float(den)
    except Exception:
        return None


def discover_samples(vcf_specs: List[Tuple[str, str]]) -> Dict[str, List[str]]:
    out = {}

    for label, path in vcf_specs:
        vf = pysam.VariantFile(path)
        out[label] = list(vf.header.samples)
        vf.close()

    return out


def main() -> None:
    args = parse_args()

    vcf_specs = parse_vcf_specs(args.vcf)
    exclude = split_exclude(args.exclude_samples)

    out_dir = os.path.dirname(args.out_prefix)
    if out_dir:
        os.makedirs(out_dir, exist_ok=True)

    vcf_specs = prepare_vcf_specs(vcf_specs, args.out_prefix)
    chrom_map = read_chrom_map(args.chrom_map)

    froh = read_froh(args.froh, exclude)
    include_samples = set(froh.keys())

    roh_idx = read_roh_segments(args.roh, include_samples)

    vcf_samples_by_label = discover_samples(vcf_specs)

    common_vcf_samples = None
    for _label, smps in vcf_samples_by_label.items():
        sset = set(smps)
        common_vcf_samples = sset if common_vcf_samples is None else common_vcf_samples & sset

    if common_vcf_samples is None:
        raise RuntimeError("No VCF samples found.")

    samples = sorted([
        s for s in common_vcf_samples
        if s in include_samples and s not in exclude
    ])

    if not samples:
        raise RuntimeError("No overlap between all VCF samples and FROH samples after exclusion.")

    sys.stderr.write(f"[INFO] Species label: {args.species_label}\n")
    sys.stderr.write(f"[INFO] VCF inputs: {len(vcf_specs)}\n")
    for label, path in vcf_specs:
        sys.stderr.write(f"[INFO]   {label} = {path}; samples = {len(vcf_samples_by_label[label])}\n")
    sys.stderr.write(f"[INFO] Samples used: {len(samples)}\n")
    sys.stderr.write(f"[INFO] Excluded samples: {','.join(sorted(exclude)) if exclude else 'none'}\n")
    sys.stderr.write(f"[INFO] Chrom map: {args.chrom_map if args.chrom_map else 'auto alias mode'}\n")

    counts = init_counts(samples)

    site_af_path = args.out_prefix + ".site_AF.tsv"
    classified_path = args.out_prefix + ".classified_sites.tsv"
    unclass_path = args.out_prefix + ".unclassified_examples.tsv"
    burden_path = args.out_prefix + ".per_sample_burden.tsv"
    ratio_path = args.out_prefix + ".ratio_metrics.tsv"
    fig2_path = args.out_prefix + ".Fig2_hom_het_counts.long.tsv"
    fig2b_path = args.out_prefix + ".Fig2b_FROH_deleterious_counts.long.tsv"
    fig2c_path = args.out_prefix + ".Fig2c_FROH_deleterious_load.long.tsv"
    summary_path = args.out_prefix + ".class_summary.tsv"
    qc_path = args.out_prefix + ".QC.tsv"

    qc = Counter()
    reason_counts = Counter()
    class_counts = Counter()
    class_counts_by_source = Counter()
    unclass_examples = []
    processed_sites = 0

    with open(site_af_path, "w", newline="") as site_f, open(classified_path, "w", newline="") as cls_f:
        site_w = csv.writer(site_f, delimiter="\t")
        cls_w = csv.writer(cls_f, delimiter="\t")

        site_w.writerow([
            "species", "source", "chrom", "pos", "ref", "alt",
            "variant_class", "class_label", "AC", "AN", "AF",
            "sift_score", "sift_prediction", "class_reason"
        ])

        cls_w.writerow([
            "species", "source", "chrom", "pos", "ref", "alt",
            "variant_class", "class_label", "sift_score",
            "sift_prediction", "class_reason"
        ])

        for source_label, vcf_path in vcf_specs:
            vf = pysam.VariantFile(vcf_path)
            source_records = 0

            for rec in vf:
                processed_sites += 1
                source_records += 1

                qc["vcf_records_total"] += 1
                qc[f"vcf_records_{source_label}"] += 1

                if args.max_sites and processed_sites > args.max_sites:
                    break

                if rec.alts is None or len(rec.alts) != 1:
                    qc["skip_not_biallelic"] += 1
                    continue

                alt = rec.alts[0]

                if len(rec.ref) != 1 or len(alt) != 1:
                    qc["skip_not_snp"] += 1
                    continue

                variant_class, sift_score, sift_pred, reason = classify_variant(
                    rec,
                    args.sift_cutoff,
                    args.allow_sift_without_effect
                )

                reason_counts[reason] += 1

                if variant_class not in VARIANT_CLASSES:
                    qc[f"skip_{variant_class.lower()}"] += 1

                    if len(unclass_examples) < args.write_unclassified_examples:
                        raw_sift = ";".join(["|".join(x) for x in parse_siftinfo_entries(rec)])
                        unclass_examples.append([
                            args.species_label, source_label, rec.chrom, rec.pos,
                            rec.ref, alt, variant_class, format_float(sift_score),
                            sift_pred if sift_pred else "NA", reason, raw_sift[:1000]
                        ])

                    continue

                AC = 0
                AN = 0

                for sample in samples:
                    try:
                        gt = rec.samples[sample].get("GT")
                    except Exception:
                        qc["skip_gt_read_error"] += 1
                        continue

                    if gt is None:
                        continue

                    alleles = [a for a in gt if a is not None and a >= 0]

                    if not alleles:
                        continue

                    if any(a not in (0, 1) for a in alleles):
                        qc["skip_non_biallelic_gt"] += 1
                        continue

                    ploidy = len(alleles)
                    dosage_alt = sum(1 for a in alleles if a == 1)
                    called_alleles = ploidy

                    AC += dosage_alt
                    AN += called_alleles

                    add_counter(
                        counts[sample][variant_class]["ALL"],
                        called_alleles,
                        dosage_alt,
                        ploidy
                    )

                    region = "ROH" if in_roh(
                        roh_idx,
                        sample,
                        rec.chrom,
                        int(rec.pos),
                        chrom_map
                    ) else "Non-ROH"

                    add_counter(
                        counts[sample][variant_class][region],
                        called_alleles,
                        dosage_alt,
                        ploidy
                    )

                if AN <= 0:
                    qc["skip_no_called_alleles"] += 1
                    continue

                AF = AC / AN

                qc["classified_records"] += 1
                class_counts[variant_class] += 1
                class_counts_by_source[(source_label, variant_class)] += 1

                site_w.writerow([
                    args.species_label, source_label, rec.chrom, rec.pos,
                    rec.ref, alt, variant_class, CLASS_LABEL[variant_class],
                    AC, AN, f"{AF:.10g}", format_float(sift_score),
                    sift_pred if sift_pred else "NA", reason
                ])

                cls_w.writerow([
                    args.species_label, source_label, rec.chrom, rec.pos,
                    rec.ref, alt, variant_class, CLASS_LABEL[variant_class],
                    format_float(sift_score),
                    sift_pred if sift_pred else "NA", reason
                ])

            vf.close()

            sys.stderr.write(f"[INFO] Finished {source_label}: raw records scanned = {source_records}\n")

            if args.max_sites and processed_sites > args.max_sites:
                break

    with open(unclass_path, "w", newline="") as f:
        w = csv.writer(f, delimiter="\t")
        w.writerow([
            "species", "source", "chrom", "pos", "ref", "alt",
            "variant_class", "sift_score", "sift_prediction",
            "reason", "SIFTINFO_first1000"
        ])
        for row in unclass_examples:
            w.writerow(row)

    with open(burden_path, "w", newline="") as f:
        w = csv.writer(f, delimiter="\t")
        w.writerow([
            "species", "sample", "FROH", "variant_class", "class_label", "region",
            "n_called_sites", "called_alleles", "alt_allele_count",
            "hom_loci", "het_loci", "hom_alt_alleles", "het_alt_alleles",
            "allele_rate", "hom_loci_rate", "het_loci_rate",
            "N_ROH", "S_ROH_bp", "Lauto_bp",
            "FROH_local_short", "FROH_local_medium", "FROH_local_long",
        ])

        for s in samples:
            fr = froh.get(s, {})

            for cls in VARIANT_CLASSES:
                for region in REGIONS:
                    c = counts[s][cls][region]

                    n_called = c["n_called_sites"]
                    called_alleles = c["called_alleles"]

                    allele_rate = safe_ratio(c["alt_allele_count"], called_alleles)
                    hom_rate = safe_ratio(c["hom_loci"], n_called)
                    het_rate = safe_ratio(c["het_loci"], n_called)

                    w.writerow([
                        args.species_label, s, format_float(fr.get("FROH")),
                        cls, CLASS_LABEL[cls], region,
                        c["n_called_sites"], c["called_alleles"], c["alt_allele_count"],
                        c["hom_loci"], c["het_loci"], c["hom_alt_alleles"], c["het_alt_alleles"],
                        format_float(allele_rate), format_float(hom_rate), format_float(het_rate),
                        format_float(fr.get("N_ROH")), format_float(fr.get("S_ROH_bp")), format_float(fr.get("Lauto_bp")),
                        format_float(fr.get("FROH_local_short")),
                        format_float(fr.get("FROH_local_medium")),
                        format_float(fr.get("FROH_local_long")),
                    ])

    ratio_specs = [
        ("Deleterious/Synonymous", "NONSYN_DELETERIOUS", "SYNONYMOUS"),
        ("Tolerated/Synonymous", "NONSYN_TOLERATED", "SYNONYMOUS"),
    ]

    component_specs = [
        ("Homozygotes", "hom_loci"),
        ("Heterozygotes", "het_loci"),
        ("ALT alleles", "alt_allele_count"),
    ]

    with open(ratio_path, "w", newline="") as f:
        w = csv.writer(f, delimiter="\t")
        w.writerow([
            "species", "sample", "FROH", "ratio_type",
            "numerator_class", "denominator_class", "component", "region",
            "numerator", "denominator", "ratio", "N_ROH", "S_ROH_bp", "Lauto_bp"
        ])

        for s in samples:
            fr = froh.get(s, {})

            for ratio_type, num_cls, den_cls in ratio_specs:
                for comp_label, field in component_specs:
                    for region in REGIONS:
                        num = counts[s][num_cls][region][field]
                        den = counts[s][den_cls][region][field]
                        ratio = safe_ratio(num, den)

                        w.writerow([
                            args.species_label, s, format_float(fr.get("FROH")),
                            ratio_type, num_cls, den_cls, comp_label, region,
                            num, den, format_float(ratio),
                            format_float(fr.get("N_ROH")),
                            format_float(fr.get("S_ROH_bp")),
                            format_float(fr.get("Lauto_bp")),
                        ])

    with open(fig2_path, "w", newline="") as f:
        w = csv.writer(f, delimiter="\t")
        w.writerow(["species", "sample", "FROH", "component", "n_loci"])

        for s in samples:
            fr = froh.get(s, {})
            c = counts[s]["NONSYN_DELETERIOUS"]["ALL"]

            w.writerow([args.species_label, s, format_float(fr.get("FROH")), "Homozygotes", c["hom_loci"]])
            w.writerow([args.species_label, s, format_float(fr.get("FROH")), "Heterozygotes", c["het_loci"]])

    with open(fig2b_path, "w", newline="") as f:
        w = csv.writer(f, delimiter="\t")
        w.writerow(["species", "sample", "FROH", "component", "value"])

        for s in samples:
            fr = froh.get(s, {})
            c = counts[s]["NONSYN_DELETERIOUS"]["ALL"]

            w.writerow([args.species_label, s, format_float(fr.get("FROH")), "Total", c["alt_allele_count"]])
            w.writerow([args.species_label, s, format_float(fr.get("FROH")), "Homozygous", c["hom_alt_alleles"]])
            w.writerow([args.species_label, s, format_float(fr.get("FROH")), "Heterozygous", c["het_alt_alleles"]])

    with open(fig2c_path, "w", newline="") as f:
        w = csv.writer(f, delimiter="\t")
        w.writerow(["species", "sample", "FROH", "component", "value"])

        for s in samples:
            fr = froh.get(s, {})
            c = counts[s]["NONSYN_DELETERIOUS"]["ALL"]
            syn = counts[s]["SYNONYMOUS"]["ALL"]

            den = syn["called_alleles"]
            total_load = safe_ratio(c["alt_allele_count"], den)
            hom_load = safe_ratio(c["hom_alt_alleles"], den)
            het_load = safe_ratio(c["het_alt_alleles"], den)

            w.writerow([args.species_label, s, format_float(fr.get("FROH")), "Total", format_float(total_load)])
            w.writerow([args.species_label, s, format_float(fr.get("FROH")), "Homozygous", format_float(hom_load)])
            w.writerow([args.species_label, s, format_float(fr.get("FROH")), "Heterozygous", format_float(het_load)])

    with open(summary_path, "w", newline="") as f:
        w = csv.writer(f, delimiter="\t")
        w.writerow([
            "species", "source", "variant_class", "class_label",
            "n_sites", "fraction_of_classified_sites"
        ])

        total = sum(class_counts.values())

        for cls in VARIANT_CLASSES:
            w.writerow([
                args.species_label, "ALL", cls, CLASS_LABEL[cls],
                class_counts[cls], format_float(safe_ratio(class_counts[cls], total))
            ])

        for source_label, _path in vcf_specs:
            stotal = sum(class_counts_by_source[(source_label, cls)] for cls in VARIANT_CLASSES)

            for cls in VARIANT_CLASSES:
                w.writerow([
                    args.species_label, source_label, cls, CLASS_LABEL[cls],
                    class_counts_by_source[(source_label, cls)],
                    format_float(safe_ratio(class_counts_by_source[(source_label, cls)], stotal))
                ])

    with open(qc_path, "w", newline="") as f:
        w = csv.writer(f, delimiter="\t")
        w.writerow(["metric", "value"])

        w.writerow(["species_label", args.species_label])
        w.writerow(["input_vcfs", ";".join([f"{a}={b}" for a, b in vcf_specs])])
        w.writerow(["froh_file", args.froh])
        w.writerow(["roh_file", args.roh])
        w.writerow(["chrom_map", args.chrom_map if args.chrom_map else "auto_alias_mode"])
        w.writerow(["n_samples_used", len(samples)])
        w.writerow(["samples_used", ",".join(samples)])
        w.writerow(["exclude_samples", ",".join(sorted(exclude)) if exclude else "none"])
        w.writerow(["sift_cutoff", args.sift_cutoff])

        for k, v in qc.items():
            w.writerow([k, v])

        for k, v in class_counts.items():
            w.writerow([f"classified_{k}", v])

        for k, v in reason_counts.items():
            w.writerow([f"class_reason_{k}", v])

    sys.stderr.write("[OK] Wrote:\n")
    for p in [
        site_af_path, classified_path, unclass_path, burden_path,
        ratio_path, fig2_path, fig2b_path, fig2c_path,
        summary_path, qc_path
    ]:
        sys.stderr.write(f"  {p}\n")


if __name__ == "__main__":
    main()
