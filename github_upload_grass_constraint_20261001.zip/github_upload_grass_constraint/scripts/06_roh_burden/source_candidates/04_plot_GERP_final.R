#!/usr/bin/env Rscript

suppressPackageStartupMessages({
  library(readr)
  library(dplyr)
  library(tidyr)
  library(ggplot2)
  library(patchwork)
  library(scales)
})

args <- commandArgs(trailingOnly = TRUE)

if (length(args) < 2) {
  stop("Usage:
Rscript 04_plot_GERP_final.R <GERP_table_prefix> <out_prefix> [exclude_samples|none] [af_binwidth]

Example:
Rscript 04_plot_GERP_final.R \
  Atau_GERP_ROH_FINAL_kb100/03_GERP_tables/Atau_GERP_kb100_gap1000_winmiss5_noBW01192 \
  Atau_GERP_ROH_FINAL_kb100/04_GERP/Atau_GERP_kb100_gap1000_winmiss5_noBW01192 \
  BW_01192 \
  0.025
")
}

table_prefix <- args[1]
out_prefix <- args[2]
exclude_samples <- ifelse(length(args) >= 3, args[3], "none")
af_binwidth <- ifelse(length(args) >= 4, as.numeric(args[4]), 0.025)

exclude_vec <- trimws(unlist(strsplit(exclude_samples, "[,; ]+")))
exclude_vec <- exclude_vec[nchar(exclude_vec) > 0]
exclude_vec <- exclude_vec[!tolower(exclude_vec) %in% c("none", "null", "na")]

dir.create(dirname(out_prefix), recursive = TRUE, showWarnings = FALSE)

site_file <- paste0(table_prefix, ".site_AF.tsv")
burden_file <- paste0(table_prefix, ".per_sample_burden.tsv")

site <- read_tsv(site_file, show_col_types = FALSE, progress = FALSE)
burden <- read_tsv(burden_file, show_col_types = FALSE, progress = FALSE)

## =========================================================
## Helper functions
## =========================================================

save_both <- function(plot, prefix, width, height) {
  pdf_file <- paste0(prefix, ".pdf")
  png_file <- paste0(prefix, ".png")
  pdf_dev <- if (capabilities("cairo")) grDevices::cairo_pdf else grDevices::pdf
  ggsave(pdf_file, plot, width = width, height = height, units = "in", device = pdf_dev)
  ggsave(png_file, plot, width = width, height = height, units = "in", dpi = 600)
  message("[WRITE] ", pdf_file)
  message("[WRITE] ", png_file)
}

theme_pub <- function(base_size = 10) {
  theme_classic(base_size = base_size) +
    theme(
      text = element_text(color = "grey15"),
      axis.text = element_text(color = "grey25"),
      axis.title = element_text(color = "grey10"),
      axis.line = element_line(color = "grey30", linewidth = 0.42),
      axis.ticks = element_line(color = "grey30", linewidth = 0.35),
      panel.grid.major.y = element_line(color = "grey90", linewidth = 0.30),
      panel.grid.major.x = element_blank(),
      panel.grid.minor = element_blank(),
      plot.title = element_text(hjust = 0.5, face = "plain", size = base_size + 1),
      plot.subtitle = element_text(hjust = 0, color = "grey35", size = base_size),
      plot.tag = element_text(face = "bold", size = base_size + 5),
      legend.title = element_blank(),
      legend.key = element_blank(),
      legend.position = "top"
    )
}

fmt_p <- function(p) {
  if (!is.finite(p)) return("p = NA")
  if (p < 0.001) return("p < 0.001")
  paste0("p = ", formatC(p, format = "f", digits = 3))
}

lm_p <- function(x, y) {
  ok <- is.finite(x) & is.finite(y)
  x <- x[ok]
  y <- y[ok]
  if (length(x) < 4) return(NA_real_)
  if (length(unique(x)) < 2 || length(unique(y)) < 2) return(NA_real_)
  fit <- lm(y ~ x)
  coef(summary(fit))[2, 4]
}

safe_paired_wilcox <- function(nonroh, roh) {
  ok <- is.finite(nonroh) & is.finite(roh)
  if (sum(ok) < 4) return(NA_real_)
  suppressWarnings(wilcox.test(nonroh[ok], roh[ok], paired = TRUE)$p.value)
}

p_stars <- function(p) {
  if (!is.finite(p)) return("NA")
  if (p < 0.001) return("***")
  if (p < 0.01) return("**")
  if (p < 0.05) return("*")
  "ns"
}

nice_y_top <- function(x) {
  if (!is.finite(x) || x <= 0) return(1)
  if (x <= 1) return(ceiling(x * 10) / 10)
  if (x <= 10) return(ceiling(x))
  if (x <= 100) return(ceiling(x / 5) * 5)
  if (x <= 1000) return(ceiling(x / 50) * 50)
  if (x <= 10000) return(ceiling(x / 500) * 500)
  ceiling(x / 1000) * 1000
}

## =========================================================
## Colors
## =========================================================

col_gt4 <- "#4E8A83"
col_gt4_dark <- "#2E6F73"
col_het <- "#B6D2CD"
col_hom <- "#2E6F73"
col_total <- "#DDEDEA"

col_nonroh <- "#8D78C9"
col_roh <- "#E3A857"
col_gerpneg <- "#B7B7B7"

comp_cols <- c(
  "Total" = col_total,
  "Homozygous" = col_hom,
  "Heterozygous" = col_het
)

ratio_cols <- c(
  "Heterozygotes" = col_het,
  "Homozygotes" = col_hom,
  "ALT alleles" = "#5F9E96"
)

region_cols <- c(
  "Non-ROH" = col_nonroh,
  "ROH" = col_roh
)

## =========================================================
## Clean input
## =========================================================

site <- site %>%
  mutate(
    variant_class = trimws(as.character(variant_class)),
    AF = as.numeric(AF)
  ) %>%
  filter(is.finite(AF), AF >= 0, AF <= 1)

burden <- burden %>%
  mutate(
    sample = as.character(sample),
    variant_class = trimws(as.character(variant_class)),
    region = trimws(as.character(region)),
    FROH = as.numeric(FROH),
    called_sites = as.numeric(called_sites),
    called_alleles = as.numeric(called_alleles),
    alt_allele_count = as.numeric(alt_allele_count),
    hom_loci = as.numeric(hom_loci),
    het_loci = as.numeric(het_loci),
    allele_rate = as.numeric(allele_rate),
    hom_loci_rate = as.numeric(hom_loci_rate),
    het_loci_rate = as.numeric(het_loci_rate)
  ) %>%
  filter(!sample %in% exclude_vec)

gt4_all <- burden %>%
  filter(variant_class == "GERP > 4", region == "ALL") %>%
  filter(is.finite(FROH))

## =========================================================
## A. Allele frequency histogram
## connected bars + black outline + distance from X/Y axes
## =========================================================

make_af_table <- function(df, classes, bw) {
  nbin <- round(1 / bw)

  grid <- expand_grid(
    variant_class = classes,
    bin_i = 0:(nbin - 1)
  )

  tab <- df %>%
    filter(variant_class %in% classes) %>%
    mutate(
      bin_i = pmin(nbin - 1, pmax(0, floor(AF / bw)))
    ) %>%
    count(variant_class, bin_i, name = "n") %>%
    group_by(variant_class) %>%
    mutate(pct = 100 * n / sum(n)) %>%
    ungroup()

  grid %>%
    left_join(tab, by = c("variant_class", "bin_i")) %>%
    mutate(
      n = replace_na(n, 0),
      pct = replace_na(pct, 0),
      xmin = bin_i * bw,
      xmax = (bin_i + 1) * bw,
      xmid = (xmin + xmax) / 2
    )
}

af_gt4 <- make_af_table(site, c("GERP > 4"), af_binwidth)
ymax_A <- nice_y_top(max(af_gt4$pct, na.rm = TRUE))

pA <- ggplot(af_gt4) +
  geom_rect(
    aes(xmin = xmin, xmax = xmax, ymin = 0, ymax = pct),
    fill = col_gt4,
    colour = "black",
    linewidth = 0.16
  ) +
  scale_x_continuous(
    limits = c(-af_binwidth * 0.65, 1.0),
    breaks = c(0, 0.25, 0.50, 0.75, 1.00),
    labels = number_format(accuracy = 0.01),
    expand = c(0, 0)
  ) +
  scale_y_continuous(
    limits = c(-1.8, ymax_A),
    breaks = seq(0, ymax_A, by = 20),
    expand = c(0, 0)
  ) +
  labs(
    title = "GERP > 4",
    x = "Allele frequency",
    y = "Percentage of SNPs"
  ) +
  theme_pub(10) +
  theme(
    legend.position = "none",
    plot.title = element_text(hjust = 0.5, size = 11)
  )

## Supplementary AF: GERP < 0 and GERP > 4
af_both <- make_af_table(site, c("GERP < 0", "GERP > 4"), af_binwidth)
ymax_AF2 <- nice_y_top(max(af_both$pct, na.rm = TRUE))

pAF_supp <- ggplot(
  af_both,
  aes(xmin = xmin, xmax = xmax, ymin = 0, ymax = pct, fill = variant_class)
) +
  geom_rect(
    colour = "black",
    linewidth = 0.13,
    alpha = 0.55
  ) +
  scale_fill_manual(values = c("GERP < 0" = col_gerpneg, "GERP > 4" = col_gt4)) +
  scale_x_continuous(
    limits = c(-af_binwidth * 0.65, 1.0),
    breaks = c(0, 0.25, 0.50, 0.75, 1.00),
    labels = number_format(accuracy = 0.01),
    expand = c(0, 0)
  ) +
  scale_y_continuous(
    limits = c(-1.8, ymax_AF2),
    breaks = seq(0, ymax_AF2, by = 20),
    expand = c(0, 0)
  ) +
  labs(
    title = "GERP < 0 and GERP > 4",
    x = "Allele frequency",
    y = "Percentage of SNPs"
  ) +
  theme_pub(10) +
  theme(
    legend.position = c(0.80, 0.92),
    legend.direction = "horizontal",
    plot.title = element_text(hjust = 0.5, size = 11)
  )

## =========================================================
## B. Heterozygous + Homozygous merged histogram with broken X axis
## =========================================================

build_hist_bins <- function(x, n_bins = 24) {
  h <- hist(x, breaks = n_bins, plot = FALSE)
  tibble(
    xmin_raw = head(h$breaks, -1),
    xmax_raw = tail(h$breaks, -1),
    xmid_raw = h$mids,
    count = h$counts
  )
}

het_x <- gt4_all$het_loci
hom_x <- gt4_all$hom_loci

het_min <- floor(min(het_x, na.rm = TRUE) / 250) * 250
het_max <- ceiling(max(het_x, na.rm = TRUE) / 250) * 250

hom_min <- floor(min(hom_x, na.rm = TRUE) / 10000) * 10000
hom_max <- ceiling(max(hom_x, na.rm = TRUE) / 10000) * 10000

left_width <- het_max - het_min
right_width <- left_width
gap_width <- left_width * 0.16

scale_hom <- right_width / (hom_max - hom_min)
right_start <- het_max + gap_width
right_end <- right_start + right_width

transform_hom <- function(x) {
  right_start + (x - hom_min) * scale_hom
}

het_bins <- build_hist_bins(het_x, 24) %>%
  mutate(
    component = "Heterozygous",
    xmin = xmin_raw,
    xmax = xmax_raw
  )

hom_bins <- build_hist_bins(hom_x, 24) %>%
  mutate(
    component = "Homozygous",
    xmin = transform_hom(xmin_raw),
    xmax = transform_hom(xmax_raw)
  )

hist_bins <- bind_rows(het_bins, hom_bins)

het_med <- median(het_x, na.rm = TRUE)
hom_med <- median(hom_x, na.rm = TRUE)

het_zero <- sum(het_x == 0, na.rm = TRUE)
hom_zero <- sum(hom_x == 0, na.rm = TRUE)
n_ind <- nrow(gt4_all)

het_breaks_raw <- pretty(c(het_min, het_max), n = 4)
het_breaks_raw <- het_breaks_raw[het_breaks_raw >= het_min & het_breaks_raw <= het_max]

hom_breaks_raw <- pretty(c(hom_min, hom_max), n = 4)
hom_breaks_raw <- hom_breaks_raw[hom_breaks_raw >= hom_min & hom_breaks_raw <= hom_max]

x_breaks <- c(het_breaks_raw, transform_hom(hom_breaks_raw))
x_labels <- c(comma(het_breaks_raw), comma(hom_breaks_raw))

ymax_B <- nice_y_top(max(hist_bins$count, na.rm = TRUE))

pB <- ggplot() +
  geom_rect(
    data = hist_bins,
    aes(xmin = xmin, xmax = xmax, ymin = 0, ymax = count, fill = component),
    colour = "black",
    linewidth = 0.13,
    alpha = 0.95
  ) +
  geom_vline(xintercept = het_med, linetype = 2, colour = "#8ABCC2", linewidth = 0.45) +
  geom_vline(xintercept = transform_hom(hom_med), linetype = 2, colour = "#8ABCC2", linewidth = 0.45) +
  annotate(
    "text",
    x = mean(c(het_min, het_max)),
    y = ymax_B * 0.98,
    label = "Heterozygous",
    fontface = "bold",
    size = 3.8
  ) +
  annotate(
    "text",
    x = mean(c(right_start, right_end)),
    y = ymax_B * 0.98,
    label = "Homozygous",
    fontface = "bold",
    size = 3.8
  ) +
  annotate(
    "text",
    x = het_med,
    y = ymax_B * 0.86,
    label = paste0("median = ", comma(round(het_med)), "\nzero = ", het_zero, "/", n_ind),
    hjust = 0,
    size = 2.6,
    colour = "grey20"
  ) +
  annotate(
    "text",
    x = transform_hom(hom_med),
    y = ymax_B * 0.86,
    label = paste0("median = ", comma(round(hom_med)), "\nzero = ", hom_zero, "/", n_ind),
    hjust = 0,
    size = 2.6,
    colour = "grey20"
  ) +
  annotate(
    "text",
    x = het_max + gap_width / 2,
    y = ymax_B * 0.42,
    label = "//",
    size = 6,
    fontface = "bold",
    colour = "grey30"
  ) +
  scale_fill_manual(values = c("Heterozygous" = col_het, "Homozygous" = col_hom), guide = "none") +
  scale_x_continuous(
    limits = c(het_min, right_end),
    breaks = x_breaks,
    labels = x_labels,
    expand = c(0.01, 0.01)
  ) +
  scale_y_continuous(
    limits = c(0, ymax_B),
    expand = expansion(mult = c(0.02, 0.08))
  ) +
  labs(
    title = "GERP > 4",
    x = "Number of loci",
    y = "Number of individuals"
  ) +
  theme_pub(10) +
  theme(
    legend.position = "none",
    plot.title = element_text(face = "bold", hjust = 0.5, size = 12)
  )

## =========================================================
## C/D. Counts and standardized load
## =========================================================

make_three_component <- function(df, mode = c("count", "load")) {
  mode <- match.arg(mode)

  if (mode == "count") {
    bind_rows(
      df %>% transmute(sample, FROH, component = "Total", value = alt_allele_count),
      df %>% transmute(sample, FROH, component = "Homozygous", value = hom_loci),
      df %>% transmute(sample, FROH, component = "Heterozygous", value = het_loci)
    )
  } else {
    bind_rows(
      df %>% transmute(sample, FROH, component = "Total", value = allele_rate),
      df %>% transmute(sample, FROH, component = "Homozygous", value = hom_loci_rate),
      df %>% transmute(sample, FROH, component = "Heterozygous", value = het_loci_rate)
    )
  }
}

plot_scatter_three <- function(dat, title_lab, y_lab, y_comma = FALSE, label_frac = c(0.96, 0.78, 0.08)) {
  dat <- dat %>%
    mutate(component = factor(component, levels = c("Total", "Homozygous", "Heterozygous"))) %>%
    filter(is.finite(FROH), is.finite(value))

  ptab <- dat %>%
    group_by(component) %>%
    summarise(p = lm_p(FROH, value), .groups = "drop") %>%
    mutate(label = paste0(component, ": ", vapply(p, fmt_p, character(1))))

  ymin <- min(dat$value, na.rm = TRUE)
  ymax <- max(dat$value, na.rm = TRUE)
  span <- ymax - ymin
  if (!is.finite(span) || span <= 0) span <- max(abs(ymax), 1)

  ptab <- ptab %>%
    mutate(
      x = min(dat$FROH, na.rm = TRUE) + 0.01,
      y = ymin + span * label_frac[as.integer(component)]
    )

  g <- ggplot(dat, aes(x = FROH, y = value, colour = component, fill = component)) +
    geom_point(size = 1.15, alpha = 0.78) +
    geom_smooth(method = "lm", se = TRUE, linewidth = 0.55, alpha = 0.10) +
    geom_text(
      data = ptab,
      aes(x = x, y = y, label = label, colour = component),
      inherit.aes = FALSE,
      hjust = 0,
      size = 2.55,
      fontface = "bold"
    ) +
    scale_colour_manual(values = comp_cols) +
    scale_fill_manual(values = comp_cols) +
    labs(
      title = title_lab,
      x = expression(F[ROH]),
      y = y_lab
    ) +
    theme_pub(10) +
    theme(
      legend.position = c(0.55, 0.98),
      legend.justification = c(0.5, 1),
      legend.direction = "horizontal",
      legend.text = element_text(size = 7),
      plot.title = element_text(hjust = 0.5, size = 10)
    )

  if (y_comma) {
    g <- g + scale_y_continuous(labels = comma)
  } else {
    g <- g + scale_y_continuous(labels = number_format(accuracy = 0.001))
  }

  g
}

pC <- plot_scatter_three(
  make_three_component(gt4_all, "count"),
  title_lab = "GERP > 4 counts",
  y_lab = "Count",
  y_comma = TRUE,
  label_frac = c(0.96, 0.50, 0.06)
)

pD <- plot_scatter_three(
  make_three_component(gt4_all, "load"),
  title_lab = "Standardized GERP > 4 load",
  y_lab = "Load",
  y_comma = FALSE,
  label_frac = c(0.95, 0.88, 0.06)
)

## =========================================================
## Ratio based on counts
## GERP > 4 / GERP < 0 = counts ratio
## =========================================================

ratio_count <- function(component_col, component_name, region_keep) {
  burden %>%
    filter(
      region == region_keep,
      variant_class %in% c("GERP > 4", "GERP < 0")
    ) %>%
    transmute(
      sample,
      FROH,
      region,
      variant_class,
      value = .data[[component_col]]
    ) %>%
    pivot_wider(names_from = variant_class, values_from = value) %>%
    rename(gt4 = `GERP > 4`, lt0 = `GERP < 0`) %>%
    mutate(
      component = component_name,
      ratio = gt4 / lt0
    ) %>%
    filter(
      is.finite(FROH),
      is.finite(ratio),
      is.finite(lt0),
      lt0 > 0,
      ratio > 0
    )
}

plot_ratio_scatter <- function(dat, title_lab, colour_map, group_col = "region", label_fracs = NULL) {
  dat <- dat %>%
    filter(is.finite(FROH), is.finite(ratio)) %>%
    mutate(plot_group = factor(as.character(.data[[group_col]]), levels = names(colour_map)))

  ptab <- dat %>%
    group_by(plot_group) %>%
    summarise(p = lm_p(FROH, ratio), .groups = "drop") %>%
    mutate(label = paste0(plot_group, ": ", vapply(p, fmt_p, character(1))))

  ymin <- min(dat$ratio, na.rm = TRUE)
  ymax <- max(dat$ratio, na.rm = TRUE)
  span <- ymax - ymin
  if (!is.finite(span) || span <= 0) span <- max(abs(ymax), 1)

  if (is.null(label_fracs)) {
    label_fracs <- seq(0.90, 0.72, length.out = nrow(ptab))
  }

  ptab <- ptab %>%
    mutate(
      x = min(dat$FROH, na.rm = TRUE) + 0.01,
      y = ymin + span * label_fracs[seq_len(n())]
    )

  ggplot(dat, aes(x = FROH, y = ratio, colour = plot_group, fill = plot_group)) +
    geom_point(size = 1.15, alpha = 0.78) +
    geom_smooth(method = "lm", se = TRUE, linewidth = 0.55, alpha = 0.10, linetype = 2) +
    geom_text(
      data = ptab,
      aes(x = x, y = y, label = label, colour = plot_group),
      inherit.aes = FALSE,
      hjust = 0,
      size = 2.65,
      fontface = "bold"
    ) +
    scale_colour_manual(values = colour_map, drop = FALSE) +
    scale_fill_manual(values = colour_map, drop = FALSE) +
    labs(
      title = title_lab,
      x = expression(F[ROH]),
      y = "GERP > 4 / GERP < 0 ratio"
    ) +
    theme_pub(10) +
    theme(
      legend.position = c(0.38, 0.98),
      legend.justification = c(0.5, 1),
      legend.direction = "horizontal",
      legend.text = element_text(size = 7),
      plot.title = element_text(hjust = 0.5, size = 10)
    )
}

## E. ALL ratio: Heterozygotes / Homozygotes
ratio_all <- bind_rows(
  ratio_count("het_loci", "Heterozygotes", "ALL"),
  ratio_count("hom_loci", "Homozygotes", "ALL")
) %>%
  mutate(component = factor(component, levels = c("Heterozygotes", "Homozygotes")))

pE <- plot_ratio_scatter(
  ratio_all,
  title_lab = "GERP > 4 / GERP < 0",
  colour_map = c("Heterozygotes" = col_het, "Homozygotes" = col_hom),
  group_col = "component",
  label_fracs = c(0.86, 0.22)
)

## F. Homozygous ratio in ROH and Non-ROH
ratio_hom_region <- bind_rows(
  ratio_count("hom_loci", "Non-ROH", "Non-ROH"),
  ratio_count("hom_loci", "ROH", "ROH")
) %>%
  mutate(region = factor(region, levels = c("Non-ROH", "ROH")))

pF <- plot_ratio_scatter(
  ratio_hom_region,
  title_lab = "Homozygous GERP > 4 / GERP < 0 ratio",
  colour_map = region_cols,
  group_col = "region",
  label_fracs = c(0.90, 0.74)
)

## G. Boxplot ROH vs Non-ROH with brackets
ratio_box <- bind_rows(
  ratio_count("het_loci", "Heterozygotes", "Non-ROH"),
  ratio_count("het_loci", "Heterozygotes", "ROH"),
  ratio_count("hom_loci", "Homozygotes", "Non-ROH"),
  ratio_count("hom_loci", "Homozygotes", "ROH"),
  ratio_count("alt_allele_count", "ALT alleles", "Non-ROH"),
  ratio_count("alt_allele_count", "ALT alleles", "ROH")
) %>%
  mutate(
    component = factor(component, levels = c("Heterozygotes", "Homozygotes", "ALT alleles")),
    region = factor(region, levels = c("Non-ROH", "ROH"))
  )

box_stat <- ratio_box %>%
  select(sample, component, region, ratio) %>%
  pivot_wider(names_from = region, values_from = ratio) %>%
  group_by(component) %>%
  summarise(
    p = safe_paired_wilcox(`Non-ROH`, ROH),
    ymax = max(c(`Non-ROH`, ROH), na.rm = TRUE),
    .groups = "drop"
  ) %>%
  mutate(
    stars = vapply(p, p_stars, character(1)),
    p_label = vapply(p, fmt_p, character(1)),
    label = paste0(stars, "\n", p_label),
    y_bracket = ymax * 1.075,
    y_text = ymax * 1.125
  )

pG <- ggplot(ratio_box, aes(x = region, y = ratio, colour = region, fill = region)) +
  geom_boxplot(width = 0.50, outlier.shape = NA, alpha = 0.22, linewidth = 0.65) +
  geom_jitter(width = 0.12, size = 1.25, alpha = 0.70) +
  geom_segment(
    data = box_stat,
    aes(x = 1, xend = 2, y = y_bracket, yend = y_bracket),
    inherit.aes = FALSE,
    colour = "black",
    linewidth = 0.45
  ) +
  geom_segment(
    data = box_stat,
    aes(x = 1, xend = 1, y = y_bracket * 0.993, yend = y_bracket),
    inherit.aes = FALSE,
    colour = "black",
    linewidth = 0.45
  ) +
  geom_segment(
    data = box_stat,
    aes(x = 2, xend = 2, y = y_bracket * 0.993, yend = y_bracket),
    inherit.aes = FALSE,
    colour = "black",
    linewidth = 0.45
  ) +
  geom_text(
    data = box_stat,
    aes(x = 1.5, y = y_text, label = label),
    inherit.aes = FALSE,
    size = 2.65,
    fontface = "bold",
    colour = "grey20"
  ) +
  facet_wrap(~ component, scales = "free_y", nrow = 1) +
  scale_colour_manual(values = region_cols) +
  scale_fill_manual(values = region_cols) +
  scale_y_continuous(expand = expansion(mult = c(0.05, 0.22))) +
  labs(
    title = "GERP > 4 / GERP < 0 ratio in ROH and Non-ROH",
    x = NULL,
    y = "GERP > 4 / GERP < 0 ratio"
  ) +
  theme_pub(10) +
  theme(
    legend.position = "none",
    strip.text = element_text(face = "bold", size = 9),
    axis.text.x = element_text(angle = 25, hjust = 1),
    plot.title = element_text(hjust = 0.5, size = 10)
  )

## H. ALT allele ratio in ROH and Non-ROH
ratio_alt_region <- bind_rows(
  ratio_count("alt_allele_count", "Non-ROH", "Non-ROH"),
  ratio_count("alt_allele_count", "ROH", "ROH")
) %>%
  mutate(region = factor(region, levels = c("Non-ROH", "ROH")))

pH <- plot_ratio_scatter(
  ratio_alt_region,
  title_lab = "ALT allele GERP > 4 / GERP < 0 ratio inside and outside ROH",
  colour_map = region_cols,
  group_col = "region",
  label_fracs = c(0.90, 0.74)
)

## =========================================================
## Main figure
## =========================================================

main_plot <- (
  pA | pB
) / (
  pC | pD
) / (
  pE | pF
) / (
  pG | pH
) +
  plot_layout(heights = c(1.0, 1.08, 1.08, 1.05)) +
  plot_annotation(tag_levels = "A") &
  theme(
    plot.tag = element_text(face = "bold", size = 15),
    plot.tag.position = c(0.01, 0.98)
  )

compact_plot <- (
  pA | pB
) / (
  pC | pD
) / (
  pE | pF
) +
  plot_layout(heights = c(1.0, 1.08, 1.08)) +
  plot_annotation(tag_levels = "A") &
  theme(
    plot.tag = element_text(face = "bold", size = 15),
    plot.tag.position = c(0.01, 0.98)
  )

## =========================================================
## Save
## =========================================================

save_both(pA, paste0(out_prefix, ".FigA_AF_GERPgt4"), 5.4, 3.6)
save_both(pAF_supp, paste0(out_prefix, ".FigS_AF_GERPneg_GERPgt4"), 5.4, 3.6)
save_both(pB, paste0(out_prefix, ".FigB_HetHom_merged_breakaxis_GERPgt4"), 7.4, 3.35)
save_both(pC, paste0(out_prefix, ".FigC_counts_vs_FROH_GERPgt4"), 5.8, 4.0)
save_both(pD, paste0(out_prefix, ".FigD_load_vs_FROH_GERPgt4"), 5.8, 4.0)
save_both(pE, paste0(out_prefix, ".FigE_ratio_ALL_HetHom_vs_FROH"), 5.8, 4.0)
save_both(pF, paste0(out_prefix, ".FigF_homo_ratio_ROH_nonROH_vs_FROH"), 5.8, 4.0)
save_both(pG, paste0(out_prefix, ".FigG_ratio_boxplot_ROH_nonROH_bracket"), 7.8, 3.8)
save_both(pH, paste0(out_prefix, ".FigH_alt_ratio_ROH_nonROH_vs_FROH"), 5.8, 4.0)

save_both(main_plot, paste0(out_prefix, ".00_main_GERP_final_reference_style"), 14.2, 15.0)
save_both(compact_plot, paste0(out_prefix, ".00_main_GERP_final_compact_reference_style"), 14.2, 11.6)

message("[DONE] GERP visualization finished.")
message("[INFO] A: connected bars, black outline, offset from X/Y axes.")
message("[INFO] B: merged heterozygous/homozygous histogram with a broken x-axis.")
message("[INFO] E: ALL heterozygous/homozygous GERP>4 / GERP<0 ratio vs FROH.")
message("[INFO] G: boxplot significance brackets added above boxes.")
