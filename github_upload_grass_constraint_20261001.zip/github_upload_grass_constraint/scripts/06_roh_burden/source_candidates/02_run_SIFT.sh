#!/bin/bash
#SBATCH --job-name=Ped_SIFT
#SBATCH --output=Ped_SIFT_polar_unpolar_pipeline/logs/Ped_SIFT.%j.out
#SBATCH --error=Ped_SIFT_polar_unpolar_pipeline/logs/Ped_SIFT.%j.err
#SBATCH --cpus-per-task=1


 bash Ped_SIFT_polar_unpolar_pipeline/scripts/00_run_Ped_SIFT_polar_unpolar.sh
#bash Ped_SIFT_polar_unpolar_pipeline/scripts/00_run_Ped_SIFT_polar_unpolar.sh

Rscript Ped_SIFT_polar_unpolar_pipeline/scripts/01_plot_PedALL_SIFT_two_layers.R \
  Ped_SIFT_polar_unpolar_pipeline/04_summary/Ped_SIFT.PedC_PedD_PedALL.per_sample_burden.tsv \
  Ped_SIFT_polar_unpolar_pipeline/04_summary/Ped_SIFT.PedC_PedD.site_AF.tsv.gz \
  Ped_SIFT_polar_unpolar_pipeline/05_figures