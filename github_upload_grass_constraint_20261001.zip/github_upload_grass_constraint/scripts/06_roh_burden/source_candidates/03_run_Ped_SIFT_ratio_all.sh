#!/usr/bin/env bash
set -euo pipefail

CONFIG=${1:-Ped_SIFT_ratio_pipeline/scripts/00_config_Ped_SIFT_ratio.sh}
source "${CONFIG}"

mkdir -p "${PED_OUTDIR}" "${PEDC_OUTDIR}" "${PEDD_OUTDIR}" "${LOGDIR}"

check_file() {
  local f="$1"
  if [[ ! -s "${f}" ]]; then
    echo "[ERROR] Missing or empty file: ${f}" >&2
    exit 1
  fi
}

check_file "${PEDC_SIFT_VCF}"
check_file "${PEDD_SIFT_VCF}"
check_file "${FROH_FILE}"
check_file "${ROH_SEG_FILE}"

if [[ -n "${CHROM_MAP:-}" && "${CHROM_MAP}" != "none" ]]; then
  check_file "${CHROM_MAP}"
fi

EXCLUDE_ARG="${EXCLUDE_SAMPLES:-none}"
if [[ -z "${EXCLUDE_ARG}" ]]; then
  EXCLUDE_ARG="none"
fi

SCRIPT_DIR=$(cd "$(dirname "$0")" && pwd)
PY="${SCRIPT_DIR}/01_calc_Ped_SIFT_ratio.py"
RPLOT="${SCRIPT_DIR}/02_plot_Ped_SIFT_ratio.R"

check_file "${PY}"
check_file "${RPLOT}"

run_one() {
  local label="$1"
  local outdir="$2"
  local prefix="$3"
  shift 3

  local vcf_args=("$@")

  echo "============================================================"
  echo "[INFO] Starting ${label} SIFT/ROH burden analysis"
  echo "[INFO] outdir = ${outdir}"
  echo "[INFO] prefix = ${prefix}"
  echo "============================================================"

  mkdir -p "${outdir}" "${LOGDIR}"

  local calc_out="${LOGDIR}/01_calc_${prefix}.out"
  local calc_err="${LOGDIR}/01_calc_${prefix}.err"
  local plot_out="${LOGDIR}/02_plot_${prefix}.out"
  local plot_err="${LOGDIR}/02_plot_${prefix}.err"

  local CMD=(
    python3 "${PY}"
    "${vcf_args[@]}"
    --froh "${FROH_FILE}"
    --roh "${ROH_SEG_FILE}"
    --out-prefix "${outdir}/${prefix}"
    --species-label "${label}"
    --sift-cutoff "${SIFT_CUTOFF}"
    --exclude-samples "${EXCLUDE_ARG}"
  )

  if [[ -n "${CHROM_MAP:-}" && "${CHROM_MAP}" != "none" ]]; then
    CMD+=(--chrom-map "${CHROM_MAP}")
  fi

  if [[ "${ALLOW_SIFT_WITHOUT_EFFECT:-0}" == "1" || \
        "${ALLOW_SIFT_WITHOUT_EFFECT:-0}" == "true" || \
        "${ALLOW_SIFT_WITHOUT_EFFECT:-0}" == "TRUE" ]]; then
    CMD+=(--allow-sift-without-effect)
  fi

  echo "[INFO] Python command:"
  printf ' %q' "${CMD[@]}"
  echo

  "${CMD[@]}" > "${calc_out}" 2> "${calc_err}"

  echo "[INFO] R plotting command:"
  echo "Rscript ${RPLOT} ${outdir} ${prefix} ${EXCLUDE_ARG} ${SIFT_CUTOFF} ${label}"

  Rscript "${RPLOT}" \
    "${outdir}" \
    "${prefix}" \
    "${EXCLUDE_ARG}" \
    "${SIFT_CUTOFF}" \
    "${label}" \
    > "${plot_out}" \
    2> "${plot_err}"

  echo "[OK] Finished ${label}"
  echo "[OK] Tables and figures: ${outdir}"
  echo "[OK] Logs:"
  echo "  ${calc_out}"
  echo "  ${calc_err}"
  echo "  ${plot_out}"
  echo "  ${plot_err}"
}

run_one "Ped"  "${PED_OUTDIR}"  "${PED_PREFIX}"  \
  --vcf "pedC=${PEDC_SIFT_VCF}" \
  --vcf "pedD=${PEDD_SIFT_VCF}"

run_one "pedC" "${PEDC_OUTDIR}" "${PEDC_PREFIX}" \
  --vcf "pedC=${PEDC_SIFT_VCF}"

run_one "pedD" "${PEDD_OUTDIR}" "${PEDD_PREFIX}" \
  --vcf "pedD=${PEDD_SIFT_VCF}"

echo "============================================================"
echo "[OK] All Ped SIFT ratio analyses finished."
echo "[OK] Results:"
echo "  ${PED_OUTDIR}"
echo "  ${PEDC_OUTDIR}"
echo "  ${PEDD_OUTDIR}"
echo "[OK] Logs: ${LOGDIR}"
echo "============================================================"
