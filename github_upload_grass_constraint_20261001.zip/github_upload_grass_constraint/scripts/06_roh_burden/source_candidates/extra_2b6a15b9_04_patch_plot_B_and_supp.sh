#!/usr/bin/env bash
set -euo pipefail

RFILE="Teosinte_GERP_unpolarized_pipeline/scripts/02_plot_Teosinte_GERP_unpolarized_AH.R"

if [[ ! -s "${RFILE}" ]]; then
  echo "[ERROR] Missing R script: ${RFILE}" >&2
  exit 1
fi

BACKUP="${RFILE}.bak.$(date +%Y%m%d_%H%M%S)"
cp "${RFILE}" "${BACKUP}"
echo "[INFO] Backup written to: ${BACKUP}"

python3 - <<'PY'
from pathlib import Path
import re

rfile = Path("Teosinte_GERP_unpolarized_pipeline/scripts/02_plot_Teosinte_GERP_unpolarized_AH.R")
s = rfile.read_text()

new_supp = r'''# Supplementary AF: GERP < 0 and GERP > 4
# Updated:
#   - side-by-side bars within each AF bin
#   - no overlap between GERP < 0 and GERP > 4
#   - bars touch each other within the same AF bin
#   - keep small distance from x/y axes, same style as panel A

af_both <- make_af_table(site, c("GERP < 0", "GERP > 4"), af_binwidth)
ymax_AF2 <- nice_y_top(max(af_both$pct, na.rm = TRUE))

af_both_plot <- af_both %>%
  mutate(
    variant_class = factor(variant_class, levels = c("GERP < 0", "GERP > 4")),
    grp_id = ifelse(variant_class == "GERP < 0", 1, 2),
    bar_w  = af_binwidth * 0.50,
    xmin2  = xmin + (grp_id - 1) * bar_w,
    xmax2  = xmin + grp_id * bar_w
  )

pAF_supp <- ggplot(af_both_plot) +
  geom_rect(
    aes(xmin = xmin2, xmax = xmax2, ymin = 0, ymax = pct, fill = variant_class),
    colour = NA,
    alpha = 0.92
  ) +
  scale_fill_manual(
    values = c("GERP < 0" = col_gerpneg, "GERP > 4" = col_gt4),
    breaks = c("GERP < 0", "GERP > 4")
  ) +
  scale_x_continuous(
    limits = c(-af_binwidth * 0.65, 1 + af_binwidth * 0.30),
    breaks = c(0, 0.25, 0.50, 0.75, 1.00),
    labels = number_format(accuracy = 0.01),
    expand = c(0, 0)
  ) +
  scale_y_continuous(
    limits = c(-0.035 * ymax_AF2, ymax_AF2),
    breaks = pretty(c(0, ymax_AF2), n = 6),
    expand = c(0, 0)
  ) +
  labs(
    title = "GERP < 0 and GERP > 4",
    x = "Allele frequency",
    y = "Percentage of SNPs"
  ) +
  theme_pub(12) +
  theme(
    legend.position = c(0.80, 0.93),
    legend.direction = "horizontal",
    legend.background = element_blank(),
    legend.key.width = grid::unit(0.50, "cm"),
    legend.key.height = grid::unit(0.35, "cm"),
    plot.title = element_text(hjust = 0.5, size = 13)
  )
'''

new_B = r'''# =========================================================
# B. Hom / Het count distribution
# Updated:
#   - no overlap between Homozygous and Heterozygous
#   - bar width visually matched to panel A
#   - small distance from x/y axes, same style as panel A
# =========================================================

b_raw <- bc %>%
  filter(component %in% c("het", "hom")) %>%
  transmute(
    sample,
    group = recode(component, "hom" = "Homozygous", "het" = "Heterozygous"),
    value = value_count
  ) %>%
  filter(is.finite(value)) %>%
  mutate(group = factor(group, levels = c("Homozygous", "Heterozygous")))

b_xmax_raw <- max(b_raw$value, na.rm = TRUE)
b_step <- nice_x_step(b_xmax_raw)
b_xmax <- ceiling(b_xmax_raw / b_step) * b_step

# Panel A has round(1 / af_binwidth) visual bars.
# Here each paired bin contains two bars, so paired-bin number is half of panel A.
# Thus each single bar has approximately the same visual width as panel A.
b_pair_nbin <- max(10, round(1 / af_binwidth) / 2)
b_binwidth <- b_xmax / b_pair_nbin
b_breaks <- seq(0, b_xmax + b_binwidth, by = b_binwidth)

b_hist <- b_raw %>%
  mutate(
    bin_id = pmin(
      length(b_breaks) - 1,
      pmax(1, findInterval(value, b_breaks, rightmost.closed = TRUE))
    ),
    xmin = b_breaks[bin_id],
    xmax = b_breaks[bin_id + 1],
    xmid = (xmin + xmax) / 2
  ) %>%
  count(group, bin_id, xmin, xmax, xmid, name = "count") %>%
  complete(
    group,
    bin_id = seq_len(length(b_breaks) - 1),
    fill = list(count = 0)
  ) %>%
  mutate(
    xmin = ifelse(is.na(xmin), b_breaks[bin_id], xmin),
    xmax = ifelse(is.na(xmax), b_breaks[bin_id + 1], xmax),
    xmid = ifelse(is.na(xmid), (xmin + xmax) / 2, xmid),
    group = factor(group, levels = c("Homozygous", "Heterozygous")),
    grp_id = ifelse(group == "Homozygous", 1, 2),
    bar_w = b_binwidth * 0.50,
    xmin2 = xmin + (grp_id - 1) * bar_w,
    xmax2 = xmin + grp_id * bar_w
  )

b_ymax <- nice_y_top(max(b_hist$count, na.rm = TRUE))

b_med <- b_raw %>%
  group_by(group) %>%
  summarise(
    med = median(value, na.rm = TRUE),
    .groups = "drop"
  ) %>%
  mutate(
    label = paste0("median = ", comma(round(med))),
    y = case_when(
      group == "Homozygous"   ~ b_ymax * 0.84,
      group == "Heterozygous" ~ b_ymax * 0.74,
      TRUE ~ b_ymax * 0.80
    ),
    x = pmin(med + b_xmax * 0.025, b_xmax * 0.86)
  )

pB <- ggplot() +
  geom_rect(
    data = b_hist,
    aes(xmin = xmin2, xmax = xmax2, ymin = 0, ymax = count, fill = group),
    colour = "grey35",
    linewidth = 0.12,
    alpha = 0.94
  ) +
  geom_vline(
    data = b_med,
    aes(xintercept = med, colour = group),
    linetype = 2,
    linewidth = 0.55,
    show.legend = FALSE
  ) +
  geom_text(
    data = b_med,
    aes(x = x, y = y, label = label, colour = group),
    hjust = 0,
    size = 3.0,
    fontface = "bold",
    show.legend = FALSE
  ) +
  scale_fill_manual(values = c("Homozygous" = col_hom, "Heterozygous" = col_het)) +
  scale_colour_manual(values = c("Homozygous" = col_hom, "Heterozygous" = col_het)) +
  scale_x_continuous(
    limits = c(-b_binwidth * 0.65, b_xmax + b_binwidth * 0.30),
    breaks = seq(0, b_xmax, by = b_step),
    labels = comma,
    expand = c(0, 0)
  ) +
  scale_y_continuous(
    limits = c(-0.035 * b_ymax, b_ymax),
    breaks = pretty(c(0, b_ymax), n = 6),
    expand = c(0, 0)
  ) +
  labs(
    title = "GERP > 4",
    x = "Number of loci",
    y = "Number of individuals"
  ) +
  theme_pub(12) +
  theme(
    legend.position = c(0.52, 0.96),
    legend.direction = "horizontal",
    legend.background = element_blank(),
    legend.key.width = grid::unit(0.55, "cm"),
    legend.key.height = grid::unit(0.40, "cm"),
    legend.text = element_text(size = 10),
    plot.title = element_text(face = "bold", hjust = 0.5, size = 14)
  )
'''

# Replace supplementary AF block:
# from "# Supplementary AF" to the B section header.
pattern_supp = re.compile(
    r"# Supplementary AF:.*?(?=\n# =========================================================\n# B\.)",
    re.S
)
s2, n1 = pattern_supp.subn(new_supp + "\n", s)

if n1 != 1:
    raise SystemExit(f"[ERROR] Supplementary AF block replacement failed; replacements={n1}")

# Replace B block:
# from B section header to C/D section header.
pattern_B = re.compile(
    r"# =========================================================\n# B\..*?(?=\n# =========================================================\n# C/D\.)",
    re.S
)
s3, n2 = pattern_B.subn(new_B + "\n", s2)

if n2 != 1:
    raise SystemExit(f"[ERROR] B block replacement failed; replacements={n2}")

rfile.write_text(s3)
print(f"[DONE] Updated R script: {rfile}")
print("[INFO] Replaced blocks:")
print("       1) Supplementary AF: GERP < 0 and GERP > 4")
print("       2) Panel B: Hom / Het count distribution")
PY

echo "[DONE] Patch finished."
echo "[INFO] Now rerun plotting:"
echo "Rscript ${RFILE} Teosinte_GERP_unpolarized_pipeline/01_tables Teosinte_GERP_unpolarized_pipeline/03_plots/Teosinte_GERP_unpolarized 0.025"
