#!/bin/bash
#SBATCH --job-name=KING_DIRECT_VCF
#SBATCH --output=king.%j.out
#SBATCH --error=king.%j.err
#SBATCH --cpus-per-task=20
#SBATCH -p parallel



# ===== 1. 运行KING分析 =====
echo "===== 开始KING分析 ====="
./king -b king_direct.bed --fam fixed.fam  --related --degree 3   --cpus 10 --prefix 3deg_relations  --sexchr 25  & 
./king -b king_direct.bed  --fam fixed.fam --duplicate --prefix duplicate  --sexchr 25 & 
./king -b king_direct.bed --fam fixed.fam  --kinship --degree 0 --cpus 10 --prefix distant_relations  --sexchr 25 & 
./king -b king_direct.bed --fam fixed.fam   --roh --rplot &
wait
echo "===== KING分析完成 ====="
# ===== 2. 处理输出文件 =====
echo "===== 处理输出文件 ====="
# 将相关性结果转换为plink格式
awk 'NR==1{print "FID1\tIID1\tFID2\tIID2\tKINSHIP"} NR>1{print $1"\t"$2"\t"$3"\t"$4"\t"$5}' 3deg_relations.kin0 > 3deg_relations.plink
awk 'NR==1{print "FID1\tIID1\tFID2\tIID2\tKINSHIP"} NR>1{print $1"\t"$2"\t"$3"\t"$4"\t"$5}' distant_relations.kin0 > distant_relations.plink
# 将重复样本结果转换为plink格式
awk 'NR==1{print "FID1\tIID1\tFID2\tIID2\tKINSHIP"} NR>1{print $1"\t"$2"\t"$3"\t"$4"\t"$5}' duplicate.kin0 > duplicate.plink
# 将结果转换为plink格式
plink --bfile king_direct --keep 3deg_relations.plink --make-bed --out king_direct_3deg --allow-extra-chr
plink --bfile king_direct --keep distant_relations.plink --make-bed --out king_direct_distant --allow-extra-chr
plink --bfile king_direct --keep duplicate.plink --make-bed --out king_direct_duplicate --allow-extra-chr


# ===== 5. 结果报告 =====
echo "===== 分析结果 ====="
echo "样本数: $(wc -l < king_direct.fam)"
echo "SNP总数: $(wc -l < king_direct.bim)"
echo "3度内关系对: $(grep -c -v "^FID" 3deg_relations.kin0)"
echo "3度外关系对: $(grep -c -v "^FID" distant_relations.kin0)"