#!/usr/bin/env python3
# -*- coding: utf-8 -*-

from __future__ import annotations

import argparse
import csv
import gzip
import math
import os
import re
import sys
import bisect
from collections import defaultdict, Counter
from typing import Dict, List, Tuple, Optional, Any

try:
    import pysam
except ImportError:
    sys.stderr.write("[ERROR] pysam is required. Install with: mamba install -c bioconda pysam\n")
    raise

VARIANT_CLASSES = ["SYNONYMOUS", "NONSYN_TOLERATED", "NONSYN_DELETERIOUS"]
REGIONS = ["ALL", "ROH", "Non-ROH"]

CLASS_LABEL = {
    "SYNONYMOUS": "Synonymous",
    "NONSYN_TOLERATED": "Tolerated nonsynonymous",
    "NONSYN_DELETERIOUS": "Deleterious nonsynonymous",
}

SYN_TERMS = ["synonymous_variant", "synonymous", "silent"]
NONSYN_TERMS = [
    "missense_variant", "missense", "nonsynonymous", "non_synonymous",
    "nonsynonymous_variant", "amino_acid_change",
]
LOF_TERMS = [
    "stop_gained", "stop_lost", "start_lost", "frameshift",
    "splice_acceptor", "splice_donor", "nonsense",
]

SIFT_SCORE_KEYS = {
    "SIFT", "SIFT_SCORE", "SIFTSCORE", "SIFT_SCORE_MIN", "SIFT4G_SCORE",
    "SIFTINFO", "SIFT_INFO", "SIFT_PRED", "SIFT_PREDICTION", "SIFT4G",
    "SIFT_PREDICTIONS",
}

FLOAT_RE = re.compile(r"(?<![A-Za-z0-9_.-])([01](?:\.\d+)?)(?![A-Za-z0-9_.-])")


def parse_args():
    p = argparse.ArgumentParser(
        description="Calculate Atau SIFT burden inside/outside ROH and merge with FROH."
    )
    p.add_argument("--vcf", required=True)
    p.add_argument("--froh", required=True)
    p.add_argument("--roh", required=True)
    p.add_argument("--lauto", default=None)
    p.add_argument("--out-prefix", required=True)
    p.add_argument("--sift-cutoff", type=float, default=0.05)
    p.add_argument("--exclude-samples", default="")
    p.add_argument("--allow-sift-without-effect", action="store_true")
    p.add_argument("--max-sites", type=int, default=0)
    return p.parse_args()


def smart_open(path, mode="rt"):
    if path.endswith(".gz"):
        return gzip.open(path, mode)
    return open(path, mode)


def norm_chrom(chrom: str) -> str:
    c = str(chrom)
    if c.lower().startswith("chr"):
        c = c[3:]
    return c


def read_tsv_dicts(path: str) -> List[Dict[str, str]]:
    with smart_open(path, "rt") as f:
        first = f.readline()
        if not first:
            return []
        f.seek(0)
        sep = "\t" if "\t" in first else None
        if sep == "\t":
            return list(csv.DictReader(f, delimiter="\t"))
        header = re.split(r"\s+", first.strip())
        out = []
        for line in f:
            if not line.strip():
                continue
            vals = re.split(r"\s+", line.strip())
            if len(vals) >= len(header):
                out.append(dict(zip(header, vals)))
        return out


def pick_col(cols, candidates, label):
    for c in candidates:
        if c in cols:
            return c
    raise RuntimeError(f"Cannot find {label}. Available columns: {list(cols)}")


def read_froh(path: str, exclude: set) -> Dict[str, Dict[str, float]]:
    rows = read_tsv_dicts(path)
    if not rows:
        raise RuntimeError(f"Empty FROH file: {path}")

    cols = rows[0].keys()
    sample_col = pick_col(cols, ["Sample", "sample", "IID", "FID"], "sample column")
    froh_col = pick_col(cols, ["FROH", "FROH_refGenome", "Froh", "froh"], "FROH column")

    out = {}
    for r in rows:
        s = str(r[sample_col])
        if s in exclude:
            continue
        try:
            f = float(r[froh_col])
        except Exception:
            continue

        rec = {"FROH": f}
        for k, v in r.items():
            try:
                rec[k] = float(v)
            except Exception:
                pass
        out[s] = rec

    if not out:
        raise RuntimeError("No samples left after reading FROH.")
    return out


def read_roh_segments(path: str, include_samples: set) -> Dict[str, Dict[str, List[Tuple[int, int]]]]:
    rows = read_tsv_dicts(path)
    if not rows:
        raise RuntimeError(f"Empty ROH file: {path}")

    cols = rows[0].keys()

    sample_col = pick_col(
        cols,
        ["sample", "Sample", "IID", "FID", "id", "ID"],
        "ROH sample column"
    )

    chr_col = pick_col(
        cols,
        ["chr", "CHR", "Chrom", "chrom", "Chromosome", "chromosome"],
        "ROH chromosome column"
    )

    start_col = pick_col(
        cols,
        ["start_bp", "Start_bp", "START_BP", "start", "Start", "START", "BP1", "POS1"],
        "ROH start column"
    )

    end_col = pick_col(
        cols,
        ["end_bp", "End_bp", "END_BP", "end", "End", "END", "BP2", "POS2"],
        "ROH end column"
    )

    raw = defaultdict(lambda: defaultdict(list))
    n = 0

    for r in rows:
        s = str(r[sample_col])
        if s not in include_samples:
            continue

        c = norm_chrom(r[chr_col])

        try:
            st = int(float(r[start_col]))
            en = int(float(r[end_col]))
        except Exception:
            continue

        if en < st:
            st, en = en, st

        raw[s][c].append((st, en))
        n += 1

    merged = defaultdict(dict)

    for s, by_chr in raw.items():
        for c, intervals in by_chr.items():
            intervals.sort()
            m = []

            for st, en in intervals:
                if not m or st > m[-1][1] + 1:
                    m.append([st, en])
                else:
                    m[-1][1] = max(m[-1][1], en)

            merged[s][c] = [(int(a), int(b)) for a, b in m]

    sys.stderr.write("[INFO] Loaded ROH intervals for %d samples; kept segments = %d\n" % (len(merged), n))

    return merged


def build_interval_index(roh):
    idx = {}
    for s, by_chr in roh.items():
        idx[s] = {}
        for c, intervals in by_chr.items():
            starts = [x[0] for x in intervals]
            ends = [x[1] for x in intervals]
            idx[s][c] = (starts, ends)
    return idx


def in_roh(idx, sample: str, chrom: str, pos: int) -> bool:
    if sample not in idx or chrom not in idx[sample]:
        return False
    starts, ends = idx[sample][chrom]
    j = bisect.bisect_right(starts, pos) - 1
    return j >= 0 and pos <= ends[j]


def flatten_info_values(record) -> List[str]:
    vals = []
    for key in record.info.keys():
        try:
            v = record.info.get(key)
        except Exception:
            continue
        if v is None:
            continue
        if isinstance(v, (tuple, list)):
            vals.extend([f"{key}={x}" for x in v if x is not None])
        else:
            vals.append(f"{key}={v}")
    return vals


def extract_ann_effect_text(record) -> str:
    texts = []

    for key in ["ANN", "CSQ", "EFF", "FUNCTIONAL_CLASS", "EFFECT", "Annotation", "annotation"]:
        if key in record.info:
            try:
                v = record.info.get(key)
            except Exception:
                v = None
            if v is None:
                continue
            if isinstance(v, (tuple, list)):
                texts.extend([str(x) for x in v])
            else:
                texts.append(str(v))

    texts.extend(flatten_info_values(record))
    return " ; ".join(texts).lower()


def extract_sift(record) -> Tuple[Optional[float], str, str]:
    candidate_texts = []

    for key in record.info.keys():
        key_u = str(key).upper()
        try:
            v = record.info.get(key)
        except Exception:
            continue
        if v is None:
            continue

        vals = [str(x) for x in v] if isinstance(v, (tuple, list)) else [str(v)]
        joined = ";".join(vals)

        if key_u in SIFT_SCORE_KEYS or "SIFT" in key_u:
            candidate_texts.append(f"{key}={joined}")
        elif re.search(r"sift|deleterious|tolerated|damaging", joined, re.I):
            candidate_texts.append(f"{key}={joined}")

    raw = " ; ".join(candidate_texts)
    raw_lower = raw.lower()

    scores = []
    for t in candidate_texts:
        if not re.search(r"sift|deleterious|tolerated|damaging|score", t, re.I):
            continue
        for m in re.finditer(
            r"(?:sift|score|deleterious|tolerated|damaging)[^0-9]{0,50}([01](?:\.\d+)?)",
            t,
            re.I,
        ):
            try:
                val = float(m.group(1))
                if 0.0 <= val <= 1.0:
                    scores.append(val)
            except Exception:
                pass

        for m in FLOAT_RE.finditer(t):
            try:
                val = float(m.group(1))
                if 0.0 <= val <= 1.0:
                    scores.append(val)
            except Exception:
                pass

    score = min(scores) if scores else None

    pred = ""
    if "deleterious" in raw_lower or "damaging" in raw_lower:
        pred = "deleterious"
    elif "tolerated" in raw_lower:
        pred = "tolerated"

    return score, pred, raw[:500]


def classify_variant(record, cutoff: float, allow_sift_without_effect: bool):
    effect_text = extract_ann_effect_text(record)
    score, pred, raw_sift = extract_sift(record)

    has_syn = any(t in effect_text for t in SYN_TERMS)
    has_nonsyn = any(t in effect_text for t in NONSYN_TERMS)
    has_lof = any(t in effect_text for t in LOF_TERMS)

    if has_nonsyn or has_lof or (
        allow_sift_without_effect and (score is not None or pred in {"deleterious", "tolerated"})
    ):
        if score is not None and math.isfinite(score):
            if score <= cutoff:
                return "NONSYN_DELETERIOUS", score, pred or "score_only", "sift_le_cutoff", raw_sift
            return "NONSYN_TOLERATED", score, pred or "score_only", "sift_gt_cutoff", raw_sift

        if pred == "deleterious":
            return "NONSYN_DELETERIOUS", score, pred, "pred_deleterious", raw_sift
        if pred == "tolerated":
            return "NONSYN_TOLERATED", score, pred, "pred_tolerated", raw_sift

        return "UNCLASSIFIED", score, pred, "nonsyn_no_sift", raw_sift

    if has_syn:
        return "SYNONYMOUS", score, pred, "synonymous", raw_sift

    return "UNCLASSIFIED", score, pred, "no_supported_effect", raw_sift


def gt_alt_dosage(gt) -> Optional[int]:
    if gt is None:
        return None
    alleles = [x for x in gt if x is not None]
    if len(alleles) == 0:
        return None
    if any(a not in (0, 1) for a in alleles):
        return None
    return sum(1 for a in alleles if a == 1)


def write_tsv(path, rows, fieldnames):
    with open(path, "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=fieldnames, delimiter="\t", extrasaction="ignore")
        w.writeheader()
        for r in rows:
            w.writerow(r)


def main():
    args = parse_args()

    exclude = set()
    if args.exclude_samples.strip():
        exclude = set(x.strip() for x in re.split(r"[,; ]+", args.exclude_samples) if x.strip())

    for f in [args.vcf, args.froh, args.roh]:
        if not os.path.exists(f):
            raise FileNotFoundError(f)

    froh = read_froh(args.froh, exclude)
    samples = set(froh.keys())
    roh = read_roh_segments(args.roh, samples)
    roh_idx = build_interval_index(roh)

    vcf = pysam.VariantFile(args.vcf)
    vcf_samples = [s for s in list(vcf.header.samples) if s in samples and s not in exclude]
    if not vcf_samples:
        raise RuntimeError("No VCF samples match FROH samples.")

    sys.stderr.write(f"[INFO] VCF samples: {len(vcf.header.samples)}\n")
    sys.stderr.write(f"[INFO] Samples used: {len(vcf_samples)}\n")
    sys.stderr.write(f"[INFO] Excluded samples: {','.join(sorted(exclude)) if exclude else 'none'}\n")

    site_rows = []
    class_rows = []
    unclassified_rows = []

    sample_stats = defaultdict(lambda: defaultdict(lambda: defaultdict(Counter)))
    site_class_counter = Counter()
    n_records = 0
    n_used_sites = 0

    for record in vcf:
        n_records += 1
        if args.max_sites and n_records > args.max_sites:
            break

        if len(record.alts or []) != 1:
            continue

        cls, score, pred, reason, raw_sift = classify_variant(
            record,
            args.sift_cutoff,
            args.allow_sift_without_effect,
        )

        if cls == "UNCLASSIFIED":
            if len(unclassified_rows) < 100:
                unclassified_rows.append({
                    "chrom": record.chrom,
                    "pos": record.pos,
                    "ref": record.ref,
                    "alt": record.alts[0],
                    "reason": reason,
                    "sift_score": "" if score is None else score,
                    "sift_prediction": pred,
                    "raw_sift": raw_sift,
                })
            continue

        chrom = norm_chrom(record.chrom)
        pos = int(record.pos)
        alt = record.alts[0]
        label = CLASS_LABEL[cls]

        called_alleles = 0
        alt_alleles = 0
        n_called_samples = 0
        n_het = 0
        n_hom_alt = 0
        n_roh_samples = 0
        n_nonroh_samples = 0

        for s in vcf_samples:
            try:
                gt = record.samples[s].get("GT")
            except Exception:
                continue
            dosage = gt_alt_dosage(gt)
            if dosage is None:
                continue

            n_called_samples += 1
            called_alleles += len([a for a in gt if a is not None])
            alt_alleles += dosage

            if dosage == 1:
                n_het += 1
            elif dosage == 2:
                n_hom_alt += 1

            sample_in_roh = in_roh(roh_idx, s, chrom, pos)
            specific_region = "ROH" if sample_in_roh else "Non-ROH"
            if sample_in_roh:
                n_roh_samples += 1
            else:
                n_nonroh_samples += 1

            for region in ["ALL", specific_region]:
                c = sample_stats[s][region][cls]
                c["called_sites"] += 1
                c["called_alleles"] += len([a for a in gt if a is not None])
                c["alt_dosage"] += dosage
                if dosage == 1:
                    c["het_loci"] += 1
                elif dosage == 2:
                    c["hom_alt_loci"] += 1
                if dosage > 0:
                    c["carrier_loci"] += 1

        if n_called_samples == 0:
            continue

        af = alt_alleles / called_alleles if called_alleles > 0 else float("nan")

        site_rows.append({
            "chrom": record.chrom,
            "pos": pos,
            "ref": record.ref,
            "alt": alt,
            "variant_class": cls,
            "class_label": label,
            "sift_score": "" if score is None else score,
            "sift_prediction": pred,
            "reason": reason,
            "n_called_samples": n_called_samples,
            "called_alleles": called_alleles,
            "alt_allele_count": alt_alleles,
            "AF": af,
        })

        class_rows.append({
            "chrom": record.chrom,
            "pos": pos,
            "ref": record.ref,
            "alt": alt,
            "variant_class": cls,
            "class_label": label,
            "sift_score": "" if score is None else score,
            "sift_prediction": pred,
            "reason": reason,
            "n_called_samples": n_called_samples,
            "called_alleles": called_alleles,
            "alt_allele_count": alt_alleles,
            "AF": af,
            "n_het_samples": n_het,
            "n_hom_alt_samples": n_hom_alt,
            "n_samples_in_ROH": n_roh_samples,
            "n_samples_in_NonROH": n_nonroh_samples,
            "raw_sift": raw_sift,
        })

        site_class_counter[cls] += 1
        n_used_sites += 1

    out_prefix = args.out_prefix
    outdir = os.path.dirname(out_prefix)
    if outdir:
        os.makedirs(outdir, exist_ok=True)

    write_tsv(
        out_prefix + ".site_AF.tsv",
        site_rows,
        [
            "chrom", "pos", "ref", "alt", "variant_class", "class_label",
            "sift_score", "sift_prediction", "reason",
            "n_called_samples", "called_alleles", "alt_allele_count", "AF",
        ],
    )

    write_tsv(
        out_prefix + ".classified_sites.tsv",
        class_rows,
        [
            "chrom", "pos", "ref", "alt", "variant_class", "class_label",
            "sift_score", "sift_prediction", "reason",
            "n_called_samples", "called_alleles", "alt_allele_count", "AF",
            "n_het_samples", "n_hom_alt_samples",
            "n_samples_in_ROH", "n_samples_in_NonROH", "raw_sift",
        ],
    )

    write_tsv(
        out_prefix + ".unclassified_examples.tsv",
        unclassified_rows,
        ["chrom", "pos", "ref", "alt", "reason", "sift_score", "sift_prediction", "raw_sift"],
    )

    burden_rows = []
    for s in sorted(vcf_samples):
        for region in REGIONS:
            for cls in VARIANT_CLASSES:
                c = sample_stats[s][region][cls]
                called_sites = int(c["called_sites"])
                called_alleles = int(c["called_alleles"])
                alt_dosage = int(c["alt_dosage"])
                burden_rows.append({
                    "sample": s,
                    "FROH": froh[s]["FROH"],
                    "region": region,
                    "variant_class": cls,
                    "class_label": CLASS_LABEL[cls],
                    "called_sites": called_sites,
                    "called_alleles": called_alleles,
                    "alt_dosage": alt_dosage,
                    "het_loci": int(c["het_loci"]),
                    "hom_alt_loci": int(c["hom_alt_loci"]),
                    "carrier_loci": int(c["carrier_loci"]),
                    "alt_per_called_site": alt_dosage / called_sites if called_sites else 0,
                    "alt_per_called_allele": alt_dosage / called_alleles if called_alleles else 0,
                })

    write_tsv(
        out_prefix + ".per_sample_burden.tsv",
        burden_rows,
        [
            "sample", "FROH", "region", "variant_class", "class_label",
            "called_sites", "called_alleles", "alt_dosage",
            "het_loci", "hom_alt_loci", "carrier_loci",
            "alt_per_called_site", "alt_per_called_allele",
        ],
    )

    ratio_rows = []
    total_by_region = defaultdict(Counter)
    for r in burden_rows:
        key = (r["region"], r["variant_class"], r["class_label"])
        total_by_region[key]["called_sites"] += int(r["called_sites"])
        total_by_region[key]["called_alleles"] += int(r["called_alleles"])
        total_by_region[key]["alt_dosage"] += int(r["alt_dosage"])
        total_by_region[key]["het_loci"] += int(r["het_loci"])
        total_by_region[key]["hom_alt_loci"] += int(r["hom_alt_loci"])

    for (region, cls, label), c in sorted(total_by_region.items()):
        called_sites = c["called_sites"]
        called_alleles = c["called_alleles"]
        alt_dosage = c["alt_dosage"]
        ratio_rows.append({
            "region": region,
            "variant_class": cls,
            "class_label": label,
            "called_sites": called_sites,
            "called_alleles": called_alleles,
            "alt_dosage": alt_dosage,
            "het_loci": c["het_loci"],
            "hom_alt_loci": c["hom_alt_loci"],
            "alt_per_called_site": alt_dosage / called_sites if called_sites else 0,
            "alt_per_called_allele": alt_dosage / called_alleles if called_alleles else 0,
        })

    write_tsv(
        out_prefix + ".ratio_metrics.tsv",
        ratio_rows,
        [
            "region", "variant_class", "class_label",
            "called_sites", "called_alleles", "alt_dosage",
            "het_loci", "hom_alt_loci",
            "alt_per_called_site", "alt_per_called_allele",
        ],
    )

    # Fig2 long tables for plotting compatibility
    fig2_rows = []
    fig2b_rows = []
    fig2c_rows = []

    for r in burden_rows:
        if r["variant_class"] != "NONSYN_DELETERIOUS":
            continue
        if r["region"] != "ALL":
            continue

        for comp, val in [
            ("Heterozygous ALT loci", r["het_loci"]),
            ("Homozygous ALT loci", r["hom_alt_loci"]),
        ]:
            fig2_rows.append({
                "sample": r["sample"],
                "FROH": r["FROH"],
                "component": comp,
                "value": val,
            })

        fig2b_rows.append({
            "sample": r["sample"],
            "FROH": r["FROH"],
            "metric": "Deleterious ALT dosage",
            "value": r["alt_dosage"],
        })
        fig2b_rows.append({
            "sample": r["sample"],
            "FROH": r["FROH"],
            "metric": "Homozygous deleterious loci",
            "value": r["hom_alt_loci"],
        })
        fig2b_rows.append({
            "sample": r["sample"],
            "FROH": r["FROH"],
            "metric": "Heterozygous deleterious loci",
            "value": r["het_loci"],
        })

        fig2c_rows.append({
            "sample": r["sample"],
            "FROH": r["FROH"],
            "metric": "Deleterious ALT dosage per called allele",
            "value": r["alt_per_called_allele"],
        })
        fig2c_rows.append({
            "sample": r["sample"],
            "FROH": r["FROH"],
            "metric": "Deleterious ALT dosage per called site",
            "value": r["alt_per_called_site"],
        })

    write_tsv(
        out_prefix + ".Fig2_hom_het_counts.long.tsv",
        fig2_rows,
        ["sample", "FROH", "component", "value"],
    )

    write_tsv(
        out_prefix + ".Fig2b_FROH_deleterious_counts.long.tsv",
        fig2b_rows,
        ["sample", "FROH", "metric", "value"],
    )

    write_tsv(
        out_prefix + ".Fig2c_FROH_deleterious_load.long.tsv",
        fig2c_rows,
        ["sample", "FROH", "metric", "value"],
    )

    summary_rows = []
    for cls in VARIANT_CLASSES:
        summary_rows.append({
            "metric": "site_count",
            "variant_class": cls,
            "class_label": CLASS_LABEL[cls],
            "value": site_class_counter[cls],
        })
    summary_rows.extend([
        {"metric": "vcf_records_scanned", "variant_class": "ALL", "class_label": "ALL", "value": n_records},
        {"metric": "classified_sites_used", "variant_class": "ALL", "class_label": "ALL", "value": n_used_sites},
        {"metric": "samples_used", "variant_class": "ALL", "class_label": "ALL", "value": len(vcf_samples)},
    ])

    write_tsv(
        out_prefix + ".summary.tsv",
        summary_rows,
        ["metric", "variant_class", "class_label", "value"],
    )

    sys.stderr.write("[DONE] Outputs written with prefix:\n")
    sys.stderr.write(f"       {out_prefix}\n")


if __name__ == "__main__":
    main()
