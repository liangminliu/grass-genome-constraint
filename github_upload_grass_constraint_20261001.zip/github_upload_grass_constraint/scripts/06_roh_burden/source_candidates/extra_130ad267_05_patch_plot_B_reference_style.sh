#!/usr/bin/env bash
set -euo pipefail

RFILE="Teosinte_GERP_unpolarized_pipeline/scripts/02_plot_Teosinte_GERP_unpolarized_AH.R"

if [[ ! -s "${RFILE}" ]]; then
  echo "[ERROR] Missing R script: ${RFILE}" >&2
  exit 1
fi

BACKUP="${RFILE}.bak.$(date +%Y%m%d_%H%M%S)"
cp "${RFILE}" "${BACKUP}"
echo "[INFO] Backup written to: ${BACKUP}"

python3 - <<'PY'
from pathlib import Path
import re

rfile = Path("Teosinte_GERP_unpolarized_pipeline/scripts/02_plot_Teosinte_GERP_unpolarized_AH.R")
s = rfile.read_text()

new_B = r'''# =========================================================
# B. Hom / Het count distribution
# Reference-style version:
#   - Homozygous on the left, Heterozygous on the right
#   - pseudo axis break in the middle
#   - no overlap
#   - visual bar width matched to panel A
# =========================================================

b_raw <- bc %>%
  filter(component %in% c("het", "hom")) %>%
  transmute(
    sample,
    group = recode(component, "hom" = "Homozygous", "het" = "Heterozygous"),
    value = value_count
  ) %>%
  filter(is.finite(value)) %>%
  mutate(group = factor(group, levels = c("Homozygous", "Heterozygous")))

b_hom <- b_raw %>% filter(group == "Homozygous")
b_het <- b_raw %>% filter(group == "Heterozygous")

# ---------------------------------------------------------
# Target bar width:
# Make B bars visually similar to A.
# A uses round(1 / af_binwidth) bars over the full x-span.
# ---------------------------------------------------------
b_all_min <- min(b_raw$value, na.rm = TRUE)
b_all_max <- max(b_raw$value, na.rm = TRUE)
b_all_span <- b_all_max - b_all_min

nbar_target <- max(20, round(1 / af_binwidth))
bar_w_target <- b_all_span / nbar_target

make_hist_table <- function(df, bar_w) {
  vmin <- floor(min(df$value, na.rm = TRUE) / bar_w) * bar_w
  vmax <- ceiling(max(df$value, na.rm = TRUE) / bar_w) * bar_w
  breaks <- seq(vmin, vmax + bar_w, by = bar_w)

  out <- df %>%
    mutate(
      bin_id = pmin(
        length(breaks) - 1,
        pmax(1, findInterval(value, breaks, rightmost.closed = TRUE))
      ),
      xmin = breaks[bin_id],
      xmax = breaks[bin_id + 1]
    ) %>%
    count(group, bin_id, xmin, xmax, name = "count") %>%
    complete(
      bin_id = seq_len(length(breaks) - 1),
      fill = list(count = 0)
    ) %>%
    mutate(
      group = unique(df$group)[1],
      xmin = ifelse(is.na(xmin), breaks[bin_id], xmin),
      xmax = ifelse(is.na(xmax), breaks[bin_id + 1], xmax),
      xmid = (xmin + xmax) / 2
    )

  out
}

hom_hist <- make_hist_table(b_hom, bar_w_target)
het_hist <- make_hist_table(b_het, bar_w_target)

# ---------------------------------------------------------
# Build a pseudo broken x-axis:
# left segment = Homozygous range
# right segment = Heterozygous range
# ---------------------------------------------------------
left_min  <- min(hom_hist$xmin, na.rm = TRUE)
left_max  <- max(hom_hist$xmax, na.rm = TRUE)
right_min <- min(het_hist$xmin, na.rm = TRUE)
right_max <- max(het_hist$xmax, na.rm = TRUE)

left_span  <- left_max - left_min
right_span <- right_max - right_min

gap_span <- left_span * 0.14
right_offset <- left_span + gap_span

transform_left <- function(x)  x - left_min
transform_right <- function(x) (x - right_min) + right_offset

hom_hist <- hom_hist %>%
  mutate(
    xmin_plot = transform_left(xmin),
    xmax_plot = transform_left(xmax),
    xmid_plot = transform_left(xmid)
  )

het_hist <- het_hist %>%
  mutate(
    xmin_plot = transform_right(xmin),
    xmax_plot = transform_right(xmax),
    xmid_plot = transform_right(xmid)
  )

# ---------------------------------------------------------
# Medians
# ---------------------------------------------------------
b_med <- b_raw %>%
  group_by(group) %>%
  summarise(
    med = median(value, na.rm = TRUE),
    .groups = "drop"
  ) %>%
  mutate(
    xintercept = case_when(
      group == "Homozygous" ~ transform_left(med),
      group == "Heterozygous" ~ transform_right(med),
      TRUE ~ NA_real_
    )
  )

# ---------------------------------------------------------
# Y scale
# ---------------------------------------------------------
b_ymax <- nice_y_top(max(c(hom_hist$count, het_hist$count), na.rm = TRUE))

b_med <- b_med %>%
  mutate(
    y = case_when(
      group == "Homozygous" ~ b_ymax * 0.82,
      group == "Heterozygous" ~ b_ymax * 0.70,
      TRUE ~ b_ymax * 0.76
    ),
    x = case_when(
      group == "Homozygous" ~ pmin(xintercept + left_span * 0.12, transform_left(left_max) * 0.93),
      group == "Heterozygous" ~ pmin(xintercept + right_span * 0.12, transform_right(right_max) * 0.98),
      TRUE ~ xintercept
    ),
    label = paste0("median = ", comma(round(med)))
  )

# ---------------------------------------------------------
# Ticks
# ---------------------------------------------------------
make_ticks <- function(vmin, vmax, n = 4) {
  pretty(c(vmin, vmax), n = n)
}

ticks_left <- make_ticks(left_min, left_max, n = 4)
ticks_left <- ticks_left[ticks_left >= left_min & ticks_left <= left_max]

ticks_right <- make_ticks(right_min, right_max, n = 5)
ticks_right <- ticks_right[ticks_right >= right_min & ticks_right <= right_max]

tick_df <- bind_rows(
  tibble(
    label_value = ticks_left,
    x = transform_left(ticks_left),
    label = comma(round(ticks_left))
  ),
  tibble(
    label_value = ticks_right,
    x = transform_right(ticks_right),
    label = comma(round(ticks_right))
  )
)

# ---------------------------------------------------------
# Group labels
# ---------------------------------------------------------
group_label_df <- tibble(
  x = c(transform_left((left_min + left_max) / 2),
        transform_right((right_min + right_max) / 2)),
  y = c(b_ymax * 0.97, b_ymax * 0.97),
  label = c("Homozygotes", "Heterozygotes")
)

# pseudo axis break marks
break_x <- left_span + gap_span / 2

pB <- ggplot() +
  geom_rect(
    data = hom_hist,
    aes(xmin = xmin_plot, xmax = xmax_plot, ymin = 0, ymax = count),
    fill = col_hom,
    colour = "grey35",
    linewidth = 0.12,
    alpha = 0.94
  ) +
  geom_rect(
    data = het_hist,
    aes(xmin = xmin_plot, xmax = xmax_plot, ymin = 0, ymax = count),
    fill = col_het,
    colour = "grey35",
    linewidth = 0.12,
    alpha = 0.94
  ) +
  geom_vline(
    data = b_med,
    aes(xintercept = xintercept, colour = group),
    linetype = 2,
    linewidth = 0.60,
    show.legend = FALSE
  ) +
  geom_text(
    data = b_med,
    aes(x = x, y = y, label = label, colour = group),
    hjust = 0,
    size = 3.0,
    fontface = "bold",
    show.legend = FALSE
  ) +
  geom_text(
    data = group_label_df,
    aes(x = x, y = y, label = label),
    fontface = "bold",
    size = 3.3,
    colour = "grey10"
  ) +
  annotate("segment",
           x = break_x - left_span * 0.018, xend = break_x - left_span * 0.006,
           y = -b_ymax * 0.012, yend =  b_ymax * 0.012,
           linewidth = 0.55, colour = "grey25") +
  annotate("segment",
           x = break_x + left_span * 0.006, xend = break_x + left_span * 0.018,
           y = -b_ymax * 0.012, yend =  b_ymax * 0.012,
           linewidth = 0.55, colour = "grey25") +
  scale_colour_manual(values = c("Homozygous" = col_hom, "Heterozygous" = col_het)) +
  scale_x_continuous(
    limits = c(-left_span * 0.08, transform_right(right_max) + right_span * 0.05),
    breaks = tick_df$x,
    labels = tick_df$label,
    expand = c(0, 0)
  ) +
  scale_y_continuous(
    limits = c(-0.035 * b_ymax, b_ymax),
    breaks = pretty(c(0, b_ymax), n = 6),
    expand = c(0, 0)
  ) +
  labs(
    title = "GERP > 4",
    x = "Number of loci",
    y = "Number of individuals"
  ) +
  theme_pub(12) +
  theme(
    legend.position = c(0.52, 0.96),
    legend.direction = "horizontal",
    legend.background = element_blank(),
    legend.key.width = grid::unit(0.55, "cm"),
    legend.key.height = grid::unit(0.40, "cm"),
    legend.text = element_text(size = 10),
    plot.title = element_text(face = "bold", hjust = 0.5, size = 14),
    axis.text.x = element_text(size = 9)
  ) +
  guides(
    colour = "none",
    fill = "none"
  ) +
  annotate("rect", xmin = Inf, xmax = Inf, ymin = Inf, ymax = Inf, alpha = 0)

# add legend manually through invisible points
pB <- pB +
  geom_point(
    data = tibble(group = factor(c("Homozygous", "Heterozygous"),
                                 levels = c("Homozygous", "Heterozygous")),
                  x = NA_real_, y = NA_real_),
    aes(x = x, y = y, fill = group),
    shape = 22, size = 5, colour = "grey35", stroke = 0.25,
    inherit.aes = FALSE
  ) +
  scale_fill_manual(values = c("Homozygous" = col_hom, "Heterozygous" = col_het))
'''

pattern_B = re.compile(
    r"# =========================================================\n# B\..*?(?=\n# =========================================================\n# C/D\.)",
    re.S
)

s2, n = pattern_B.subn(new_B + "\n", s)

if n != 1:
    raise SystemExit(f"[ERROR] B block replacement failed; replacements={n}")

rfile.write_text(s2)
print(f"[DONE] Updated R script: {rfile}")
print("[INFO] Replaced block: Panel B")
PY

echo "[DONE] Patch finished."
echo "[INFO] Now rerun plotting:"
echo "Rscript ${RFILE} Teosinte_GERP_unpolarized_pipeline/01_tables Teosinte_GERP_unpolarized_pipeline/03_plots/Teosinte_GERP_unpolarized 0.025"
