#!/usr/bin/env bash
#SBATCH --job-name=Teosinte_GERP_unpolarized
#SBATCH --partition=parallel
#SBATCH --cpus-per-task=1
#SBATCH --output=Teosinte_GERP_unpolarized_pipeline/logs/%x.%j.out
#SBATCH --error=Teosinte_GERP_unpolarized_pipeline/logs/%x.%j.err

set -euo pipefail

BASE="Teosinte_GERP_unpolarized_pipeline"
TABLE_DIR="${BASE}/01_tables"
OUT_PREFIX="${BASE}/03_plots/Teosinte_GERP_unpolarized"

mkdir -p "$(dirname "${OUT_PREFIX}")" "${BASE}/logs"
bash Teosinte_GERP_unpolarized_pipeline/scripts/00_run_Teosinte_GERP_unpolarized.sh

required=(
  "Teosinte_GERP.site_AF.tsv"
  "plot_A_site_spectrum.tsv"
  "Teosinte_GERP.per_sample_burden.tsv"
  "plot_BC_GERP4_burden.tsv"
  "plot_DE_GERP4_over_lt0_ratio.tsv"
  "plot_F_ROH_nonROH_burden.tsv"
  "plot_GH_ROH_nonROH_ratio.tsv"
)

for x in "${required[@]}"; do
  if [[ ! -s "${TABLE_DIR}/${x}" ]]; then
    echo "[ERROR] Missing table: ${TABLE_DIR}/${x}" >&2
    echo "[ERROR] Run calculation first:" >&2
    echo "bash ${BASE}/scripts/00_run_Teosinte_GERP_unpolarized.sh" >&2
    exit 1
  fi
done

Rscript "${BASE}/scripts/02_plot_Teosinte_GERP_unpolarized_AH.R" \
  "${TABLE_DIR}" \
  "${OUT_PREFIX}" \
  0.025

echo "[DONE] plots written to ${BASE}/03_plots"
