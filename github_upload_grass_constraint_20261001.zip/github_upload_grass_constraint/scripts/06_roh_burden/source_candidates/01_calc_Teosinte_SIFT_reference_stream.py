#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import argparse
import bisect
import os
import re
import subprocess
import sys
from collections import defaultdict

import pandas as pd


CLASSES = [
    "Synonymous",
    "Tolerated nonsynonymous",
    "Deleterious nonsynonymous",
]

REGIONS = [
    "ALL",
    "ROH",
    "Non-ROH",
]


def parse_args():
    p = argparse.ArgumentParser(
        description="Stream-read problematic SIFT VCF and calculate Teosinte SIFT burden in Atau-reference format."
    )
    p.add_argument("--vcf", required=True)
    p.add_argument("--roh", required=True)
    p.add_argument("--froh", required=True)
    p.add_argument("--species", default="Teosinte")
    p.add_argument("--sift-cutoff", type=float, default=0.05)
    p.add_argument("--out-prefix", required=True)
    return p.parse_args()


def canon_chrom(x):
    x = str(x)
    x = x.strip()
    if x.lower().startswith("chr"):
        x = x[3:]
    return x


def init_counter():
    return {
        "called_sites": 0,
        "called_alleles": 0,
        "alt_dosage": 0,
        "het_loci": 0,
        "hom_alt_loci": 0,
    }


def update_counter(d, dosage):
    d["called_sites"] += 1
    d["called_alleles"] += 2
    d["alt_dosage"] += dosage
    if dosage == 1:
        d["het_loci"] += 1
    elif dosage == 2:
        d["hom_alt_loci"] += 1


def add_rates(df):
    if df.empty:
        return df

    df["alt_allele_rate"] = df["alt_dosage"] / df["called_alleles"].replace(0, pd.NA)
    df["het_loci_rate"] = df["het_loci"] / df["called_sites"].replace(0, pd.NA)
    df["hom_alt_loci_rate"] = df["hom_alt_loci"] / df["called_sites"].replace(0, pd.NA)
    return df


def open_vcf_stream(path):
    if path.endswith(".gz"):
        proc = subprocess.Popen(
            ["zcat", path],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            bufsize=1024 * 1024,
        )
        return proc.stdout, proc
    return open(path, "rt"), None


def close_vcf_stream(handle, proc):
    if proc is None:
        handle.close()
        return 0, ""
    handle.close()
    stderr = proc.stderr.read()
    ret = proc.wait()
    return ret, stderr


def parse_info_dict(info_str):
    out = {}
    if info_str == ".":
        return out

    for item in info_str.split(";"):
        if not item:
            continue
        if "=" in item:
            k, v = item.split("=", 1)
            out[k] = v
        else:
            out[item] = True
    return out


def classify_consequence(info_str):
    """
    Important:
    Check nonsynonymous/missense first.
    'nonsynonymous' contains the substring 'synonymous'.
    """
    s = info_str.lower()

    nonsyn_patterns = [
        "missense_variant",
        "missense",
        "nonsynonymous",
        "non_synonymous",
        "non-synonymous",
        "nonsyn",
    ]

    for pat in nonsyn_patterns:
        if pat in s:
            return "nonsynonymous"

    syn_patterns = [
        "synonymous_variant",
        "synonymous",
    ]

    for pat in syn_patterns:
        if pat in s:
            return "synonymous"

    return "unknown"


def extract_sift_scores(info_str):
    """
    Extract SIFT score from SIFT-related INFO fields.

    Deliberately ignores SIFT_Threshold-like fields.
    """
    scores = []
    info = parse_info_dict(info_str)

    for k, v in info.items():
        key = str(k)
        val = str(v)

        key_upper = key.upper()
        val_upper = val.upper()

        if "SIFT" not in key_upper and "SIFT" not in val_upper:
            continue

        if "THRESHOLD" in key_upper:
            continue

        # Common cases:
        # SIFT=0.03
        # SIFT_score=0.03
        # SIFTINFO=...|0.03|...
        # deleterious(0.03)
        nums = re.findall(
            r"(?<![A-Za-z0-9_.-])(?:0(?:\.\d+)?|1(?:\.0+)?)(?![A-Za-z0-9_.-])",
            val,
        )

        for x in nums:
            try:
                f = float(x)
                if 0.0 <= f <= 1.0:
                    scores.append(f)
            except Exception:
                pass

    return scores


def classify_site(info_str, cutoff):
    consequence = classify_consequence(info_str)

    if consequence == "synonymous":
        return "synonymous", "Synonymous", None, consequence

    if consequence == "nonsynonymous":
        scores = extract_sift_scores(info_str)

        if len(scores) == 0:
            return "nonsynonymous_no_sift", None, None, consequence

        min_sift = min(scores)

        if min_sift < cutoff:
            return "deleterious_nonsynonymous", "Deleterious nonsynonymous", min_sift, consequence

        return "tolerated_nonsynonymous", "Tolerated nonsynonymous", min_sift, consequence

    return "unknown", None, None, consequence


def gt_to_alt_dosage(sample_field, gt_index):
    if sample_field in {".", "./.", ".|."}:
        return None

    parts = sample_field.split(":")
    if gt_index >= len(parts):
        return None

    gt = parts[gt_index]
    if gt in {".", "./.", ".|."}:
        return None

    alleles = re.split(r"[\/|]", gt)
    if len(alleles) != 2:
        return None

    if "." in alleles:
        return None

    try:
        a0 = int(alleles[0])
        a1 = int(alleles[1])
    except Exception:
        return None

    if a0 not in (0, 1) or a1 not in (0, 1):
        return None

    return a0 + a1


def read_roh_intervals(path):
    df = pd.read_csv(path, sep="\t")
    lower = {c.lower(): c for c in df.columns}

    sample_col = None
    for x in ["sample", "iid", "id"]:
        if x in lower:
            sample_col = lower[x]
            break

    chr_col = None
    for x in ["chr", "chrom", "chromosome"]:
        if x in lower:
            chr_col = lower[x]
            break

    start_col = None
    for x in ["start_bp", "pos1", "start", "bp1"]:
        if x in lower:
            start_col = lower[x]
            break

    end_col = None
    for x in ["end_bp", "pos2", "end", "bp2"]:
        if x in lower:
            end_col = lower[x]
            break

    if sample_col is None or chr_col is None or start_col is None or end_col is None:
        raise RuntimeError(
            f"Cannot detect ROH columns in {path}. Columns={list(df.columns)}"
        )

    tmp = defaultdict(lambda: defaultdict(list))

    for _, r in df.iterrows():
        s = str(r[sample_col])
        c = canon_chrom(r[chr_col])

        try:
            st = int(r[start_col])
            en = int(r[end_col])
        except Exception:
            continue

        if en < st:
            st, en = en, st

        tmp[s][c].append((st, en))

    roh = defaultdict(dict)

    for s in tmp:
        for c in tmp[s]:
            intervals = sorted(tmp[s][c])
            roh[s][c] = {
                "starts": [x[0] for x in intervals],
                "ends": [x[1] for x in intervals],
            }

    return roh


def in_roh(pos, roh_obj):
    if not roh_obj:
        return False

    starts = roh_obj["starts"]
    ends = roh_obj["ends"]

    idx = bisect.bisect_right(starts, pos) - 1

    if idx < 0:
        return False

    return pos <= ends[idx]


def read_froh(path):
    df = pd.read_csv(path, sep="\t")
    lower = {c.lower(): c for c in df.columns}

    sample_col = None
    for x in ["sample", "iid", "id"]:
        if x in lower:
            sample_col = lower[x]
            break

    froh_col = None
    for x in ["froh", "f_roh", "froh_total", "froh_all"]:
        if x in lower:
            froh_col = lower[x]
            break

    if sample_col is None or froh_col is None:
        raise RuntimeError(f"Cannot detect sample/FROH columns in {path}. Columns={list(df.columns)}")

    out = df[[sample_col, froh_col]].copy()
    out.columns = ["sample", "FROH"]
    out["sample"] = out["sample"].astype(str)
    return out


def main():
    args = parse_args()

    os.makedirs(os.path.dirname(args.out_prefix), exist_ok=True)

    print(f"[INFO] VCF          = {args.vcf}")
    print(f"[INFO] ROH          = {args.roh}")
    print(f"[INFO] FROH         = {args.froh}")
    print(f"[INFO] species      = {args.species}")
    print(f"[INFO] sift_cutoff  = {args.sift_cutoff}")
    print(f"[INFO] out_prefix   = {args.out_prefix}")

    froh_df = read_froh(args.froh)
    sample_to_froh = dict(zip(froh_df["sample"], froh_df["FROH"]))

    print("[INFO] Reading ROH intervals...")
    roh = read_roh_intervals(args.roh)
    print(f"[INFO] ROH samples loaded: {len(roh)}")

    site_af_out = args.out_prefix + ".site_AF.tsv"
    burden_out = args.out_prefix + ".per_sample_burden.tsv"
    malformed_out = args.out_prefix + ".malformed_records.tsv"
    no_sift_out = args.out_prefix + ".no_sift_nonsynonymous.tsv"
    summary_out = args.out_prefix + ".stream_read.summary.tsv"

    counters = defaultdict(init_counter)

    samples = []
    n_header_lines = 0
    n_total_records = 0
    n_malformed = 0
    n_biallelic = 0
    n_unknown = 0
    n_syn = 0
    n_tol = 0
    n_del = 0
    n_nonsyn_no_sift = 0
    n_no_gt = 0
    n_used_sites = 0

    handle, proc = open_vcf_stream(args.vcf)

    with open(site_af_out, "w") as site_fh, \
         open(malformed_out, "w") as bad_fh, \
         open(no_sift_out, "w") as ns_fh:

        site_fh.write(
            "chrom\tpos\tref\talt\tAC\tAN\tAF\tvariant_class\tclass_label\tmin_sift\tannotation_class\n"
        )

        bad_fh.write(
            "chrom\tpos\treason\tn_fields\texpected_fields\tn_samples\tline_prefix\n"
        )

        ns_fh.write(
            "chrom\tpos\tref\talt\tannotation_class\tinfo_prefix\n"
        )

        print("[INFO] Streaming VCF...")

        try:
            for raw_line in handle:
                line = raw_line.rstrip("\n")

                if not line:
                    continue

                if line.startswith("##"):
                    n_header_lines += 1
                    continue

                if line.startswith("#CHROM"):
                    fields = line.split("\t")
                    if len(fields) < 10:
                        raise RuntimeError("VCF #CHROM header does not contain sample columns.")
                    samples = fields[9:]
                    print(f"[INFO] VCF samples detected: {len(samples)}")
                    continue

                if not samples:
                    raise RuntimeError("VCF #CHROM header was not found before records.")

                n_total_records += 1

                arr = line.split("\t")
                expected_fields = 9 + len(samples)

                if len(arr) != expected_fields:
                    n_malformed += 1
                    chrom = arr[0] if len(arr) > 0 else "NA"
                    pos = arr[1] if len(arr) > 1 else "NA"
                    prefix = line[:200].replace("\t", "\\t")
                    bad_fh.write(
                        f"{chrom}\t{pos}\tcolumn_count_mismatch\t{len(arr)}\t{expected_fields}\t{len(samples)}\t{prefix}\n"
                    )
                    continue

                chrom, pos_s, vid, ref, alt, qual, flt, info_str, fmt = arr[:9]
                sample_fields = arr[9:]

                if "," in alt:
                    continue

                if alt in {".", "<NON_REF>", "NON_REF"}:
                    continue

                try:
                    pos = int(pos_s)
                except Exception:
                    n_malformed += 1
                    prefix = line[:200].replace("\t", "\\t")
                    bad_fh.write(
                        f"{chrom}\t{pos_s}\tinvalid_position\t{len(arr)}\t{expected_fields}\t{len(samples)}\t{prefix}\n"
                    )
                    continue

                n_biallelic += 1

                variant_class, class_label, min_sift, annotation_class = classify_site(
                    info_str,
                    args.sift_cutoff
                )

                if variant_class == "unknown":
                    n_unknown += 1
                    continue

                if variant_class == "nonsynonymous_no_sift":
                    n_nonsyn_no_sift += 1
                    ns_fh.write(
                        f"{chrom}\t{pos}\t{ref}\t{alt}\t{annotation_class}\t{info_str[:300]}\n"
                    )
                    continue

                if variant_class == "synonymous":
                    n_syn += 1
                elif variant_class == "tolerated_nonsynonymous":
                    n_tol += 1
                elif variant_class == "deleterious_nonsynonymous":
                    n_del += 1

                fmt_keys = fmt.split(":")
                if "GT" not in fmt_keys:
                    n_no_gt += 1
                    continue

                gt_index = fmt_keys.index("GT")

                site_ac = 0
                site_an = 0
                sample_dosages = []

                for s, sf in zip(samples, sample_fields):
                    dosage = gt_to_alt_dosage(sf, gt_index)
                    sample_dosages.append((s, dosage))

                    if dosage is None:
                        continue

                    site_ac += dosage
                    site_an += 2

                if site_an == 0:
                    continue

                site_af = site_ac / site_an
                n_used_sites += 1

                site_fh.write(
                    f"{chrom}\t{pos}\t{ref}\t{alt}\t{site_ac}\t{site_an}\t{site_af}\t"
                    f"{variant_class}\t{class_label}\t"
                    f"{min_sift if min_sift is not None else 'NA'}\t"
                    f"{annotation_class}\n"
                )

                chrom_key = canon_chrom(chrom)

                for s, dosage in sample_dosages:
                    if dosage is None:
                        continue

                    # ALL
                    update_counter(counters[(s, "ALL", class_label)], dosage)

                    # ROH / Non-ROH
                    sample_roh_chrom = roh.get(s, {}).get(chrom_key)
                    region_name = "ROH" if in_roh(pos, sample_roh_chrom) else "Non-ROH"
                    update_counter(counters[(s, region_name, class_label)], dosage)

        finally:
            zcat_ret, zcat_stderr = close_vcf_stream(handle, proc)

    print(f"[INFO] VCF header lines             : {n_header_lines}")
    print(f"[INFO] VCF total records            : {n_total_records}")
    print(f"[INFO] Biallelic records checked    : {n_biallelic}")
    print(f"[INFO] Malformed records skipped    : {n_malformed}")
    print(f"[INFO] Unknown annotation skipped   : {n_unknown}")
    print(f"[INFO] Nonsynonymous no SIFT skipped: {n_nonsyn_no_sift}")
    print(f"[INFO] No-GT records skipped        : {n_no_gt}")
    print(f"[INFO] Synonymous sites             : {n_syn}")
    print(f"[INFO] Tolerated nonsynonymous sites: {n_tol}")
    print(f"[INFO] Deleterious nonsyn sites     : {n_del}")
    print(f"[INFO] Used sites with genotypes    : {n_used_sites}")
    print(f"[INFO] zcat return code             : {zcat_ret}")

    if zcat_stderr:
        print("[WARN] zcat stderr message:", file=sys.stderr)
        print(zcat_stderr, file=sys.stderr)

    if zcat_ret != 0:
        print(
            "[WARN] zcat returned non-zero status. The source gzip may have EOF/checksum/truncation issues. "
            "Statistics were calculated from records successfully streamed before zcat stopped.",
            file=sys.stderr,
        )

    rows = []
    for s in samples:
        froh = sample_to_froh.get(s, pd.NA)

        for region_name in REGIONS:
            for class_label in CLASSES:
                dic = counters[(s, region_name, class_label)]

                row = {
                    "species": args.species,
                    "sample": s,
                    "FROH": froh,
                    "region": region_name,
                    "variant_class": class_label.replace(" ", "_").lower(),
                    "class_label": class_label,
                }
                row.update(dic)
                rows.append(row)

    burden_df = pd.DataFrame(rows)
    burden_df = add_rates(burden_df)
    burden_df.to_csv(burden_out, sep="\t", index=False)

    summary_df = pd.DataFrame([{
        "vcf": args.vcf,
        "zcat_return_code": zcat_ret,
        "n_header_lines": n_header_lines,
        "n_total_records": n_total_records,
        "n_biallelic_records": n_biallelic,
        "n_malformed_records_skipped": n_malformed,
        "n_unknown_annotation_skipped": n_unknown,
        "n_nonsynonymous_no_sift_skipped": n_nonsyn_no_sift,
        "n_no_gt_records_skipped": n_no_gt,
        "n_synonymous_sites": n_syn,
        "n_tolerated_nonsynonymous_sites": n_tol,
        "n_deleterious_nonsynonymous_sites": n_del,
        "n_used_sites_with_genotypes": n_used_sites,
        "n_samples": len(samples),
    }])

    summary_df.to_csv(summary_out, sep="\t", index=False)

    print(f"[OUT] {site_af_out}")
    print(f"[OUT] {burden_out}")
    print(f"[OUT] {malformed_out}")
    print(f"[OUT] {no_sift_out}")
    print(f"[OUT] {summary_out}")
    print("[DONE] Reference-format SIFT calculation finished.")


if __name__ == "__main__":
    main()
