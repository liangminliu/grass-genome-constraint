#!/usr/bin/env Rscript

suppressPackageStartupMessages({
  library(ggplot2)
  library(patchwork)
})

args <- commandArgs(trailingOnly = TRUE)

if (length(args) < 7) {
  stop(
    "Usage:\n",
    "Rscript 05_plot_Ped_SIFT_vs_Ho.R <heterozygosity.tsv> <SIFT_burden.tsv> <out_prefix> ",
    "<subgenome> <variant_class> <layer> <region> [remove_samples] [drop_regex] [total_method]\n\n",
    "Example:\n",
    "Rscript 05_plot_Ped_SIFT_vs_Ho.R Ped63.individual_heterozygosity.tsv Ped_SIFT.per_sample_burden.tsv ",
    "out/PedALL.SIFTlt005.polarized PedALL SIFT_lt0.05 polarized_derived ALL NONE NONE carrier\n"
  )
}

hetero_file   <- args[1]
sift_file     <- args[2]
out_prefix    <- args[3]
subgenome_keep <- args[4]
variant_keep   <- args[5]
layer_keep     <- args[6]
region_keep    <- args[7]

remove_arg <- ifelse(length(args) >= 8, args[8], "NONE")
drop_regex <- ifelse(length(args) >= 9, args[9], "NONE")

# total_method:
# carrier  : Total = hom_count + het_count, rate = Total / n_called_sites
# additive : Total = load_0.5, rate = load_0.5_per_site
total_method <- ifelse(length(args) >= 10, args[10], "carrier")

if (!total_method %in% c("carrier", "additive")) {
  stop("total_method must be either 'carrier' or 'additive'.")
}

out_dir <- dirname(out_prefix)
dir.create(out_dir, recursive = TRUE, showWarnings = FALSE)

read_tsv <- function(x) {
  read.delim(
    x,
    sep = "\t",
    header = TRUE,
    stringsAsFactors = FALSE,
    check.names = FALSE,
    comment.char = "",
    quote = ""
  )
}

to_num <- function(x) {
  suppressWarnings(as.numeric(gsub(",", "", as.character(x))))
}

find_col <- function(df, candidates, required = TRUE) {
  hit <- candidates[candidates %in% colnames(df)]
  if (length(hit) > 0) return(hit[1])

  if (required) {
    stop("Cannot find required column. Candidates: ", paste(candidates, collapse = ", "))
  }

  return(NA_character_)
}

safe_cor <- function(x, y, method = "pearson") {
  ok <- is.finite(x) & is.finite(y)
  x <- x[ok]
  y <- y[ok]

  if (length(x) < 3 || length(unique(x)) < 2 || length(unique(y)) < 2) {
    return(c(r = NA_real_, p = NA_real_))
  }

  ct <- suppressWarnings(cor.test(x, y, method = method, exact = FALSE))
  return(c(r = unname(ct$estimate), p = ct$p.value))
}

fmt_p <- function(p) {
  ifelse(
    is.na(p),
    "P = NA",
    ifelse(
      p < 2.2e-16,
      "P < 2.2e-16",
      paste0("P = ", formatC(p, format = "e", digits = 2))
    )
  )
}

fmt_r <- function(r) {
  ifelse(is.na(r), "R = NA", paste0("R = ", sprintf("%.2f", r)))
}

label_count <- function(x) {
  format(round(x, 0), big.mark = ",", scientific = FALSE, trim = TRUE)
}

label_rate <- function(x) {
  sprintf("%.3f", x)
}

# -----------------------------
# 1. Read individual heterozygosity
# -----------------------------
het <- read_tsv(hetero_file)

sample_col_het <- find_col(het, c("IID", "sample", "Sample", "ID", "id"))
ho_col <- find_col(het, c("Ho_individual", "Ho", "heterozygosity", "Heterozygosity"))

het2 <- data.frame(
  sample = as.character(het[[sample_col_het]]),
  Ho_individual = to_num(het[[ho_col]]),
  stringsAsFactors = FALSE
)

het2 <- het2[is.finite(het2$Ho_individual), ]
het2 <- het2[!duplicated(het2$sample), ]

# -----------------------------
# 2. Read SIFT burden table
# -----------------------------
sift <- read_tsv(sift_file)

required_cols <- c(
  "sample",
  "subgenome",
  "variant_class",
  "layer",
  "region",
  "n_called_sites",
  "hom_count",
  "het_count"
)

miss <- setdiff(required_cols, colnames(sift))
if (length(miss) > 0) {
  stop("Missing required columns in SIFT table: ", paste(miss, collapse = ", "))
}

sift2 <- sift[
  sift$subgenome == subgenome_keep &
    sift$variant_class == variant_keep &
    sift$layer == layer_keep &
    sift$region == region_keep,
  ,
  drop = FALSE
]

if (nrow(sift2) == 0) {
  stop(
    "No rows left after filtering:\n",
    "subgenome = ", subgenome_keep, "\n",
    "variant_class = ", variant_keep, "\n",
    "layer = ", layer_keep, "\n",
    "region = ", region_keep
  )
}

sift2$sample <- as.character(sift2$sample)
sift2$n_called_sites <- to_num(sift2$n_called_sites)
sift2$hom_count <- to_num(sift2$hom_count)
sift2$het_count <- to_num(sift2$het_count)

if ("load_0.5" %in% colnames(sift2)) {
  sift2$load_0.5 <- to_num(sift2$`load_0.5`)
} else {
  sift2$load_0.5 <- sift2$hom_count + 0.5 * sift2$het_count
}

if ("load_0.5_per_site" %in% colnames(sift2)) {
  sift2$load_0.5_per_site <- to_num(sift2$load_0.5_per_site)
} else {
  sift2$load_0.5_per_site <- sift2$load_0.5 / sift2$n_called_sites
}

# 如果同一样品意外出现重复行，则按样品汇总，避免重复点
agg <- aggregate(
  cbind(n_called_sites, hom_count, het_count, load_0.5) ~ sample,
  data = sift2,
  FUN = sum,
  na.rm = TRUE
)

agg$hom_rate <- agg$hom_count / agg$n_called_sites
agg$het_rate <- agg$het_count / agg$n_called_sites

if (total_method == "carrier") {
  agg$total_count <- agg$hom_count + agg$het_count
  agg$total_rate <- agg$total_count / agg$n_called_sites
  total_label <- "Total carrier"
} else {
  agg$total_count <- agg$load_0.5
  agg$total_rate <- agg$load_0.5 / agg$n_called_sites
  total_label <- "Additive total"
}

# -----------------------------
# 3. Convert to long format
# -----------------------------
make_long <- function(df) {
  rbind(
    data.frame(
      sample = df$sample,
      component = "Total",
      value_count = df$total_count,
      value_rate = df$total_rate,
      n_called_sites = df$n_called_sites,
      stringsAsFactors = FALSE
    ),
    data.frame(
      sample = df$sample,
      component = "Homozygous",
      value_count = df$hom_count,
      value_rate = df$hom_rate,
      n_called_sites = df$n_called_sites,
      stringsAsFactors = FALSE
    ),
    data.frame(
      sample = df$sample,
      component = "Heterozygous",
      value_count = df$het_count,
      value_rate = df$het_rate,
      n_called_sites = df$n_called_sites,
      stringsAsFactors = FALSE
    )
  )
}

dat <- make_long(agg)

dat$component <- factor(
  dat$component,
  levels = c("Total", "Homozygous", "Heterozygous")
)

# -----------------------------
# 4. Merge with Ho
# -----------------------------
dat <- merge(dat, het2, by = "sample", all = FALSE)

if (nrow(dat) == 0) {
  stop("No overlapping samples between heterozygosity file and SIFT burden file.")
}

if (remove_arg != "NONE" && nzchar(remove_arg)) {
  remove_samples <- unlist(strsplit(remove_arg, ","))
  remove_samples <- trimws(remove_samples)
  dat <- dat[!dat$sample %in% remove_samples, , drop = FALSE]
}

if (drop_regex != "NONE" && nzchar(drop_regex)) {
  dat <- dat[!grepl(drop_regex, dat$sample), , drop = FALSE]
}

dat <- dat[
  is.finite(dat$Ho_individual) &
    is.finite(dat$value_count) &
    is.finite(dat$value_rate),
  ,
  drop = FALSE
]

if (nrow(dat) == 0) {
  stop("No valid data points after filtering.")
}

# -----------------------------
# 5. Correlation statistics
# -----------------------------
make_stats <- function(df, ycol, yname) {
  out <- lapply(levels(df$component), function(cl) {
    sub <- df[df$component == cl, , drop = FALSE]

    x <- sub$Ho_individual
    y <- sub[[ycol]]
    ok <- is.finite(x) & is.finite(y)

    pc <- safe_cor(x, y, method = "pearson")
    sp <- safe_cor(x, y, method = "spearman")

    data.frame(
      subgenome = subgenome_keep,
      variant_class = variant_keep,
      layer = layer_keep,
      region = region_keep,
      total_method = total_method,
      y_metric = yname,
      component = cl,
      n = sum(ok),
      pearson_R = pc["r"],
      pearson_P = pc["p"],
      spearman_rho = sp["r"],
      spearman_P = sp["p"],
      stringsAsFactors = FALSE
    )
  })

  do.call(rbind, out)
}

stat_count <- make_stats(dat, "value_count", "count")
stat_rate  <- make_stats(dat, "value_rate", "standardized_rate")

stat_all <- rbind(stat_count, stat_rate)

stat_all$pearson_FDR_BH <- ave(
  stat_all$pearson_P,
  stat_all$y_metric,
  FUN = function(p) p.adjust(p, method = "BH")
)

stat_all$spearman_FDR_BH <- ave(
  stat_all$spearman_P,
  stat_all$y_metric,
  FUN = function(p) p.adjust(p, method = "BH")
)

write.table(
  dat[order(dat$sample, dat$component), ],
  paste0(out_prefix, ".merged_Ho_SIFT.tsv"),
  sep = "\t",
  quote = FALSE,
  row.names = FALSE
)

write.table(
  stat_all,
  paste0(out_prefix, ".correlation_summary.tsv"),
  sep = "\t",
  quote = FALSE,
  row.names = FALSE
)

# -----------------------------
# 6. Plot
# -----------------------------
# SIFT 使用暖色系，区别于 GERP 的蓝色系
cols <- c(
  Total = "#F1CBB8",
  Homozygous = "#A64032",
  Heterozygous = "#E28A42"
)

make_label_df <- function(df, stats_df) {
  xr <- range(df$Ho_individual, finite = TRUE)
  yr <- range(df$Y, finite = TRUE)

  x_span <- diff(xr)
  y_span <- diff(yr)

  x_lab <- xr[1] + 0.045 * x_span

  offset <- c(
    Total = 0.030,
    Homozygous = -0.020,
    Heterozygous = 0.025
  ) * y_span

  labs <- lapply(levels(df$component), function(cl) {
    sub <- df[df$component == cl, , drop = FALSE]
    st <- stats_df[stats_df$component == cl, , drop = FALSE]

    y_lab <- median(sub$Y, na.rm = TRUE)

    ok <- is.finite(sub$Ho_individual) & is.finite(sub$Y)

    if (sum(ok) >= 3 && length(unique(sub$Ho_individual[ok])) >= 2) {
      tmp <- data.frame(
        x = sub$Ho_individual[ok],
        y = sub$Y[ok]
      )

      fit <- lm(y ~ x, data = tmp)
      y_lab <- as.numeric(predict(fit, newdata = data.frame(x = x_lab)))
    }

    y_lab <- y_lab + offset[cl]
    y_lab <- max(min(y_lab, yr[2] - 0.03 * y_span), yr[1] + 0.03 * y_span)

    data.frame(
      component = factor(cl, levels = levels(df$component)),
      x = x_lab,
      y = y_lab,
      label = paste0(
        cl, ": ",
        fmt_r(st$pearson_R[1]),
        "; ",
        fmt_p(st$pearson_P[1])
      ),
      stringsAsFactors = FALSE
    )
  })

  do.call(rbind, labs)
}

plot_one <- function(df, ycol, stats_df, title, ylab, y_label_fun) {
  pd <- df
  pd$Y <- pd[[ycol]]

  lab_df <- make_label_df(pd, stats_df)

  ggplot(
    pd,
    aes(
      x = Ho_individual,
      y = Y,
      color = component
    )
  ) +
    geom_point(size = 1.45, alpha = 0.38) +
    geom_smooth(
      method = "lm",
      formula = y ~ x,
      se = FALSE,
      linewidth = 0.75
    ) +
    geom_text(
      data = lab_df,
      aes(
        x = x,
        y = y,
        label = label,
        color = component
      ),
      inherit.aes = FALSE,
      hjust = 0,
      vjust = 0.5,
      size = 2.55,
      fontface = "bold"
    ) +
    scale_color_manual(
      values = cols,
      breaks = c("Total", "Homozygous", "Heterozygous")
    ) +
    scale_x_continuous(
      expand = expansion(mult = c(0.055, 0.055))
    ) +
    scale_y_continuous(
      labels = y_label_fun,
      expand = expansion(mult = c(0.075, 0.105))
    ) +
    labs(
      title = title,
      x = "Ho_individual",
      y = ylab,
      color = NULL
    ) +
    theme_classic(base_size = 8) +
    theme(
      plot.title = element_text(hjust = 0.5, size = 9, face = "plain"),
      axis.title = element_text(size = 8),
      axis.text = element_text(size = 7, color = "black"),
      axis.line = element_line(linewidth = 0.35, color = "grey35"),
      axis.ticks = element_line(linewidth = 0.3, color = "grey35"),
      panel.grid.major = element_line(linewidth = 0.22, color = "grey92"),
      panel.grid.minor = element_blank(),
      legend.position = "top",
      legend.justification = "center",
      legend.direction = "horizontal",
      legend.key.width = unit(7, "mm"),
      legend.key.height = unit(3, "mm"),
      legend.text = element_text(size = 6.8),
      plot.margin = margin(4, 6, 4, 6)
    )
}

main_title_count <- paste0("SIFT<0.05 counts")
main_title_rate  <- paste0("Standardized SIFT<0.05 load")

p_count <- plot_one(
  dat,
  ycol = "value_count",
  stats_df = stat_count,
  title = main_title_count,
  ylab = "Count",
  y_label_fun = label_count
)

p_rate <- plot_one(
  dat,
  ycol = "value_rate",
  stats_df = stat_rate,
  title = main_title_rate,
  ylab = "Load",
  y_label_fun = label_rate
)

combined <- p_count + p_rate +
  plot_layout(ncol = 2, guides = "collect") +
  plot_annotation(
    tag_levels = list(c("E", "F")),
    subtitle = paste0(
      subgenome_keep,
      " | ",
      variant_keep,
      " | ",
      layer_keep,
      " | ",
      region_keep,
      " | Total = ",
      total_label
    )
  ) &
  theme(
    legend.position = "top",
    legend.justification = "center",
    plot.tag = element_text(size = 10, face = "bold"),
    plot.subtitle = element_text(size = 7, hjust = 0.5, color = "grey35")
  )

ggsave(
  paste0(out_prefix, ".panel_EF.pdf"),
  combined,
  width = 7.6,
  height = 2.55,
  useDingbats = FALSE
)

ggsave(
  paste0(out_prefix, ".panel_EF.png"),
  combined,
  width = 7.6,
  height = 2.55,
  dpi = 600
)

ggsave(
  paste0(out_prefix, ".E_SIFT_count_vs_Ho.pdf"),
  p_count,
  width = 3.8,
  height = 2.35,
  useDingbats = FALSE
)

ggsave(
  paste0(out_prefix, ".F_SIFT_rate_vs_Ho.pdf"),
  p_rate,
  width = 3.8,
  height = 2.35,
  useDingbats = FALSE
)

message("[OK] merged table: ", paste0(out_prefix, ".merged_Ho_SIFT.tsv"))
message("[OK] correlation summary: ", paste0(out_prefix, ".correlation_summary.tsv"))
message("[OK] combined PDF: ", paste0(out_prefix, ".panel_EF.pdf"))
message("[OK] combined PNG: ", paste0(out_prefix, ".panel_EF.png"))
