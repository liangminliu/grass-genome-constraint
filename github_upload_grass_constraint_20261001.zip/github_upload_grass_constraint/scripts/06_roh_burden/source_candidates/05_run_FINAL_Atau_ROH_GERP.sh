#!/usr/bin/env bash
set -euo pipefail

BASE_DIR="/gpfs/hpc/home/kib_unit/lidezhu/liuliangmin/6.pop/05.FROH"
cd "${BASE_DIR}"

FINAL_DIR="Atau_GERP_ROH_FINAL_kb100"
SCRIPT_DIR="${FINAL_DIR}/scripts"
LOG_DIR="${FINAL_DIR}/logs"

ROH_DIR="ROH_pipeline/Atau/04_froh/plink_kb100_gap1000_winmiss5_noBW01192"

FROH_FILE="${ROH_DIR}/FROH.final.plink.kb100_gap1000_winmiss5_noBW01192.tsv"
ROH_SEG_FILE="${ROH_DIR}/ROH.segments.plink.ge100000.minSNP50.kb100_gap1000_winmiss5_noBW01192.classified.tsv"
LAUTO_FILE="ROH_pipeline/Atau/04_froh/Lauto.from_filtered_SNPs.tsv"

GERP4_VCF="Atau_merged_gt4_snps.vcf.gz"
GERPNEG_VCF="Atau_merged_lt0_snps.vcf.gz"

ROH_TABLE_PREFIX="${FINAL_DIR}/01_ROH_tables/Atau_ROH_FROH_kb100_gap1000_winmiss5_noBW01192"
ROH_PLOT_PREFIX="${FINAL_DIR}/02_ROH_FROH/Atau_ROH_FROH_kb100_gap1000_winmiss5_noBW01192"

GERP_TABLE_PREFIX="${FINAL_DIR}/03_GERP_tables/Atau_GERP_kb100_gap1000_winmiss5_noBW01192"
GERP_PLOT_PREFIX="${FINAL_DIR}/04_GERP/Atau_GERP_kb100_gap1000_winmiss5_noBW01192"

EXCLUDE_SAMPLES="BW_01192"
SPECIES_LABEL="Aegilops tauschii"

mkdir -p \
  "${LOG_DIR}" \
  "${FINAL_DIR}/01_ROH_tables" \
  "${FINAL_DIR}/02_ROH_FROH" \
  "${FINAL_DIR}/03_GERP_tables" \
  "${FINAL_DIR}/04_GERP"

require_file() {
  if [[ ! -s "$1" ]]; then
    echo "[ERROR] Missing or empty file: $1" >&2
    exit 1
  fi
}

require_cmd() {
  command -v "$1" >/dev/null 2>&1 || {
    echo "[ERROR] Missing command: $1" >&2
    exit 1
  }
}

for x in python3 Rscript bcftools; do
  require_cmd "$x"
done

for f in \
  "${FROH_FILE}" \
  "${ROH_SEG_FILE}" \
  "${LAUTO_FILE}" \
  "${GERP4_VCF}" \
  "${GERPNEG_VCF}" \
  "${SCRIPT_DIR}/01_prepare_ROH_FROH_tables.py" \
  "${SCRIPT_DIR}/02_plot_ROH_FROH_final.R" \
  "${SCRIPT_DIR}/03_calc_GERP_burden_ROH.py" \
  "${SCRIPT_DIR}/04_plot_GERP_final.R"
do
  require_file "$f"
done

echo "============================================================"
echo "[INFO] Final Atau kb100 ROH/FROH + GERP pipeline"
echo "[INFO] FROH_FILE         = ${FROH_FILE}"
echo "[INFO] ROH_SEG_FILE      = ${ROH_SEG_FILE}"
echo "[INFO] LAUTO_FILE        = ${LAUTO_FILE}"
echo "[INFO] GERP4_VCF         = ${GERP4_VCF}"
echo "[INFO] GERPNEG_VCF       = ${GERPNEG_VCF}"
echo "[INFO] ROH_TABLE_PREFIX  = ${ROH_TABLE_PREFIX}"
echo "[INFO] ROH_PLOT_PREFIX   = ${ROH_PLOT_PREFIX}"
echo "[INFO] GERP_TABLE_PREFIX = ${GERP_TABLE_PREFIX}"
echo "[INFO] GERP_PLOT_PREFIX  = ${GERP_PLOT_PREFIX}"
echo "============================================================"

for vcf in "${GERP4_VCF}" "${GERPNEG_VCF}"; do
  if [[ ! -s "${vcf}.csi" && ! -s "${vcf}.tbi" ]]; then
    echo "[INFO] Indexing ${vcf}..."
    bcftools index -f --csi "${vcf}"
  fi
done

echo "[STEP 1] Prepare ROH/FROH plot tables"

python3 "${SCRIPT_DIR}/01_prepare_ROH_FROH_tables.py" \
  --froh "${FROH_FILE}" \
  --roh "${ROH_SEG_FILE}" \
  --lauto "${LAUTO_FILE}" \
  --out-prefix "${ROH_TABLE_PREFIX}" \
  --exclude-samples "${EXCLUDE_SAMPLES}" \
  --min-roh-bp 100000 \
  --long-roh-bp 1000000 \
  --window-bp 5000000

echo "[CHECK] ROH/FROH table summary:"
cat "${ROH_TABLE_PREFIX}.summary.txt"

N_UNIQ=$(awk -F'\t' '$1=="n_unique_window_frequencies"{print $2}' "${ROH_TABLE_PREFIX}.summary.txt")
if [[ "${N_UNIQ}" -le 1 ]]; then
  echo "[ERROR] D plot frequency has only one unique value. Check ROH/window calculation." >&2
  exit 1
fi

echo "[STEP 2] Plot ROH/FROH final figure"

Rscript "${SCRIPT_DIR}/02_plot_ROH_FROH_final.R" \
  "${ROH_TABLE_PREFIX}" \
  "${ROH_PLOT_PREFIX}" \
  "${SPECIES_LABEL}"

echo "[STEP 3] Calculate GERP burden using kb100 ROH"

python3 "${SCRIPT_DIR}/03_calc_GERP_burden_ROH.py" \
  --gerp4-vcf "${GERP4_VCF}" \
  --gerpneg-vcf "${GERPNEG_VCF}" \
  --froh "${FROH_FILE}" \
  --roh "${ROH_SEG_FILE}" \
  --lauto "${LAUTO_FILE}" \
  --out-prefix "${GERP_TABLE_PREFIX}" \
  --exclude-samples "${EXCLUDE_SAMPLES}" \
  --ploidy 2

echo "[STEP 4] Plot GERP final figure"

Rscript "${SCRIPT_DIR}/04_plot_GERP_final.R" \
  "${GERP_TABLE_PREFIX}" \
  "${GERP_PLOT_PREFIX}" \
  "${EXCLUDE_SAMPLES}" \
  0.025

echo "[DONE] Final outputs:"
echo "ROH/FROH:"
echo "  ${ROH_PLOT_PREFIX}.00_main_ROH_FROH_final_combined.pdf"
echo "GERP:"
echo "  ${GERP_PLOT_PREFIX}.00_main_GERP_final_combined.pdf"
echo "  ${GERP_PLOT_PREFIX}.00_main_GERP_final_compact.pdf"