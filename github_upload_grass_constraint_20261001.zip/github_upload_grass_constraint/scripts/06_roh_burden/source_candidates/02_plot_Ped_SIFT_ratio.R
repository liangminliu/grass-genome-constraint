#!/usr/bin/env Rscript

suppressPackageStartupMessages({
  pkgs <- c("ggplot2", "patchwork", "scales")
  miss <- pkgs[!vapply(pkgs, requireNamespace, logical(1), quietly = TRUE)]
  if (length(miss) > 0) {
    stop("Missing R packages: ", paste(miss, collapse = ", "))
  }

  library(ggplot2)
  library(patchwork)
  library(scales)
})

args <- commandArgs(trailingOnly = TRUE)

if (length(args) < 2) {
  stop("Usage: Rscript 02_plot_Ped_SIFT_ratio.R <RESULT_DIR> <PREFIX> [exclude_samples|none] [sift_cutoff] [species_label]\n")
}

RESULT_DIR <- args[1]
PREFIX <- args[2]
EXCLUDE_RAW <- ifelse(length(args) >= 3, args[3], "none")
SIFT_CUTOFF <- ifelse(length(args) >= 4, as.numeric(args[4]), 0.05)
SPECIES_LABEL <- ifelse(length(args) >= 5, args[5], PREFIX)

if (is.na(SIFT_CUTOFF)) SIFT_CUTOFF <- 0.05
if (!dir.exists(RESULT_DIR)) stop("[ERROR] RESULT_DIR does not exist: ", RESULT_DIR)

EXCLUDE_SAMPLES <- character(0)
if (!tolower(EXCLUDE_RAW) %in% c("none", "null", "na", "")) {
  EXCLUDE_SAMPLES <- unlist(strsplit(EXCLUDE_RAW, "[,; ]+"))
  EXCLUDE_SAMPLES <- EXCLUDE_SAMPLES[EXCLUDE_SAMPLES != ""]
}

FILE_SITE_AF <- file.path(RESULT_DIR, paste0(PREFIX, ".site_AF.tsv"))
FILE_RATIO <- file.path(RESULT_DIR, paste0(PREFIX, ".ratio_metrics.tsv"))
FILE_FIG2_LONG <- file.path(RESULT_DIR, paste0(PREFIX, ".Fig2_hom_het_counts.long.tsv"))
FILE_FIG2B_LONG <- file.path(RESULT_DIR, paste0(PREFIX, ".Fig2b_FROH_deleterious_counts.long.tsv"))
FILE_FIG2C_LONG <- file.path(RESULT_DIR, paste0(PREFIX, ".Fig2c_FROH_deleterious_load.long.tsv"))

read_tsv <- function(file) {
  if (!file.exists(file)) stop("[ERROR] Missing file: ", file)
  if (requireNamespace("data.table", quietly = TRUE)) {
    df <- data.table::fread(file, sep = "\t", header = TRUE, data.table = FALSE, quote = "", showProgress = FALSE)
  } else {
    df <- read.delim(file, header = TRUE, sep = "\t", quote = "", comment.char = "", check.names = FALSE, stringsAsFactors = FALSE)
  }
  names(df) <- trimws(names(df))
  df
}

need_cols <- function(df, cols, label) {
  miss <- setdiff(cols, names(df))
  if (length(miss) > 0) stop("[ERROR] Missing columns in ", label, ": ", paste(miss, collapse = ", "))
}

as_num <- function(x) {
  if (is.numeric(x)) return(as.numeric(x))
  x <- as.character(x)
  x <- gsub(",", "", x)
  x <- gsub("%", "", x)
  suppressWarnings(as.numeric(x))
}

fmt_p <- function(p) {
  if (!is.finite(p)) return("p = NA")
  if (p < 0.001) return("p < 0.001")
  paste0("p = ", formatC(p, format = "f", digits = 3))
}

lm_p <- function(x, y) {
  ok <- is.finite(x) & is.finite(y)
  if (sum(ok) < 4) return(NA_real_)
  if (length(unique(x[ok])) < 2 || length(unique(y[ok])) < 2) return(NA_real_)
  fit <- tryCatch(lm(y[ok] ~ x[ok]), error = function(e) NULL)
  if (is.null(fit)) return(NA_real_)
  ss <- summary(fit)
  if (nrow(coef(ss)) < 2) return(NA_real_)
  coef(ss)[2, 4]
}

nice_y_top <- function(x) {
  if (!is.finite(x) || x <= 0) return(1)
  if (x <= 1) return(ceiling(x * 10) / 10)
  if (x <= 10) return(ceiling(x))
  if (x <= 100) return(ceiling(x / 5) * 5)
  if (x <= 1000) return(ceiling(x / 50) * 50)
  if (x <= 10000) return(ceiling(x / 500) * 500)
  ceiling(x / 1000) * 1000
}

theme_pub <- function(base_size = 12) {
  theme_classic(base_size = base_size) +
    theme(
      axis.text = element_text(color = "black"),
      axis.title = element_text(color = "black"),
      axis.line = element_line(linewidth = 0.45, color = "grey35"),
      axis.ticks = element_line(linewidth = 0.35, color = "grey35"),
      panel.grid.major.y = element_line(linewidth = 0.25, color = "grey90"),
      panel.grid.major.x = element_blank(),
      panel.grid.minor = element_blank(),
      plot.title = element_text(hjust = 0.5, face = "plain", size = base_size + 1),
      legend.title = element_blank(),
      legend.background = element_rect(fill = scales::alpha("white", 0.85), color = NA)
    )
}

empty_plot <- function(msg) {
  ggplot() + annotate("text", x = 0.5, y = 0.5, label = msg, size = 4) + theme_void()
}

save_pdf_png <- function(plot, stem, width, height) {
  pdf_file <- file.path(RESULT_DIR, paste0(PREFIX, ".", stem, ".pdf"))
  png_file <- file.path(RESULT_DIR, paste0(PREFIX, ".", stem, ".png"))
  pdf_dev <- if (capabilities("cairo")) grDevices::cairo_pdf else grDevices::pdf
  ggsave(pdf_file, plot = plot, width = width, height = height, units = "in", device = pdf_dev)
  ggsave(png_file, plot = plot, width = width, height = height, units = "in", dpi = 600)
  message("[WRITE] ", pdf_file)
  message("[WRITE] ", png_file)
}

filter_exclude <- function(df) {
  if ("sample" %in% names(df) && length(EXCLUDE_SAMPLES) > 0) {
    df <- df[!as.character(df$sample) %in% EXCLUDE_SAMPLES, , drop = FALSE]
  }
  df
}

COL_SYN <- "#D9D9D9"
COL_TOL <- "#D7E8F3"
COL_DEL <- "#5B8DB8"
COL_TOTAL <- "#DDECF7"
COL_HOM <- "#5B8DB8"
COL_HET <- "#D7E8F3"
COL_NONROH <- "#8172B3"
COL_ROH <- "#E6A547"

make_af_summary <- function(df, classes, binwidth = 0.05) {
  df <- df[df$class_plot %in% classes, , drop = FALSE]
  if (nrow(df) == 0) stop("[ERROR] No AF records after class filtering.")
  n_bins <- round(1 / binwidth)
  df$bin_i <- floor(df$AF / binwidth + 1e-10)
  df$bin_i[df$AF >= 1] <- n_bins - 1
  df$bin_i <- pmax(0, pmin(df$bin_i, n_bins - 1))
  tab <- aggregate(list(n = rep(1, nrow(df))), by = list(class_plot = df$class_plot, bin_i = df$bin_i), FUN = sum)
  tab$percentage <- ave(tab$n, tab$class_plot, FUN = function(z) 100 * z / sum(z))
  grid <- expand.grid(class_plot = factor(classes, levels = classes), bin_i = 0:(n_bins - 1))
  out <- merge(grid, tab[, c("class_plot", "bin_i", "percentage")], by = c("class_plot", "bin_i"), all.x = TRUE, sort = FALSE)
  out$percentage[is.na(out$percentage)] <- 0
  out$class_plot <- factor(out$class_plot, levels = classes)
  out$bin_left <- out$bin_i * binwidth
  out$class_id <- as.numeric(out$class_plot) - 1
  k <- length(classes)
  out$xmin <- out$bin_left + out$class_id * binwidth / k
  out$xmax <- out$bin_left + (out$class_id + 1) * binwidth / k
  out
}

plot_af_nogap <- function(df, classes, fill_cols, title, binwidth = 0.05) {
  dat <- make_af_summary(df, classes, binwidth)
  y_max <- max(dat$percentage, na.rm = TRUE)
  y_top <- nice_y_top(y_max)
  if (y_top <= y_max) y_top <- y_top + 5
  y_bottom <- -0.035 * y_top

  ggplot(dat) +
    geom_rect(aes(xmin = xmin, xmax = xmax, ymin = 0, ymax = percentage, fill = class_plot), colour = NA, linewidth = 0) +
    scale_fill_manual(values = fill_cols, drop = FALSE) +
    scale_x_continuous(breaks = seq(0, 1, 0.25), limits = c(-binwidth * 0.45, 1), expand = c(0, 0)) +
    scale_y_continuous(breaks = pretty(c(0, y_top), n = 4), limits = c(y_bottom, y_top), expand = c(0, 0)) +
    labs(title = title, x = "ALT allele frequency", y = "Percentage of SNPs") +
    theme_pub(12) +
    theme(
      plot.title = element_text(hjust = 0.5, face = "plain", size = 13, margin = margin(b = 4)),
      legend.position = c(0.96, 0.96),
      legend.justification = c(1, 1),
      legend.direction = "horizontal",
      legend.key.size = grid::unit(0.35, "cm"),
      legend.text = element_text(size = 9),
      plot.margin = margin(8, 8, 6, 8)
    )
}

site_af <- tryCatch({
  df <- read_tsv(FILE_SITE_AF)
  need_cols(df, c("AF", "class_label"), "site_AF.tsv")
  df$AF <- as_num(df$AF)
  df <- df[is.finite(df$AF), , drop = FALSE]
  df$AF <- pmax(0, pmin(df$AF, 1))
  df$class_plot <- NA_character_
  df$class_plot[df$class_label == "Synonymous"] <- "Synonymous"
  df$class_plot[df$class_label == "Tolerated nonsynonymous"] <- "Tolerated\nnonsynonymous"
  df$class_plot[df$class_label == "Deleterious nonsynonymous"] <- "Deleterious\nnonsynonymous"
  df <- df[!is.na(df$class_plot), , drop = FALSE]
  df
}, error = function(e) {
  message("[WARN] Fig1 input failed: ", e$message)
  NULL
})

if (!is.null(site_af) && nrow(site_af) > 0) {
  pA <- plot_af_nogap(
    site_af,
    classes = c("Tolerated\nnonsynonymous", "Deleterious\nnonsynonymous"),
    fill_cols = c("Tolerated\nnonsynonymous" = COL_TOL, "Deleterious\nnonsynonymous" = COL_DEL),
    title = paste0(SPECIES_LABEL, ": deleterious vs tolerated"),
    binwidth = 0.05
  )
  pA3 <- plot_af_nogap(
    site_af,
    classes = c("Synonymous", "Tolerated\nnonsynonymous", "Deleterious\nnonsynonymous"),
    fill_cols = c("Synonymous" = COL_SYN, "Tolerated\nnonsynonymous" = COL_TOL, "Deleterious\nnonsynonymous" = COL_DEL),
    title = paste0(SPECIES_LABEL, ": synonymous, tolerated and deleterious"),
    binwidth = 0.05
  )
} else {
  pA <- empty_plot("AF spectrum data not available")
  pA3 <- empty_plot("AF spectrum data not available")
}

save_pdf_png(pA, "Fig1_AF_spectrum", width = 6.2, height = 4.2)
save_pdf_png(pA3, "Fig1_AF_spectrum_3class_supp", width = 6.8, height = 4.2)

plot_hist_component <- function(df, component_name, fill_col, title_label) {
  x <- df$n_loci[df$component == component_name]
  x <- x[is.finite(x)]
  if (length(x) == 0) return(empty_plot(paste0(component_name, " data not available")))
  med <- median(x, na.rm = TRUE)
  zero_n <- sum(x == 0, na.rm = TRUE)
  n_all <- length(x)
  bw <- diff(range(x, na.rm = TRUE)) / 25
  if (!is.finite(bw) || bw <= 0) bw <- 1
  xmax <- max(x, na.rm = TRUE)

  ggplot(data.frame(n_loci = x), aes(x = n_loci)) +
    geom_histogram(binwidth = bw, boundary = 0, closed = "left", fill = fill_col, color = "grey40", linewidth = 0.35) +
    geom_vline(xintercept = med, linetype = "dashed", linewidth = 0.60, color = fill_col) +
    annotate("text", x = Inf, y = Inf, label = paste0("median = ", format(round(med), big.mark = ","), "\nzero = ", zero_n, "/", n_all),
             hjust = 1.05, vjust = 1.2, size = 3.5) +
    scale_x_continuous(labels = comma, breaks = pretty(c(0, xmax), n = 4), expand = expansion(mult = c(0.02, 0.05))) +
    scale_y_continuous(breaks = pretty_breaks(n = 5), expand = expansion(mult = c(0.02, 0.08))) +
    labs(title = title_label, x = paste0("Number of deleterious loci (SIFT <= ", SIFT_CUTOFF, ")"), y = "Number of individuals") +
    theme_pub(12) +
    theme(plot.title = element_text(size = 15, face = "bold", hjust = 0.5),
          axis.title.x = element_text(size = 10),
          axis.title.y = element_text(size = 11),
          panel.grid.major.x = element_blank())
}

fig2_df <- tryCatch({
  df <- read_tsv(FILE_FIG2_LONG)
  need_cols(df, c("sample", "FROH", "component", "n_loci"), "Fig2_hom_het_counts.long.tsv")
  df <- filter_exclude(df)
  df$FROH <- as_num(df$FROH)
  df$n_loci <- as_num(df$n_loci)
  df <- df[df$component %in% c("Homozygotes", "Heterozygotes") & is.finite(df$n_loci), , drop = FALSE]
  df
}, error = function(e) {
  message("[WARN] Fig2 input failed: ", e$message)
  NULL
})

if (!is.null(fig2_df) && nrow(fig2_df) > 0) {
  pB_het <- plot_hist_component(fig2_df, "Heterozygotes", COL_HET, "Heterozygotes")
  pC_hom <- plot_hist_component(fig2_df, "Homozygotes", COL_HOM, "Homozygotes")
  pBC <- pB_het + pC_hom + plot_layout(ncol = 2)
} else {
  pB_het <- empty_plot("Heterozygote count data not available")
  pC_hom <- empty_plot("Homozygote count data not available")
  pBC <- empty_plot("Fig2 hom/het count data not available")
}

save_pdf_png(pBC, "Fig2_hom_het_counts", width = 7.2, height = 3.4)

load_component_long <- function(file, label) {
  df <- read_tsv(file)
  need_cols(df, c("sample", "FROH", "component", "value"), label)
  df <- filter_exclude(df)
  df$FROH <- as_num(df$FROH)
  df$value <- as_num(df$value)
  df$component <- as.character(df$component)
  df <- df[df$component %in% c("Total", "Homozygous", "Heterozygous"), , drop = FALSE]
  df <- df[is.finite(df$FROH) & is.finite(df$value), , drop = FALSE]
  df$component <- factor(df$component, levels = c("Total", "Homozygous", "Heterozygous"))
  df
}

plot_froh_scatter <- function(df, title, ylab) {
  cols <- c("Total" = COL_TOTAL, "Homozygous" = COL_HOM, "Heterozygous" = COL_HET)

  labs_df <- do.call(rbind, lapply(levels(df$component), function(cl) {
    z <- df[df$component == cl, , drop = FALSE]
    data.frame(component = cl, p_label = paste0(cl, ": ", fmt_p(lm_p(z$FROH, z$value))), stringsAsFactors = FALSE)
  }))

  xr <- range(df$FROH, na.rm = TRUE)
  yr <- range(df$value, na.rm = TRUE)
  if (!is.finite(diff(xr)) || diff(xr) == 0) xr <- xr + c(-0.01, 0.01)
  if (!is.finite(diff(yr)) || diff(yr) == 0) yr <- yr + c(-1, 1)

  labs_df$x <- xr[1] + 0.02 * diff(xr)
  labs_df$y <- yr[2] - seq(0.05, 0.17, length.out = nrow(labs_df)) * diff(yr)
  labs_df$component <- factor(labs_df$component, levels = levels(df$component))

  ggplot(df, aes(x = FROH, y = value, color = component, fill = component)) +
    geom_point(alpha = 0.75, size = 1.8) +
    geom_smooth(method = "lm", se = FALSE, linewidth = 0.7) +
    geom_text(data = labs_df, aes(x = x, y = y, label = p_label, color = component),
              inherit.aes = FALSE, hjust = 0, size = 3.4, fontface = "bold") +
    scale_color_manual(values = cols, drop = FALSE) +
    scale_fill_manual(values = cols, drop = FALSE) +
    labs(title = title, x = expression(F[ROH]), y = ylab) +
    theme_pub(12) +
    theme(legend.position = "top", plot.title = element_text(face = "plain", size = 12))
}

fig2b_df <- tryCatch(load_component_long(FILE_FIG2B_LONG, "Fig2b"), error = function(e) NULL)
fig2c_df <- tryCatch(load_component_long(FILE_FIG2C_LONG, "Fig2c"), error = function(e) NULL)

pD <- if (!is.null(fig2b_df) && nrow(fig2b_df) > 0) plot_froh_scatter(fig2b_df, "SIFT deleterious counts", "Count") else empty_plot("FROH deleterious count data not available")
pE <- if (!is.null(fig2c_df) && nrow(fig2c_df) > 0) plot_froh_scatter(fig2c_df, "Standardized deleterious load", "Load") else empty_plot("FROH deleterious load data not available")

save_pdf_png(pD, "Fig2b_FROH_deleterious_counts", width = 5.8, height = 4.2)
save_pdf_png(pE, "Fig2c_FROH_deleterious_load", width = 5.8, height = 4.2)

ratio_df <- tryCatch({
  df <- read_tsv(FILE_RATIO)
  need_cols(df, c("sample", "FROH", "ratio_type", "component", "region", "ratio"), "ratio_metrics.tsv")
  df <- filter_exclude(df)
  df$FROH <- as_num(df$FROH)
  df$ratio <- as_num(df$ratio)
  df$sample <- as.character(df$sample)
  df$ratio_type <- as.character(df$ratio_type)
  df$component <- as.character(df$component)
  df$region <- as.character(df$region)
  df <- df[df$ratio_type %in% c("Deleterious/Synonymous", "Tolerated/Synonymous"), , drop = FALSE]
  df <- df[is.finite(df$FROH) & is.finite(df$ratio), , drop = FALSE]
  df$ratio_type <- factor(df$ratio_type, levels = c("Deleterious/Synonymous", "Tolerated/Synonymous"))
  df$component <- factor(df$component, levels = c("Heterozygotes", "Homozygotes", "ALT alleles"))
  df$region <- factor(df$region, levels = c("ALL", "Non-ROH", "ROH"))
  df
}, error = function(e) NULL)

plot_ratio_froh <- function(df, ratio_name) {
  z <- df[df$ratio_type == ratio_name & df$region == "ALL" & df$component %in% c("Heterozygotes", "Homozygotes"), , drop = FALSE]
  if (nrow(z) == 0) return(empty_plot(paste0(ratio_name, " data not available")))

  cols <- c("Heterozygotes" = COL_HET, "Homozygotes" = COL_HOM)
  comps <- c("Heterozygotes", "Homozygotes")

  labs_df <- do.call(rbind, lapply(comps, function(cl) {
    zz <- z[z$component == cl, , drop = FALSE]
    data.frame(component = cl, p_label = fmt_p(lm_p(zz$FROH, zz$ratio)), stringsAsFactors = FALSE)
  }))

  xr <- range(z$FROH, na.rm = TRUE)
  yr <- range(z$ratio, na.rm = TRUE)
  if (!is.finite(diff(xr)) || diff(xr) == 0) xr <- xr + c(-0.01, 0.01)
  if (!is.finite(diff(yr)) || diff(yr) == 0) yr <- yr + c(-1, 1)

  labs_df$x <- xr[1] + 0.02 * diff(xr)
  labs_df$y <- yr[2] - seq(0.10, 0.20, length.out = nrow(labs_df)) * diff(yr)
  labs_df$component <- factor(labs_df$component, levels = comps)

  ggplot(z, aes(x = FROH, y = ratio, color = component)) +
    geom_point(alpha = 0.75, size = 1.8) +
    geom_smooth(method = "lm", se = FALSE, linewidth = 0.7, linetype = "dashed") +
    geom_text(data = labs_df, aes(x = x, y = y, label = p_label, color = component),
              inherit.aes = FALSE, hjust = 0, size = 3.4, fontface = "bold") +
    scale_color_manual(values = cols, drop = FALSE) +
    labs(title = ratio_name, x = expression(F[ROH]), y = "Nonsynonymous / synonymous ratio") +
    theme_pub(12) +
    theme(legend.position = "top", plot.title = element_text(face = "bold", size = 12))
}

plot_inside_outside_roh <- function(df) {
  z <- df[df$region %in% c("ROH", "Non-ROH") & df$component == "Homozygotes", , drop = FALSE]
  if (nrow(z) == 0) return(empty_plot("Inside/outside ROH data not available"))
  z$region <- factor(as.character(z$region), levels = c("Non-ROH", "ROH"))

  ggplot(z, aes(x = FROH, y = ratio, color = region)) +
    geom_point(alpha = 0.75, size = 1.7) +
    geom_smooth(method = "lm", se = FALSE, linewidth = 0.7, linetype = "dashed") +
    facet_wrap(~ ratio_type, nrow = 1, scales = "free_y") +
    scale_color_manual(values = c("Non-ROH" = COL_NONROH, "ROH" = COL_ROH), drop = FALSE) +
    labs(title = "Homozygous nonsynonymous/synonymous ratios",
         x = expression(F[ROH]), y = "Nonsynonymous / synonymous ratio") +
    theme_pub(12) +
    theme(legend.position = "top", strip.background = element_blank(),
          strip.text = element_text(face = "bold", size = 12),
          plot.title = element_text(face = "bold", size = 13))
}

if (!is.null(ratio_df) && nrow(ratio_df) > 0) {
  pF <- plot_ratio_froh(ratio_df, "Deleterious/Synonymous")
  pG <- plot_ratio_froh(ratio_df, "Tolerated/Synonymous")
  pH <- plot_inside_outside_roh(ratio_df)
} else {
  pF <- empty_plot("Deleterious/Synonymous data not available")
  pG <- empty_plot("Tolerated/Synonymous data not available")
  pH <- empty_plot("Inside/outside ROH data not available")
}

pFG <- pF + pG + plot_layout(ncol = 2, guides = "collect") & theme(legend.position = "top")
save_pdf_png(pFG, "Fig3_FROH_burden", width = 8.2, height = 3.8)
save_pdf_png(pFG, "Fig3_FROH_burden_ratio", width = 8.2, height = 3.8)
save_pdf_png(pH, "Fig4_inside_outside_ROH", width = 8.2, height = 3.8)

p_multi1 <- (pA | pB_het | pC_hom) /
  (pD | pE | plot_spacer()) +
  plot_layout(heights = c(1.0, 1.05)) +
  plot_annotation(tag_levels = "A") &
  theme(plot.tag = element_text(face = "bold", size = 13),
        plot.tag.position = c(0.01, 0.98))

save_pdf_png(p_multi1, "SIFT_deleterious_FROH_multipanel", width = 13.5, height = 8.8)

p_multi2 <- (pA | pB_het | pC_hom) /
  (pD | pE | plot_spacer()) /
  (pF | pG | pH) +
  plot_layout(heights = c(1.0, 1.05, 1.05)) +
  plot_annotation(tag_levels = "A") &
  theme(plot.tag = element_text(face = "bold", size = 13),
        plot.tag.position = c(0.01, 0.98))

save_pdf_png(p_multi2, "SIFT_ratio_multipanel", width = 15.0, height = 12.5)

message("[DONE] All figures regenerated and overwritten in: ", RESULT_DIR)
