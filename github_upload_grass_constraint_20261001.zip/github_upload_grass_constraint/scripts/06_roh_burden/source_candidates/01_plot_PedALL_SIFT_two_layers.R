#!/usr/bin/env Rscript

suppressPackageStartupMessages({
  library(ggplot2)
  library(dplyr)
  library(tidyr)
  library(readr)
  library(patchwork)
  library(scales)
})

args <- commandArgs(trailingOnly = TRUE)

if (length(args) < 3) {
  stop("Usage: Rscript 01_plot_PedALL_SIFT_two_layers.R <per_sample.tsv> <site_AF.tsv.gz> <outroot>")
}

per_sample_file <- args[1]
site_af_file    <- args[2]
outroot         <- args[3]

dir.create(outroot, recursive = TRUE, showWarnings = FALSE)

sample_raw <- read_tsv(per_sample_file, show_col_types = FALSE)
site_raw   <- read_tsv(site_af_file, show_col_types = FALSE)

num_sample_cols <- c(
  "n_called_sites", "called_alleles", "allele_count",
  "hom_count", "het_count", "partial_count", "zero_count",
  "allele_rate", "hom_loci_rate", "het_loci_rate",
  "load_0.5", "load_0.5_per_site", "FROH"
)

for (x in intersect(num_sample_cols, colnames(sample_raw))) {
  sample_raw[[x]] <- suppressWarnings(as.numeric(sample_raw[[x]]))
}

num_site_cols <- c(
  "n_called_samples", "called_alleles", "allele_count",
  "hom_count", "het_count", "partial_count", "zero_count",
  "allele_rate", "hom_loci_rate", "het_loci_rate"
)

for (x in intersect(num_site_cols, colnames(site_raw))) {
  site_raw[[x]] <- suppressWarnings(as.numeric(site_raw[[x]]))
}

###############################################################################
# Data
###############################################################################

sample_all <- sample_raw %>%
  filter(subgenome == "PedALL") %>%
  mutate(
    load_0.5_per_site = ifelse(
      is.na(load_0.5_per_site) & !is.na(load_0.5) & n_called_sites > 0,
      load_0.5 / n_called_sites,
      load_0.5_per_site
    )
  )

site_all <- site_raw %>%
  filter(subgenome %in% c("PedC", "PedD"))

###############################################################################
# Style
###############################################################################

class_levels <- c("SIFT_synonymous", "SIFT_tolerated", "SIFT_lt0.05")

class_labels <- c(
  "SIFT_synonymous" = "Synonymous",
  "SIFT_tolerated" = "Tolerated\nnonsynonymous",
  "SIFT_lt0.05" = "Deleterious\nnonsynonymous"
)

class_cols <- c(
  "SIFT_synonymous" = "#D9D9D9",
  "SIFT_tolerated" = "#DCEAF5",
  "SIFT_lt0.05" = "#5C8DBC"
)

component_levels <- c("Total", "Homozygous", "Heterozygous")

component_cols <- c(
  "Total" = "#DCEAF5",
  "Homozygous" = "#8DB8DD",
  "Heterozygous" = "#5C8DBC"
)

ratio_component_levels <- c("Heterozygous", "Homozygous")

ratio_component_cols <- c(
  "Heterozygous" = "#5C8DBC",
  "Homozygous" = "#D97A70"
)

region_cols <- c(
  "Non-ROH" = "#7A6BAE",
  "ROH" = "#E3A143"
)

theme_ref <- function(base_size = 11) {
  theme_classic(base_size = base_size) +
    theme(
      axis.text = element_text(color = "black"),
      axis.title = element_text(color = "black"),
      plot.title = element_text(face = "bold", size = base_size + 1),
      legend.title = element_blank(),
      legend.position = "top",
      legend.key.size = unit(0.45, "cm"),
      legend.text = element_text(size = base_size - 1),
      panel.grid.major.y = element_line(color = "grey92", linewidth = 0.35),
      panel.grid.major.x = element_blank(),
      panel.grid.minor = element_blank(),
      strip.background = element_blank(),
      strip.text = element_text(face = "bold"),
      plot.margin = margin(5.5, 7, 5.5, 5.5)
    )
}

###############################################################################
# Helpers
###############################################################################

safe_ratio <- function(a, b) {
  ifelse(!is.na(a) & !is.na(b) & b > 0, a / b, NA_real_)
}

fmt_p <- function(p) {
  ifelse(
    is.na(p), "p = NA",
    ifelse(p < 0.001, "p < 0.001", paste0("p = ", signif(p, 2)))
  )
}

get_lm_p <- function(df, xcol, ycol) {
  d <- df %>%
    filter(!is.na(.data[[xcol]]), !is.na(.data[[ycol]]))

  if (nrow(d) < 4) return(NA_real_)
  if (length(unique(d[[xcol]])) < 3) return(NA_real_)

  fit <- try(lm(d[[ycol]] ~ d[[xcol]]), silent = TRUE)
  if (inherits(fit, "try-error")) return(NA_real_)

  summary(fit)$coefficients[2, 4]
}

make_p_labels <- function(df, xcol, ycol, group_col) {
  empty_out <- tibble(
    group = character(),
    x = numeric(),
    y = numeric(),
    label = character()
  )

  if (!all(c(xcol, ycol, group_col) %in% colnames(df))) {
    return(empty_out)
  }

  d <- df %>%
    filter(
      !is.na(.data[[xcol]]),
      !is.na(.data[[ycol]]),
      !is.na(.data[[group_col]])
    )

  if (nrow(d) == 0) {
    return(empty_out)
  }

  groups <- unique(d[[group_col]])

  yr <- range(d[[ycol]], na.rm = TRUE)
  xr <- range(d[[xcol]], na.rm = TRUE)

  if (!all(is.finite(yr)) || !all(is.finite(xr))) {
    return(empty_out)
  }

  y_span <- diff(yr)
  if (!is.finite(y_span) || y_span == 0) y_span <- 1

  x_span <- diff(xr)
  if (!is.finite(x_span) || x_span == 0) x_span <- 1

  x_pos <- xr[1] + 0.02 * x_span

  bind_rows(lapply(seq_along(groups), function(i) {
    g <- groups[i]
    sub <- d[d[[group_col]] == g, , drop = FALSE]
    p <- get_lm_p(sub, xcol, ycol)

    tibble(
      group = as.character(g),
      x = x_pos,
      y = yr[2] - (i - 1) * 0.085 * y_span,
      label = paste0(g, ": ", fmt_p(p))
    )
  }))
}

pretty_binwidth <- function(x, n = 24) {
  x <- x[is.finite(x)]
  if (length(x) == 0) return(1)
  r <- range(x)
  bw <- diff(r) / n
  if (!is.finite(bw) || bw <= 0) bw <- max(r[2], 1) / n
  if (!is.finite(bw) || bw <= 0) bw <- 1
  bw
}

ensure_cols <- function(df, cols) {
  for (cc in cols) {
    if (!cc %in% colnames(df)) {
      df[[cc]] <- NA_real_
    }
  }
  df
}

###############################################################################
# Ratio tables
###############################################################################

make_ratio_tables <- function(df_layer) {

  all_wide <- df_layer %>%
    filter(region == "ALL") %>%
    select(
      sample, FROH, variant_class,
      allele_rate, hom_loci_rate, het_loci_rate
    ) %>%
    pivot_wider(
      names_from = variant_class,
      values_from = c(allele_rate, hom_loci_rate, het_loci_rate)
    )

  all_wide <- ensure_cols(
    all_wide,
    c(
      "allele_rate_SIFT_lt0.05", "allele_rate_SIFT_tolerated", "allele_rate_SIFT_synonymous",
      "hom_loci_rate_SIFT_lt0.05", "hom_loci_rate_SIFT_tolerated", "hom_loci_rate_SIFT_synonymous",
      "het_loci_rate_SIFT_lt0.05", "het_loci_rate_SIFT_tolerated", "het_loci_rate_SIFT_synonymous"
    )
  )

  ratio_all <- all_wide %>%
    transmute(
      sample = sample,
      FROH = FROH,

      del_syn_allele = safe_ratio(`allele_rate_SIFT_lt0.05`, `allele_rate_SIFT_synonymous`),
      tol_syn_allele = safe_ratio(`allele_rate_SIFT_tolerated`, `allele_rate_SIFT_synonymous`),

      del_syn_hom = safe_ratio(`hom_loci_rate_SIFT_lt0.05`, `hom_loci_rate_SIFT_synonymous`),
      del_syn_het = safe_ratio(`het_loci_rate_SIFT_lt0.05`, `het_loci_rate_SIFT_synonymous`),

      tol_syn_hom = safe_ratio(`hom_loci_rate_SIFT_tolerated`, `hom_loci_rate_SIFT_synonymous`),
      tol_syn_het = safe_ratio(`het_loci_rate_SIFT_tolerated`, `het_loci_rate_SIFT_synonymous`)
    )

  region_wide <- df_layer %>%
    filter(region %in% c("ROH", "nonROH")) %>%
    mutate(region_label = ifelse(region == "ROH", "ROH", "Non-ROH")) %>%
    select(sample, FROH, region_label, variant_class, allele_rate) %>%
    pivot_wider(
      names_from = variant_class,
      values_from = allele_rate
    )

  region_wide <- ensure_cols(
    region_wide,
    c("SIFT_lt0.05", "SIFT_tolerated", "SIFT_synonymous")
  )

  region_wide <- region_wide %>%
    mutate(
      del_syn_allele = safe_ratio(`SIFT_lt0.05`, `SIFT_synonymous`),
      tol_syn_allele = safe_ratio(`SIFT_tolerated`, `SIFT_synonymous`)
    )

  list(
    ratio_all = ratio_all,
    ratio_region = region_wide
  )
}

###############################################################################
# Plot one layer
###############################################################################

plot_one_layer <- function(layer_name, layer_dir_name, layer_title, x_af_label) {

  message("[INFO] Plot layer: ", layer_name)

  outdir <- file.path(outroot, layer_dir_name)
  dir.create(outdir, recursive = TRUE, showWarnings = FALSE)

  df_layer <- sample_all %>%
    filter(layer == layer_name) %>%
    mutate(
      variant_class = factor(variant_class, levels = class_levels)
    )

  site_layer <- site_all %>%
    filter(layer == layer_name, region == "ALL") %>%
    mutate(
      variant_class = factor(variant_class, levels = class_levels)
    )

  write_tsv(df_layer, file.path(outdir, "PedALL.plot_per_sample.tsv"))

  ratios <- make_ratio_tables(df_layer)
  ratio_all <- ratios$ratio_all
  ratio_region <- ratios$ratio_region

  write_tsv(ratio_all, file.path(outdir, "PedALL.sample_ratio.ALL.tsv"))
  write_tsv(ratio_region, file.path(outdir, "PedALL.sample_ratio.ROH_nonROH.tsv"))

  ###########################################################################
  # A. Allele frequency distribution
  ###########################################################################

  binwidth_af <- 0.025

  af_bin <- site_layer %>%
    filter(!is.na(allele_rate), variant_class %in% class_levels) %>%
    mutate(
      af_bin = pmin(1, floor(allele_rate / binwidth_af) * binwidth_af),
      af_mid = af_bin + binwidth_af / 2
    ) %>%
    count(variant_class, af_mid, name = "n") %>%
    group_by(variant_class) %>%
    mutate(
      total = sum(n),
      percent = ifelse(total > 0, 100 * n / total, NA_real_)
    ) %>%
    ungroup()

  write_tsv(af_bin, file.path(outdir, "PedALL.site_AF_distribution.tsv"))

  pA <- ggplot(af_bin, aes(x = af_mid, y = percent, fill = variant_class)) +
    geom_col(
      position = position_dodge(width = binwidth_af * 0.86),
      width = binwidth_af * 0.72,
      linewidth = 0
    ) +
    scale_fill_manual(values = class_cols, labels = class_labels, drop = FALSE) +
    scale_x_continuous(
      limits = c(0, 1),
      breaks = seq(0, 1, 0.25),
      expand = expansion(mult = c(0.01, 0.01))
    ) +
    scale_y_continuous(expand = expansion(mult = c(0.02, 0.10))) +
    labs(
      title = "A",
      x = x_af_label,
      y = "Percentage of SNPs"
    ) +
    theme_ref(base_size = 11) +
    theme(
      legend.position = c(0.72, 0.88),
      legend.direction = "horizontal",
      plot.title = element_text(hjust = -0.09, vjust = 1.5)
    )

  ###########################################################################
  # B/C. Deleterious heterozygous and homozygous counts
  ###########################################################################

  del_all <- df_layer %>%
    filter(region == "ALL", variant_class == "SIFT_lt0.05") %>%
    filter(!is.na(het_count), !is.na(hom_count))

  het_median <- median(del_all$het_count, na.rm = TRUE)
  het_zero <- sum(del_all$het_count == 0, na.rm = TRUE)
  het_n <- sum(!is.na(del_all$het_count))

  hom_median <- median(del_all$hom_count, na.rm = TRUE)
  hom_zero <- sum(del_all$hom_count == 0, na.rm = TRUE)
  hom_n <- sum(!is.na(del_all$hom_count))

  pB <- ggplot(del_all, aes(x = het_count)) +
    geom_histogram(
      binwidth = pretty_binwidth(del_all$het_count, 24),
      fill = "#DCEAF5",
      color = "grey70",
      linewidth = 0.25
    ) +
    geom_vline(
      xintercept = het_median,
      linetype = "dashed",
      linewidth = 0.5,
      color = "#8DB8DD"
    ) +
    annotate(
      "text",
      x = Inf,
      y = Inf,
      hjust = 1.05,
      vjust = 1.25,
      size = 3.2,
      label = paste0(
        "median = ", comma(round(het_median)),
        "\nzero = ", het_zero, "/", het_n
      )
    ) +
    scale_y_continuous(expand = expansion(mult = c(0.02, 0.12))) +
    labs(
      title = "B  Heterozygotes",
      x = "Number of deleterious loci",
      y = "Number of individuals"
    ) +
    theme_ref(base_size = 11) +
    theme(legend.position = "none")

  pC <- ggplot(del_all, aes(x = hom_count)) +
    geom_histogram(
      binwidth = pretty_binwidth(del_all$hom_count, 24),
      fill = "#5C8DBC",
      color = "grey70",
      linewidth = 0.25
    ) +
    geom_vline(
      xintercept = hom_median,
      linetype = "dashed",
      linewidth = 0.5,
      color = "#5C8DBC"
    ) +
    annotate(
      "text",
      x = Inf,
      y = Inf,
      hjust = 1.05,
      vjust = 1.25,
      size = 3.2,
      label = paste0(
        "median = ", comma(round(hom_median)),
        "\nzero = ", hom_zero, "/", hom_n
      )
    ) +
    scale_y_continuous(expand = expansion(mult = c(0.02, 0.12))) +
    labs(
      title = "C  Homozygotes",
      x = "Number of deleterious loci",
      y = "Number of individuals"
    ) +
    theme_ref(base_size = 11) +
    theme(legend.position = "none")

  ###########################################################################
  # D. Raw deleterious counts vs FROH
  ###########################################################################

  count_long <- del_all %>%
    transmute(
      sample = sample,
      FROH = FROH,
      Total = allele_count,
      Homozygous = hom_count,
      Heterozygous = het_count
    ) %>%
    pivot_longer(
      cols = all_of(component_levels),
      names_to = "component",
      values_to = "count"
    ) %>%
    mutate(component = factor(component, levels = component_levels))

  write_tsv(count_long, file.path(outdir, "PedALL.deleterious_counts_vs_FROH.tsv"))

  label_D <- make_p_labels(count_long, "FROH", "count", "component") %>%
    rename(component = group)

  pD <- ggplot(count_long, aes(x = FROH, y = count, color = component)) +
    geom_point(alpha = 0.55, size = 1.7, na.rm = TRUE) +
    geom_smooth(method = "lm", se = FALSE, linewidth = 0.65, na.rm = TRUE) +
    geom_text(
      data = label_D,
      aes(x = x, y = y, label = label, color = component),
      inherit.aes = FALSE,
      hjust = 0,
      size = 3.0
    ) +
    scale_color_manual(values = component_cols, drop = FALSE) +
    scale_y_continuous(labels = comma, expand = expansion(mult = c(0.05, 0.12))) +
    scale_x_continuous(expand = expansion(mult = c(0.04, 0.04))) +
    labs(
      title = "D  SIFT deleterious counts",
      x = expression(F[ROH]),
      y = "Count"
    ) +
    theme_ref(base_size = 11)

  ###########################################################################
  # E. Standardized deleterious load vs FROH
  ###########################################################################

  load_long <- del_all %>%
    transmute(
      sample = sample,
      FROH = FROH,
      Total = allele_rate,
      Homozygous = hom_loci_rate,
      Heterozygous = het_loci_rate
    ) %>%
    pivot_longer(
      cols = all_of(component_levels),
      names_to = "component",
      values_to = "load"
    ) %>%
    mutate(component = factor(component, levels = component_levels))

  write_tsv(load_long, file.path(outdir, "PedALL.standardized_deleterious_load_vs_FROH.tsv"))

  label_E <- make_p_labels(load_long, "FROH", "load", "component") %>%
    rename(component = group)

  pE <- ggplot(load_long, aes(x = FROH, y = load, color = component)) +
    geom_point(alpha = 0.55, size = 1.7, na.rm = TRUE) +
    geom_smooth(method = "lm", se = FALSE, linewidth = 0.65, na.rm = TRUE) +
    geom_text(
      data = label_E,
      aes(x = x, y = y, label = label, color = component),
      inherit.aes = FALSE,
      hjust = 0,
      size = 3.0
    ) +
    scale_color_manual(values = component_cols, drop = FALSE) +
    scale_y_continuous(expand = expansion(mult = c(0.05, 0.12))) +
    scale_x_continuous(expand = expansion(mult = c(0.04, 0.04))) +
    labs(
      title = "E  Standardized deleterious load",
      x = expression(F[ROH]),
      y = "Load"
    ) +
    theme_ref(base_size = 11)

  ###########################################################################
  # F/G. Ratios
  ###########################################################################

  ratio_del_long <- ratio_all %>%
    transmute(
      sample = sample,
      FROH = FROH,
      Heterozygous = del_syn_het,
      Homozygous = del_syn_hom
    ) %>%
    pivot_longer(
      cols = all_of(ratio_component_levels),
      names_to = "component",
      values_to = "ratio"
    ) %>%
    mutate(component = factor(component, levels = ratio_component_levels))

  ratio_tol_long <- ratio_all %>%
    transmute(
      sample = sample,
      FROH = FROH,
      Heterozygous = tol_syn_het,
      Homozygous = tol_syn_hom
    ) %>%
    pivot_longer(
      cols = all_of(ratio_component_levels),
      names_to = "component",
      values_to = "ratio"
    ) %>%
    mutate(component = factor(component, levels = ratio_component_levels))

  write_tsv(ratio_del_long, file.path(outdir, "PedALL.deleterious_synonymous_ratio_vs_FROH.tsv"))
  write_tsv(ratio_tol_long, file.path(outdir, "PedALL.tolerated_synonymous_ratio_vs_FROH.tsv"))

  label_F <- make_p_labels(ratio_del_long, "FROH", "ratio", "component") %>%
    rename(component = group)

  label_G <- make_p_labels(ratio_tol_long, "FROH", "ratio", "component") %>%
    rename(component = group)

  pF <- ggplot(ratio_del_long, aes(x = FROH, y = ratio, color = component)) +
    geom_point(alpha = 0.70, size = 1.8, na.rm = TRUE) +
    geom_smooth(method = "lm", se = FALSE, linewidth = 0.65, aes(linetype = component), na.rm = TRUE) +
    geom_text(
      data = label_F,
      aes(x = x, y = y, label = label, color = component),
      inherit.aes = FALSE,
      hjust = 0,
      size = 3.0
    ) +
    scale_color_manual(values = ratio_component_cols, drop = FALSE) +
    scale_linetype_manual(values = c("Heterozygous" = "dashed", "Homozygous" = "solid"), drop = FALSE) +
    scale_x_continuous(expand = expansion(mult = c(0.04, 0.04))) +
    scale_y_continuous(expand = expansion(mult = c(0.05, 0.12))) +
    labs(
      title = "F  Deleterious/Synonymous",
      x = expression(F[ROH]),
      y = "Nonsynonymous / synonymous ratio"
    ) +
    theme_ref(base_size = 11)

  pG <- ggplot(ratio_tol_long, aes(x = FROH, y = ratio, color = component)) +
    geom_point(alpha = 0.70, size = 1.8, na.rm = TRUE) +
    geom_smooth(method = "lm", se = FALSE, linewidth = 0.65, aes(linetype = component), na.rm = TRUE) +
    geom_text(
      data = label_G,
      aes(x = x, y = y, label = label, color = component),
      inherit.aes = FALSE,
      hjust = 0,
      size = 3.0
    ) +
    scale_color_manual(values = ratio_component_cols, drop = FALSE) +
    scale_linetype_manual(values = c("Heterozygous" = "dashed", "Homozygous" = "solid"), drop = FALSE) +
    scale_x_continuous(expand = expansion(mult = c(0.04, 0.04))) +
    scale_y_continuous(expand = expansion(mult = c(0.05, 0.12))) +
    labs(
      title = "G  Tolerated/Synonymous",
      x = expression(F[ROH]),
      y = "Nonsynonymous / synonymous ratio"
    ) +
    theme_ref(base_size = 11)

  ###########################################################################
  # H. ROH / nonROH ratios
  ###########################################################################

  h_del <- ratio_region %>%
    transmute(
      sample = sample,
      FROH = FROH,
      region = factor(region_label, levels = c("Non-ROH", "ROH")),
      ratio = del_syn_allele
    )

  h_tol <- ratio_region %>%
    transmute(
      sample = sample,
      FROH = FROH,
      region = factor(region_label, levels = c("Non-ROH", "ROH")),
      ratio = tol_syn_allele
    )

  write_tsv(h_del, file.path(outdir, "PedALL.ROH_nonROH_deleterious_synonymous_ratio.tsv"))
  write_tsv(h_tol, file.path(outdir, "PedALL.ROH_nonROH_tolerated_synonymous_ratio.tsv"))

  label_H1 <- make_p_labels(h_del, "FROH", "ratio", "region") %>%
    rename(region = group)

  label_H2 <- make_p_labels(h_tol, "FROH", "ratio", "region") %>%
    rename(region = group)

  pH1 <- ggplot(h_del, aes(x = FROH, y = ratio, color = region)) +
    geom_point(alpha = 0.75, size = 1.8, na.rm = TRUE) +
    geom_smooth(method = "lm", se = FALSE, linewidth = 0.65, na.rm = TRUE) +
    geom_text(
      data = label_H1,
      aes(x = x, y = y, label = label, color = region),
      inherit.aes = FALSE,
      hjust = 0,
      size = 3.0
    ) +
    scale_color_manual(values = region_cols, drop = FALSE) +
    scale_x_continuous(expand = expansion(mult = c(0.04, 0.04))) +
    scale_y_continuous(expand = expansion(mult = c(0.05, 0.12))) +
    labs(
      title = "H  Deleterious/Synonymous",
      x = expression(F[ROH]),
      y = "Nonsynonymous / synonymous ratio"
    ) +
    theme_ref(base_size = 11)

  pH2 <- ggplot(h_tol, aes(x = FROH, y = ratio, color = region)) +
    geom_point(alpha = 0.75, size = 1.8, na.rm = TRUE) +
    geom_smooth(method = "lm", se = FALSE, linewidth = 0.65, na.rm = TRUE) +
    geom_text(
      data = label_H2,
      aes(x = x, y = y, label = label, color = region),
      inherit.aes = FALSE,
      hjust = 0,
      size = 3.0
    ) +
    scale_color_manual(values = region_cols, drop = FALSE) +
    scale_x_continuous(expand = expansion(mult = c(0.04, 0.04))) +
    scale_y_continuous(expand = expansion(mult = c(0.05, 0.12))) +
    labs(
      title = "Tolerated/Synonymous",
      x = expression(F[ROH]),
      y = NULL
    ) +
    theme_ref(base_size = 11)

  pH <- pH1 | pH2

  ###########################################################################
  # Combined layout
  ###########################################################################

  top_row <- pA + pB + pC + plot_layout(widths = c(2.2, 1, 1))
  middle_row <- pD + pE + plot_layout(widths = c(1, 1))
  bottom_row <- pF + pG + pH + plot_layout(widths = c(1, 1, 2.05))

  combined <- top_row / middle_row / bottom_row +
    plot_layout(heights = c(1.05, 1.15, 1.25)) +
    plot_annotation(
      title = layer_title,
      theme = theme(
        plot.title = element_text(face = "bold", size = 15, hjust = 0.5)
      )
    )

  ggsave(file.path(outdir, "PedALL.SIFT.A_H.combined.pdf"), combined, width = 15.5, height = 11.5)
  ggsave(file.path(outdir, "PedALL.SIFT.A_H.combined.png"), combined, width = 15.5, height = 11.5, dpi = 300)

  ggsave(file.path(outdir, "A_AF_distribution.pdf"), pA, width = 7.2, height = 3.8)
  ggsave(file.path(outdir, "B_heterozygous_deleterious_hist.pdf"), pB, width = 4.2, height = 3.8)
  ggsave(file.path(outdir, "C_homozygous_deleterious_hist.pdf"), pC, width = 4.2, height = 3.8)
  ggsave(file.path(outdir, "D_deleterious_counts_vs_FROH.pdf"), pD, width = 6.2, height = 4.4)
  ggsave(file.path(outdir, "E_standardized_deleterious_load_vs_FROH.pdf"), pE, width = 6.2, height = 4.4)
  ggsave(file.path(outdir, "F_deleterious_synonymous_ratio_vs_FROH.pdf"), pF, width = 4.5, height = 4.2)
  ggsave(file.path(outdir, "G_tolerated_synonymous_ratio_vs_FROH.pdf"), pG, width = 4.5, height = 4.2)
  ggsave(file.path(outdir, "H_ROH_nonROH_ratio_vs_FROH.pdf"), pH, width = 8.8, height = 4.2)

  message("[INFO] Wrote figures to: ", outdir)
}

###############################################################################
# Run two layers
###############################################################################

plot_one_layer(
  layer_name = "unpolarized_alt",
  layer_dir_name = "01_unpolarized_ALT",
  layer_title = "Ped full-genome SIFT burden: unpolarized ALT dosage",
  x_af_label = "ALT allele frequency"
)

plot_one_layer(
  layer_name = "polarized_derived",
  layer_dir_name = "02_polarized_derived",
  layer_title = "Ped full-genome SIFT burden: polarized derived dosage",
  x_af_label = "Derived allele frequency"
)
