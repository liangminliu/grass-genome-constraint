#!/usr/bin/env bash
#SBATCH --job-name=Ped_GERP
#SBATCH --partition=parallel
#SBATCH --cpus-per-task=1
#SBATCH --output=Ped_GERP_fullgenome_pipeline/logs/%x.%j.out
#SBATCH --error=Ped_GERP_fullgenome_pipeline/logs/%x.%j.err

set -euo pipefail

TABLE_DIR="Ped_GERP_fullgenome_pipeline/01_tables"
OUT_PREFIX="Ped_GERP_fullgenome_pipeline/03_plots/Ped_GERP_fullgenome"

mkdir -p "$(dirname "${OUT_PREFIX}")" "Ped_GERP_fullgenome_pipeline/logs"

#bash Ped_GERP_fullgenome_pipeline/scripts/00_run_Ped_GERP_fullgenome.sh

required=(
  "plot_A_site_spectrum.tsv"
  "plot_BC_GERP4_burden.tsv"
  "plot_DE_GERP4_over_lt0_ratio.tsv"
  "plot_F_ROH_nonROH_burden.tsv"
  "plot_GH_ROH_nonROH_ratio.tsv"
)

for x in "${required[@]}"; do
  if [[ ! -s "${TABLE_DIR}/${x}" ]]; then
    echo "[ERROR] Missing table: ${TABLE_DIR}/${x}" >&2
    echo "[ERROR] Run calculation first:" >&2
    echo "bash Ped_GERP_fullgenome_pipeline/scripts/00_run_Ped_GERP_fullgenome.sh" >&2
    exit 1
  fi
done

Rscript Ped_GERP_fullgenome_pipeline/scripts/02_plot_Ped_GERP_AH.R "${TABLE_DIR}" polarized "${OUT_PREFIX}"
Rscript Ped_GERP_fullgenome_pipeline/scripts/02_plot_Ped_GERP_AH.R "${TABLE_DIR}" unpolarized "${OUT_PREFIX}"

echo "[DONE] plots written to Ped_GERP_fullgenome_pipeline/03_plots"
