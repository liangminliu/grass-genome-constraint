#!/usr/bin/env Rscript

suppressPackageStartupMessages({
  library(readr)
  library(dplyr)
  library(ggplot2)
  library(patchwork)
  library(scales)
})

args <- commandArgs(trailingOnly = TRUE)

if (length(args) < 3) {
  stop("Usage:\nRscript 02_plot_Teosinte_ROH_FROH_final.R <table_prefix> <out_prefix> <species_label>\n")
}

table_prefix  <- args[1]
out_prefix    <- args[2]
species_label <- args[3]

dir.create(dirname(out_prefix), recursive = TRUE, showWarnings = FALSE)

read_table <- function(x) {
  read_tsv(x, show_col_types = FALSE, progress = FALSE)
}

## =========================
## Parameters
## =========================
REPRESENTATIVE_N      <- 5

FREQ_ROH_BP           <- 100000
WINDOW_BP             <- 1000000
LANDSCAPE_ROH_BP      <- 100000

## 只影响 E 图显示，不改变 ROH/FROH 计算结果
MIN_VISUAL_WIDTH_BP   <- 1500000
ROH_TRACK_HALF_HEIGHT <- 0.24
BASELINE_HALF_HEIGHT  <- 0.045

## =========================
## Read tables
## =========================
froh        <- read_table(paste0(table_prefix, ".froh.tsv"))
chr_info    <- read_table(paste0(table_prefix, ".chr_info.tsv"))
roh         <- read_table(paste0(table_prefix, ".roh_segments.clean.tsv"))
by_class    <- read_table(paste0(table_prefix, ".cumulative_by_class.tsv"))
freq        <- read_table(paste0(table_prefix, ".ROH_frequency.1Mb.tsv"))
rep_samples <- read_table(paste0(table_prefix, ".representative_samples.tsv"))
rep_roh     <- read_table(paste0(table_prefix, ".representative_ROH.tsv"))

## =========================
## Type harmonization
## =========================
froh <- froh %>%
  mutate(sample = as.character(sample))

chr_info <- chr_info %>%
  mutate(
    chr = as.character(chr),
    chr_label = as.character(chr_label),
    center = offset + chr_len / 2,
    xmin = offset,
    xmax = offset + chr_len,
    bg_key = ifelse(chr_index %% 2 == 1, "bg_odd", "bg_even"),
    seg_key = ifelse(chr_index %% 2 == 1, "seg_odd", "seg_even")
  )

roh <- roh %>%
  mutate(
    sample = as.character(sample),
    chr = as.character(chr)
  )

by_class <- by_class %>%
  mutate(
    sample = as.character(sample),
    roh_class = factor(
      roh_class,
      levels = c("100–250 kb", "250–500 kb", "500 kb–1 Mb", ">1 Mb")
    )
  )

freq <- freq %>%
  mutate(
    chr = as.character(chr),
    bg_key = ifelse(bg_group == "odd", "bg_odd", "bg_even")
  )

rep_samples <- rep_samples %>%
  mutate(
    sample = as.character(sample),
    sample_rank = as.integer(sample_rank)
  ) %>%
  arrange(sample_rank)

rep_roh <- rep_roh %>%
  mutate(
    sample = as.character(sample),
    chr = as.character(chr)
  )

roh$roh_class <- factor(
  roh$roh_class,
  levels = c("100–250 kb", "250–500 kb", "500 kb–1 Mb", ">1 Mb")
)

## =========================
## Theme
## =========================
theme_roh <- function(base_size = 10) {
  theme_classic(base_size = base_size) +
    theme(
      text = element_text(color = "grey15"),
      axis.text = element_text(color = "grey25"),
      axis.title = element_text(color = "grey10"),
      axis.line = element_line(color = "grey30", linewidth = 0.42),
      axis.ticks = element_line(color = "grey30", linewidth = 0.35),
      panel.grid.major.y = element_line(color = "grey90", linewidth = 0.28),
      panel.grid.major.x = element_blank(),
      panel.grid.minor = element_blank(),
      plot.title = element_text(hjust = 0.0, face = "bold", size = base_size + 3),
      plot.subtitle = element_text(hjust = 0.0, color = "grey35", size = base_size),
      plot.tag = element_text(face = "bold", size = base_size + 6),
      legend.title = element_blank(),
      legend.key = element_blank()
    )
}

save_both <- function(plot, prefix, width, height) {
  pdf_file <- paste0(prefix, ".pdf")
  png_file <- paste0(prefix, ".png")
  pdf_dev <- if (capabilities("cairo")) grDevices::cairo_pdf else grDevices::pdf

  ggsave(pdf_file, plot, width = width, height = height, units = "in", device = pdf_dev)
  ggsave(png_file, plot, width = width, height = height, units = "in", dpi = 600)

  message("[WRITE] ", pdf_file)
  message("[WRITE] ", png_file)
}

## =========================
## Colors
## =========================
col_hist_fill   <- "#C9CEC1"
col_hist_border <- "#737A6E"
col_mean        <- "#4B78A8"
col_median      <- "grey45"
col_roh_freq    <- "#1F5D9D"

fill_values <- c(
  bg_odd  = "#FCFCFC",
  bg_even = "#F6F6F6"
)

roh_values <- c(
  seg_odd  = "#4FB7B3",
  seg_even = "#555555"
)

baseline_col <- "#DDDDDD"

## =========================
## A. FROH distribution
## =========================
froh_mean   <- mean(froh$FROH, na.rm = TRUE)
froh_median <- median(froh$FROH, na.rm = TRUE)

pA <- ggplot(froh, aes(x = FROH)) +
  geom_histogram(
    bins = 22,
    fill = col_hist_fill,
    colour = col_hist_border,
    linewidth = 0.35
  ) +
  geom_vline(xintercept = froh_mean, colour = col_mean, linewidth = 0.5) +
  geom_vline(xintercept = froh_median, colour = col_median, linetype = 2, linewidth = 0.45) +
  annotate(
    "text",
    x = froh_mean + max(froh$FROH, na.rm = TRUE) * 0.08,
    y = Inf,
    label = paste0("mean = ", signif(froh_mean, 3)),
    hjust = 0,
    vjust = 1.8,
    size = 2.8,
    colour = col_mean
  ) +
  labs(
    title = "Genome-wide FROH distribution",
    subtitle = paste0(species_label, ", n = ", nrow(froh)),
    x = expression(F[ROH]),
    y = "Number of individuals",
    tag = "A"
  ) +
  theme_roh(10)

## =========================
## B. Cumulative FROH contribution by ROH length
## =========================
mean_cum <- by_class %>%
  group_by(roh_class) %>%
  summarise(cumulative_FROH = mean(cumulative_FROH, na.rm = TRUE), .groups = "drop")

pB <- ggplot(by_class, aes(x = roh_class, y = cumulative_FROH, group = sample)) +
  geom_line(colour = "grey68", alpha = 0.55, linewidth = 0.35) +
  geom_point(colour = "grey62", alpha = 0.55, size = 0.7) +
  geom_line(
    data = mean_cum,
    aes(x = roh_class, y = cumulative_FROH, group = 1),
    inherit.aes = FALSE,
    colour = "black",
    linewidth = 0.8
  ) +
  geom_point(
    data = mean_cum,
    aes(x = roh_class, y = cumulative_FROH),
    inherit.aes = FALSE,
    colour = "black",
    size = 1.6
  ) +
  labs(
    title = "Cumulative FROH contribution by ROH length",
    subtitle = "ROH classes: 100–250 kb, 250–500 kb, 500 kb–1 Mb, >1 Mb",
    x = "ROH length class",
    y = expression("Cumulative " * F[ROH]),
    tag = "B"
  ) +
  theme_roh(10) +
  theme(axis.text.x = element_text(angle = 18, hjust = 1))

## =========================
## C. ROH length distribution
## =========================
mean_len   <- mean(roh$length_Mb, na.rm = TRUE)
median_len <- median(roh$length_Mb, na.rm = TRUE)
min_len    <- min(roh$length_Mb, na.rm = TRUE)
max_len    <- max(roh$length_Mb, na.rm = TRUE)

x_left  <- floor(min_len * 100) / 100
x_right <- ceiling(max_len * 100) / 100

if (x_right <= x_left) {
  x_right <- x_left + 0.01
}

pC <- ggplot(roh, aes(x = length_Mb)) +
  geom_histogram(
    bins = 70,
    fill = col_hist_fill,
    colour = col_hist_border,
    linewidth = 0.2
  ) +
  geom_vline(xintercept = mean_len, colour = col_mean, linewidth = 0.5) +
  geom_vline(xintercept = median_len, colour = col_median, linetype = 2, linewidth = 0.4) +
  annotate(
    "text",
    x = mean_len + (x_right - x_left) * 0.08,
    y = Inf,
    label = paste0("mean = ", round(mean_len, 2), " Mb"),
    hjust = 0,
    vjust = 1.7,
    size = 2.8,
    colour = col_mean
  ) +
  scale_x_continuous(
    limits = c(x_left, x_right),
    expand = expansion(mult = c(0.01, 0.01))
  ) +
  scale_y_continuous(labels = comma) +
  labs(
    title = "ROH length distribution",
    subtitle = paste0(
      "ROH segments ≥100 kb; observed range = ",
      sprintf("%.3f", min_len), "–", sprintf("%.3f", max_len), " Mb"
    ),
    x = "ROH length (Mb)",
    y = "Number of ROH segments",
    tag = "C"
  ) +
  theme_roh(10)

## =========================
## D. Genome-wide ROH frequency
## =========================
pD <- ggplot() +
  geom_rect(
    data = chr_info,
    aes(xmin = xmin, xmax = xmax, ymin = -Inf, ymax = Inf, fill = bg_key),
    inherit.aes = FALSE,
    colour = NA,
    alpha = 1
  ) +
  geom_segment(
    data = freq,
    aes(x = x, xend = x, y = 0, yend = roh_frequency),
    colour = col_roh_freq,
    linewidth = 0.35,
    lineend = "butt"
  ) +
  scale_fill_manual(values = fill_values, guide = "none") +
  scale_x_continuous(
    breaks = chr_info$center,
    labels = chr_info$chr_label,
    expand = c(0.005, 0.005)
  ) +
  scale_y_continuous(
    labels = percent_format(accuracy = 1),
    limits = c(0, 1),
    expand = c(0, 0)
  ) +
  labs(
    title = "Genome-wide ROH frequency",
    subtitle = "ROH segments ≥100 kb; window size = 1 Mb",
    x = "Chromosome",
    y = "Frequency of individuals with ROH",
    tag = "D"
  ) +
  theme_roh(10) +
  theme(
    axis.text.x = element_text(angle = 45, hjust = 1, size = 8)
  )

## =========================
## E. Representative individual ROH landscape
## =========================
rep_df <- rep_samples %>%
  arrange(sample_rank) %>%
  mutate(
    y = rev(seq_len(n())),
    xmin_all = min(chr_info$xmin),
    xmax_all = max(chr_info$xmax),
    sample_label = paste0(sample, " (", signif(FROH, 3), ")")
  )

baseline_df <- rep_df %>%
  mutate(
    ymin = y - BASELINE_HALF_HEIGHT,
    ymax = y + BASELINE_HALF_HEIGHT
  )

land2 <- rep_roh %>%
  left_join(rep_df %>% select(sample, y), by = "sample") %>%
  left_join(
    chr_info %>% select(chr, chr_start, chr_end, xmin, xmax, offset, seg_key),
    by = "chr"
  ) %>%
  mutate(
    xmid = (xstart + xend) / 2,
    raw_width = pmax(xend - xstart, 1),
    plot_width = pmax(raw_width, MIN_VISUAL_WIDTH_BP),
    xstart_plot = pmax(xmin, xmid - plot_width / 2),
    xend_plot = pmin(xmax, xmid + plot_width / 2),
    ymin = y - ROH_TRACK_HALF_HEIGHT,
    ymax = y + ROH_TRACK_HALF_HEIGHT
  )

pE <- ggplot() +
  geom_rect(
    data = chr_info,
    aes(xmin = xmin, xmax = xmax, ymin = -Inf, ymax = Inf, fill = bg_key),
    inherit.aes = FALSE,
    colour = NA,
    alpha = 1
  ) +
  geom_rect(
    data = baseline_df,
    aes(xmin = xmin_all, xmax = xmax_all, ymin = ymin, ymax = ymax),
    inherit.aes = FALSE,
    fill = baseline_col,
    colour = NA,
    alpha = 0.95
  ) +
  geom_rect(
    data = land2,
    aes(
      xmin = xstart_plot,
      xmax = xend_plot,
      ymin = ymin,
      ymax = ymax,
      fill = seg_key
    ),
    inherit.aes = FALSE,
    colour = NA,
    alpha = 0.92
  ) +
  scale_fill_manual(
    values = c(fill_values, roh_values),
    guide = "none"
  ) +
  scale_x_continuous(
    breaks = chr_info$center,
    labels = chr_info$chr_label,
    expand = c(0.005, 0.005)
  ) +
  scale_y_continuous(
    breaks = rep_df$y,
    labels = rep_df$sample_label,
    expand = expansion(mult = c(0.03, 0.03))
  ) +
  labs(
    title = "Representative individual ROH landscape",
    subtitle = "ROH segments ≥100 kb; five highest-FROH individuals are shown above and five lowest-FROH individuals below",
    x = "Chromosome",
    y = expression("Individuals (" * F[ROH] * ")"),
    tag = "E"
  ) +
  theme_roh(10) +
  theme(
    panel.grid.major.y = element_blank(),
    axis.text.y = element_text(size = 8, colour = "grey20"),
    axis.text.x = element_text(size = 8),
    axis.title.y = element_text(size = 11),
    plot.title = element_text(size = 14, face = "bold"),
    plot.subtitle = element_text(size = 10.5, colour = "grey35")
  )

## =========================
## Combined figure
## =========================
combined <- (pA | pB) / (pC | pD) / pE +
  plot_layout(heights = c(1, 1, 1.35)) +
  plot_annotation(tag_levels = NULL) &
  theme(plot.tag = element_text(face = "bold", size = 14))

## =========================
## Write outputs
## =========================
save_both(pA, paste0(out_prefix, ".FigA_FROH_distribution"), 5.2, 3.5)
save_both(pB, paste0(out_prefix, ".FigB_cumulative_FROH_contribution"), 5.4, 3.5)
save_both(pC, paste0(out_prefix, ".FigC_ROH_length_distribution"), 5.2, 3.5)
save_both(pD, paste0(out_prefix, ".FigD_genomewide_ROH_frequency_ge100kb"), 5.5, 3.6)
save_both(pE, paste0(out_prefix, ".FigE_representative_ROH_landscape_ge100kb"), 13.5, 5.2)
save_both(combined, paste0(out_prefix, ".00_main_ROH_FROH_final_Dge100kb_Ege100kb"), 11.8, 12.6)

message("[DONE] Teosinte ROH/FROH final plots generated.")