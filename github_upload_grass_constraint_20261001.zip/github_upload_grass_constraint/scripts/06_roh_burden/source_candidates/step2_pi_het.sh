#!/bin/bash
#SBATCH --job-name=pi_het
#SBATCH --partition=parallel
#SBATCH --cpus-per-task=10
#SBATCH --output=logs/pi_het_%J.out
#SBATCH --error=logs/pi_het_%J.err

set -euo pipefail

###############################################################################
# 参数
###############################################################################
VCF="all.filtered.bi-allelic.miss0.5.snp.vcf.gz"
OUTDIR="vcftools_miss0.5_results"
mkdir -p logs "${OUTDIR}"

###############################################################################
# 1. 计算全体样本的 π（site-pi）
###############################################################################
echo "Calculating site-pi for all samples..."

vcftools \
  --gzvcf "${VCF}"   --site-pi   --out "${OUTDIR}/all.filtered.bi-allelic"

###############################################################################
# 2. 计算全体样本的杂合度（H）
###############################################################################
echo "Calculating heterozygosity for all samples..."

vcftools \
  --gzvcf "${VCF}" \
  --het \
  --out "${OUTDIR}/all.filtered.bi-allelic.miss0.5"

###############################################################################
# 3. 从 .het 文件计算 H
###############################################################################
awk 'BEGIN{OFS="\t"}
NR==1 {print "INDV","Heterozygosity"; next}
{
  het = ($4 - $2) / $4
  printf "%s\t%.6f\n", $1, het
}' vcftools_miss0.5_results/all.filtered.bi-allelic.miss0.5.het \
> vcftools_miss0.5_results/all.filtered.bi-allelic.miss0.5.heterozygosity.txt






###############################################################################
# 4. （可选）计算平均 π
###############################################################################
awk '{sum+=$3; n++} END{print sum/n}' \
  "vcftools_results/Zmay_v5.sites.pi" > "${OUTDIR}/all.filtered.bi-allelic.miss0.5.mean_pi.txt"

awk '{sum+=$3; n++} END{print sum/n}' \
  "vcftools_results/Zmay_v5.sites.pi" > "vcftools_results/all.filtered.bi-allelic.mean_pi.txt"
