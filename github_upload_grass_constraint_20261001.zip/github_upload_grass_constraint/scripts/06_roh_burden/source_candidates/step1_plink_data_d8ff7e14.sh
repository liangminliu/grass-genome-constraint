#!/bin/bash
#SBATCH --job-name=KING_DIRECT_VCF
#SBATCH --output=king_direct.%j.out
#SBATCH --error=king_direct.%j.err
#SBATCH --cpus-per-task=20
#SBATCH -p FAT2

# ===== 关键配置 =====
SOURCE_VCF="./all_chr.filter.vcf.gz"
CONTAINER=~/liuliangmin/4.may/software/Reseq_genek.sif

echo "===== 开始处理VCF文件 ====="
echo "开始时间: $(date)"

# ===== 1. 提取样品（对应需要的样品）=====
singularity exec $CONTAINER bcftools view -S keep_maize_final.list \
    --drop-genotypes \
    -Oz -o extracted_150sp_maize.vcf.gz \
    $SOURCE_VCF

# 检查文件是否成功生成
if [ ! -f "extracted_150sp_maize.vcf.gz" ]; then
    echo "错误: 样品提取失败"
    exit 1
fi


# ===== 3. 索引新VCF文件 =====
echo "===== 正在索引VCF文件 ====="
singularity exec $CONTAINER bcftools index extracted_150sp_maize.vcf.gz

# ===== 4. 转换为PLINK格式（处理下划线问题）=====
echo "===== 转换为PLINK格式 ====="
singularity exec $CONTAINER plink --vcf extracted_150sp_maize.vcf.gz \
    --allow-extra-chr \
    --chr-set 10 \
    --double-id \
    --make-bed \
    --out king_direct

# 检查PLINK文件是否成功生成
if [ ! -f "king_direct.bed" ] || [ ! -f "king_direct.bim" ] || [ ! -f "king_direct.fam" ]; then
    echo "错误: PLINK格式转换失败"
    exit 1
fi

# ===== 5. 检查样品ID处理结果 =====
echo "===== 检查样品ID处理结果 ====="
echo "前10个样品ID在fam文件中的格式："
head king_direct.fam | cut -d' ' -f1,2

# ===== 6. 结果报告 =====
echo "===== 分析结果 ====="
echo "样本数: $(wc -l < king_direct.fam)"
echo "SNP总数: $(wc -l < king_direct.bim)"
echo "处理完成时间: $(date)"
echo "===== 处理完成 ====="