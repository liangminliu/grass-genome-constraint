#!/usr/bin/env Rscript

suppressPackageStartupMessages({
  library(readr)
  library(dplyr)
  library(ggplot2)
  library(patchwork)
  library(scales)
})

args <- commandArgs(trailingOnly = TRUE)

if (length(args) < 3) {
  stop("Usage:\nRscript 02_plot_Ped_ROH_FROH_final.R <table_prefix> <out_prefix> <species_label>\n")
}

table_prefix  <- args[1]
out_prefix    <- args[2]
species_label <- args[3]

dir.create(dirname(out_prefix), recursive = TRUE, showWarnings = FALSE)

read_table <- function(x) read_tsv(x, show_col_types = FALSE, progress = FALSE)

## =========================
## Parameters
## =========================
EXCLUDE_SAMPLE_GLOBAL <- "PE01225437"   # 全局去掉这个极端值
E_EXCLUDE_PREFIX      <- "^PE"          # E 图不展示 PE 开头样品
REPRESENTATIVE_N      <- 5

FREQ_ROH_BP           <- 100000         # D 图：ROH >=100 kb
WINDOW_BP             <- 1000000        # D 图：1 Mb window
LANDSCAPE_ROH_BP      <- 100000         # E 图：ROH >=100 kb

## 这些参数只影响 E 图显示，不改变原始结果
MIN_VISUAL_WIDTH_BP   <- 1500000        # 让短 ROH 也能看清
ROH_TRACK_HALF_HEIGHT <- 0.24           # ROH 块更粗
BASELINE_HALF_HEIGHT  <- 0.045

## =========================
## Read tables
## =========================
froh        <- read_table(paste0(table_prefix, ".froh.tsv"))
chr_info    <- read_table(paste0(table_prefix, ".chr_info.tsv"))
roh         <- read_table(paste0(table_prefix, ".roh_segments.clean.tsv"))
by_class    <- read_table(paste0(table_prefix, ".cumulative_by_class.tsv"))

## 可选读取；这版实际不依赖它们来生成 D/E
rep_samples_file <- paste0(table_prefix, ".representative_samples.tsv")
rep_roh_file     <- paste0(table_prefix, ".representative_ROH.tsv")

## =========================
## Type harmonization
## =========================
froh        <- froh     %>% mutate(sample = as.character(sample))
chr_info    <- chr_info %>% mutate(chr = as.character(chr), chr_label = as.character(chr_label))
roh         <- roh      %>% mutate(sample = as.character(sample), chr = as.character(chr))
by_class    <- by_class %>% mutate(sample = as.character(sample))

## =========================
## Global sample filtering
## 去除极端值 PE01225437
## =========================
froh     <- froh     %>% filter(sample != EXCLUDE_SAMPLE_GLOBAL)
roh      <- roh      %>% filter(sample != EXCLUDE_SAMPLE_GLOBAL)
by_class <- by_class %>% filter(sample != EXCLUDE_SAMPLE_GLOBAL)

## ROH class order
class_levels <- c("100–250 kb", "250–500 kb", "500 kb–1 Mb", ">1 Mb")
by_class$roh_class <- factor(by_class$roh_class, levels = class_levels)
roh$roh_class      <- factor(roh$roh_class, levels = class_levels)

## chromosome helper columns
chr_info <- chr_info %>%
  mutate(
    center  = offset + chr_len / 2,
    xmin    = offset,
    xmax    = offset + chr_len,
    bg_key  = ifelse(chr_index %% 2 == 1, "bg_odd", "bg_even"),
    seg_key = ifelse(chr_index %% 2 == 1, "seg_odd", "seg_even")
  )

## =========================
## Theme
## =========================
theme_roh <- function(base_size = 10) {
  theme_classic(base_size = base_size) +
    theme(
      text = element_text(color = "grey15"),
      axis.text = element_text(color = "grey25"),
      axis.title = element_text(color = "grey10"),
      axis.line = element_line(color = "grey30", linewidth = 0.42),
      axis.ticks = element_line(color = "grey30", linewidth = 0.35),
      panel.grid.major.y = element_line(color = "grey90", linewidth = 0.28),
      panel.grid.major.x = element_blank(),
      panel.grid.minor = element_blank(),
      plot.title = element_text(hjust = 0.0, face = "bold", size = base_size + 3),
      plot.subtitle = element_text(hjust = 0.0, color = "grey35", size = base_size),
      plot.tag = element_text(face = "bold", size = base_size + 6),
      legend.title = element_blank(),
      legend.key = element_blank()
    )
}

save_both <- function(plot, prefix, width, height) {
  pdf_file <- paste0(prefix, ".pdf")
  png_file <- paste0(prefix, ".png")
  pdf_dev <- if (capabilities("cairo")) grDevices::cairo_pdf else grDevices::pdf

  ggsave(pdf_file, plot, width = width, height = height, units = "in", device = pdf_dev)
  ggsave(png_file, plot, width = width, height = height, units = "in", dpi = 600)

  message("[WRITE] ", pdf_file)
  message("[WRITE] ", png_file)
}

## =========================
## Colors
## =========================
col_hist_fill   <- "#C9CEC1"
col_hist_border <- "#737A6E"
col_mean        <- "#4B78A8"
col_median      <- "grey45"
col_roh_freq    <- "#1F5D9D"

fill_values <- c(
  bg_odd  = "#FCFCFC",
  bg_even = "#F6F6F6"
)

roh_values <- c(
  seg_odd  = "#4FB7B3",
  seg_even = "#555555"
)

baseline_col <- "#DDDDDD"

## =========================
## A. FROH distribution
## =========================
froh_mean   <- mean(froh$FROH, na.rm = TRUE)
froh_median <- median(froh$FROH, na.rm = TRUE)

pA <- ggplot(froh, aes(x = FROH)) +
  geom_histogram(
    bins = 22,
    fill = col_hist_fill,
    colour = col_hist_border,
    linewidth = 0.35
  ) +
  geom_vline(xintercept = froh_mean, colour = col_mean, linewidth = 0.5) +
  geom_vline(xintercept = froh_median, colour = col_median, linetype = 2, linewidth = 0.45) +
  annotate(
    "text",
    x = froh_mean + max(froh$FROH, na.rm = TRUE) * 0.08,
    y = Inf,
    label = paste0("mean = ", signif(froh_mean, 3)),
    hjust = 0,
    vjust = 1.8,
    size = 2.8,
    colour = col_mean
  ) +
  labs(
    title = "Genome-wide FROH distribution",
    subtitle = paste0(species_label, ", n = ", nrow(froh)),
    x = expression(F[ROH]),
    y = "Number of individuals",
    tag = "A"
  ) +
  theme_roh(10)

## =========================
## B. Cumulative FROH contribution
## =========================
mean_cum <- by_class %>%
  group_by(roh_class) %>%
  summarise(cumulative_FROH = mean(cumulative_FROH, na.rm = TRUE), .groups = "drop")

pB <- ggplot(by_class, aes(x = roh_class, y = cumulative_FROH, group = sample)) +
  geom_line(colour = "grey68", alpha = 0.55, linewidth = 0.35) +
  geom_point(colour = "grey62", alpha = 0.55, size = 0.7) +
  geom_line(
    data = mean_cum,
    aes(x = roh_class, y = cumulative_FROH, group = 1),
    inherit.aes = FALSE,
    colour = "black",
    linewidth = 0.8
  ) +
  geom_point(
    data = mean_cum,
    aes(x = roh_class, y = cumulative_FROH),
    inherit.aes = FALSE,
    colour = "black",
    size = 1.6
  ) +
  labs(
    title = "Cumulative FROH contribution by ROH length",
    subtitle = "ROH classes: 100–250 kb, 250–500 kb, 500 kb–1 Mb, >1 Mb",
    x = "ROH length class",
    y = expression("Cumulative " * F[ROH]),
    tag = "B"
  ) +
  theme_roh(10) +
  theme(axis.text.x = element_text(angle = 18, hjust = 1))

## =========================
## C. ROH length distribution
## 横轴按观测最小值-最大值
## =========================
mean_len   <- mean(roh$length_Mb, na.rm = TRUE)
median_len <- median(roh$length_Mb, na.rm = TRUE)
min_len    <- min(roh$length_Mb, na.rm = TRUE)
max_len    <- max(roh$length_Mb, na.rm = TRUE)

x_left  <- floor(min_len * 100) / 100
x_right <- ceiling(max_len * 100) / 100
if (x_right <= x_left) x_right <- x_left + 0.01

pC <- ggplot(roh, aes(x = length_Mb)) +
  geom_histogram(
    bins = 70,
    fill = col_hist_fill,
    colour = col_hist_border,
    linewidth = 0.2
  ) +
  geom_vline(xintercept = mean_len, colour = col_mean, linewidth = 0.5) +
  geom_vline(xintercept = median_len, colour = col_median, linetype = 2, linewidth = 0.4) +
  annotate(
    "text",
    x = mean_len + (x_right - x_left) * 0.08,
    y = Inf,
    label = paste0("mean = ", round(mean_len, 2), " Mb"),
    hjust = 0,
    vjust = 1.7,
    size = 2.8,
    colour = col_mean
  ) +
  scale_x_continuous(
    limits = c(x_left, x_right),
    expand = expansion(mult = c(0.01, 0.01))
  ) +
  scale_y_continuous(labels = comma) +
  labs(
    title = "ROH length distribution",
    subtitle = paste0("ROH segments ≥100 kb; observed range = ",
                      sprintf("%.3f", min_len), "–", sprintf("%.3f", max_len), " Mb"),
    x = "ROH length (Mb)",
    y = "Number of ROH segments",
    tag = "C"
  ) +
  theme_roh(10)

## =========================
## Helper: recompute D in R
## 保证去掉 PE01225437 后 D 图也一致
## =========================
compute_freq_windows <- function(chr_info, roh, n_samples,
                                 win_bp = 1000000,
                                 freq_roh_bp = 100000) {

  roh2 <- roh %>% filter(length_bp >= freq_roh_bp)

  out_list <- list()
  idx <- 1L

  for (i in seq_len(nrow(chr_info))) {
    cinfo <- chr_info[i, ]
    chr_i <- cinfo$chr
    chr_start <- cinfo$chr_start
    chr_end   <- cinfo$chr_end
    chr_len   <- cinfo$chr_len
    chr_off   <- cinfo$offset
    bg_group  <- cinfo$bg_key

    nwin <- ceiling(chr_len / win_bp)

    chr_roh <- roh2 %>% filter(chr == chr_i)

    for (wi in seq_len(nwin)) {
      w0 <- wi - 1
      win_start <- chr_start + w0 * win_bp
      win_end   <- min(chr_start + wi * win_bp - 1, chr_end)
      mid       <- (win_start + win_end) / 2
      x         <- chr_off + (mid - chr_start)

      if (nrow(chr_roh) > 0) {
        n_ind <- chr_roh %>%
          filter(start_bp <= win_end, end_bp >= win_start) %>%
          distinct(sample) %>%
          nrow()
      } else {
        n_ind <- 0
      }

      out_list[[idx]] <- data.frame(
        chr = chr_i,
        win_i = w0,
        win_start_bp = win_start,
        win_end_bp = win_end,
        mid_bp = mid,
        x = x,
        bg_group = bg_group,
        n_individuals = n_ind,
        n_samples = n_samples,
        roh_frequency = ifelse(n_samples > 0, n_ind / n_samples, 0),
        stringsAsFactors = FALSE
      )
      idx <- idx + 1L
    }
  }

  bind_rows(out_list)
}

freq <- compute_freq_windows(
  chr_info = chr_info,
  roh = roh,
  n_samples = nrow(froh),
  win_bp = WINDOW_BP,
  freq_roh_bp = FREQ_ROH_BP
)

## =========================
## D. Genome-wide ROH frequency
## 使用过滤后的样品重新计算
## =========================
pD <- ggplot() +
  geom_rect(
    data = chr_info,
    aes(xmin = xmin, xmax = xmax, ymin = -Inf, ymax = Inf, fill = bg_key),
    inherit.aes = FALSE,
    colour = NA,
    alpha = 1
  ) +
  geom_segment(
    data = freq,
    aes(x = x, xend = x, y = 0, yend = roh_frequency),
    colour = col_roh_freq,
    linewidth = 0.35,
    lineend = "butt"
  ) +
  scale_fill_manual(values = fill_values, guide = "none") +
  scale_x_continuous(
    breaks = chr_info$center,
    labels = chr_info$chr,
    expand = c(0.005, 0.005)
  ) +
  scale_y_continuous(
    labels = percent_format(accuracy = 1),
    limits = c(0, 1),
    expand = c(0, 0)
  ) +
  labs(
    title = "Genome-wide ROH frequency",
    subtitle = "ROH segments ≥100 kb; window size = 1 Mb",
    x = "Chromosome",
    y = "Frequency of individuals with long ROH",
    tag = "D"
  ) +
  theme_roh(10) +
  theme(
    axis.text.x = element_text(angle = 45, hjust = 1, size = 8)
  )

## =========================
## E. Representative individual ROH landscape
## 不展示 PE 开头样品
## 重新从 froh + roh 选择代表个体
## =========================
froh_e <- froh %>%
  filter(!grepl(E_EXCLUDE_PREFIX, sample)) %>%
  arrange(FROH, sample)

if (nrow(froh_e) < REPRESENTATIVE_N * 2) {
  stop("Not enough non-PE samples to select representative individuals for panel E.")
}

low_e  <- froh_e %>% slice_head(n = REPRESENTATIVE_N)
high_e <- froh_e %>% slice_tail(n = REPRESENTATIVE_N) %>% arrange(desc(FROH), sample)

rep_df <- bind_rows(high_e, low_e) %>%
  distinct(sample, .keep_all = TRUE) %>%
  mutate(
    sample_rank = seq_len(n()),
    y = rev(seq_len(n())),
    xmin_all = min(chr_info$xmin),
    xmax_all = max(chr_info$xmax),
    sample_label = paste0(sample, " (", signif(FROH, 3), ")")
  )

land_e <- roh %>%
  filter(sample %in% rep_df$sample, length_bp >= LANDSCAPE_ROH_BP)

land2 <- land_e %>%
  left_join(rep_df %>% select(sample, y), by = "sample") %>%
  left_join(
    chr_info %>% select(chr, seg_key, chr_xmin = xmin, chr_xmax = xmax),
    by = "chr"
  ) %>%
  mutate(
    xstart = as.numeric(xstart_bp <- NA),
    xend   = as.numeric(xend_bp <- NA)
  )

## 重新计算 landscape 的 xstart / xend
land2 <- land_e %>%
  left_join(rep_df %>% select(sample, y), by = "sample") %>%
  left_join(
    chr_info %>% select(chr, chr_start, chr_end, offset, seg_key, chr_xmin = xmin, chr_xmax = xmax),
    by = "chr"
  ) %>%
  mutate(
    adj_start = pmax(start_bp, chr_start),
    adj_end   = pmin(end_bp, chr_end),
    xstart    = offset + (adj_start - chr_start),
    xend      = offset + (adj_end - chr_start),
    xmid      = (xstart + xend) / 2,
    raw_width = pmax(xend - xstart, 1),
    plot_width = pmax(raw_width, MIN_VISUAL_WIDTH_BP),
    xstart_plot = pmax(chr_xmin, xmid - plot_width / 2),
    xend_plot   = pmin(chr_xmax, xmid + plot_width / 2),
    ymin = y - ROH_TRACK_HALF_HEIGHT,
    ymax = y + ROH_TRACK_HALF_HEIGHT
  )

baseline_df <- rep_df %>%
  mutate(
    ymin = y - BASELINE_HALF_HEIGHT,
    ymax = y + BASELINE_HALF_HEIGHT
  )

pE <- ggplot() +
  geom_rect(
    data = chr_info,
    aes(xmin = xmin, xmax = xmax, ymin = -Inf, ymax = Inf, fill = bg_key),
    inherit.aes = FALSE,
    colour = NA,
    alpha = 1
  ) +
  geom_rect(
    data = baseline_df,
    aes(xmin = xmin_all, xmax = xmax_all, ymin = ymin, ymax = ymax),
    inherit.aes = FALSE,
    fill = baseline_col,
    colour = NA,
    alpha = 0.95
  ) +
  geom_rect(
    data = land2,
    aes(
      xmin = xstart_plot,
      xmax = xend_plot,
      ymin = ymin,
      ymax = ymax,
      fill = seg_key
    ),
    inherit.aes = FALSE,
    colour = NA,
    alpha = 0.92
  ) +
  scale_fill_manual(
    values = c(fill_values, roh_values),
    guide = "none"
  ) +
  scale_x_continuous(
    breaks = chr_info$center,
    labels = chr_info$chr,
    expand = c(0.005, 0.005)
  ) +
  scale_y_continuous(
    breaks = rep_df$y,
    labels = rep_df$sample_label,
    expand = expansion(mult = c(0.03, 0.03))
  ) +
  labs(
    title = "Representative individual ROH landscape",
    subtitle = "ROH segments ≥100 kb; five most inbred individuals are shown above and five least inbred individuals below",
    x = "Chromosome",
    y = expression("Individuals (" * F[ROH] * ")"),
    tag = "E"
  ) +
  theme_roh(10) +
  theme(
    panel.grid.major.y = element_blank(),
    axis.text.y = element_text(size = 8, colour = "grey20"),
    axis.text.x = element_text(size = 8),
    axis.title.y = element_text(size = 11),
    plot.title = element_text(size = 14, face = "bold"),
    plot.subtitle = element_text(size = 10.5, colour = "grey35")
  )

## =========================
## Combined
## =========================
combined <- (pA | pB) / (pC | pD) / pE +
  plot_layout(heights = c(1, 1, 1.35)) +
  plot_annotation(tag_levels = NULL) &
  theme(plot.tag = element_text(face = "bold", size = 14))

## =========================
## Write outputs
## =========================
save_both(pA, paste0(out_prefix, ".FigA_FROH_distribution"), 5.2, 3.5)
save_both(pB, paste0(out_prefix, ".FigB_cumulative_FROH_contribution"), 5.4, 3.5)
save_both(pC, paste0(out_prefix, ".FigC_ROH_length_distribution"), 5.2, 3.5)
save_both(pD, paste0(out_prefix, ".FigD_genomewide_ROH_frequency_ge100kb"), 5.5, 3.6)
save_both(pE, paste0(out_prefix, ".FigE_representative_ROH_landscape_ge100kb"), 13.5, 5.2)
save_both(combined, paste0(out_prefix, ".00_main_ROH_FROH_final_Dge100kb_Ege100kb"), 11.8, 12.6)

message("[DONE] ROH/FROH final plots generated.")
message("[INFO] Globally excluded sample: ", EXCLUDE_SAMPLE_GLOBAL)
message("[INFO] E panel excluded prefix: ", E_EXCLUDE_PREFIX)