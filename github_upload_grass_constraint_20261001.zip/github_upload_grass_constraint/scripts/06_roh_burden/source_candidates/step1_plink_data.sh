#!/bin/bash
#SBATCH --job-name=KING_DIRECT_VCF
#SBATCH --output=king_direct.%j.out
#SBATCH --error=king_direct.%j.err
#SBATCH --cpus-per-task=10
#SBATCH -p FAT2

# ===== 关键配置 =====
SOURCE_VCF="./Atau.vcf.gz"
CONTAINER=~/liuliangmin/4.may/software/Reseq_genek.sif

echo "===== 开始处理VCF文件 ====="
echo "开始时间: $(date)"

# ===== 1. 提取样品（缺失率低于0.15的样品）=====
echo "===== 正在提取样品 ====="
singularity exec $CONTAINER bcftools view -S keep_142.list \
                 -Oz -o extracted_142sp_Atau.vcf.gz \
                 $SOURCE_VCF

# 检查文件是否成功生成
if [ ! -f "extracted_142sp_Atau.vcf.gz" ]; then
    echo "错误: 样品提取失败"
    exit 1
fi

# ===== 2. 重命名染色体并输出VCF =====
echo "===== 正在重命名染色体并输出VCF ====="
singularity exec $CONTAINER bcftools annotate --rename-chrs chrom_map.txt \
    extracted_142sp_Atau.vcf.gz \
    -Oz -o extracted_142sp_Atau.renamed.vcf.gz

# 检查重命名是否成功
if [ ! -f "extracted_142sp_Atau.renamed.vcf.gz" ]; then
    echo "错误: 染色体重命名失败"
    exit 1
fi

# ===== 3. 索引新VCF文件 =====
echo "===== 正在索引VCF文件 ====="
singularity exec $CONTAINER bcftools index extracted_142sp_Atau.renamed.vcf.gz

# ===== 4. 转换为PLINK格式（处理下划线问题）=====
echo "===== 转换为PLINK格式 ====="
singularity exec $CONTAINER plink --vcf extracted_142sp_Atau.renamed.vcf.gz \
    --allow-extra-chr \
    --chr-set 7 \
    --double-id \
    --make-bed \
    --out king_direct

# 检查PLINK文件是否成功生成
if [ ! -f "king_direct.bed" ] || [ ! -f "king_direct.bim" ] || [ ! -f "king_direct.fam" ]; then
    echo "错误: PLINK格式转换失败"
    exit 1
fi

# ===== 5. 检查样品ID处理结果 =====
echo "===== 检查样品ID处理结果 ====="
echo "前10个样品ID在fam文件中的格式："
head king_direct.fam | cut -d' ' -f1,2

# ===== 6. 结果报告 =====
echo "===== 分析结果 ====="
echo "样本数: $(wc -l < king_direct.fam)"
echo "SNP总数: $(wc -l < king_direct.bim)"
echo "处理完成时间: $(date)"
echo "===== 处理完成 ====="