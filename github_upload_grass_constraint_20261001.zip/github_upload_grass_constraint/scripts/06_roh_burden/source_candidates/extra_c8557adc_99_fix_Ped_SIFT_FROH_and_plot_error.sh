#!/usr/bin/env bash
set -euo pipefail

WORKDIR="/gpfs/hpc/home/kib_unit/lidezhu/liuliangmin/6.pop/05.FROH"
OUTROOT="Ped_SIFT_polar_unpolar_pipeline"

cd "${WORKDIR}"

RUN_SH="${OUTROOT}/scripts/00_run_Ped_SIFT_polar_unpolar.sh"
PLOT_R="${OUTROOT}/scripts/01_plot_PedALL_SIFT_two_layers.R"

if [[ ! -s "${RUN_SH}" ]]; then
    echo "[ERROR] Cannot find ${RUN_SH}" >&2
    exit 1
fi

if [[ ! -s "${PLOT_R}" ]]; then
    echo "[ERROR] Cannot find ${PLOT_R}" >&2
    exit 1
fi

mkdir -p "${OUTROOT}/logs"

ts=$(date +%Y%m%d_%H%M%S)

cp -f "${RUN_SH}" "${RUN_SH}.bak.${ts}"
cp -f "${PLOT_R}" "${PLOT_R}.bak.${ts}"

echo "[INFO] Backup:"
echo "  ${RUN_SH}.bak.${ts}"
echo "  ${PLOT_R}.bak.${ts}"

###############################################################################
# 1. Patch 00_run_Ped_SIFT_polar_unpolar.sh
#    Replace fixed FROH_FILE line and old missing-FROH block with auto-detection.
###############################################################################

python3 - <<'PY'
from pathlib import Path
import re

path = Path("Ped_SIFT_polar_unpolar_pipeline/scripts/00_run_Ped_SIFT_polar_unpolar.sh")
text = path.read_text()

auto_block = r'''
###############################################################################
# Auto-detect FROH file
###############################################################################

FROH_FILE_DEFAULT_1="ROH_pipeline/Ped/04_froh/plink_kb100_gap1000_winmiss5/FROH.final.plink.kb100_gap1000_winmiss5.tsv"
FROH_FILE_DEFAULT_2="ROH_pipeline/Ped/04_froh/plink_kb100_gap1000_winmiss5/FROH.final.plink.local3.tsv"
FROH_FILE_DEFAULT_3="ROH_pipeline/Ped/04_froh/plink_kb100_gap1000_winmiss5/FROH.final.plink.tsv"
FROH_FILE_DEFAULT_4="ROH_pipeline/Ped/04_froh/plink/FROH.final.plink.local3.tsv"
FROH_FILE_DEFAULT_5="ROH_pipeline/Ped/04_froh/plink/FROH.final.plink.tsv"

if [[ -s "${FROH_FILE_DEFAULT_1}" ]]; then
    FROH_FILE="${FROH_FILE_DEFAULT_1}"
elif [[ -s "${FROH_FILE_DEFAULT_2}" ]]; then
    FROH_FILE="${FROH_FILE_DEFAULT_2}"
elif [[ -s "${FROH_FILE_DEFAULT_3}" ]]; then
    FROH_FILE="${FROH_FILE_DEFAULT_3}"
elif [[ -s "${FROH_FILE_DEFAULT_4}" ]]; then
    FROH_FILE="${FROH_FILE_DEFAULT_4}"
elif [[ -s "${FROH_FILE_DEFAULT_5}" ]]; then
    FROH_FILE="${FROH_FILE_DEFAULT_5}"
else
    echo "[WARN] Missing FROH file in expected locations."
    echo "[WARN] Continue with FROH = NA"
    FROH_FILE="NA"
fi

echo "[INFO] FROH_FILE = ${FROH_FILE}"
'''.strip()

# Remove old simple FROH_FILE assignment if present
text = re.sub(
    r'\nFROH_FILE="ROH_pipeline/Ped/04_froh/[^"\n]+FROH[^"\n]*"\n',
    "\n" + auto_block + "\n",
    text,
    count=1
)

# If there was no hard-coded FROH_FILE assignment, insert after ROH_SEG line
if auto_block not in text:
    m = re.search(r'ROH_SEG="[^"\n]+"\n', text)
    if not m:
        raise SystemExit("[ERROR] Cannot find ROH_SEG line to insert FROH auto-detection block.")
    text = text[:m.end()] + "\n" + auto_block + "\n" + text[m.end():]

# Remove the old missing-FROH warning block if it still exists.
old_block_pattern = r'''
if \[\[ ! -s "\$\{FROH_FILE\}" \]\]; then
\s*echo "\[WARN\] Missing FROH file: \$\{FROH_FILE\}"
\s*echo "\[WARN\] Continue with FROH = NA"
\s*FROH_FILE="NA"
fi
'''
text = re.sub(old_block_pattern, "", text, flags=re.MULTILINE)

# Also remove a common alternative old block with >&2 or spacing variations.
text = re.sub(
    r'\nif \[\[ ! -s "\$\{FROH_FILE\}" \]\]; then\n(?:[^\n]*\n){1,6}?fi\n',
    lambda m: "" if "Missing FROH" in m.group(0) and 'FROH_FILE="NA"' in m.group(0) else m.group(0),
    text,
    count=1
)

path.write_text(text)
print("[INFO] Patched FROH auto-detection in:", path)
PY

###############################################################################
# 2. Patch R plotting script:
#    Replace make_p_labels() with a safe version that always returns 'group'.
###############################################################################

python3 - <<'PY'
from pathlib import Path

path = Path("Ped_SIFT_polar_unpolar_pipeline/scripts/01_plot_PedALL_SIFT_two_layers.R")
text = path.read_text()

start_key = "make_p_labels <- function"
end_key = "pretty_binwidth <- function"

start = text.find(start_key)
if start < 0:
    raise SystemExit("[ERROR] Cannot find make_p_labels function in R script.")

end = text.find(end_key, start)
if end < 0:
    raise SystemExit("[ERROR] Cannot find pretty_binwidth function after make_p_labels.")

safe_func = r'''
make_p_labels <- function(df, xcol, ycol, group_col) {
  empty_out <- tibble(
    group = character(),
    x = numeric(),
    y = numeric(),
    label = character()
  )

  if (!all(c(xcol, ycol, group_col) %in% colnames(df))) {
    return(empty_out)
  }

  d <- df %>%
    filter(
      !is.na(.data[[xcol]]),
      !is.na(.data[[ycol]]),
      !is.na(.data[[group_col]])
    )

  if (nrow(d) == 0) {
    return(empty_out)
  }

  groups <- unique(d[[group_col]])

  yr <- range(d[[ycol]], na.rm = TRUE)
  xr <- range(d[[xcol]], na.rm = TRUE)

  if (!all(is.finite(yr)) || !all(is.finite(xr))) {
    return(empty_out)
  }

  y_span <- diff(yr)
  if (!is.finite(y_span) || y_span == 0) y_span <- 1

  x_span <- diff(xr)
  if (!is.finite(x_span) || x_span == 0) x_span <- 1

  x_pos <- xr[1] + 0.02 * x_span

  bind_rows(lapply(seq_along(groups), function(i) {
    g <- groups[i]
    sub <- d[d[[group_col]] == g, , drop = FALSE]
    p <- get_lm_p(sub, xcol, ycol)

    tibble(
      group = as.character(g),
      x = x_pos,
      y = yr[2] - (i - 1) * 0.085 * y_span,
      label = paste0(g, ": ", fmt_p(p))
    )
  }))
}

'''.lstrip()

text = text[:start] + safe_func + text[end:]

path.write_text(text)
print("[INFO] Patched safe make_p_labels() in:", path)
PY

###############################################################################
# 3. Show detected FROH files
###############################################################################

echo "============================================================"
echo "[INFO] Current FROH candidates:"
ls -lh ROH_pipeline/Ped/04_froh/plink_kb100_gap1000_winmiss5/*FROH* 2>/dev/null || true
ls -lh ROH_pipeline/Ped/04_froh/plink/*FROH* 2>/dev/null || true
echo "============================================================"

###############################################################################
# 4. Re-run calculation
###############################################################################

echo "[STEP 1] Re-run SIFT burden calculation"
bash "${RUN_SH}"

###############################################################################
# 5. Check FROH in output
###############################################################################

PER_SAMPLE="${OUTROOT}/04_summary/Ped_SIFT.PedC_PedD_PedALL.per_sample_burden.tsv"
SITE_AF="${OUTROOT}/04_summary/Ped_SIFT.PedC_PedD.site_AF.tsv.gz"
FIG_DIR="${OUTROOT}/05_figures"

if [[ ! -s "${PER_SAMPLE}" ]]; then
    echo "[ERROR] Missing per-sample result after calculation: ${PER_SAMPLE}" >&2
    exit 1
fi

if [[ ! -s "${SITE_AF}" ]]; then
    echo "[ERROR] Missing site-AF result after calculation: ${SITE_AF}" >&2
    exit 1
fi

echo "============================================================"
echo "[CHECK] FROH values in per-sample table:"
awk -F'\t' '
NR==1{
  for(i=1;i<=NF;i++) h[$i]=i
  print "FROH column index =", h["FROH"]
  next
}
NR<=8{
  print $1, $2, $3, $4, $5, $(h["FROH"])
}
' "${PER_SAMPLE}"
echo "============================================================"

###############################################################################
# 6. Re-run visualization
###############################################################################

echo "[STEP 2] Re-run visualization"
Rscript "${PLOT_R}" \
  "${PER_SAMPLE}" \
  "${SITE_AF}" \
  "${FIG_DIR}" \
  > "${OUTROOT}/logs/01_plot_PedALL_SIFT_two_layers.out" \
  2> "${OUTROOT}/logs/01_plot_PedALL_SIFT_two_layers.err"

echo "============================================================"
echo "[DONE] Fixed and re-run finished."
echo ""
echo "[Main outputs]"
echo "${PER_SAMPLE}"
echo "${SITE_AF}"
echo ""
echo "[Figures]"
echo "${FIG_DIR}/01_unpolarized_ALT/PedALL.SIFT.A_H.combined.pdf"
echo "${FIG_DIR}/02_polarized_derived/PedALL.SIFT.A_H.combined.pdf"
echo ""
echo "[Plot logs]"
echo "${OUTROOT}/logs/01_plot_PedALL_SIFT_two_layers.out"
echo "${OUTROOT}/logs/01_plot_PedALL_SIFT_two_layers.err"
echo "============================================================"
