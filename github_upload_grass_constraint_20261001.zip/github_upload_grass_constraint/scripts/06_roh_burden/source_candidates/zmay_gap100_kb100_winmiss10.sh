#!/usr/bin/env bash
#SBATCH --job-name=ROH_beagle
#SBATCH --partition=FAT1
#SBATCH --cpus-per-task=1
#SBATCH --mem=100G
#SBATCH --array=1-6%6
#SBATCH --output=logs/ROH_beagle_%A_%a.out
#SBATCH --error=logs/ROH_beagle_%A_%a.err

set -euo pipefail

############################################
# 0) 输入与软件
############################################
VCF_IN="all.filtered.snp.vcf.gz"
CHR_LIST="bu_chr.list"

BEAGLE_JAR="/gpfs/hpc/home/kib_unit/lidezhu/biosoftware/beagle.27Feb25.75f.jar"

THREADS=${SLURM_CPUS_PER_TASK}

OUTDIR="ROH_pipeline"
mkdir -p "${OUTDIR}"/{00_prep,01_beagle,02_plink,03_froh,logs}

############################################
# 1) 当前染色体
############################################
CHR=$(sed -n "${SLURM_ARRAY_TASK_ID}p" "${CHR_LIST}")
echo "[INFO] CHR=${CHR}"

############################################
# 2) 构建 ROH 专用 VCF（仅 bi-allelic SNP）
############################################
VCF_ROH="${OUTDIR}/00_prep/${CHR}.roh.snps.vcf.gz"

bcftools view \
  -r "${CHR}" \
  -m2 -M2 -v snps \
  -Oz \
  -o "${VCF_ROH}" \
  "${VCF_IN}"

bcftools index -f "${VCF_ROH}"

############################################
# 3) Beagle 填充（无参考）
############################################
BEAGLE_PREFIX="${OUTDIR}/01_beagle/${CHR}.beagle"
VCF_IMPUTED="${BEAGLE_PREFIX}.vcf.gz"

java -Xmx100g -jar "${BEAGLE_JAR}" \
  gt="${VCF_ROH}" \
  out="${BEAGLE_PREFIX}" \
  nthreads="${THREADS}" \
  seed=2024 \
  impute=true

bcftools index -f "${VCF_IMPUTED}"

############################################
# 4) PLINK：ROH 调用
############################################
PLINK_PREFIX="${OUTDIR}/02_plink/${CHR}.plink"

plink \
  --vcf "${VCF_IMPUTED}" \
  --double-id \
  --allow-extra-chr \
  --make-bed \
  --out "${PLINK_PREFIX}"

ROH_PREFIX="${OUTDIR}/02_plink/${CHR}.roh"

plink \
  --bfile "${PLINK_PREFIX}" \
  --allow-extra-chr \
  --homozyg \
  --homozyg-snp 50 \
  --homozyg-window-snp 50 \
  --homozyg-density 50 \
  --homozyg-gap 100 \
  --homozyg-kb 100 \
  --homozyg-window-het 1 \
  --homozyg-window-missing 10 \
  --homozyg-window-threshold 0.05 \
  --out "${ROH_PREFIX}"

############################################
# 5) 汇总该染色体 ROH 总长度（bp）
############################################
HOM_FILE="${ROH_PREFIX}.hom"
OUT_SUM="${OUTDIR}/03_froh/${CHR}.roh_sum.bp.tsv"

if [[ ! -s "${HOM_FILE}" ]]; then
  echo -e "FID\tIID\tS_ROH_bp_chr" > "${OUT_SUM}"
  exit 0
fi

KB_COL=$(head -n 1 "${HOM_FILE}" | awk '
{
  for(i=1;i<=NF;i++){
    if(toupper($i)=="KB"){print i; exit}
  }
  print 0
}')

if [[ "${KB_COL}" -eq 0 ]]; then
  echo "[ERROR] Cannot find KB column"
  exit 1
fi

awk -v kbcol="${KB_COL}" 'BEGIN{OFS="\t"}
NR>1{
  key=$1"\t"$2
  sum[key]+=$kbcol*1000
}
END{
  print "FID","IID","S_ROH_bp_chr"
  for(k in sum) print k, sum[k]
}' "${HOM_FILE}" \
| sort -k1,1 -k2,2 \
> "${OUT_SUM}"

echo "[INFO] Finished CHR=${CHR}"
