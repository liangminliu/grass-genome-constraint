#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import argparse
import bisect
import gzip
import os
import re
import subprocess
import sys
from collections import defaultdict

import pandas as pd


def parse_args():
    p = argparse.ArgumentParser(
        description="Direct streaming calculation of SIFT deleterious ALT burden from VCF.gz without BGZF/tabix/pysam."
    )
    p.add_argument("--vcf", required=True)
    p.add_argument("--roh", required=True)
    p.add_argument("--froh", required=True)
    p.add_argument("--species", default="Teosinte")
    p.add_argument("--sift-cutoff", type=float, default=0.05)
    p.add_argument("--out-prefix", required=True)
    return p.parse_args()


def init_counter():
    return {
        "called_sites": 0,
        "called_alleles": 0,
        "alt_allele_count": 0,
        "het_loci": 0,
        "hom_alt_loci": 0,
    }


def update_counter(d, dosage):
    d["called_sites"] += 1
    d["called_alleles"] += 2
    d["alt_allele_count"] += dosage
    if dosage == 1:
        d["het_loci"] += 1
    elif dosage == 2:
        d["hom_alt_loci"] += 1


def add_rates(df):
    if df.empty:
        return df
    df["alt_allele_rate"] = df["alt_allele_count"] / df["called_alleles"].replace(0, pd.NA)
    df["het_loci_rate"] = df["het_loci"] / df["called_sites"].replace(0, pd.NA)
    df["hom_alt_loci_rate"] = df["hom_alt_loci"] / df["called_sites"].replace(0, pd.NA)
    return df


def open_vcf_stream(path):
    """
    Open VCF as text stream.

    For .gz:
      use zcat so that ordinary gzip / non-BGZF files can be streamed.
      zcat return code is checked after reading.

    For plain .vcf:
      use normal open.
    """
    if path.endswith(".gz"):
        proc = subprocess.Popen(
            ["zcat", path],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            bufsize=1024 * 1024,
        )
        return proc.stdout, proc
    else:
        return open(path, "rt"), None


def close_vcf_stream(handle, proc):
    if proc is None:
        handle.close()
        return 0, ""

    handle.close()
    stderr = proc.stderr.read()
    ret = proc.wait()
    return ret, stderr


def parse_info_dict(info_str):
    info = {}
    if info_str == ".":
        return info

    for item in info_str.split(";"):
        if not item:
            continue
        if "=" in item:
            k, v = item.split("=", 1)
            info[k] = v
        else:
            info[item] = True
    return info


def extract_sift_scores(info_str):
    """
    Robust extraction of SIFT score from SIFT-containing INFO fields.

    The parser only searches fields whose key or value contains 'SIFT',
    and extracts numeric values in [0,1], especially decimals such as 0.03.
    """
    scores = []
    info = parse_info_dict(info_str)

    for k, v in info.items():
        text = str(v)
        kt = str(k)

        if "SIFT" not in kt.upper() and "SIFT" not in text.upper():
            continue

        # Prefer decimal values like 0.03, 0.000, 1.000
        nums = re.findall(r"(?<![A-Za-z0-9_.-])(?:0\.\d+|1\.0+)(?![A-Za-z0-9_.-])", text)
        for x in nums:
            try:
                f = float(x)
                if 0.0 <= f <= 1.0:
                    scores.append(f)
            except Exception:
                pass

        # Also support explicit SIFT=0 or SIFT=1
        if kt.upper() in {"SIFT", "SIFTSCORE", "SIFT_SCORE"}:
            for x in re.split(r"[,|]", text):
                try:
                    f = float(x)
                    if 0.0 <= f <= 1.0:
                        scores.append(f)
                except Exception:
                    pass

    return scores


def extract_annotation_class(info_str):
    s = info_str.lower()
    if "synonymous_variant" in s or "synonymous" in s:
        return "synonymous"
    if "missense_variant" in s or "missense" in s or "nonsynonymous" in s:
        return "missense"
    return "unknown"


def gt_to_alt_dosage(sample_field, gt_index):
    """
    Convert diploid GT to unpolarized ALT dosage.

    Examples:
      0/0 -> 0
      0/1 -> 1
      1/0 -> 1
      1/1 -> 2
      ./. -> None
    """
    if sample_field in {".", "./.", ".|."}:
        return None

    parts = sample_field.split(":")
    if gt_index >= len(parts):
        return None

    gt = parts[gt_index]

    if gt in {".", "./.", ".|."}:
        return None

    alleles = re.split(r"[\/|]", gt)
    if len(alleles) != 2:
        return None

    if "." in alleles:
        return None

    try:
        a0 = int(alleles[0])
        a1 = int(alleles[1])
    except Exception:
        return None

    # Only biallelic SNPs are expected. Ignore non-0/1 alleles.
    if a0 not in (0, 1) or a1 not in (0, 1):
        return None

    return a0 + a1


def read_roh_intervals(path):
    """
    Return:
      roh[sample][chrom] = {"starts": [...], "ends": [...]}
    """
    df = pd.read_csv(path, sep="\t")
    lower = {c.lower(): c for c in df.columns}

    sample_col = None
    for x in ["sample", "iid", "id"]:
        if x in lower:
            sample_col = lower[x]
            break

    chr_col = None
    for x in ["chr", "chrom", "chromosome"]:
        if x in lower:
            chr_col = lower[x]
            break

    start_col = None
    for x in ["start_bp", "pos1", "start", "bp1"]:
        if x in lower:
            start_col = lower[x]
            break

    end_col = None
    for x in ["end_bp", "pos2", "end", "bp2"]:
        if x in lower:
            end_col = lower[x]
            break

    if sample_col is None or chr_col is None or start_col is None or end_col is None:
        raise RuntimeError(
            f"Cannot detect ROH columns in {path}. "
            f"Need sample/IID, chr, start_bp, end_bp-like columns. "
            f"Columns={list(df.columns)}"
        )

    tmp = defaultdict(lambda: defaultdict(list))

    for _, r in df.iterrows():
        s = str(r[sample_col])
        c = str(r[chr_col])
        try:
            st = int(r[start_col])
            en = int(r[end_col])
        except Exception:
            continue
        if en < st:
            st, en = en, st
        tmp[s][c].append((st, en))

    roh = defaultdict(dict)

    for s in tmp:
        for c in tmp[s]:
            intervals = sorted(tmp[s][c])
            starts = [x[0] for x in intervals]
            ends = [x[1] for x in intervals]
            roh[s][c] = {"starts": starts, "ends": ends}

    return roh


def in_roh(pos, roh_obj):
    if not roh_obj:
        return False

    starts = roh_obj["starts"]
    ends = roh_obj["ends"]

    idx = bisect.bisect_right(starts, pos) - 1
    if idx < 0:
        return False
    return pos <= ends[idx]


def read_froh(path):
    df = pd.read_csv(path, sep="\t")
    lower = {c.lower(): c for c in df.columns}

    sample_col = None
    for x in ["sample", "iid", "id"]:
        if x in lower:
            sample_col = lower[x]
            break

    froh_col = None
    for x in ["froh", "f_roh", "froh_total", "froh_all"]:
        if x in lower:
            froh_col = lower[x]
            break

    if sample_col is None or froh_col is None:
        raise RuntimeError(
            f"Cannot detect sample/FROH columns in {path}. "
            f"Columns={list(df.columns)}"
        )

    out = df[[sample_col, froh_col]].copy()
    out.columns = ["sample", "FROH"]
    out["sample"] = out["sample"].astype(str)
    return out


def main():
    args = parse_args()

    print(f"[INFO] VCF          = {args.vcf}")
    print(f"[INFO] ROH          = {args.roh}")
    print(f"[INFO] FROH         = {args.froh}")
    print(f"[INFO] species      = {args.species}")
    print(f"[INFO] sift_cutoff  = {args.sift_cutoff}")
    print(f"[INFO] out_prefix   = {args.out_prefix}")

    print("[INFO] Reading ROH intervals...")
    roh = read_roh_intervals(args.roh)
    print(f"[INFO] ROH samples loaded: {len(roh)}")

    samples = []
    site_rows = []

    deleterious = defaultdict(init_counter)
    synonymous = defaultdict(init_counter)
    all_used = defaultdict(init_counter)
    region_counter = defaultdict(init_counter)

    n_total_records = 0
    n_biallelic_records = 0
    n_sift_del_sites = 0
    n_syn_sites = 0
    n_used_sites = 0
    n_header_lines = 0

    print("[INFO] Streaming VCF...")
    handle, proc = open_vcf_stream(args.vcf)

    try:
        for line in handle:
            line = line.rstrip("\n")

            if not line:
                continue

            if line.startswith("##"):
                n_header_lines += 1
                continue

            if line.startswith("#CHROM"):
                fields = line.split("\t")
                if len(fields) < 10:
                    raise RuntimeError("VCF header does not contain sample columns.")
                samples = fields[9:]
                print(f"[INFO] VCF samples detected: {len(samples)}")
                continue

            if not samples:
                raise RuntimeError("VCF sample header line #CHROM was not found before records.")

            n_total_records += 1

            arr = line.split("\t")
            if len(arr) < 10:
                continue

            chrom, pos_s, vid, ref, alt, qual, flt, info_str, fmt = arr[:9]
            sample_fields = arr[9:]

            if "," in alt:
                continue
            if alt in {".", "<NON_REF>", "NON_REF"}:
                continue

            try:
                pos = int(pos_s)
            except Exception:
                continue

            n_biallelic_records += 1

            scores = extract_sift_scores(info_str)
            annotation_class = extract_annotation_class(info_str)

            variant_class = None
            min_sift = None

            if scores:
                min_sift = min(scores)
                if min_sift < args.sift_cutoff:
                    variant_class = "SIFT_deleterious"
                    n_sift_del_sites += 1

            if variant_class is None and annotation_class == "synonymous":
                variant_class = "synonymous"
                n_syn_sites += 1

            if variant_class is None:
                continue

            n_used_sites += 1

            site_rows.append({
                "chrom": chrom,
                "pos": pos,
                "ref": ref,
                "alt": alt,
                "variant_class": variant_class,
                "min_sift": min_sift if min_sift is not None else "NA",
                "annotation_class": annotation_class,
            })

            fmt_keys = fmt.split(":")
            if "GT" not in fmt_keys:
                continue
            gt_index = fmt_keys.index("GT")

            for s, sf in zip(samples, sample_fields):
                dosage = gt_to_alt_dosage(sf, gt_index)
                if dosage is None:
                    continue

                if variant_class == "SIFT_deleterious":
                    update_counter(deleterious[s], dosage)
                elif variant_class == "synonymous":
                    update_counter(synonymous[s], dosage)

                update_counter(all_used[s], dosage)

                sample_roh_chrom = roh.get(s, {}).get(chrom)
                region = "ROH" if in_roh(pos, sample_roh_chrom) else "nonROH"
                update_counter(region_counter[(s, variant_class, region)], dosage)

    finally:
        zcat_ret, zcat_stderr = close_vcf_stream(handle, proc)

    print(f"[INFO] VCF header lines       : {n_header_lines}")
    print(f"[INFO] VCF total records      : {n_total_records}")
    print(f"[INFO] Biallelic records used : {n_biallelic_records}")
    print(f"[INFO] SIFT deleterious sites : {n_sift_del_sites}")
    print(f"[INFO] Synonymous sites       : {n_syn_sites}")
    print(f"[INFO] Total used sites       : {n_used_sites}")
    print(f"[INFO] zcat return code       : {zcat_ret}")

    if zcat_stderr:
        print("[WARN] zcat stderr message:", file=sys.stderr)
        print(zcat_stderr, file=sys.stderr)

    if zcat_ret != 0:
        print(
            "[WARN] zcat returned non-zero status. "
            "The source gzip may have EOF/checksum/truncation issues. "
            "Statistics were calculated from records successfully streamed before zcat stopped.",
            file=sys.stderr,
        )

    os.makedirs(os.path.dirname(args.out_prefix), exist_ok=True)

    site_df = pd.DataFrame(site_rows)
    site_out = args.out_prefix + ".site_class.tsv"
    site_df.to_csv(site_out, sep="\t", index=False)
    print(f"[OUT] {site_out}")

    burden_rows = []
    for s in samples:
        for cls, dic in [
            ("SIFT_deleterious", deleterious[s]),
            ("synonymous", synonymous[s]),
            ("all_used", all_used[s]),
        ]:
            row = {
                "species": args.species,
                "sample": s,
                "variant_class": cls,
            }
            row.update(dic)
            burden_rows.append(row)

    burden_df = pd.DataFrame(burden_rows)
    burden_df = add_rates(burden_df)

    burden_out = args.out_prefix + ".per_sample_burden.tsv"
    burden_df.to_csv(burden_out, sep="\t", index=False)
    print(f"[OUT] {burden_out}")

    region_rows = []
    for (s, cls, region), dic in region_counter.items():
        row = {
            "species": args.species,
            "sample": s,
            "variant_class": cls,
            "region": region,
        }
        row.update(dic)
        region_rows.append(row)

    region_df = pd.DataFrame(region_rows)
    region_df = add_rates(region_df)

    region_out = args.out_prefix + ".per_sample_region_burden.tsv"
    region_df.to_csv(region_out, sep="\t", index=False)
    print(f"[OUT] {region_out}")

    froh_df = read_froh(args.froh)

    del_df = burden_df[burden_df["variant_class"] == "SIFT_deleterious"].copy()
    merge_df = del_df.merge(froh_df, on="sample", how="left")

    merge_out = args.out_prefix + ".FROH.merge.tsv"
    merge_df.to_csv(merge_out, sep="\t", index=False)
    print(f"[OUT] {merge_out}")

    summary_out = args.out_prefix + ".stream_read.summary.tsv"
    summary_df = pd.DataFrame([{
        "vcf": args.vcf,
        "zcat_return_code": zcat_ret,
        "n_header_lines": n_header_lines,
        "n_total_records": n_total_records,
        "n_biallelic_records": n_biallelic_records,
        "n_sift_deleterious_sites": n_sift_del_sites,
        "n_synonymous_sites": n_syn_sites,
        "n_used_sites": n_used_sites,
        "n_samples": len(samples),
    }])
    summary_df.to_csv(summary_out, sep="\t", index=False)
    print(f"[OUT] {summary_out}")

    print("[DONE] Direct streaming SIFT calculation finished.")


if __name__ == "__main__":
    main()
