#!/usr/bin/env Rscript

suppressPackageStartupMessages({
  library(readr)
  library(dplyr)
  library(tidyr)
  library(ggplot2)
  library(patchwork)
  library(scales)
})

args <- commandArgs(trailingOnly = TRUE)

if (length(args) < 3) {
  stop("Usage:
Rscript 02_plot_Ped_GERP_AH.R <table_dir> <mode: polarized|unpolarized> <out_prefix> [af_binwidth]

Example:
Rscript Ped_GERP_fullgenome_pipeline/scripts/02_plot_Ped_GERP_AH.R \
  Ped_GERP_fullgenome_pipeline/01_tables \
  polarized \
  Ped_GERP_fullgenome_pipeline/03_plots/Ped_GERP_fullgenome \
  0.025
")
}

table_dir <- args[1]
mode_use <- args[2]
out_prefix <- args[3]
af_binwidth <- ifelse(length(args) >= 4, as.numeric(args[4]), 0.025)

dir.create(dirname(out_prefix), recursive = TRUE, showWarnings = FALSE)

## =========================================================
## Helper functions
## =========================================================

read_tsv2 <- function(x) {
  read_tsv(
    file.path(table_dir, x),
    show_col_types = FALSE,
    progress = FALSE,
    na = c("NA", "NaN", "nan", "")
  )
}

to_num <- function(df) {
  df %>%
    mutate(across(everything(), ~ suppressWarnings(type.convert(.x, as.is = TRUE))))
}

save_both <- function(plot, prefix, width, height) {
  pdf_file <- paste0(prefix, ".pdf")
  png_file <- paste0(prefix, ".png")
  pdf_dev <- if (capabilities("cairo")) grDevices::cairo_pdf else grDevices::pdf
  ggsave(pdf_file, plot, width = width, height = height, units = "in", device = pdf_dev)
  ggsave(png_file, plot, width = width, height = height, units = "in", dpi = 600)
  message("[WRITE] ", pdf_file)
  message("[WRITE] ", png_file)
}

theme_pub <- function(base_size = 11) {
  theme_classic(base_size = base_size) +
    theme(
      text = element_text(color = "grey15"),
      axis.text = element_text(color = "grey25", size = base_size),
      axis.title = element_text(color = "grey10", size = base_size + 1),
      axis.line = element_line(color = "grey30", linewidth = 0.45),
      axis.ticks = element_line(color = "grey30", linewidth = 0.35),
      panel.grid.major.y = element_line(color = "grey90", linewidth = 0.32),
      panel.grid.major.x = element_blank(),
      panel.grid.minor = element_blank(),
      plot.title = element_text(hjust = 0.5, face = "plain", size = base_size + 1),
      plot.tag = element_text(face = "bold", size = base_size + 5),
      legend.title = element_blank(),
      legend.key = element_blank(),
      legend.position = "top",
      legend.text = element_text(size = base_size - 1),
      strip.background = element_rect(fill = "white", color = "grey25", linewidth = 0.45),
      strip.text = element_text(face = "bold", size = base_size - 1),
      plot.margin = margin(6, 6, 6, 6)
    )
}

fmt_p <- function(p) {
  if (!is.finite(p)) return("p = NA")
  if (p < 0.001) return("p < 0.001")
  paste0("p = ", formatC(p, format = "f", digits = 3))
}

lm_p <- function(x, y) {
  ok <- is.finite(x) & is.finite(y)
  x <- x[ok]
  y <- y[ok]
  if (length(x) < 4) return(NA_real_)
  if (length(unique(x)) < 2 || length(unique(y)) < 2) return(NA_real_)
  fit <- try(lm(y ~ x), silent = TRUE)
  if (inherits(fit, "try-error")) return(NA_real_)
  coef(summary(fit))[2, 4]
}

safe_paired_wilcox <- function(nonroh, roh) {
  ok <- is.finite(nonroh) & is.finite(roh)
  if (sum(ok) < 4) return(NA_real_)
  suppressWarnings(wilcox.test(nonroh[ok], roh[ok], paired = TRUE)$p.value)
}

p_stars <- function(p) {
  if (!is.finite(p)) return("NA")
  if (p < 0.001) return("***")
  if (p < 0.01) return("**")
  if (p < 0.05) return("*")
  "ns"
}

nice_y_top <- function(x) {
  if (!is.finite(x) || x <= 0) return(1)
  if (x <= 1) return(ceiling(x * 10) / 10)
  if (x <= 5) return(ceiling(x))
  if (x <= 10) return(ceiling(x))
  if (x <= 50) return(ceiling(x / 5) * 5)
  if (x <= 100) return(ceiling(x / 10) * 10)
  if (x <= 1000) return(ceiling(x / 50) * 50)
  if (x <= 10000) return(ceiling(x / 500) * 500)
  if (x <= 100000) return(ceiling(x / 5000) * 5000)
  ceiling(x / 10000) * 10000
}

round_up_to <- function(x, base) {
  ceiling(x / base) * base
}

## =========================================================
## Colors and histogram style
## =========================================================

col_gt4 <- "#4E8A83"
col_het <- "#B6D2CD"
col_hom <- "#2E6F73"
col_total <- "#DDEDEA"

col_nonroh <- "#8D78C9"
col_roh <- "#E3A857"
col_gerpneg <- "#B7B7B7"

comp_cols <- c(
  "Total" = col_total,
  "Homozygous" = col_hom,
  "Heterozygous" = col_het
)

region_cols <- c(
  "Non-ROH" = col_nonroh,
  "ROH" = col_roh
)

BAR_OUTLINE <- 0.10

## A: single class fills one full bin.
## B and supplementary: two classes split the same bin into left and right halves.
HALF_SHIFT <- 0.25
HALF_WIDTH <- 0.50

## =========================================================
## Read input tables
## =========================================================

site <- read_tsv2("Ped_GERP.site_AF.tsv") %>%
  to_num() %>%
  filter(mode == mode_use) %>%
  mutate(
    variant_class = recode(
      as.character(variant_class),
      "GERP4" = "GERP > 4",
      "GERP_lt0" = "GERP < 0"
    ),
    AF = as.numeric(target_af)
  ) %>%
  filter(is.finite(AF), AF >= 0, AF <= 1)

bc <- read_tsv2("plot_BC_GERP4_burden.tsv") %>%
  to_num() %>%
  filter(mode == mode_use) %>%
  mutate(
    sample = as.character(sample),
    FROH = as.numeric(FROH),
    value_count = as.numeric(value_count),
    value_rate = as.numeric(value_rate)
  ) %>%
  filter(is.finite(FROH))

ratio_all_in <- read_tsv2("plot_DE_GERP4_over_lt0_ratio.tsv") %>%
  to_num() %>%
  filter(mode == mode_use) %>%
  mutate(
    sample = as.character(sample),
    FROH = as.numeric(FROH),
    ratio_rate = as.numeric(ratio_rate)
  ) %>%
  filter(is.finite(FROH), is.finite(ratio_rate))

roh_ratio_in <- read_tsv2("plot_GH_ROH_nonROH_ratio.tsv") %>%
  to_num() %>%
  filter(mode == mode_use) %>%
  mutate(
    sample = as.character(sample),
    FROH = as.numeric(FROH),
    ratio_rate = as.numeric(ratio_rate),
    region = recode(as.character(region), "nonROH" = "Non-ROH", "ROH" = "ROH")
  ) %>%
  filter(is.finite(FROH), is.finite(ratio_rate))

allele_label <- ifelse(mode_use == "polarized", "Derived alleles", "ALT alleles")

## =========================================================
## A. AF histogram
## =========================================================

make_af_table <- function(df, classes, bw) {
  nbin <- round(1 / bw)

  grid <- expand_grid(
    variant_class = classes,
    bin_i = 0:(nbin - 1)
  )

  tab <- df %>%
    filter(variant_class %in% classes) %>%
    mutate(bin_i = pmin(nbin - 1, pmax(0, floor(AF / bw)))) %>%
    count(variant_class, bin_i, name = "n") %>%
    group_by(variant_class) %>%
    mutate(pct = 100 * n / sum(n)) %>%
    ungroup()

  grid %>%
    left_join(tab, by = c("variant_class", "bin_i")) %>%
    mutate(
      n = replace_na(n, 0),
      pct = replace_na(pct, 0),
      xmin = bin_i * bw,
      xmax = (bin_i + 1) * bw,
      xmid = (xmin + xmax) / 2
    )
}

af_gt4 <- make_af_table(site, c("GERP > 4"), af_binwidth)
ymax_A <- nice_y_top(max(af_gt4$pct, na.rm = TRUE))

pA <- ggplot(af_gt4) +
  geom_rect(
    aes(xmin = xmin, xmax = xmax, ymin = 0, ymax = pct),
    fill = col_gt4,
    colour = "black",
    linewidth = BAR_OUTLINE
  ) +
  geom_vline(
    xintercept = 0.25,
    linetype = "dashed",
    linewidth = 0.35,
    colour = "grey45"
  ) +
  scale_x_continuous(
    limits = c(-af_binwidth * 0.55, 1 + af_binwidth * 0.35),
    breaks = c(0, 0.25, 0.50, 0.75, 1.00),
    labels = number_format(accuracy = 0.01),
    expand = c(0, 0)
  ) +
  scale_y_continuous(
    limits = c(-0.04 * ymax_A, ymax_A),
    breaks = pretty(c(0, ymax_A), n = 5),
    expand = c(0, 0)
  ) +
  labs(
    title = "GERP > 4",
    x = "Allele frequency",
    y = "Percentage of SNPs"
  ) +
  theme_pub(11) +
  theme(
    legend.position = "none",
    plot.title = element_text(hjust = 0.5, size = 12)
  )

## =========================================================
## Supplementary AF: GERP < 0 and GERP > 4
## =========================================================

af_both <- make_af_table(site, c("GERP < 0", "GERP > 4"), af_binwidth) %>%
  mutate(
    bw = xmax - xmin,
    bar_w = bw * HALF_WIDTH,
    xmid2 = case_when(
      variant_class == "GERP < 0" ~ xmid - bw * HALF_SHIFT,
      variant_class == "GERP > 4" ~ xmid + bw * HALF_SHIFT,
      TRUE ~ xmid
    ),
    xmin2 = xmid2 - bar_w / 2,
    xmax2 = xmid2 + bar_w / 2
  )

ymax_AF2 <- nice_y_top(max(af_both$pct, na.rm = TRUE))

pAF_supp <- ggplot(af_both) +
  geom_rect(
    aes(xmin = xmin2, xmax = xmax2, ymin = 0, ymax = pct, fill = variant_class),
    colour = "black",
    linewidth = BAR_OUTLINE,
    alpha = 1
  ) +
  scale_fill_manual(values = c("GERP < 0" = col_gerpneg, "GERP > 4" = col_gt4)) +
  scale_x_continuous(
    limits = c(-af_binwidth * 0.55, 1 + af_binwidth * 0.35),
    breaks = c(0, 0.25, 0.50, 0.75, 1.00),
    labels = number_format(accuracy = 0.01),
    expand = c(0, 0)
  ) +
  scale_y_continuous(
    limits = c(-0.04 * ymax_AF2, ymax_AF2),
    breaks = pretty(c(0, ymax_AF2), n = 5),
    expand = c(0, 0)
  ) +
  labs(
    title = "GERP < 0 and GERP > 4",
    x = "Allele frequency",
    y = "Percentage of SNPs"
  ) +
  theme_pub(11) +
  theme(
    legend.position = c(0.78, 0.92),
    legend.direction = "horizontal",
    plot.title = element_text(hjust = 0.5, size = 12)
  )

## =========================================================
## B. Shared X-axis histogram
## Reference-like x-axis and wider bars.
##
## Key settings:
##   b_tick_step = 50,000
##   b_binwidth  = 25,000
##   Homozygous and Heterozygous split each bin into two half-width bars.
##
## Therefore each visible bar width is 12,500, close to the reference style
## and much wider than the previous 5,000-width bars.
## =========================================================

b_raw <- bc %>%
  filter(component %in% c("het", "hom")) %>%
  transmute(
    sample,
    group = recode(component, "hom" = "Homozygous", "het" = "Heterozygous"),
    value = value_count
  ) %>%
  filter(is.finite(value)) %>%
  mutate(group = factor(group, levels = c("Homozygous", "Heterozygous")))

b_med_raw <- b_raw %>%
  group_by(group) %>%
  summarise(
    med = median(value, na.rm = TRUE),
    .groups = "drop"
  )

## Reference-style X axis.
## Do not let one extreme outlier stretch the whole B panel.
b_tick_step <- 50000

b_xmax_core <- as.numeric(quantile(b_raw$value, 0.97, na.rm = TRUE))
b_xmax_med  <- max(b_med_raw$med, na.rm = TRUE) * 2.10
b_xmax_plot <- round_up_to(max(b_xmax_core, b_xmax_med, 250000), b_tick_step)

## Use only the central range for histogram display.
## This matches the reference-style B panel and prevents extreme values from compressing the bars.
b_plot <- b_raw %>%
  filter(value <= b_xmax_plot)

## Wider B bars:
## previous: b_tick_step / 5 = 10,000, then split into 5,000 bars
## current : b_tick_step / 2 = 25,000, then split into 12,500 bars
b_binwidth <- b_tick_step / 2
b_breaks <- seq(0, b_xmax_plot + b_binwidth, by = b_binwidth)

b_bins <- tibble(
  bin_id = seq_len(length(b_breaks) - 1),
  xmin = head(b_breaks, -1),
  xmax = tail(b_breaks, -1)
) %>%
  mutate(
    xmid = (xmin + xmax) / 2
  )

b_hist <- b_plot %>%
  mutate(
    bin_id = findInterval(value, b_breaks, rightmost.closed = TRUE),
    bin_id = pmin(nrow(b_bins), pmax(1, bin_id))
  ) %>%
  count(group, bin_id, name = "count") %>%
  complete(
    group,
    bin_id = seq_len(nrow(b_bins)),
    fill = list(count = 0)
  ) %>%
  left_join(b_bins, by = "bin_id") %>%
  mutate(
    ## Homozygous = left half of each bin
    ## Heterozygous = right half of each bin
    ## They touch but do not overlap.
    xmin2 = case_when(
      group == "Homozygous" ~ xmin,
      group == "Heterozygous" ~ xmid,
      TRUE ~ xmin
    ),
    xmax2 = case_when(
      group == "Homozygous" ~ xmid,
      group == "Heterozygous" ~ xmax,
      TRUE ~ xmax
    )
  )

b_ymax <- nice_y_top(max(b_hist$count, na.rm = TRUE))

b_med <- b_med_raw %>%
  filter(med <= b_xmax_plot) %>%
  mutate(
    label = paste0("median = ", comma(round(med))),
    y = case_when(
      group == "Homozygous" ~ b_ymax * 0.84,
      group == "Heterozygous" ~ b_ymax * 0.76,
      TRUE ~ b_ymax * 0.80
    ),
    x = pmin(med + b_xmax_plot * 0.025, b_xmax_plot * 0.82)
  )

pB <- ggplot() +
  geom_rect(
    data = b_hist,
    aes(xmin = xmin2, xmax = xmax2, ymin = 0, ymax = count, fill = group),
    colour = "black",
    linewidth = BAR_OUTLINE,
    alpha = 1
  ) +
  geom_vline(
    data = b_med,
    aes(xintercept = med, colour = group),
    linetype = "dashed",
    linewidth = 0.50,
    show.legend = FALSE
  ) +
  geom_text(
    data = b_med,
    aes(x = x, y = y, label = label, colour = group),
    hjust = 0,
    size = 3.0,
    fontface = "bold",
    show.legend = FALSE
  ) +
  scale_fill_manual(values = c("Homozygous" = col_hom, "Heterozygous" = col_het)) +
  scale_colour_manual(values = c("Homozygous" = col_hom, "Heterozygous" = col_het)) +
  scale_x_continuous(
    limits = c(-b_tick_step * 0.12, b_xmax_plot + b_tick_step * 0.12),
    breaks = seq(0, b_xmax_plot, by = b_tick_step),
    labels = comma,
    expand = c(0, 0)
  ) +
  scale_y_continuous(
    limits = c(-0.04 * b_ymax, b_ymax),
    breaks = pretty(c(0, b_ymax), n = 5),
    expand = c(0, 0)
  ) +
  labs(
    title = "GERP > 4",
    x = "Number of loci",
    y = "Number of individuals"
  ) +
  theme_pub(11) +
  theme(
    legend.position = c(0.52, 0.96),
    legend.direction = "horizontal",
    legend.text = element_text(size = 9),
    plot.title = element_text(face = "bold", hjust = 0.5, size = 13)
  )

## =========================================================
## C/D. Counts and standardized load
## =========================================================

make_three_component <- function(df, mode = c("count", "load")) {
  mode <- match.arg(mode)

  total_component <- intersect(c("allele_count", "carrier_all", "total"), unique(df$component))
  if (length(total_component) == 0) {
    stop("Cannot find total component in plot_BC_GERP4_burden.tsv")
  }
  total_component <- total_component[1]

  if (mode == "count") {
    bind_rows(
      df %>% filter(component == total_component) %>% transmute(sample, FROH, component = "Total", value = value_count),
      df %>% filter(component == "hom") %>% transmute(sample, FROH, component = "Homozygous", value = value_count),
      df %>% filter(component == "het") %>% transmute(sample, FROH, component = "Heterozygous", value = value_count)
    )
  } else {
    bind_rows(
      df %>% filter(component == total_component) %>% transmute(sample, FROH, component = "Total", value = value_rate),
      df %>% filter(component == "hom") %>% transmute(sample, FROH, component = "Homozygous", value = value_rate),
      df %>% filter(component == "het") %>% transmute(sample, FROH, component = "Heterozygous", value = value_rate)
    )
  }
}

plot_scatter_three <- function(dat, title_lab, y_lab, y_comma = FALSE, label_frac = c(0.96, 0.78, 0.08)) {
  dat <- dat %>%
    mutate(component = factor(component, levels = c("Total", "Homozygous", "Heterozygous"))) %>%
    filter(is.finite(FROH), is.finite(value))

  ptab <- dat %>%
    group_by(component) %>%
    summarise(p = lm_p(FROH, value), .groups = "drop") %>%
    mutate(label = paste0(component, ": ", vapply(p, fmt_p, character(1))))

  ymin <- min(dat$value, na.rm = TRUE)
  ymax <- max(dat$value, na.rm = TRUE)
  span <- ymax - ymin
  if (!is.finite(span) || span <= 0) span <- max(abs(ymax), 1)

  ptab <- ptab %>%
    mutate(
      x = min(dat$FROH, na.rm = TRUE) + 0.025 * diff(range(dat$FROH, na.rm = TRUE)),
      y = ymin + span * label_frac[as.integer(component)]
    )

  g <- ggplot(dat, aes(x = FROH, y = value, colour = component, fill = component)) +
    geom_point(size = 1.15, alpha = 0.78) +
    geom_smooth(method = "lm", se = TRUE, linewidth = 0.55, alpha = 0.10) +
    geom_text(
      data = ptab,
      aes(x = x, y = y, label = label, colour = component),
      inherit.aes = FALSE,
      hjust = 0,
      size = 2.65,
      fontface = "bold"
    ) +
    scale_colour_manual(values = comp_cols) +
    scale_fill_manual(values = comp_cols) +
    scale_x_continuous(expand = expansion(mult = c(0.05, 0.05))) +
    labs(title = title_lab, x = expression(F[ROH]), y = y_lab) +
    theme_pub(10) +
    theme(
      legend.position = c(0.55, 0.98),
      legend.justification = c(0.5, 1),
      legend.direction = "horizontal",
      legend.text = element_text(size = 7),
      plot.title = element_text(hjust = 0.5, size = 10)
    )

  if (y_comma) {
    g <- g + scale_y_continuous(labels = comma, expand = expansion(mult = c(0.04, 0.12)))
  } else {
    g <- g + scale_y_continuous(labels = number_format(accuracy = 0.001), expand = expansion(mult = c(0.04, 0.12)))
  }

  g
}

pC <- plot_scatter_three(
  make_three_component(bc, "count"),
  title_lab = "GERP > 4 counts",
  y_lab = "Count",
  y_comma = TRUE,
  label_frac = c(0.96, 0.50, 0.06)
)

pD <- plot_scatter_three(
  make_three_component(bc, "load"),
  title_lab = "Standardized GERP > 4 load",
  y_lab = "Load",
  y_comma = FALSE,
  label_frac = c(0.95, 0.88, 0.06)
)

## =========================================================
## E/F/H. Ratio scatter plots
## =========================================================

plot_ratio_scatter <- function(dat, title_lab, colour_map, group_col = "region", label_fracs = NULL) {
  dat <- dat %>%
    filter(is.finite(FROH), is.finite(ratio)) %>%
    mutate(plot_group = factor(as.character(.data[[group_col]]), levels = names(colour_map)))

  ptab <- dat %>%
    group_by(plot_group) %>%
    summarise(p = lm_p(FROH, ratio), .groups = "drop") %>%
    mutate(label = paste0(plot_group, ": ", vapply(p, fmt_p, character(1))))

  ymin <- min(dat$ratio, na.rm = TRUE)
  ymax <- max(dat$ratio, na.rm = TRUE)
  span <- ymax - ymin
  if (!is.finite(span) || span <= 0) span <- max(abs(ymax), 1)

  if (is.null(label_fracs)) {
    label_fracs <- seq(0.90, 0.72, length.out = nrow(ptab))
  }

  ptab <- ptab %>%
    mutate(
      x = min(dat$FROH, na.rm = TRUE) + 0.025 * diff(range(dat$FROH, na.rm = TRUE)),
      y = ymin + span * label_fracs[seq_len(n())]
    )

  ggplot(dat, aes(x = FROH, y = ratio, colour = plot_group, fill = plot_group)) +
    geom_point(size = 1.15, alpha = 0.78) +
    geom_smooth(method = "lm", se = TRUE, linewidth = 0.55, alpha = 0.10, linetype = 2) +
    geom_text(
      data = ptab,
      aes(x = x, y = y, label = label, colour = plot_group),
      inherit.aes = FALSE,
      hjust = 0,
      size = 2.65,
      fontface = "bold"
    ) +
    scale_colour_manual(values = colour_map, drop = FALSE) +
    scale_fill_manual(values = colour_map, drop = FALSE) +
    scale_x_continuous(expand = expansion(mult = c(0.05, 0.05))) +
    scale_y_continuous(expand = expansion(mult = c(0.06, 0.14))) +
    labs(title = title_lab, x = expression(F[ROH]), y = "GERP > 4 / GERP < 0 ratio") +
    theme_pub(10) +
    theme(
      legend.position = c(0.38, 0.98),
      legend.justification = c(0.5, 1),
      legend.direction = "horizontal",
      legend.text = element_text(size = 7),
      plot.title = element_text(hjust = 0.5, size = 10)
    )
}

ratio_all <- ratio_all_in %>%
  filter(state %in% c("het", "hom")) %>%
  mutate(
    component = recode(state, "het" = "Heterozygotes", "hom" = "Homozygotes"),
    component = factor(component, levels = c("Heterozygotes", "Homozygotes")),
    ratio = ratio_rate
  )

pE <- plot_ratio_scatter(
  ratio_all,
  title_lab = "GERP > 4 / GERP < 0",
  colour_map = c("Heterozygotes" = col_het, "Homozygotes" = col_hom),
  group_col = "component",
  label_fracs = c(0.86, 0.22)
)

ratio_hom_region <- roh_ratio_in %>%
  filter(state == "hom", region %in% c("Non-ROH", "ROH")) %>%
  mutate(
    region = factor(region, levels = c("Non-ROH", "ROH")),
    ratio = ratio_rate
  )

pF <- plot_ratio_scatter(
  ratio_hom_region,
  title_lab = "Homozygous GERP > 4 / GERP < 0 ratio",
  colour_map = region_cols,
  group_col = "region",
  label_fracs = c(0.90, 0.74)
)

ratio_alt_region <- roh_ratio_in %>%
  filter(state == "allele_count", region %in% c("Non-ROH", "ROH")) %>%
  mutate(
    region = factor(region, levels = c("Non-ROH", "ROH")),
    ratio = ratio_rate
  )

pH <- plot_ratio_scatter(
  ratio_alt_region,
  title_lab = paste0(allele_label, " GERP > 4 / GERP < 0 ratio inside and outside ROH"),
  colour_map = region_cols,
  group_col = "region",
  label_fracs = c(0.90, 0.74)
)

## =========================================================
## G. Boxplot ROH vs Non-ROH
## =========================================================

ratio_box <- roh_ratio_in %>%
  filter(state %in% c("het", "hom", "allele_count"),
         region %in% c("Non-ROH", "ROH")) %>%
  mutate(
    component = recode(
      state,
      "het" = "Heterozygotes",
      "hom" = "Homozygotes",
      "allele_count" = allele_label
    ),
    component = factor(component, levels = c("Heterozygotes", "Homozygotes", allele_label)),
    region = factor(region, levels = c("Non-ROH", "ROH")),
    ratio = ratio_rate
  )

box_stat <- ratio_box %>%
  select(sample, component, region, ratio) %>%
  pivot_wider(names_from = region, values_from = ratio) %>%
  group_by(component) %>%
  summarise(
    p = safe_paired_wilcox(`Non-ROH`, ROH),
    ymax = max(c(`Non-ROH`, ROH), na.rm = TRUE),
    .groups = "drop"
  ) %>%
  mutate(
    stars = vapply(p, p_stars, character(1)),
    p_label = vapply(p, fmt_p, character(1)),
    label = paste0(stars, "\n", p_label),
    y_bracket = ymax * 1.075,
    y_text = ymax * 1.125
  )

pG <- ggplot(ratio_box, aes(x = region, y = ratio, colour = region, fill = region)) +
  geom_boxplot(width = 0.50, outlier.shape = NA, alpha = 0.22, linewidth = 0.65) +
  geom_jitter(width = 0.12, size = 1.15, alpha = 0.70) +
  geom_segment(
    data = box_stat,
    aes(x = 1, xend = 2, y = y_bracket, yend = y_bracket),
    inherit.aes = FALSE,
    colour = "black",
    linewidth = 0.45
  ) +
  geom_segment(
    data = box_stat,
    aes(x = 1, xend = 1, y = y_bracket * 0.993, yend = y_bracket),
    inherit.aes = FALSE,
    colour = "black",
    linewidth = 0.45
  ) +
  geom_segment(
    data = box_stat,
    aes(x = 2, xend = 2, y = y_bracket * 0.993, yend = y_bracket),
    inherit.aes = FALSE,
    colour = "black",
    linewidth = 0.45
  ) +
  geom_text(
    data = box_stat,
    aes(x = 1.5, y = y_text, label = label),
    inherit.aes = FALSE,
    size = 2.65,
    fontface = "bold",
    colour = "grey20"
  ) +
  facet_wrap(~ component, scales = "free_y", nrow = 1) +
  scale_colour_manual(values = region_cols) +
  scale_fill_manual(values = region_cols) +
  scale_y_continuous(expand = expansion(mult = c(0.05, 0.22))) +
  labs(
    title = "GERP > 4 / GERP < 0 ratio in ROH and Non-ROH",
    x = NULL,
    y = "GERP > 4 / GERP < 0 ratio"
  ) +
  theme_pub(10) +
  theme(
    legend.position = "none",
    strip.text = element_text(face = "bold", size = 9),
    axis.text.x = element_text(angle = 25, hjust = 1),
    plot.title = element_text(hjust = 0.5, size = 10)
  )

## =========================================================
## Main figure: original 2-column layout
## =========================================================

main_plot <- (
  pA | pB
) / (
  pC | pD
) / (
  pE | pF
) / (
  pG | pH
) +
  plot_layout(heights = c(1.0, 1.08, 1.08, 1.05)) +
  plot_annotation(tag_levels = "A") &
  theme(
    plot.tag = element_text(face = "bold", size = 15),
    plot.tag.position = c(0.01, 0.98)
  )

compact_plot <- (
  pA | pB
) / (
  pC | pD
) / (
  pE | pF
) +
  plot_layout(heights = c(1.0, 1.08, 1.08)) +
  plot_annotation(tag_levels = "A") &
  theme(
    plot.tag = element_text(face = "bold", size = 15),
    plot.tag.position = c(0.01, 0.98)
  )

## =========================================================
## Save
## =========================================================

prefix_mode <- paste0(out_prefix, ".", mode_use)

save_both(pA, paste0(prefix_mode, ".FigA_AF_GERPgt4"), 5.4, 3.6)
save_both(pAF_supp, paste0(prefix_mode, ".FigS_AF_GERPneg_GERPgt4"), 5.4, 3.6)
save_both(pB, paste0(prefix_mode, ".FigB_HetHom_sharedX_GERPgt4"), 5.8, 3.6)
save_both(pC, paste0(prefix_mode, ".FigC_counts_vs_FROH_GERPgt4"), 5.8, 4.0)
save_both(pD, paste0(prefix_mode, ".FigD_load_vs_FROH_GERPgt4"), 5.8, 4.0)
save_both(pE, paste0(prefix_mode, ".FigE_ratio_ALL_HetHom_vs_FROH"), 5.8, 4.0)
save_both(pF, paste0(prefix_mode, ".FigF_homo_ratio_ROH_nonROH_vs_FROH"), 5.8, 4.0)
save_both(pG, paste0(prefix_mode, ".FigG_ratio_boxplot_ROH_nonROH_bracket"), 7.8, 3.8)
save_both(pH, paste0(prefix_mode, ".FigH_alt_ratio_ROH_nonROH_vs_FROH"), 5.8, 4.0)

save_both(main_plot, paste0(prefix_mode, ".A_H.reference_style"), 14.2, 15.0)
save_both(compact_plot, paste0(prefix_mode, ".A_F.compact_reference_style"), 14.2, 11.6)

save_both(main_plot, paste0(out_prefix, ".", mode_use, ".A_H"), 14.2, 15.0)

message("[DONE] Ped GERP visualization finished.")
message("[INFO] B: reference-like x-axis, 50k tick interval, central distribution x-limit.")
message("[INFO] A/B/supp: axis gaps, continuous histogram bars, no overlap.")
