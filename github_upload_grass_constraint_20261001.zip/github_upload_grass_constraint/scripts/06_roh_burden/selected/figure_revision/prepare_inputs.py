from pathlib import Path
import pandas as pd,numpy as np,json,hashlib
Q=Path('06_REVIEW/froh_audit_20260930');N=Path('N:/work/meso_bamboo/GERP/FIG/FROH');X=Path('outputs/submission_ready_tables_20260901/Supplementary_Table_S6_Candidate_Variant_Burden_ROH.xlsx')
configs=[('bamboo','S6C_bamboo','Ped_GERP_fullgenome_pipeline/01_tables/Ped_GERP.per_sample_burden.tsv'),('teosinte','S6B_teosinte','Teosinte_GERP_unpolarized_pipeline/01_tables/Teosinte_GERP.per_sample_burden.tsv'),('Aegilops','S6A_Aegilops','Atau_GERP_ROH_FINAL_kb100/03_GERP_tables/Atau_GERP_kb100_gap1000_winmiss5_noBW01192.per_sample_burden.tsv')]
allrows=[];audit=[]
for sp,sheet,rel in configs:
 a=pd.read_excel(X,sheet_name=sheet,header=1);b=pd.read_csv(N/rel,sep='\t')
 def filt(d):
  d=d[(d.region=='ALL') & d.variant_class.isin(['GERP4','GERP > 4','GERP>4'])].copy()
  if 'mode' in d:d=d[d['mode']=='unpolarized']
  return d.rename(columns={'alt_allele_count':'target_allele_count'})
 a=filt(a);b=filt(b)
 assert not a['sample'].duplicated().any() and not b['sample'].duplicated().any()
 cols=['FROH','het_loci','hom_loci','target_allele_count']
 m=a.merge(b,on='sample',suffixes=('_s6','_raw'),validate='one_to_one')
 delta={c:float(np.max(np.abs(m[c+'_s6']-m[c+'_raw']))) for c in cols}
 assert len(m)==len(a) and all(v<1e-7 for v in delta.values())
 assert np.all(a.target_allele_count==2*a.hom_loci+a.het_loci)
 z=a[['sample']+cols].copy();z.insert(0,'species',sp);allrows.append(z)
 b.to_csv(Q/(sp+'_original_ALL_GERP4.tsv'),sep='\t',index=False)
 audit.append(dict(species=sp,n_s6=len(a),n_original=len(b),excluded=sorted(set(b['sample'])-set(a['sample'])),max_abs_difference=delta,source=str(N/rel),sha256=hashlib.sha256((N/rel).read_bytes()).hexdigest()))
pd.concat(allrows).to_csv(Q/'S8_source_data.tsv',sep='\t',index=False)
(Q/'input_audit.json').write_text(json.dumps(audit,indent=2),encoding='utf8')
print(json.dumps(audit,indent=2))
