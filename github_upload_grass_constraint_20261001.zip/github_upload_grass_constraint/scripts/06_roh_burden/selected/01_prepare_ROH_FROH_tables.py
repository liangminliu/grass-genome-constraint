#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import argparse
import csv
import math
import os
import re
from collections import defaultdict


def norm_sample(x):
    return str(x).strip()


def norm_chr(x):
    x = str(x).strip()
    x = re.sub(r"^chr", "", x, flags=re.I)
    x = x.upper()
    x = re.sub(r"\.0$", "", x)
    if re.fullmatch(r"[1-7]", x):
        x = x + "D"
    return x


def open_tsv(path):
    return open(path, "r", encoding="utf-8-sig", newline="")


def parse_exclude(x):
    if not x or x.lower() in {"none", "null", "na"}:
        return set()
    return {norm_sample(i) for i in re.split(r"[,; \t]+", x) if i.strip()}


def to_float(x, default=float("nan")):
    try:
        if x is None:
            return default
        return float(str(x).replace(",", ""))
    except Exception:
        return default


def to_int(x, default=0):
    v = to_float(x, default=float("nan"))
    if math.isfinite(v):
        return int(round(v))
    return default


def pick_col(cols, candidates, required=True, label="column"):
    for c in candidates:
        if c in cols:
            return c
    if required:
        raise ValueError(f"Cannot find {label}. Tried {candidates}. Current columns: {cols}")
    return None


def chr_order_key(chrom):
    m = re.match(r"^(\d+)", chrom)
    return int(m.group(1)) if m else 999


def classify_roh(length_bp):
    if 100000 <= length_bp < 250000:
        return "100–250 kb"
    if 250000 <= length_bp < 500000:
        return "250–500 kb"
    if 500000 <= length_bp < 1000000:
        return "500 kb–1 Mb"
    if length_bp >= 1000000:
        return ">1 Mb"
    return None


def read_froh(path, exclude):
    rows = []

    with open_tsv(path) as fh:
        rd = csv.DictReader(fh, delimiter="\t")
        cols = rd.fieldnames

        sample_col = pick_col(cols, ["sample", "IID", "Sample", "ID"], label="sample in FROH")
        froh_col = pick_col(cols, ["FROH", "froh", "Froh"], label="FROH")

        for r in rd:
            sid = norm_sample(r[sample_col])
            if sid in exclude:
                continue

            F = to_float(r[froh_col])
            if math.isfinite(F):
                rows.append({"sample": sid, "FROH": F})

    return rows


def read_lauto(path):
    chrom_rows = []
    total = None

    with open_tsv(path) as fh:
        rd = csv.DictReader(fh, delimiter="\t")

        for r in rd:
            chrom = str(r.get("chr", "")).strip()

            if chrom == "TOTAL":
                total = to_int(r.get("Lauto_bp"))
                continue

            c = norm_chr(chrom)
            start = to_int(r.get("start_bp"))
            end = to_int(r.get("end_bp"))
            L = to_int(r.get("Lauto_bp"))

            if L <= 0 and end >= start:
                L = end - start + 1

            if L > 0:
                chrom_rows.append({
                    "chr": c,
                    "chr_start": start,
                    "chr_end": end,
                    "chr_len": L
                })

    chrom_rows = sorted(chrom_rows, key=lambda x: chr_order_key(x["chr"]))

    offset = 0
    for i, r in enumerate(chrom_rows, start=1):
        r["chr_index"] = i
        r["offset"] = offset
        r["bg_group"] = "odd" if i % 2 == 1 else "even"
        r["seg_group"] = "odd" if i % 2 == 1 else "even"
        offset += r["chr_len"]

    if total is None:
        total = sum(r["chr_len"] for r in chrom_rows)

    return chrom_rows, total


def read_roh_segments(path, exclude, min_roh_bp):
    rows = []

    with open_tsv(path) as fh:
        rd = csv.DictReader(fh, delimiter="\t")
        cols = rd.fieldnames

        sample_col = pick_col(cols, ["sample", "IID", "Sample", "ID"], label="sample in ROH")
        chr_col = pick_col(cols, ["chr", "CHR", "chrom", "chromosome"], label="chr in ROH")
        start_col = pick_col(cols, ["start_bp", "POS1", "start"], label="start in ROH")
        end_col = pick_col(cols, ["end_bp", "POS2", "end"], label="end in ROH")
        len_col = pick_col(cols, ["length_bp", "LEN_bp", "bp"], required=False, label="length in ROH")
        nsnp_col = pick_col(cols, ["nsnp", "NSNP"], required=False, label="nsnp in ROH")

        for r in rd:
            sid = norm_sample(r[sample_col])
            if sid in exclude:
                continue

            chrom = norm_chr(r[chr_col])
            start = to_int(r[start_col])
            end = to_int(r[end_col])

            if end < start:
                start, end = end, start

            length_bp = to_int(r[len_col]) if len_col else end - start + 1

            if length_bp < min_roh_bp:
                continue

            cls = classify_roh(length_bp)
            if cls is None:
                continue

            nsnp = to_int(r[nsnp_col]) if nsnp_col else 0

            rows.append({
                "sample": sid,
                "chr": chrom,
                "start_bp": start,
                "end_bp": end,
                "length_bp": length_bp,
                "length_Mb": length_bp / 1e6,
                "nsnp": nsnp,
                "roh_class": cls
            })

    return rows


def write_tsv(path, rows, fieldnames):
    os.makedirs(os.path.dirname(path), exist_ok=True)

    with open(path, "w", encoding="utf-8", newline="") as fh:
        w = csv.DictWriter(fh, delimiter="\t", fieldnames=fieldnames)
        w.writeheader()

        for r in rows:
            w.writerow({k: r.get(k, "") for k in fieldnames})


def compute_cumulative_by_class(froh_rows, roh_rows, Ltotal):
    class_levels = ["100–250 kb", "250–500 kb", "500 kb–1 Mb", ">1 Mb"]

    samples = [r["sample"] for r in froh_rows]
    sample_to_froh = {r["sample"]: r["FROH"] for r in froh_rows}

    sums = defaultdict(int)
    nroh = defaultdict(int)

    for r in roh_rows:
        key = (r["sample"], r["roh_class"])
        sums[key] += r["length_bp"]
        nroh[key] += 1

    out = []

    for sid in samples:
        cum = 0.0

        for cls in class_levels:
            s = sums.get((sid, cls), 0)
            n = nroh.get((sid, cls), 0)
            Fclass = s / Ltotal if Ltotal > 0 else 0.0
            cum += Fclass

            out.append({
                "sample": sid,
                "FROH": sample_to_froh.get(sid, ""),
                "roh_class": cls,
                "n_roh": n,
                "sum_roh_bp": s,
                "FROH_class": Fclass,
                "cumulative_FROH": cum
            })

    return out


def compute_roh_frequency(froh_rows, roh_rows, chr_info, win_bp, freq_roh_bp):
    """
    D 图：
      使用 ROH >= freq_roh_bp。
      当前最终要求：freq_roh_bp = 1000000，即 ROH >1 Mb。
      每 5 Mb window 中，统计至少有一个 ROH 覆盖该 window 的个体数。
    """
    samples = [r["sample"] for r in froh_rows]
    n_samples = len(samples)

    chr_map = {r["chr"]: r for r in chr_info}

    windows = []
    window_sets = {}

    for cinfo in chr_info:
        chrom = cinfo["chr"]
        chr_start = cinfo["chr_start"]
        chr_end = cinfo["chr_end"]
        chr_len = cinfo["chr_len"]

        nwin = int(math.ceil(chr_len / win_bp))

        for wi in range(nwin):
            win_start = chr_start + wi * win_bp
            win_end = min(chr_start + (wi + 1) * win_bp - 1, chr_end)
            mid = (win_start + win_end) / 2.0
            x = cinfo["offset"] + (mid - chr_start)

            rec = {
                "chr": chrom,
                "win_i": wi,
                "win_start_bp": win_start,
                "win_end_bp": win_end,
                "mid_bp": mid,
                "x": x,
                "bg_group": cinfo["bg_group"],
                "n_individuals": 0,
                "n_samples": n_samples,
                "roh_frequency": 0.0
            }

            windows.append(rec)
            window_sets[(chrom, wi)] = set()

    freq_rows = [r for r in roh_rows if r["length_bp"] >= freq_roh_bp]

    for r in freq_rows:
        chrom = r["chr"]

        if chrom not in chr_map:
            continue

        cinfo = chr_map[chrom]
        chr_start = cinfo["chr_start"]
        chr_end = cinfo["chr_end"]

        s = max(r["start_bp"], chr_start)
        e = min(r["end_bp"], chr_end)

        if e < s:
            continue

        w1 = max(0, int(math.floor((s - chr_start) / win_bp)))
        w2 = min(
            int(math.ceil(cinfo["chr_len"] / win_bp)) - 1,
            int(math.floor((e - chr_start) / win_bp))
        )

        for wi in range(w1, w2 + 1):
            key = (chrom, wi)

            if key not in window_sets:
                continue

            win_start = chr_start + wi * win_bp
            win_end = min(chr_start + (wi + 1) * win_bp - 1, chr_end)

            if s <= win_end and e >= win_start:
                window_sets[key].add(r["sample"])

    for rec in windows:
        key = (rec["chr"], rec["win_i"])
        n = len(window_sets[key])
        rec["n_individuals"] = n
        rec["roh_frequency"] = n / n_samples if n_samples > 0 else 0.0

    return windows, freq_rows


def compute_representative(froh_rows, roh_rows, chr_info, landscape_roh_bp):
    """
    E 图：
      FROH 最高 5 个体 + FROH 最低 5 个体。
      使用所有 ROH >= landscape_roh_bp。
      当前最终要求：landscape_roh_bp = 100000。
    """
    chr_map = {r["chr"]: r for r in chr_info}

    sorted_froh = sorted(froh_rows, key=lambda x: x["FROH"])

    low = sorted_froh[:5]
    high = sorted_froh[-5:][::-1]
    rep = high + low

    rep_samples = [r["sample"] for r in rep]
    sample_rank = {s: i + 1 for i, s in enumerate(rep_samples)}
    sample_froh = {r["sample"]: r["FROH"] for r in rep}

    out = []

    for r in roh_rows:
        if r["sample"] not in sample_rank:
            continue

        if r["length_bp"] < landscape_roh_bp:
            continue

        if r["chr"] not in chr_map:
            continue

        cinfo = chr_map[r["chr"]]

        s = max(r["start_bp"], cinfo["chr_start"])
        e = min(r["end_bp"], cinfo["chr_end"])

        if e < s:
            continue

        xstart = cinfo["offset"] + (s - cinfo["chr_start"])
        xend = cinfo["offset"] + (e - cinfo["chr_start"])

        out.append({
            "sample": r["sample"],
            "sample_rank": sample_rank[r["sample"]],
            "FROH": sample_froh[r["sample"]],
            "chr": r["chr"],
            "start_bp": r["start_bp"],
            "end_bp": r["end_bp"],
            "length_bp": r["length_bp"],
            "length_Mb": r["length_Mb"],
            "roh_class": r["roh_class"],
            "xstart": xstart,
            "xend": xend,
            "seg_group": cinfo["seg_group"]
        })

    rep_table = []

    for i, r in enumerate(rep, start=1):
        group = "Highest_FROH" if i <= 5 else "Lowest_FROH"

        rep_table.append({
            "sample": r["sample"],
            "sample_rank": i,
            "FROH": r["FROH"],
            "group": group
        })

    return rep_table, out


def main():
    ap = argparse.ArgumentParser()

    ap.add_argument("--froh", required=True)
    ap.add_argument("--roh", required=True)
    ap.add_argument("--lauto", required=True)
    ap.add_argument("--out-prefix", required=True)
    ap.add_argument("--exclude-samples", default="BW_01192")

    ap.add_argument("--min-roh-bp", type=int, default=100000)
    ap.add_argument("--freq-roh-bp", type=int, default=1000000)
    ap.add_argument("--landscape-roh-bp", type=int, default=100000)
    ap.add_argument("--window-bp", type=int, default=5000000)

    args = ap.parse_args()

    exclude = parse_exclude(args.exclude_samples)

    froh_rows = read_froh(args.froh, exclude)
    chr_info, Ltotal = read_lauto(args.lauto)
    roh_rows = read_roh_segments(args.roh, exclude, args.min_roh_bp)

    cumulative = compute_cumulative_by_class(froh_rows, roh_rows, Ltotal)

    windows, freq_rows = compute_roh_frequency(
        froh_rows,
        roh_rows,
        chr_info,
        args.window_bp,
        args.freq_roh_bp
    )

    rep_samples, rep_roh = compute_representative(
        froh_rows,
        roh_rows,
        chr_info,
        args.landscape_roh_bp
    )

    prefix = args.out_prefix
    os.makedirs(os.path.dirname(prefix), exist_ok=True)

    write_tsv(
        prefix + ".froh.tsv",
        froh_rows,
        ["sample", "FROH"]
    )

    write_tsv(
        prefix + ".chr_info.tsv",
        chr_info,
        ["chr", "chr_start", "chr_end", "chr_len", "offset", "chr_index", "bg_group", "seg_group"]
    )

    write_tsv(
        prefix + ".roh_segments.clean.tsv",
        roh_rows,
        ["sample", "chr", "start_bp", "end_bp", "length_bp", "length_Mb", "nsnp", "roh_class"]
    )

    write_tsv(
        prefix + ".cumulative_by_class.tsv",
        cumulative,
        ["sample", "FROH", "roh_class", "n_roh", "sum_roh_bp", "FROH_class", "cumulative_FROH"]
    )

    write_tsv(
        prefix + ".ROH_frequency.5Mb.tsv",
        windows,
        ["chr", "win_i", "win_start_bp", "win_end_bp", "mid_bp", "x", "bg_group", "n_individuals", "n_samples", "roh_frequency"]
    )

    write_tsv(
        prefix + ".ROH_for_frequency.tsv",
        freq_rows,
        ["sample", "chr", "start_bp", "end_bp", "length_bp", "length_Mb", "nsnp", "roh_class"]
    )

    write_tsv(
        prefix + ".representative_samples.tsv",
        rep_samples,
        ["sample", "sample_rank", "FROH", "group"]
    )

    write_tsv(
        prefix + ".representative_ROH.tsv",
        rep_roh,
        ["sample", "sample_rank", "FROH", "chr", "start_bp", "end_bp", "length_bp", "length_Mb", "roh_class", "xstart", "xend", "seg_group"]
    )

    freq_values = sorted(set(round(r["roh_frequency"], 8) for r in windows))

    with open(prefix + ".summary.txt", "w", encoding="utf-8") as out:
        out.write(f"n_samples\t{len(froh_rows)}\n")
        out.write(f"n_roh_segments_ge_min\t{len(roh_rows)}\n")
        out.write(f"min_roh_bp\t{args.min_roh_bp}\n")
        out.write(f"freq_roh_bp_for_D\t{args.freq_roh_bp}\n")
        out.write(f"landscape_roh_bp_for_E\t{args.landscape_roh_bp}\n")
        out.write(f"n_roh_for_D_frequency\t{len(freq_rows)}\n")
        out.write(f"n_representative_roh_for_E\t{len(rep_roh)}\n")
        out.write(f"n_windows\t{len(windows)}\n")
        out.write(f"n_unique_window_frequencies\t{len(freq_values)}\n")
        out.write(f"min_frequency\t{min(freq_values) if freq_values else 'NA'}\n")
        out.write(f"max_frequency\t{max(freq_values) if freq_values else 'NA'}\n")
        out.write("first_20_unique_frequencies\t" + ",".join(map(str, freq_values[:20])) + "\n")

    print("[WRITE]", prefix + ".froh.tsv")
    print("[WRITE]", prefix + ".chr_info.tsv")
    print("[WRITE]", prefix + ".roh_segments.clean.tsv")
    print("[WRITE]", prefix + ".cumulative_by_class.tsv")
    print("[WRITE]", prefix + ".ROH_frequency.5Mb.tsv")
    print("[WRITE]", prefix + ".representative_ROH.tsv")
    print("[WRITE]", prefix + ".summary.txt")


if __name__ == "__main__":
    main()