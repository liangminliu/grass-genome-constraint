#!/bin/bash
#SBATCH --job-name=snpEff
#SBATCH --output=snpEff.%A_%a.out
#SBATCH --error=snpEff.%A_%a.err
#SBATCH --cpus-per-task=20
#SBATCH --partition=parallel

singularity exec  ~/liuliangmin/4.may/software/Reseq_genek.sif java -jar /opt/snpEff/snpEff.jar -c  ./snpEff.config -ud 5000 -csvStats test.csv -htmlStats test.html -o vcf  ped  71sp.filtered.bi-allelic.snp.rename.vcf.gz > 71sp.filtered.snp.ann.vcf