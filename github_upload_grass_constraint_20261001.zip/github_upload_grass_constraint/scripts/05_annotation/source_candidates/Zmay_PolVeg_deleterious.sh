#!/usr/bin/env bash
#SBATCH --job-name=zmay_PolVeg_deleterious
#SBATCH --partition=parallel
#SBATCH --nodes=1
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=8
#SBATCH --array=1-3
#SBATCH --output=logs/zmay_PolVeg_deleterious_%A_%a.out
#SBATCH --error=logs/zmay_PolVeg_deleterious_%A_%a.err

set -euo pipefail

############################################
# 0. Fixed inputs
############################################

# 上一步 GERP 统计根目录（由前一个 Pol/Veg GERP 脚本产生）
STAT_ROOT="Zmay_PolVeg_CDS_GERP_stats"

# gene sets
POL_LIST="Zmay_Pol.list"
VEG_LIST="Zmay_Veg.list"

# annotation
GENE_BED="genes.merged.bed"
CDS_BED="CDS_gene_merged/CDS.gene.merged.bed"

# SNP intersects (已处理好的 SNP 注释交集结果；A 中不含 gene_id)
GENE_SNP_INTERSECT="genes_processed.intersect.bed"
CDS_SNP_INTERSECT="CDS_processed.intersect.bed"

# deleterious SNP files（按阈值切换）
OUT_ROOT="Zmay_PolVeg_gene_deleterious_stats"
mkdir -p logs "${OUT_ROOT}"

############################################
# 1. Threshold
############################################

CLASSES=("gt2" "gt4" "gt6")
IDX=$((SLURM_ARRAY_TASK_ID - 1))
if [[ ${IDX} -lt 0 || ${IDX} -ge ${#CLASSES[@]} ]]; then
  echo "[ERROR] Bad SLURM_ARRAY_TASK_ID=${SLURM_ARRAY_TASK_ID}" >&2
  exit 1
fi

CLASS="${CLASSES[$IDX]}"
echo "[INFO] Threshold = ${CLASS}"

GENE_DEL_BED="merged_${CLASS}_genes_detailed.bed"
CDS_DEL_BED="merged_${CLASS}_CDS_detailed.bed"

############################################
# 2. Check shared inputs
############################################

for f in \
  "${POL_LIST}" \
  "${VEG_LIST}" \
  "${GENE_BED}" \
  "${CDS_BED}" \
  "${GENE_SNP_INTERSECT}" \
  "${CDS_SNP_INTERSECT}" \
  "${GENE_DEL_BED}" \
  "${CDS_DEL_BED}"
do
  [[ -s "$f" ]] || { echo "[ERROR] Missing $f" >&2; exit 1; }
done

############################################
# 3. Helper: prepare clean gene list
############################################

prepare_gene_list() {
  local in_list="$1"
  local out_list="$2"

  awk 'NF>0{
    g=$1
    sub(/\r$/,"",g)
    if(g!="") print g
  }' "${in_list}" \
  | sed '/^[[:space:]]*$/d' \
  | sort -u \
  > "${out_list}"
}

############################################
# 4. Helper: run one set
############################################

run_one_set() {
  local SET_NAME="$1"      # Pol / Veg
  local GENE_LIST_SRC="$2" # Zmay_Pol.list / Zmay_Veg.list

  local OUT_DIR="${OUT_ROOT}/${SET_NAME}/${CLASS}"
  mkdir -p "${OUT_DIR}"

  local TARGET_GENE_LIST="${OUT_DIR}/target_gene.list"
  local TARGET_GENE_BED="${OUT_DIR}/target_gene.bed"
  local TARGET_CDS_BED="${OUT_DIR}/target_cds.bed"

  local PER_GENE_STAT="${STAT_ROOT}/${SET_NAME}/${CLASS}/per_gene_stats.tsv"

  echo "[INFO] ===== Processing ${SET_NAME} ${CLASS} ====="

  ##########################################
  # 4.1 Check per-gene stat from previous step
  ##########################################
  [[ -s "${PER_GENE_STAT}" ]] || {
    echo "[ERROR] Missing ${PER_GENE_STAT}" >&2
    exit 1
  }

  ##########################################
  # 4.2 Prepare target gene list
  ##########################################
  prepare_gene_list "${GENE_LIST_SRC}" "${TARGET_GENE_LIST}"

  [[ -s "${TARGET_GENE_LIST}" ]] || {
    echo "[ERROR] Empty gene list for ${SET_NAME}" >&2
    exit 1
  }

  echo "[INFO] ${SET_NAME} target gene count: $(wc -l < "${TARGET_GENE_LIST}")"

  ##########################################
  # 4.3 Build target_gene.bed / target_cds.bed
  ##########################################
  awk 'NR==FNR{a[$1]=1; next} ($4 in a)' \
    "${TARGET_GENE_LIST}" \
    "${GENE_BED}" \
    > "${TARGET_GENE_BED}"

  awk 'NR==FNR{a[$1]=1; next} ($4 in a)' \
    "${TARGET_GENE_LIST}" \
    "${CDS_BED}" \
    > "${TARGET_CDS_BED}"

  echo "[INFO] ${SET_NAME} target_gene.bed lines: $(wc -l < "${TARGET_GENE_BED}")"
  echo "[INFO] ${SET_NAME} target_cds.bed  lines: $(wc -l < "${TARGET_CDS_BED}")"

  ##########################################
  # note:
  # bedtools -wa -wb 输出中
  # B 文件 target_gene/target_cds 的 gene_id 固定在 (NF-2)
  # 因为 target bed 至少是 chr start end gene_id
  ##########################################

  ##########################################
  # 4.4 Gene SNP count
  ##########################################
  if [[ -s "${TARGET_GENE_BED}" ]]; then
    bedtools intersect -wa -wb \
      -a "${GENE_SNP_INTERSECT}" \
      -b "${TARGET_GENE_BED}" \
    | awk '
      BEGIN{OFS="\t"}
      {
        gene=$(NF-2);
        key=$1 ":" $2 "-" $3 ":" gene;
        if(!seen[key]++) c[gene]++;
      }
      END{
        for(g in c) print g,c[g]
      }' \
    | sort -k1,1 \
    > "${OUT_DIR}/gene.snp.tsv"
  else
    : > "${OUT_DIR}/gene.snp.tsv"
  fi

  ##########################################
  # 4.5 CDS SNP count
  ##########################################
  if [[ -s "${TARGET_CDS_BED}" ]]; then
    bedtools intersect -wa -wb \
      -a "${CDS_SNP_INTERSECT}" \
      -b "${TARGET_CDS_BED}" \
    | awk '
      BEGIN{OFS="\t"}
      {
        gene=$(NF-2);
        key=$1 ":" $2 "-" $3 ":" gene;
        if(!seen[key]++) c[gene]++;
      }
      END{
        for(g in c) print g,c[g]
      }' \
    | sort -k1,1 \
    > "${OUT_DIR}/cds.snp.tsv"
  else
    : > "${OUT_DIR}/cds.snp.tsv"
  fi

  ##########################################
  # 4.6 Gene deleterious SNP count
  ##########################################
  if [[ -s "${TARGET_GENE_BED}" ]]; then
    bedtools intersect -wa -wb \
      -a "${GENE_DEL_BED}" \
      -b "${TARGET_GENE_BED}" \
    | awk '
      BEGIN{OFS="\t"}
      {
        gene=$(NF-2);
        key=$1 ":" $2 "-" $3 ":" gene;
        if(!seen[key]++) c[gene]++;
      }
      END{
        for(g in c) print g,c[g]
      }' \
    | sort -k1,1 \
    > "${OUT_DIR}/gene.del.tsv"
  else
    : > "${OUT_DIR}/gene.del.tsv"
  fi

  ##########################################
  # 4.7 CDS deleterious SNP count
  ##########################################
  if [[ -s "${TARGET_CDS_BED}" ]]; then
    bedtools intersect -wa -wb \
      -a "${CDS_DEL_BED}" \
      -b "${TARGET_CDS_BED}" \
    | awk '
      BEGIN{OFS="\t"}
      {
        gene=$(NF-2);
        key=$1 ":" $2 "-" $3 ":" gene;
        if(!seen[key]++) c[gene]++;
      }
      END{
        for(g in c) print g,c[g]
      }' \
    | sort -k1,1 \
    > "${OUT_DIR}/cds.del.tsv"
  else
    : > "${OUT_DIR}/cds.del.tsv"
  fi

  ##########################################
  # 4.8 Length table from per_gene_stats.tsv
  ##########################################
  awk 'BEGIN{OFS="\t"} NR>1{print $1,$2,$3}' \
    "${PER_GENE_STAT}" \
    | sort -k1,1 \
    > "${OUT_DIR}/gene_len.tsv"

  ##########################################
  # 4.9 Final merge & ratios
  ##########################################
  # gene_snp_ratio = gene_snp_total / gene_len
  # gene_deleterious_ratio = gene_deleterious_snp / gene_snp_total
  # cds_snp_ratio  = cds_snp_total  / cds_len
  # cds_deleterious_ratio = cds_deleterious_snp / cds_snp_total

  awk '
  BEGIN{
    OFS="\t";
    print "gene_id",
          "gene_len","gene_snp_total","gene_snp_ratio",
          "gene_deleterious_snp","gene_deleterious_ratio",
          "cds_len","cds_snp_total","cds_snp_ratio",
          "cds_deleterious_snp","cds_deleterious_ratio";
  }

  FNR==NR{
    gl[$1]=$2; cl[$1]=$3; genes[$1]=1; next
  }

  FILENAME ~ /gene\.snp\.tsv$/ {gs[$1]=$2; genes[$1]=1; next}
  FILENAME ~ /cds\.snp\.tsv$/  {cs[$1]=$2; genes[$1]=1; next}
  FILENAME ~ /gene\.del\.tsv$/ {gd[$1]=$2; genes[$1]=1; next}
  FILENAME ~ /cds\.del\.tsv$/  {cd[$1]=$2; genes[$1]=1; next}

  END{
    for(g in genes){
      gene_len = gl[g] + 0;
      cds_len  = cl[g] + 0;

      gene_snp = gs[g] + 0;
      cds_snp  = cs[g] + 0;

      gene_del = gd[g] + 0;
      cds_del  = cd[g] + 0;

      gsr = (gene_len > 0) ? gene_snp / gene_len : 0;
      csr = (cds_len  > 0) ? cds_snp  / cds_len  : 0;

      gdr = (gene_snp > 0) ? gene_del / gene_snp : 0;
      cdr = (cds_snp  > 0) ? cds_del  / cds_snp  : 0;

      printf "%s\t%d\t%d\t%.6f\t%d\t%.6f\t%d\t%d\t%.6f\t%d\t%.6f\n",
        g,
        gene_len, gene_snp, gsr,
        gene_del, gdr,
        cds_len, cds_snp, csr,
        cds_del, cdr;
    }
  }' \
  "${OUT_DIR}/gene_len.tsv" \
  "${OUT_DIR}/gene.snp.tsv" \
  "${OUT_DIR}/cds.snp.tsv" \
  "${OUT_DIR}/gene.del.tsv" \
  "${OUT_DIR}/cds.del.tsv" \
  | sort -k1,1 \
  > "${OUT_DIR}/zmay_gene_deleterious_stats.${SET_NAME}.tsv"

  ##########################################
  # 4.10 Quick sanity checks
  ##########################################
  echo "[INFO] ${SET_NAME} gene.snp.tsv head:"
  head -n 5 "${OUT_DIR}/gene.snp.tsv" || true

  echo "[INFO] ${SET_NAME} gene.del.tsv head:"
  head -n 5 "${OUT_DIR}/gene.del.tsv" || true

  echo "[INFO] ${SET_NAME} final output:"
  echo "       ${OUT_DIR}/zmay_gene_deleterious_stats.${SET_NAME}.tsv"
}

############################################
# 5. Run Pol and Veg
############################################

run_one_set "Pol" "${POL_LIST}"
run_one_set "Veg" "${VEG_LIST}"

echo "[INFO] DONE ${CLASS}"