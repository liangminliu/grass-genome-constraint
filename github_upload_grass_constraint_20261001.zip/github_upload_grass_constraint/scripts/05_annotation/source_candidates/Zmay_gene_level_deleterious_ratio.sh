#!/usr/bin/env bash
#SBATCH --job-name=zmay_core_deleterious
#SBATCH --partition=parallel
#SBATCH --nodes=1
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=8
#SBATCH --array=1-3
#SBATCH --output=logs/zmay_core_deleterious_%A_%a.out
#SBATCH --error=logs/zmay_core_deleterious_%A_%a.err

set -euo pipefail

############################################
# 0. Fixed inputs
############################################

STAT_ROOT="Zmay_target_gene_CDS_GERP_stats"

# annotation
GENE_BED="genes.merged.bed"
CDS_BED="CDS_gene_merged/CDS.gene.merged.bed"

# SNP intersects (A already processed; no gene_id inside)
GENE_SNP_INTERSECT="genes_processed.intersect.bed"
CDS_SNP_INTERSECT="CDS_processed.intersect.bed"

# deleterious SNP files (10 cols; no gene_id inside)
CORE_PAN="core_5sp_1to1.SG.pan"

OUT_ROOT="Zmay_gene_deleterious_stats"
mkdir -p logs "${OUT_ROOT}"

############################################
# 1. Threshold
############################################

CLASSES=("gt2" "gt4" "gt6")
CLASS="${CLASSES[$((SLURM_ARRAY_TASK_ID-1))]}"
OUT_DIR="${OUT_ROOT}/${CLASS}"
mkdir -p "${OUT_DIR}"

echo "[INFO] Threshold = ${CLASS}"

PER_GENE_STAT="${STAT_ROOT}/${CLASS}/per_gene_stats.tsv"
GENE_DEL_BED="merged_${CLASS}_genes_detailed.bed"
CDS_DEL_BED="merged_${CLASS}_CDS_detailed.bed"

############################################
# 2. Check inputs
############################################

for f in \
  "${PER_GENE_STAT}" \
  "${GENE_BED}" \
  "${CDS_BED}" \
  "${GENE_SNP_INTERSECT}" \
  "${CDS_SNP_INTERSECT}" \
  "${GENE_DEL_BED}" \
  "${CDS_DEL_BED}" \
  "${CORE_PAN}"
do
  [[ -s "$f" ]] || { echo "[ERROR] Missing $f" >&2; exit 1; }
done

############################################
# 3. Core gene list (Zmay)
############################################

awk '{print $NF}' "${CORE_PAN}" \
| sed 's/^Zmay_//' \
| awk 'NF>0' \
| sort -u \
> "${OUT_DIR}/core_gene.list"

############################################
# 4. Build core_gene.bed / core_cds.bed
############################################

awk 'NR==FNR{a[$1]; next} ($4 in a)' \
  "${OUT_DIR}/core_gene.list" \
  "${GENE_BED}" \
> "${OUT_DIR}/core_gene.bed"

awk 'NR==FNR{a[$1]; next} ($4 in a)' \
  "${OUT_DIR}/core_gene.list" \
  "${CDS_BED}" \
> "${OUT_DIR}/core_cds.bed"

############################################
# Helper note:
# bedtools -wa -wb output:
# gene_id from B (core_gene/core_cds) is ALWAYS field (NF-2)
############################################

############################################
# 5. Gene SNP count
############################################

bedtools intersect -wa -wb \
  -a "${GENE_SNP_INTERSECT}" \
  -b "${OUT_DIR}/core_gene.bed" \
| awk '
BEGIN{OFS="\t"}
{
  gene=$(NF-2);
  key=$1 ":" $2 "-" $3 ":" gene;
  if(!seen[key]++) c[gene]++;
}
END{for(g in c) print g,c[g]}
' \
> "${OUT_DIR}/core_gene.snp.tsv"

############################################
# 6. CDS SNP count
############################################

bedtools intersect -wa -wb \
  -a "${CDS_SNP_INTERSECT}" \
  -b "${OUT_DIR}/core_cds.bed" \
| awk '
BEGIN{OFS="\t"}
{
  gene=$(NF-2);
  key=$1 ":" $2 "-" $3 ":" gene;
  if(!seen[key]++) c[gene]++;
}
END{for(g in c) print g,c[g]}
' \
> "${OUT_DIR}/core_cds.snp.tsv"

############################################
# 7. Gene deleterious SNP count  (FIXED)
############################################

bedtools intersect -wa -wb \
  -a "${GENE_DEL_BED}" \
  -b "${OUT_DIR}/core_gene.bed" \
| awk '
BEGIN{OFS="\t"}
{
  gene=$(NF-2);
  key=$1 ":" $2 "-" $3 ":" gene;
  if(!seen[key]++) c[gene]++;
}
END{for(g in c) print g,c[g]}
' \
> "${OUT_DIR}/core_gene.del.tsv"

############################################
# 8. CDS deleterious SNP count  (FIXED)
############################################

bedtools intersect -wa -wb \
  -a "${CDS_DEL_BED}" \
  -b "${OUT_DIR}/core_cds.bed" \
| awk '
BEGIN{OFS="\t"}
{
  gene=$(NF-2);
  key=$1 ":" $2 "-" $3 ":" gene;
  if(!seen[key]++) c[gene]++;
}
END{for(g in c) print g,c[g]}
' \
> "${OUT_DIR}/core_cds.del.tsv"

############################################
# 9. Length table
############################################

awk 'BEGIN{OFS="\t"} NR>1{print $1,$2,$3}' \
  "${PER_GENE_STAT}" \
> "${OUT_DIR}/gene_len.tsv"

############################################
# 10. Final merge & ratios
############################################
# gene_snp_ratio = gene_snp_total / gene_len
# gene_deleterious_ratio = gene_deleterious_snp / gene_snp_total
# cds_snp_ratio  = cds_snp_total  / cds_len
# cds_deleterious_ratio = cds_deleterious_snp / cds_snp_total

awk '
BEGIN{
  OFS="\t";
  print "gene_id",
        "gene_len","gene_snp_total","gene_snp_ratio",
        "gene_deleterious_snp","gene_deleterious_ratio",
        "cds_len","cds_snp_total","cds_snp_ratio",
        "cds_deleterious_snp","cds_deleterious_ratio";
}

FNR==NR{
  gl[$1]=$2; cl[$1]=$3; genes[$1]=1; next
}

FILENAME~"core_gene.snp"{gs[$1]=$2; genes[$1]=1; next}
FILENAME~"core_cds.snp"{cs[$1]=$2; genes[$1]=1; next}
FILENAME~"core_gene.del"{gd[$1]=$2; genes[$1]=1; next}
FILENAME~"core_cds.del"{cd[$1]=$2; genes[$1]=1; next}

END{
  for(g in genes){
    gene_len=gl[g]+0; cds_len=cl[g]+0;
    gene_snp=gs[g]+0; cds_snp=cs[g]+0;
    gene_del=gd[g]+0; cds_del=cd[g]+0;

    gsr=(gene_len>0)?gene_snp/gene_len:0;
    csr=(cds_len>0)?cds_snp/cds_len:0;

    gdr=(gene_snp>0)?gene_del/gene_snp:0;
    cdr=(cds_snp>0)?cds_del/cds_snp:0;

    printf "%s\t%d\t%d\t%.6f\t%d\t%.6f\t%d\t%d\t%.6f\t%d\t%.6f\n",
      g,
      gene_len,gene_snp,gsr,
      gene_del,gdr,
      cds_len,cds_snp,csr,
      cds_del,cdr;
  }
}
' \
"${OUT_DIR}/gene_len.tsv" \
"${OUT_DIR}/core_gene.snp.tsv" \
"${OUT_DIR}/core_cds.snp.tsv" \
"${OUT_DIR}/core_gene.del.tsv" \
"${OUT_DIR}/core_cds.del.tsv" \
| sort -k1,1 \
> "${OUT_DIR}/zmay_gene_deleterious_stats.core1to1.tsv"

############################################
# 11. Quick sanity checks
############################################

echo "[INFO] core_gene.snp.tsv head:"
head -n 5 "${OUT_DIR}/core_gene.snp.tsv" || true

echo "[INFO] core_gene.del.tsv head:"
head -n 5 "${OUT_DIR}/core_gene.del.tsv" || true

echo "[INFO] DONE ${CLASS}"
