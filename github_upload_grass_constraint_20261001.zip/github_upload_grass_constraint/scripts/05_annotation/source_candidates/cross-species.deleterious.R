#!/usr/bin/env Rscript

suppressPackageStartupMessages({
  library(dplyr)
  library(readr)
  library(stringr)
  library(ggplot2)
  library(ggsignif)
})

## =========================================================
## Parameters
## =========================================================
TH <- "gt2"   # gt2 / gt4 / gt6

PAN_FILE <- "core_5sp_1to1.SG.pan"

ATau_TSV <- paste0("Atau_", TH, "_gene_deleterious.tsv")
ZMay_TSV <- paste0("Zmay_", TH, "_gene_deleterious.tsv")
PedC_TSV <- paste0("pedC_", TH, "_gene_deleterious_stats.tsv")
PedD_TSV <- paste0("pedD_", TH, "_gene_deleterious_stats.tsv")

OUT_PREFIX <- paste0("Fig_core1to1_", TH, "_paired_meanCI")

NBOOT <- 5000
CONF  <- 0.95
SEED  <- 20260105

PLOT_LEVELS <- c(
  "A.tauschii",
  "Z.mays",
  "P.edulis (pedC+pedD mean)"
)

## =========================================================
## Helper functions
## =========================================================
read_burden <- function(file, out_col) {
  read_tsv(file, show_col_types = FALSE) %>%
    transmute(
      gene_id = as.character(gene_id),
      !!out_col := as.numeric(deleterious_ratio) * 100
    ) %>%
    filter(is.finite(.data[[out_col]]))
}

p_to_star <- function(p) {
  if (p < 0.001) "***"
  else if (p < 0.01) "**"
  else if (p < 0.05) "*"
  else "ns"
}

bootstrap_mean_ci <- function(mat, nboot, conf, seed) {
  set.seed(seed)
  n <- nrow(mat)
  boot <- replicate(nboot, {
    idx <- sample.int(n, n, replace = TRUE)
    colMeans(mat[idx, , drop = FALSE])
  })
  alpha <- (1 - conf) / 2
  tibble(
    group   = colnames(mat),
    mean    = colMeans(mat),
    ci_low  = apply(boot, 1, quantile, probs = alpha),
    ci_high = apply(boot, 1, quantile, probs = 1 - alpha)
  )
}

## =========================================================
## 1. Read pan file & NORMALIZE gene IDs
## =========================================================
pan_raw <- read_tsv(PAN_FILE, col_names = FALSE, show_col_types = FALSE)

pan_df <- tibble(
  SG         = pan_raw[[1]],
  Atau_gene  = pan_raw[[5]],
  pedC_gene  = pan_raw[[7]],
  pedD_gene  = pan_raw[[8]],
  Zmay_gene  = pan_raw[[9]]
) %>%
  filter(!is.na(SG), SG != "-") %>%
  mutate(
    Atau_gene = str_replace(Atau_gene, "^[^_]+_", ""),
    pedC_gene = str_replace(pedC_gene, "^[^_]+_", ""),
    pedD_gene = str_replace(pedD_gene, "^[^_]+_", ""),
    Zmay_gene = str_replace(Zmay_gene, "^[^_]+_", "")
  )

## =========================================================
## 2. Read burden tables
## =========================================================
atau <- read_burden(ATau_TSV, "Atau_burden")
zmay <- read_burden(ZMay_TSV, "Zmay_burden")
pedc <- read_burden(PedC_TSV, "pedC_burden")
pedd <- read_burden(PedD_TSV, "pedD_burden")

## =========================================================
## 3. Build paired matrix (SG as unit)
## =========================================================
paired <- pan_df %>%
  left_join(atau, by = c("Atau_gene" = "gene_id")) %>%
  left_join(zmay, by = c("Zmay_gene" = "gene_id")) %>%
  left_join(pedc, by = c("pedC_gene" = "gene_id")) %>%
  left_join(pedd, by = c("pedD_gene" = "gene_id")) %>%
  mutate(
    pedMean = (pedC_burden + pedD_burden) / 2
  ) %>%
  select(
    SG,
    Atau = Atau_burden,
    Zmay = Zmay_burden,
    pedMean
  ) %>%
  filter(is.finite(Atau), is.finite(Zmay), is.finite(pedMean))

cat("[INFO] Paired SG count:", nrow(paired), "\n")

if (nrow(paired) < 20) {
  stop("[ERROR] Too few paired SGs (<20). Check gene ID consistency.")
}

## =========================================================
## 4. Paired Wilcoxon tests
## =========================================================
wilcox_tbl <- bind_rows(
  tibble(
    group1 = "A.tauschii",
    group2 = "Z.mays",
    p = wilcox.test(paired$Atau, paired$Zmay, paired = TRUE)$p.value
  ),
  tibble(
    group1 = "A.tauschii",
    group2 = "P.edulis (pedC+pedD mean)",
    p = wilcox.test(paired$Atau, paired$pedMean, paired = TRUE)$p.value
  ),
  tibble(
    group1 = "Z.mays",
    group2 = "P.edulis (pedC+pedD mean)",
    p = wilcox.test(paired$Zmay, paired$pedMean, paired = TRUE)$p.value
  )
) %>%
  mutate(
    p_adj = p.adjust(p, method = "BH"),
    signif = vapply(p_adj, p_to_star, character(1))
  )

## =========================================================
## 5. Bootstrap mean ± CI
## =========================================================
mat <- as.matrix(paired[, c("Atau", "Zmay", "pedMean")])
colnames(mat) <- PLOT_LEVELS

boot_tbl <- bootstrap_mean_ci(mat, NBOOT, CONF, SEED)

## =========================================================
## 6. Plot
## =========================================================
sig_df <- wilcox_tbl %>%
  filter(signif != "ns") %>%
  mutate(
    y_position = max(boot_tbl$ci_high) * (1 + 0.08 * seq_len(n()))
  )

p <- ggplot(boot_tbl, aes(x = group, y = mean)) +
  geom_point(size = 3) +
  geom_errorbar(aes(ymin = ci_low, ymax = ci_high), width = 0.15) +
  geom_signif(
    data = sig_df,
    aes(
      xmin = group1,
      xmax = group2,
      annotations = signif,
      y_position = y_position
    ),
    manual = TRUE
  ) +
  coord_cartesian(ylim = c(0, max(sig_df$y_position) * 1.1)) +
  labs(
    y = paste0("Mean deleterious SNPs in CDS (%) [", TH, "]"),
    x = NULL
  ) +
  theme_classic(base_size = 15) +
  theme(axis.text.x = element_text(face = "italic"))

ggsave(paste0(OUT_PREFIX, ".pdf"), p, width = 6, height = 4.5)
ggsave(paste0(OUT_PREFIX, ".png"), p, width = 6, height = 4.5, dpi = 300)

cat("✓ Finished", TH, "\n")
