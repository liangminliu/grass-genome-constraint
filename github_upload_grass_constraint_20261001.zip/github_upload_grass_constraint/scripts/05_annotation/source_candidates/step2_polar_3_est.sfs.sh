#!/bin/bash
#SBATCH --job-name=polarise
#SBATCH --partition=parallel
#SBATCH --nodes=2
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=8
#SBATCH --output=%j.out
#SBATCH --error=%j.err



# supply argument chr=Ped01C & config & outd 
# polarise per chromosome, because to put whole genome on one pile would be too heavy
# example of running the script: sbatch --export=chr=Ped01C polar_3_est.sfs.sh

# the script has been modified for the purpose of ped species polarisation
# Modified for SLURM submission system with ped chromosome naming




# Working directory
wd=$SLURM_SUBMIT_DIR
bin="~/biosoftware/est-sfs-release-2.04/est-sfs"  # Update this path
beddir="/path/to/outgr_alignments"  # Update this path

# Set default values for parameters
if [ -z "$outd" ]; then
    echo "outdir not specified using default est_sfs_results"
    outd="est_sfs_results"
fi

if [ -z "$config" ]; then
    echo "configuration file not specified using default config_kimura.txt"
    config="config_kimura.txt"
fi

if [ -z "$focfreq" ]; then
    echo "You need to supply focal freq file if you do not want default:"
    focfreq=$wd/focal_freq_sfs.txt
fi

if [ -z "$outgr" ]; then
    echo "You need to supply bedfile with outgroups"
    outgr=$wd/outgroups.bed
    exit 1
fi

if [ -z "$chr" ]; then
    echo "You need to supply chromosome name (e.g., Ped01C, Ped01D, etc.)"
    exit 1
fi

# Validate chromosome name format
if [[ ! $chr =~ ^Ped[0-9]{2}[CD]$ ]]; then
    echo "Error: Chromosome name should be in format PedXXC or PedXXD (e.g., Ped01C, Ped12D)"
    exit 1
fi

echo "Processing chromosome: $chr"

# Create temporary directory
TMPDIR=${TMPDIR:-/tmp}
WORKDIR=$(mktemp -d -p "$TMPDIR" polarise_${chr}_XXXXXX)

# Cleanup function
cleanup() {
    rm -rf "$WORKDIR"
}
trap cleanup EXIT

# Copy required files to working directory
cp $wd/$focfreq $WORKDIR/
cp $wd/$outgr $WORKDIR/
cp $wd/$config $WORKDIR/
cp $wd/seedfile.txt $WORKDIR/
cp $wd/polar_2_fix.outgroups.py $WORKDIR/
cd $WORKDIR

# Get basenames
focfreq=$(basename $focfreq)
outgr=$(basename $outgr)

echo "Filtering input files for chromosome $chr..."

# Filter focal frequency file for specific chromosome
grep "^$chr" $focfreq > ${chr}_focal_freq.txt || {
    echo "No data found for chromosome $chr in focal frequency file"
    exit 1
}

# Filter outgroup file for specific chromosome  
grep "^$chr" $outgr > ${chr}_outgroups.bed || {
    echo "No data found for chromosome $chr in outgroup file"
    exit 1
}

# Check if filtered files have data
if [[ ! -s ${chr}_focal_freq.txt ]]; then
    echo "Error: No focal frequency data for chromosome $chr"
    exit 1
fi

if [[ ! -s ${chr}_outgroups.bed ]]; then
    echo "Error: No outgroup data for chromosome $chr"
    exit 1
fi

echo "Found $(wc -l < ${chr}_focal_freq.txt) focal sites and $(wc -l < ${chr}_outgroups.bed) outgroup sites"

# Remove indels in the bed alignment
awk '{if ($NF ~ /^[ACGT],[ACGT]$/) print $0}' ${chr}_outgroups.bed | \
sort -k1,1 -k2,2n > ${chr}_outgroups.noindel.bed

# Fix the outgroup alignment (ambiguities)
python3 polar_2_fix.outgroups.py -bed ${chr}_outgroups.noindel.bed > fix_${chr}.log

# Intersection of focal frequencies with outgroups
bedtools intersect -sorted -loj -a ${chr}_focal_freq.txt -b ${chr}_outgroups.noindel.fixed.bed > ${chr}.intersected

# Parse the intersected file for est-sfs format (for 2 outgroups: Alu and Hca)
paste <(cut -f 4 ${chr}.intersected) <(cut -f 12 ${chr}.intersected | awk -F, '{
    # Initialize counters for Alu (first outgroup) and Hca (second outgroup)
    a_alu=0; c_alu=0; g_alu=0; t_alu=0;
    a_hca=0; c_hca=0; g_hca=0; t_hca=0;
    
    # Parse Alu (first outgroup) - $1
    if($1 ~ /[aA]/) a_alu=1;
    if($1 ~ /[cC]/) c_alu=1;
    if($1 ~ /[gG]/) g_alu=1;
    if($1 ~ /[tT]/) t_alu=1;
    
    # Parse Hca (second outgroup) - $2
    if($2 ~ /[aA]/) a_hca=1;
    if($2 ~ /[cC]/) c_hca=1;
    if($2 ~ /[gG]/) g_hca=1;
    if($2 ~ /[tT]/) t_hca=1;
    
    printf "%d,%d,%d,%d %d,%d,%d,%d\n", a_alu,c_alu,g_alu,t_alu,a_hca,c_hca,g_hca,t_hca
}') > ${chr}.est_sfs.input

# Count missing sites (sites without outgroup coverage)
missing=$(grep -c "0,0,0,0 0,0,0,0" ${chr}.est_sfs.input)
total_sites=$(wc -l < ${chr}.est_sfs.input)

echo "Total sites: $total_sites, Missing outgroup data: $missing"

# Check if we have enough data to proceed
if [[ $total_sites -eq 0 ]]; then
    echo "Error: No sites found after intersection"
    exit 1
fi

# Run est-sfs
echo "Running est-sfs analysis..."
$bin $config ${chr}.est_sfs.input seedfile.txt ${chr}.sfs.output.txt ${chr}.site.output.txt

# Create complete output with positions
paste <(cut -f 1-3,12 ${chr}.intersected) ${```bash
chr}.est_sfs.input <(tail -n +9 ${chr}.site.output.txt) | tr -s " " \\t > ${chr}.site.complete.output.bed

# Format SFS output
cat ${chr}.sfs.output.txt | tr "," \\n | sponge ${chr}.sfs.output.txt

# Run R script for polarisation analysis (if available)
if [[ -f "$wd/plot_polarisation.R" ]]; then
    echo "Running polarisation analysis..."
    Rscript $wd/plot_polarisation.R ${chr}.site.complete.output.bed ${chr}.sfs.output.txt
else
    echo "Warning: plot_polarisation.R not found, skipping visualization"
fi

# Report results
echo "=== Analysis Summary for $chr ==="
wc -l *
echo "There are $missing sites without outgroup reference out of $total_sites total sites"
echo "Coverage: $(( (total_sites - missing) * 100 / total_sites ))%"

# Create output directory and copy results
mkdir -p $outd
mv * $outd/
cp -r $outd $wd/ || echo "Warning: Could not copy results to working directory"

echo "Polarisation analysis completed for chromosome $chr"