#!/bin/bash
#SBATCH --job-name=Atau_core_deleterious
#SBATCH --partition=parallel
#SBATCH --nodes=1
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=6
#SBATCH --array=1-3
#SBATCH --output=logs/Atau_core_del_%A_%a.out
#SBATCH --error=logs/Atau_core_del_%A_%a.err

set -euo pipefail
module load bedtools 2>/dev/null || true

############################################
# inputs
############################################
ALL_CDS_SNP="CDS_processed.intersect.bed"
CDS_GENE_BED="CDS.gene.bed"
STAT_ROOT="target_gene_CDS_GERP_stats"
CORE_PAN="core_5sp_1to1.SG.pan"

declare -A DEL
DEL[gt2]="merged_gt2_CDS_detailed.bed"
DEL[gt4]="merged_gt4_CDS_detailed.bed"
DEL[gt6]="merged_gt6_CDS_detailed.bed"

############################################
# array
############################################
CLS=(gt2 gt4 gt6)
IDX=$((SLURM_ARRAY_TASK_ID-1))
TH=${CLS[$IDX]}

OUT="Atau_core_gene_deleterious/${TH}"
mkdir -p logs "${OUT}"

############################################
# 1) core gene list  (TSV/one-column)
#    注意：CORE_PAN 里第5列是 Atau_基因ID，你原来是对的
############################################
awk 'NF>=5 && $5!="-"{print $5}' "${CORE_PAN}" \
| sed 's/^Atau_//' \
| awk 'NF>0' \
| sort -u \
> "${OUT}/core_gene.list"

############################################
# 2) core CDS bed
#    你的 core_cds.bed 里出现重复行（你展示的 head 已经重复了）
#    这里直接 sort -u 去重，避免 intersect 产生额外冗余匹配
############################################
awk 'NR==FNR{a[$1]=1; next} ($4 in a)' \
  "${OUT}/core_gene.list" "${CDS_GENE_BED}" \
| LC_ALL=C sort -u \
> "${OUT}/core_cds.bed"

############################################
# 3) CDS SNP total per gene  (TSV: gene \t count)
############################################
bedtools intersect -wa -wb \
  -a "${ALL_CDS_SNP}" -b "${OUT}/core_cds.bed" \
| awk -v OFS="\t" '
{
  g=$(NF-2);                 # gene_id 在 b 的第4列，按你的字段布局 NF-2 没问题
  k=$1":"$2"-"$3":"g;        # 用 chr:start-end:gene 做唯一键，避免重复计数
  if(!s[k]++){ c[g]++ }
}
END{
  for(g in c) print g, c[g]
}' \
| LC_ALL=C sort -k1,1 \
> "${OUT}/cds_snp_total.tsv"

############################################
# 4) deleterious CDS SNP per gene (TSV: gene \t count)
############################################
bedtools intersect -wa -wb \
  -a "${DEL[$TH]}" -b "${OUT}/core_cds.bed" \
| awk -v OFS="\t" '
{
  g=$(NF-2);
  k=$1":"$2"-"$3":"g;
  if(!s[k]++){ c[g]++ }
}
END{
  for(g in c) print g, c[g]
}' \
| LC_ALL=C sort -k1,1 \
> "${OUT}/cds_deleterious_snp.tsv"

############################################
# 5) CDS length per gene (TSV: gene \t cds_len)
#    你原来是 print $1,$3 —— 但要强制 TSV
############################################
awk -v OFS="\t" 'NR>1{print $1,$3}' \
  "${STAT_ROOT}/${TH}/per_gene_stats.tsv" \
| LC_ALL=C sort -k1,1 \
> "${OUT}/cds_len.tsv"

############################################
# 6) merge：以 core_gene.list 为“主键全集”，避免缺失导致 join 丢行
#    base.tsv: gene \t 0 (占位)
############################################
awk -v OFS="\t" '{print $1,0}' "${OUT}/core_gene.list" \
| LC_ALL=C sort -k1,1 \
> "${OUT}/base.tsv"

# 依次把 cds_len、total_snp、deleterious_snp join 进来
# join 要求两边都按 key 排序 & 分隔符一致（这里全部是 tab）
join -t $'\t' -a 1 -e 0 -o 1.1,2.2 \
  "${OUT}/base.tsv" \
  "${OUT}/cds_len.tsv" \
> "${OUT}/j1_len.tsv"
# j1_len.tsv: gene \t cds_len

join -t $'\t' -a 1 -e 0 -o 1.1,1.2,2.2 \
  "${OUT}/j1_len.tsv" \
  "${OUT}/cds_snp_total.tsv" \
> "${OUT}/j2_total.tsv"
# j2_total.tsv: gene \t cds_len \t cds_snp_total

join -t $'\t' -a 1 -e 0 -o 1.1,1.2,1.3,2.2 \
  "${OUT}/j2_total.tsv" \
  "${OUT}/cds_deleterious_snp.tsv" \
> "${OUT}/j3_del.tsv"
# j3_del.tsv: gene \t cds_len \t cds_snp_total \t cds_deleterious_snp

############################################
# 7) final format
############################################
awk -v OFS="\t" '
BEGIN{
  print "gene_id","cds_len","cds_snp_total","cds_snp_ratio","cds_deleterious_snp","deleterious_ratio"
}
{
  gene=$1; len=$2; snp=$3; del=$4;
  snp_ratio = (len>0)? snp/len : 0;
  del_ratio = (snp>0)? del/snp : 0;
  printf "%s\t%d\t%d\t%.8f\t%d\t%.8f\n", gene, len, snp, snp_ratio, del, del_ratio
}' "${OUT}/j3_del.tsv" \
> "${OUT}/Atau_${TH}_core_gene_deleterious.tsv"

############################################
# cleanup
############################################
rm -f "${OUT}/base.tsv" "${OUT}/j1_len.tsv" "${OUT}/j2_total.tsv" "${OUT}/j3_del.tsv"

echo "[DONE] ${TH}"
