#!/bin/bash
#SBATCH --job-name=step1_parse_vcf
#SBATCH --nodes=1
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=30
#SBATCH --mem=400G
#SBATCH --output=step1_parse_vcf.%j.log
#SBATCH --error=step1_parse_vcf.%j.err
#SBATCH --partition=FAT1

set -euo pipefail

# ==============================
# Inputs
# ==============================
ref_name="Zmay.fa"
vcf_name="all.filtered.bi-allelic.miss0.5.snp.vcf.gz"
SIF="$HOME/liuliangmin/4.may/software/Reseq_genek.sif"

PY_SCRIPT="./mod_polar_1_parse.vartbl.py"
CONVERT_SCRIPT="./convert_tsv_format.py"

# mod_polar 使用哪个表：
#   - 若 mod_polar 解析的是 A/C/G/T 字母GT（你给的脚本是这样），用 table.tsv
#   - 若 mod_polar 解析的是 0/1 数字GT，改为 table_numeric.tsv
POLAR_INPUT_MODE="acgt"   # acgt 或 numeric
# ==============================

cd "$SLURM_SUBMIT_DIR"

echo "[INFO] PWD: $PWD"
echo "[INFO] REF: $ref_name"
echo "[INFO] VCF: $vcf_name"
echo "[INFO] SIF: $SIF"
echo "[INFO] PY_SCRIPT: $PY_SCRIPT"
echo "[INFO] POLAR_INPUT_MODE: $POLAR_INPUT_MODE"

# ------------------------------
# 0) Sanity checks
# ------------------------------
[[ -s "$ref_name" ]] || { echo "[ERROR] REF not found: $ref_name"; exit 1; }
[[ -s "$vcf_name" ]] || { echo "[ERROR] VCF not found: $vcf_name"; exit 1; }

# VCF index check
if [[ ! -s "${vcf_name}.tbi" ]]; then
  echo "[WARN] VCF index not found (${vcf_name}.tbi). Trying to create with bcftools index..."
  # 如果容器里有 bcftools，可以放到容器；这里假设宿主也可以
  bcftools index -t "$vcf_name"
fi
[[ -s "${vcf_name}.tbi" ]] || { echo "[ERROR] Still no VCF index: ${vcf_name}.tbi"; exit 1; }

# ------------------------------
# 1) Build reference index/dict (if needed)
# ------------------------------
if [[ ! -s "${ref_name}.fai" ]]; then
  echo "[INFO] Building FASTA index (.fai)"
  singularity exec "$SIF" samtools faidx "$ref_name"
fi
[[ -s "${ref_name}.fai" ]] || { echo "[ERROR] Failed to create ${ref_name}.fai"; exit 1; }

dict_name="${ref_name%.fa}.dict"
dict_name="${dict_name%.fasta}.dict"

if [[ ! -s "$dict_name" ]]; then
  echo "[INFO] Creating sequence dictionary: $dict_name"
  singularity exec --bind "$PWD:$PWD" "$SIF" \
    gatk CreateSequenceDictionary \
      -R "$ref_name" \
      -O "$dict_name"
fi
[[ -s "$dict_name" ]] || { echo "[ERROR] Failed to create dict: $dict_name"; exit 1; }

# ------------------------------
# 2) VariantsToTable
# ------------------------------
echo "[INFO] Running GATK VariantsToTable ..."
rm -f table.tsv

singularity exec --bind "$PWD:$PWD" "$SIF" \
  gatk VariantsToTable \
    --java-options "-Xms160g -Xmx160g -DGATK_STACKTRACE_ON_USER_EXCEPTION=true" \
    -V "$vcf_name" \
    -R "$ref_name" \
    -F CHROM -F POS -F REF -F ALT \
    -F NSAMPLES -F NCALLED -F AN -F HET -F HOM-REF -F HOM-VAR \
    -GF GT \
    -O table.tsv \
  1> variants_to_table.stdout.log \
  2> variants_to_table.stderr.log

if [[ ! -s table.tsv ]]; then
  echo "[ERROR] table.tsv not generated!"
  echo "[ERROR] Check logs: variants_to_table.stderr.log / variants_to_table.stdout.log"
  echo "[ERROR] First 50 lines of stderr:"
  sed -n '1,50p' variants_to_table.stderr.log || true
  exit 1
fi

echo "[INFO] table.tsv generated: $(wc -l < table.tsv) lines"
cp -f table.tsv input.table.tsv

# ------------------------------
# 3) Compute average AN (called alleles)
#    Column 7 is AN in your table format
# ------------------------------
n=$(awk 'NR>1 {sum+=$7; nsite+=1} END {if(nsite>0) print int(sum/nsite); else print 0}' table.tsv)
echo "[INFO] Average number of called alleles (AN): $n"

# ------------------------------
# 4) Optional: convert to numeric GT matrix (0/1)
# ------------------------------
if [[ -s "$CONVERT_SCRIPT" ]]; then
  echo "[INFO] Converting table.tsv to numeric GT format ..."
  python3 "$CONVERT_SCRIPT"
  [[ -s table_numeric.tsv ]] || echo "[WARN] table_numeric.tsv not found after conversion (check convert script)."
else
  echo "[WARN] convert script not found: $CONVERT_SCRIPT (skip)"
fi

# ------------------------------
# 5) Generate ACGT counts input for SFS/DAF (mod_polar parse)
# ------------------------------
## population 模式：
 #python3 "$py_name" -tab table.tsv -Nallele "$n"
 
 
 # 你现在固定 128；也可以改成用 $n（population 模式）
NALLELE_FIXED=128

polar_in="table.tsv"
if [[ "$POLAR_INPUT_MODE" == "numeric" ]]; then
  polar_in="table_numeric.tsv"
fi

[[ -s "$polar_in" ]] || { echo "[ERROR] polar input not found: $polar_in"; exit 1; }

echo "[INFO] Running mod_polar parser on: $polar_in (Nallele=$NALLELE_FIXED)"
python3 "$PY_SCRIPT" -tab "$polar_in" -Nallele "$NALLELE_FIXED"

# ------------------------------
# 6) Summary
# ------------------------------
echo "[INFO] Number of sites in ACGT input:"
ls -1 *.acgt.format.tsv 2>/dev/null | xargs -r wc -l

echo "[INFO] Number of variants in input VCF:"
zcat "$vcf_name" | grep -v "^#" | wc -l

echo "[INFO] Chromosome distribution in ACGT file:"
cut -f1 *.acgt.format.tsv | sort | uniq -c | sort -k2,2

echo "[INFO] Parsing completed."
