#!/bin/bash
#SBATCH -J sites_derivedcount
#SBATCH -p parallel
#SBATCH -N 1
#SBATCH -n 1
#SBATCH --mem=24G
#SBATCH --time=48:00:00
#SBATCH -o logs/sites_derivedcount.%j.out
#SBATCH -e logs/sites_derivedcount.%j.err

###############################################################################
# Pipeline:
#   Per-chromosome ancestral inference + genotype table
#   → genome-wide site-level derived allele count table
#
# Final output:
#   result/sites_derivedcount.genome.tsv
#
# Statistical meaning:
#   This table is the fundamental observation layer for
#   SFS / polyDFE / DAF / load inference.
###############################################################################

set -euo pipefail

echo "[INFO] Job started at $(date)"

###############################################################################
# 0. PATH CONFIGURATION
###############################################################################

ANCESTRAL_DIR="./ancestral_results"
TABLE_TSV="/gpfs/hpc/home/kib_unit/lidezhu/liuliangmin/5.deleterious/05_sfs/all_sfs/table.tsv"
SYN_XLS="/gpfs/hpc/home/kib_unit/lidezhu/liuliangmin/5.deleterious/05_sfs/all_sfs/TOLERATED_SYNONYMOUS.xls"
HICONF_BED="bed_classes/hiconf.bed"

WORKDIR="work"
RESULTDIR="result"
QCDIR="qc"
LOGDIR="logs"

mkdir -p ${WORKDIR} ${RESULTDIR} ${QCDIR} ${LOGDIR}

###############################################################################
# 1. PREPARE FUNCTIONAL CATEGORY MAPS
###############################################################################
# All category annotations are converted to:
#   CHROM  POS  category
###############################################################################

echo "[STEP 1] Preparing functional category maps"

# synonymous (1-based already)
awk 'BEGIN{OFS="\t"}{print $1,$2,"syn"}' \
  ${SYN_XLS} \
  > ${WORKDIR}/syn.sites.tsv

# high-confidence deleterious (BED → 1-based)
awk 'BEGIN{OFS="\t"}{print $1,$2+1,"hiconf"}' \
  ${HICONF_BED} \
  > ${WORKDIR}/hiconf.sites.tsv

# merge category maps (hiconf overrides syn if conflict)
cat ${WORKDIR}/syn.sites.tsv ${WORKDIR}/hiconf.sites.tsv \
  | awk '
    BEGIN{FS=OFS="\t"}
    {map[$1 FS $2]=$3}
    END{for(k in map) print k,map[k]}
  ' > ${WORKDIR}/category.map.tsv

###############################################################################
# 2. PER-CHROMOSOME DERIVED ALLELE COUNT
###############################################################################
# Output columns:
#   CHROM POS REF ALT ANC DER derived_count n_called
###############################################################################

echo "[STEP 2] Calculating per-chromosome derived allele counts"

> ${WORKDIR}/sites_derivedcount.allchr.raw.tsv

for ANC_BED in ${ANCESTRAL_DIR}/*.ancestral.bed; do

  CHR=$(basename ${ANC_BED} .ancestral.bed)
  echo "[INFO] Processing ${CHR}"

  # remove NA ancestral sites
  awk '$4!="NA"' ${ANC_BED} > ${WORKDIR}/${CHR}.ancestral.OK.bed

  # derived allele counting
  awk -v CHR=${CHR} '
  BEGIN { FS=OFS="\t" }

  # read ancestral
  FNR==NR {
    anc[$1 FS $2] = $4
    next
  }

  {
    if ($1 != CHR) next

    key = $1 FS $2
    if (!(key in anc)) next

    ANC = anc[key]
    if (ANC=="NA") next

    ref = $3
    alt = $4

    if (ANC==ref) DER=alt
    else if (ANC==alt) DER=ref
    else next

    derived = 0
    called  = 0

    for (i=10; i<=NF; i++) {
      gt=$i
      if (gt=="./.") continue
      split(gt,a,/[\/|]/)
      for (k in a) {
        called++
        if (a[k]==DER) derived++
      }
    }

    print $1,$2,ref,alt,ANC,DER,derived,called
  }
  ' ${WORKDIR}/${CHR}.ancestral.OK.bed ${TABLE_TSV} \
    > ${WORKDIR}/sites_derivedcount.${CHR}.tsv

  cat ${WORKDIR}/sites_derivedcount.${CHR}.tsv \
    >> ${WORKDIR}/sites_derivedcount.allchr.raw.tsv
done

###############################################################################
# 3. ADD FUNCTIONAL CATEGORY LABEL
###############################################################################
# Final output columns:
#   CHROM POS REF ALT ANC DER derived_count n_called category
###############################################################################

echo "[STEP 3] Adding functional category labels"

awk '
BEGIN { FS=OFS="\t" }

# read category map
FNR==NR {
  cat[$1 FS $2] = $3
  next
}

# join to derivedcount table
{
  key = $1 FS $2
  c = (key in cat ? cat[key] : "NA")
  print $1,$2,$3,$4,$5,$6,$7,$8,c
}
' ${WORKDIR}/category.map.tsv \
  ${WORKDIR}/sites_derivedcount.allchr.raw.tsv \
  > ${RESULTDIR}/sites_derivedcount.genome.tsv

###############################################################################
# 4. QC SUMMARY
###############################################################################
# Basic sanity checks for downstream inference
###############################################################################

echo "[STEP 4] QC summary"

{
echo "### Total sites"
wc -l ${RESULTDIR}/sites_derivedcount.genome.tsv

echo
echo "### derived_count distribution"
cut -f7 ${RESULTDIR}/sites_derivedcount.genome.tsv | sort | uniq -c

echo
echo "### n_called distribution"
cut -f8 ${RESULTDIR}/sites_derivedcount.genome.tsv | sort | uniq -c

echo
echo "### category counts"
cut -f9 ${RESULTDIR}/sites_derivedcount.genome.tsv | sort | uniq -c
} > ${QCDIR}/qc_summary.genome.txt

echo "[INFO] Pipeline finished successfully at $(date)"
