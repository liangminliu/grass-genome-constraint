#!/usr/bin/env bash
set -euo pipefail

############################################################
# 输入根目录
############################################################

DEL_DIR="core_gene_deleterious_ratio/gene_level"
GERP_DIR="ped_target_gene_CDS_GERP_stats"

OUTDIR="${DEL_DIR}/with_cdslen"
mkdir -p "${OUTDIR}"

############################################################
# 参数
############################################################

SUBS=(pedC pedD)
THS=(gt2 gt4 gt6)

############################################################
# 主循环
############################################################

for SUB in "${SUBS[@]}"; do
  for TH in "${THS[@]}"; do

    DEL_FILE="${DEL_DIR}/${SUB}_${TH}_gene_deleterious.tsv"
    STATS_FILE="${GERP_DIR}/gerp_${TH}/${SUB}/per_gene_stats.tsv"
    OUT_FILE="${OUTDIR}/${SUB}_${TH}_gene_deleterious.with_cdslen.tsv"

    echo "[INFO] Processing ${SUB} ${TH}"

    if [[ ! -s "${DEL_FILE}" ]]; then
      echo "[ERROR] Missing ${DEL_FILE}" >&2
      exit 1
    fi

    if [[ ! -s "${STATS_FILE}" ]]; then
      echo "[ERROR] Missing ${STATS_FILE}" >&2
      exit 1
    fi

    awk '
      BEGIN{FS=OFS="\t"}

      # 先读 per_gene_stats.tsv，取 cds_len（第 3 列）
      FNR==NR {
        if (NR>1)
          cdslen[$1]=$3
        next
      }

      # deleterious 表头
      NR==1 {
        print "gene_id","cds_len","cds_snp_total","deleterious_snp","deleterious_ratio"
        next
      }

      {
        g=$1
        len=(g in cdslen)? cdslen[g]:"NA"
        print g, len, $2, $3, $4
      }
    ' "${STATS_FILE}" "${DEL_FILE}" \
    > "${OUT_FILE}"

    echo "[INFO] Wrote ${OUT_FILE}"

  done
done

echo "[INFO] ALL DONE"
