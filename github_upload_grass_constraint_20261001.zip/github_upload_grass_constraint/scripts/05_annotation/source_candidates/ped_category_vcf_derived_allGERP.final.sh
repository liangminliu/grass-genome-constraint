#!/usr/bin/env bash
#SBATCH --job-name=ped_cat_vcf_derived
#SBATCH --partition=parallel
#SBATCH --nodes=1
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=10
#SBATCH --output=logs/ped_cat_vcf_derived_%j.out
#SBATCH --error=logs/ped_cat_vcf_derived_%j.err

set -euo pipefail
module load bedtools 2>/dev/null || true
module load bcftools 2>/dev/null || true
module load tabix 2>/dev/null || true

############################################################
# 0. Fixed inputs
############################################################
GENE_EXPANDED="ped_gene_expanded.tsv"
GENE_BED="genes.bed"
CDS_BED="CDS_jcvi.bed"
INTERSECT_ROOT="intersect_results"

GENE_SNP_INTERSECT="genes.intersect.bed"
CDS_SNP_INTERSECT="CDS_jcvi.intersect.bed"

ANCESTRAL_BED="all.ancestral.bed"

OUT_ROOT="ped_category_stats_vcf_derived"
mkdir -p logs "${OUT_ROOT}"

############################################################
# 1. Thresholds
############################################################
GERP_CLASSES=("gt2" "gt4" "gt6")

############################################################
# 2. Column definitions
############################################################
# genes.intersect.bed / CDS_jcvi.intersect.bed
SNP_GENE_COL=8

# detailed.bed definitions
DEL_CHR_COL=1
DEL_START_COL=2
DEL_END_COL=3
DEL_GERP_COL=7
DEL_GENE_COL=11

############################################################
# 3. Check common inputs
############################################################
for f in \
  "${GENE_EXPANDED}" \
  "${GENE_BED}" \
  "${CDS_BED}" \
  "${GENE_SNP_INTERSECT}" \
  "${CDS_SNP_INTERSECT}" \
  "${ANCESTRAL_BED}"
do
  [[ -s "${f}" ]] || { echo "[ERROR] Missing ${f}" >&2; exit 1; }
done

############################################################
# 4. Categories
############################################################
CATS=("retained_1to2" "pedC_only" "pedD_only")

############################################################
# 5. Clean common text inputs
############################################################
COMMON_TMP="${OUT_ROOT}/common_tmp"
mkdir -p "${COMMON_TMP}"

CLEAN_GENE_EXPANDED="${COMMON_TMP}/ped_gene_expanded.clean.tsv"
CLEAN_ANCESTRAL="${COMMON_TMP}/all.ancestral.clean.bed"

tr -d '\r' < "${GENE_EXPANDED}" > "${CLEAN_GENE_EXPANDED}"
tr -d '\r' < "${ANCESTRAL_BED}" > "${CLEAN_ANCESTRAL}"

############################################################
# Helpers
############################################################
normalize_gene_id() {
  sed -e 's/^pedC_//' -e 's/^pedD_//'
}

############################################################
# 6. Main loop over GERP classes
############################################################
for SHORT_CLASS in "${GERP_CLASSES[@]}"; do
  CLASS="gerp_${SHORT_CLASS}"

  echo
  echo "##########################################################"
  echo "[INFO] Processing ${CLASS}"
  echo "##########################################################"

  ##########################################################
  # per-class inputs
  ##########################################################
  VCF_PEDC="./pedC_${SHORT_CLASS}_snps.vcf.gz"
  VCF_PEDD="./pedD_${SHORT_CLASS}_snps.vcf.gz"

  GENE_DEL_BED_PEDC="pedC_${SHORT_CLASS}_genes_detailed.bed"
  CDS_DEL_BED_PEDC="pedC_${SHORT_CLASS}_CDS_jcvi_detailed.bed"
  GENE_DEL_BED_PEDD="pedD_${SHORT_CLASS}_genes_detailed.bed"
  CDS_DEL_BED_PEDD="pedD_${SHORT_CLASS}_CDS_jcvi_detailed.bed"

  for f in \
    "${VCF_PEDC}" "${VCF_PEDD}" \
    "${GENE_DEL_BED_PEDC}" "${CDS_DEL_BED_PEDC}" \
    "${GENE_DEL_BED_PEDD}" "${CDS_DEL_BED_PEDD}"
  do
    [[ -s "${f}" ]] || { echo "[ERROR] Missing ${f}" >&2; exit 1; }
  done

  ##########################################################
  # output dirs
  ##########################################################
  CLASS_DIR="${OUT_ROOT}/${CLASS}"
  TMP_DIR="${CLASS_DIR}/tmp"
  mkdir -p "${TMP_DIR}"

  PER_GENE_TSV="${CLASS_DIR}/all_categories_per_gene.tsv"
  SUMMARY_TSV="${CLASS_DIR}/all_categories_summary.tsv"
  DEL_SITE_TSV="${CLASS_DIR}/deleterious_site_table.tsv"
  DERIVED_SITE_TSV="${CLASS_DIR}/derived_site_table.tsv"
  QC_TSV="${CLASS_DIR}/qc_summary.tsv"

  ##########################################################
  # headers
  ##########################################################
  printf "%s\n" \
"subgenome	category	gerp_class	gene_id	gene_len	cds_len	gene_conserved_sites	gene_conserved_pct	cds_conserved_sites	cds_conserved_pct	gene_snp_total	gene_snp_density	cds_snp_total	cds_snp_density	gene_deleterious_snp	gene_deleterious_ratio	gene_deleterious_density	cds_deleterious_snp	cds_deleterious_ratio	cds_deleterious_density	gene_derived_del_count	gene_derived_del_freq_sum	gene_derived_del_density	cds_derived_del_count	cds_derived_del_freq_sum	cds_derived_del_density	mean_gene_del_gerp	max_gene_del_gerp	mean_cds_del_gerp	max_cds_del_gerp" \
  > "${PER_GENE_TSV}"

  printf "%s\n" \
"subgenome	category	gerp_class	n_genes	sum_gene_len	sum_cds_len	sum_gene_conserved_sites	gene_conserved_pct_weighted	sum_cds_conserved_sites	cds_conserved_pct_weighted	sum_gene_snp_total	gene_snp_density	sum_cds_snp_total	cds_snp_density	sum_gene_deleterious_snp	gene_deleterious_ratio	gene_deleterious_density	sum_cds_deleterious_snp	cds_deleterious_ratio	cds_deleterious_density	sum_gene_derived_del_count	sum_gene_derived_del_freq_sum	gene_derived_del_density	sum_cds_derived_del_count	sum_cds_derived_del_freq_sum	cds_derived_del_density	mean_gene_del_gerp_weighted	max_gene_del_gerp	max_cds_del_gerp_weighted	max_cds_del_gerp" \
  > "${SUMMARY_TSV}"

  printf "%s\n" \
"subgenome	category	gerp_class	region_type	gene_id	chr	start	end	ref	alt	af	ac	an	ancestral	derived_state	is_used_for_derived	derived_freq	gerp_score" \
  > "${DEL_SITE_TSV}"

  printf "%s\n" \
"subgenome	category	gerp_class	region_type	gene_id	chr	start	end	ref	alt	af	ac	an	ancestral	derived_state	derived_freq	gerp_score" \
  > "${DERIVED_SITE_TSV}"

  printf "%s\n" \
"subgenome	category	gerp_class	region_type	n_target_genes	n_deleterious_sites	n_with_ancestral	n_biallelic_snp	n_AA_eq_REF	n_AA_eq_ALT	n_ambiguous	n_used_for_derived" \
  > "${QC_TSV}"

  ##########################################################
  # 6.1 pre-extract VCF site table for pedC / pedD
  # columns: chr start end ref alt af ac an
  ##########################################################
  bcftools query -f '%CHROM\t%POS\t%REF\t%ALT\t%AF\t%AC\t%AN\n' "${VCF_PEDC}" \
  | awk 'BEGIN{FS=OFS="\t"}{
      if(index($4,",")>0) next
      if(length($3)!=1 || length($4)!=1) next
      print $1, $2-1, $2, toupper($3), toupper($4), $5, $6, $7
    }' > "${TMP_DIR}/pedC.vcf.sites.tsv"

  bcftools query -f '%CHROM\t%POS\t%REF\t%ALT\t%AF\t%AC\t%AN\n' "${VCF_PEDD}" \
  | awk 'BEGIN{FS=OFS="\t"}{
      if(index($4,",")>0) next
      if(length($3)!=1 || length($4)!=1) next
      print $1, $2-1, $2, toupper($3), toupper($4), $5, $6, $7
    }' > "${TMP_DIR}/pedD.vcf.sites.tsv"

  ##########################################################
  # 6.2 main over subgenomes and categories
  ##########################################################
  for SUB in pedC pedD; do
    echo
    echo "=========================================================="
    echo "[INFO] ${CLASS} / ${SUB}"
    echo "=========================================================="

    if [[ "${SUB}" == "pedC" ]]; then
      VCF_SITE_TABLE="${TMP_DIR}/pedC.vcf.sites.tsv"
      GENE_DEL_BED="${GENE_DEL_BED_PEDC}"
      CDS_DEL_BED="${CDS_DEL_BED_PEDC}"
    else
      VCF_SITE_TABLE="${TMP_DIR}/pedD.vcf.sites.tsv"
      GENE_DEL_BED="${GENE_DEL_BED_PEDD}"
      CDS_DEL_BED="${CDS_DEL_BED_PEDD}"
    fi

    GENE_GERP_ALL="${INTERSECT_ROOT}/${CLASS}/${SUB}_*.genes.intersect.bed"
    CDS_GERP_ALL="${INTERSECT_ROOT}/${CLASS}/${SUB}_*.CDS_jcvi.intersect.bed"

    if ! ls ${GENE_GERP_ALL} >/dev/null 2>&1; then
      echo "[ERROR] Missing ${GENE_GERP_ALL}" >&2
      exit 1
    fi
    if ! ls ${CDS_GERP_ALL} >/dev/null 2>&1; then
      echo "[ERROR] Missing ${CDS_GERP_ALL}" >&2
      exit 1
    fi

    for CAT in "${CATS[@]}"; do
      if [[ "${CAT}" == "pedC_only" && "${SUB}" == "pedD" ]]; then continue; fi
      if [[ "${CAT}" == "pedD_only" && "${SUB}" == "pedC" ]]; then continue; fi

      echo "[INFO] Category = ${CAT}"

      WORK_DIR="${TMP_DIR}/${CAT}/${SUB}"
      mkdir -p "${WORK_DIR}"

      ########################################################
      # target gene list
      ########################################################
      GENE_LIST="${WORK_DIR}/target_gene_ids.txt"

      awk -v sg="${SUB}" -v grp="${CAT}" 'BEGIN{FS="[[:space:]]+"; OFS="\t"}
        NR==1{next}
        {
          gsub(/\r/, "", $0)
          if ($2==sg && $4==grp && toupper($5)=="TRUE") print $1
        }' "${CLEAN_GENE_EXPANDED}" \
      | normalize_gene_id \
      | sort -u > "${GENE_LIST}"

      NGENE=$(wc -l < "${GENE_LIST}" || true)
      echo "[INFO] ${SUB} ${CAT} genes = ${NGENE}"
      if [[ "${NGENE}" -eq 0 ]]; then
        echo "[WARN] Empty gene set, skip"
        continue
      fi

      ########################################################
      # target gene / cds bed
      ########################################################
      TARGET_GENE_BED="${WORK_DIR}/target.genes.bed"
      TARGET_CDS_BED="${WORK_DIR}/target.cds.bed"

      awk 'BEGIN{OFS="\t"}{print $1,$2,$3,$4}' "${GENE_BED}" \
      | awk 'NR==FNR{a[$1]=1;next} a[$4]' "${GENE_LIST}" - \
      > "${TARGET_GENE_BED}"

      awk 'BEGIN{OFS="\t"}{
        gene=$4
        sub(/:.*/, "", gene)
        sub(/\..*/, "", gene)
        print $1,$2,$3,gene
      }' "${CDS_BED}" \
      | awk 'NR==FNR{a[$1]=1;next} a[$4]' "${GENE_LIST}" - \
      > "${TARGET_CDS_BED}"

      ########################################################
      # lengths
      ########################################################
      awk 'BEGIN{OFS="\t"}{len[$4]+=$3-$2} END{for(g in len) print g,len[g]}' \
        "${TARGET_GENE_BED}" | sort -k1,1 > "${WORK_DIR}/gene_length.tsv"

      sort -k4,4 -k1,1 -k2,2n "${TARGET_CDS_BED}" \
      | awk 'BEGIN{OFS="\t"}
        NR==1{cg=$4;cchr=$1;cs=$2;ce=$3;sum=0;next}
        {
          g=$4; chr=$1; s=$2; e=$3
          if(g!=cg || chr!=cchr){
            sum += (ce-cs); print cg,sum
            cg=g; cchr=chr; cs=s; ce=e; sum=0; next
          }
          if(s<=ce){ if(e>ce) ce=e }
          else { sum += (ce-cs); cs=s; ce=e }
        }
        END{ if(NR>0){ sum+=(ce-cs); print cg,sum } }' \
      | sort -k1,1 > "${WORK_DIR}/cds_length.tsv"

      ########################################################
      # conserved counts
      ########################################################
      bedtools intersect -wa -a ${GENE_GERP_ALL} -b "${TARGET_GENE_BED}" \
        > "${WORK_DIR}/gene_cons.raw.bed"
      bedtools intersect -wa -a ${CDS_GERP_ALL} -b "${TARGET_CDS_BED}" \
        > "${WORK_DIR}/cds_cons.raw.bed"

      if [[ -s "${WORK_DIR}/gene_cons.raw.bed" ]]; then
        awk 'BEGIN{OFS="\t"}{gene=$(NF-2); print $1,$2,$3,gene}' \
          "${WORK_DIR}/gene_cons.raw.bed" \
        | awk 'BEGIN{OFS="\t"}{k=$1"\t"$2"\t"$3"\t"$4; if(!seen[k]++) c[$4]++} END{for(g in c) print g,c[g]}' \
        | sort -k1,1 > "${WORK_DIR}/gene_conserved_count.tsv"
      else
        : > "${WORK_DIR}/gene_conserved_count.tsv"
      fi

      if [[ -s "${WORK_DIR}/cds_cons.raw.bed" ]]; then
        awk 'BEGIN{OFS="\t"}{
          gene=$(NF-2); sub(/:.*/, "", gene); sub(/\..*/, "", gene); print $1,$2,$3,gene
        }' "${WORK_DIR}/cds_cons.raw.bed" \
        | awk 'BEGIN{OFS="\t"}{k=$1"\t"$2"\t"$3"\t"$4; if(!seen[k]++) c[$4]++} END{for(g in c) print g,c[g]}' \
        | sort -k1,1 > "${WORK_DIR}/cds_conserved_count.tsv"
      else
        : > "${WORK_DIR}/cds_conserved_count.tsv"
      fi

      ########################################################
      # total SNP counts
      ########################################################
      awk -v gcol="${SNP_GENE_COL}" 'BEGIN{FS=OFS="\t"}
        NR==FNR{target[$1]=1; next}
        {
          gene=$(gcol); sub(/:.*/, "", gene); sub(/\..*/, "", gene)
          if(!(gene in target)) next
          k=$1"\t"$2"\t"$3"\t"gene
          if(!seen[k]++) c[gene]++
        }
        END{for(g in c) print g,c[g]}' \
        "${GENE_LIST}" "${GENE_SNP_INTERSECT}" \
      | sort -k1,1 > "${WORK_DIR}/gene_snp_total.tsv"

      awk -v gcol="${SNP_GENE_COL}" 'BEGIN{FS=OFS="\t"}
        NR==FNR{target[$1]=1; next}
        {
          gene=$(gcol); sub(/:.*/, "", gene); sub(/\..*/, "", gene)
          if(!(gene in target)) next
          k=$1"\t"$2"\t"$3"\t"gene
          if(!seen[k]++) c[gene]++
        }
        END{for(g in c) print g,c[g]}' \
        "${GENE_LIST}" "${CDS_SNP_INTERSECT}" \
      | sort -k1,1 > "${WORK_DIR}/cds_snp_total.tsv"

      ########################################################
      # deleterious site processing for gene/cds
      ########################################################
      for REGION in gene cds; do
        if [[ "${REGION}" == "gene" ]]; then
          DEL_BED="${GENE_DEL_BED}"
        else
          DEL_BED="${CDS_DEL_BED}"
        fi

        ######################################################
        # Step A: restrict detailed bed to target genes,
        # keep chr start end gene gerp_score
        ######################################################
        awk -v gcol="${DEL_GENE_COL}" \
            -v c1="${DEL_CHR_COL}" \
            -v c2="${DEL_START_COL}" \
            -v c3="${DEL_END_COL}" \
            -v gcol2="${DEL_GERP_COL}" \
            'BEGIN{FS=OFS="\t"}
            NR==FNR{target[$1]=1; next}
            {
              gene=$(gcol)
              sub(/:.*/, "", gene)
              sub(/\..*/, "", gene)
              if(!(gene in target)) next
              print $(c1), $(c2), $(c3), gene, $(gcol2)
            }' "${GENE_LIST}" "${DEL_BED}" \
        | sort -u > "${WORK_DIR}/${REGION}.deleterious.sites.basic.tsv"

        ######################################################
        # raw deleterious counts per gene
        ######################################################
        awk 'BEGIN{FS=OFS="\t"}{c[$4]++} END{for(g in c) print g,c[g]}' \
          "${WORK_DIR}/${REGION}.deleterious.sites.basic.tsv" \
        | sort -k1,1 > "${WORK_DIR}/${REGION}_deleterious_count.tsv"

        ######################################################
        # deleterious GERP summary per gene
        ######################################################
        awk 'BEGIN{FS=OFS="\t"}
          {
            sum[$4]+=$5
            n[$4]++
            if(!($4 in max) || $5>max[$4]) max[$4]=$5
          }
          END{
            for(g in n){
              mean=sum[g]/n[g]
              printf "%s\t%.10f\t%.10f\n", g, mean, max[g]
            }
          }' "${WORK_DIR}/${REGION}.deleterious.sites.basic.tsv" \
        | sort -k1,1 > "${WORK_DIR}/${REGION}_deleterious_gerp_summary.tsv"

        ######################################################
        # Step B: annotate deleterious sites with VCF + ancestral
        # output cols:
        # sub cat class region gene chr start end ref alt af ac an anc state use dfr gerp
        ######################################################
        awk 'BEGIN{FS=OFS="\t"}
          FNR==NR{
            k=$1"\t"$2"\t"$3
            anc[k]=toupper($4)
            next
          }
          ARGIND==2{
            k=$1"\t"$2"\t"$3
            ref[k]=toupper($4)
            alt[k]=toupper($5)
            af[k]=$6
            ac[k]=$7
            an[k]=$8
            next
          }
          {
            k=$1"\t"$2"\t"$3
            gene=$4
            gerp=$5

            r=(k in ref)?ref[k]:"."
            a=(k in alt)?alt[k]:"."
            f=(k in af)?af[k]:"."
            c=(k in ac)?ac[k]:"."
            n=(k in an)?an[k]:"."
            aa=(k in anc)?anc[k]:"."

            state="NO_ANCESTRAL"
            use="NO"
            dfr="."

            if (aa != ".") {
              state="AMBIGUOUS"
              if (r != "." && a != ".") {
                if (aa == r) {
                  state="AA_EQ_REF"
                  use="YES"
                  dfr=f
                } else if (aa == a) {
                  state="AA_EQ_ALT"
                  use="NO"
                  if (f != ".") dfr=1-f
                } else {
                  state="AMBIGUOUS"
                }
              }
            }

            print "'"${SUB}"'","'"${CAT}"'","'"${SHORT_CLASS}"'","'"${REGION}"'",gene,$1,$2,$3,r,a,f,c,n,aa,state,use,dfr,gerp
          }' \
          "${CLEAN_ANCESTRAL}" \
          "${VCF_SITE_TABLE}" \
          "${WORK_DIR}/${REGION}.deleterious.sites.basic.tsv" \
        > "${WORK_DIR}/${REGION}.deleterious.annotated.tsv"

        ######################################################
        # append deleterious site table
        ######################################################
        awk 'BEGIN{FS=OFS="\t"}{
          print $1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17,$18
        }' "${WORK_DIR}/${REGION}.deleterious.annotated.tsv" \
        >> "${DEL_SITE_TSV}"

        ######################################################
        # append derived site table (main analysis: use == YES)
        ######################################################
        awk 'BEGIN{FS=OFS="\t"} $16=="YES"{
          print $1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$17,$18
        }' "${WORK_DIR}/${REGION}.deleterious.annotated.tsv" \
        >> "${DERIVED_SITE_TSV}"

        ######################################################
        # derived per-gene count / freq
        ######################################################
        awk 'BEGIN{FS=OFS="\t"} $16=="YES"{
          c[$5]++
          s[$5]+=$17
        } END{
          for(g in c) printf "%s\t%d\t%.10f\n", g, c[g], s[g]
        }' "${WORK_DIR}/${REGION}.deleterious.annotated.tsv" \
        | sort -k1,1 > "${WORK_DIR}/${REGION}_derived_per_gene.tsv"

        ######################################################
        # QC summary
        ######################################################
        awk 'BEGIN{FS=OFS="\t"}
          {
            n++
            if($14!=".") a++
            if($9!="." && $10!=".") b++
            if($15=="AA_EQ_REF") r++
            else if($15=="AA_EQ_ALT") t++
            else if($15=="AMBIGUOUS") m++
            if($16=="YES") u++
          }
          END{
            printf "%s\t%s\t%s\t%s\t%d\t%d\t%d\t%d\t%d\t%d\t%d\t%d\n", \
              "'"${SUB}"'","'"${CAT}"'","'"${SHORT_CLASS}"'","'"${REGION}"'", "'"${NGENE}"'", n, a, b, r, t, m, u
          }' "${WORK_DIR}/${REGION}.deleterious.annotated.tsv" \
        >> "${QC_TSV}"
      done

      ########################################################
      # merge per-gene result
      ########################################################
      awk 'BEGIN{FS=OFS="\t"}
        ARGIND==1  {gl[$1]=$2; genes[$1]=1; next}
        ARGIND==2  {cl[$1]=$2; genes[$1]=1; next}
        ARGIND==3  {gcons[$1]=$2; next}
        ARGIND==4  {ccons[$1]=$2; next}
        ARGIND==5  {gsnp[$1]=$2; next}
        ARGIND==6  {csnp[$1]=$2; next}
        ARGIND==7  {gdel[$1]=$2; next}
        ARGIND==8  {cdel[$1]=$2; next}
        ARGIND==9  {gdc[$1]=$2; gdf[$1]=$3; next}
        ARGIND==10 {cdc[$1]=$2; cdf[$1]=$3; next}
        ARGIND==11 {gmean[$1]=$2; gmax[$1]=$3; next}
        ARGIND==12 {cmean[$1]=$2; cmax[$1]=$3; next}
        END{
          for(g in genes){
            gene_len=(g in gl)?gl[g]:0
            cds_len =(g in cl)?cl[g]:0

            gene_cons=(g in gcons)?gcons[g]:0
            cds_cons =(g in ccons)?ccons[g]:0

            gene_snp =(g in gsnp)?gsnp[g]:0
            cds_snp  =(g in csnp)?csnp[g]:0

            gene_del =(g in gdel)?gdel[g]:0
            cds_del  =(g in cdel)?cdel[g]:0

            gene_ddc =(g in gdc)?gdc[g]:0
            gene_ddf =(g in gdf)?gdf[g]:0
            cds_ddc  =(g in cdc)?cdc[g]:0
            cds_ddf  =(g in cdf)?cdf[g]:0

            gene_gmean=(g in gmean)?gmean[g]:0
            gene_gmax =(g in gmax)?gmax[g]:0
            cds_gmean =(g in cmean)?cmean[g]:0
            cds_gmax  =(g in cmax)?cmax[g]:0

            gene_cons_pct = (gene_len>0)?gene_cons/gene_len*100:0
            cds_cons_pct  = (cds_len>0)?cds_cons/cds_len*100:0

            gene_snp_den  = (gene_len>0)?gene_snp/gene_len:0
            cds_snp_den   = (cds_len>0)?cds_snp/cds_len:0

            gene_del_ratio = (gene_snp>0)?gene_del/gene_snp:0
            cds_del_ratio  = (cds_snp>0)?cds_del/cds_snp:0

            gene_del_den  = (gene_len>0)?gene_del/gene_len:0
            cds_del_den   = (cds_len>0)?cds_del/cds_len:0

            gene_dd_den   = (gene_len>0)?gene_ddc/gene_len:0
            cds_dd_den    = (cds_len>0)?cds_ddc/cds_len:0

            printf "%s\t%s\t%s\t%s\t%d\t%d\t%d\t%.6f\t%d\t%.6f\t%d\t%.6f\t%d\t%.6f\t%d\t%.6f\t%.6f\t%d\t%.6f\t%.6f\t%d\t%.10f\t%.6f\t%d\t%.10f\t%.6f\t%.10f\t%.10f\t%.10f\t%.10f\n", \
              "'"${SUB}"'","'"${CAT}"'","'"${SHORT_CLASS}"'",g,\
              gene_len,cds_len,\
              gene_cons,gene_cons_pct,\
              cds_cons,cds_cons_pct,\
              gene_snp,gene_snp_den,\
              cds_snp,cds_snp_den,\
              gene_del,gene_del_ratio,gene_del_den,\
              cds_del,cds_del_ratio,cds_del_den,\
              gene_ddc,gene_ddf,gene_dd_den,\
              cds_ddc,cds_ddf,cds_dd_den,\
              gene_gmean,gene_gmax,cds_gmean,cds_gmax
          }
        }' \
        "${WORK_DIR}/gene_length.tsv" \
        "${WORK_DIR}/cds_length.tsv" \
        "${WORK_DIR}/gene_conserved_count.tsv" \
        "${WORK_DIR}/cds_conserved_count.tsv" \
        "${WORK_DIR}/gene_snp_total.tsv" \
        "${WORK_DIR}/cds_snp_total.tsv" \
        "${WORK_DIR}/gene_deleterious_count.tsv" \
        "${WORK_DIR}/cds_deleterious_count.tsv" \
        "${WORK_DIR}/gene_derived_per_gene.tsv" \
        "${WORK_DIR}/cds_derived_per_gene.tsv" \
        "${WORK_DIR}/gene_deleterious_gerp_summary.tsv" \
        "${WORK_DIR}/cds_deleterious_gerp_summary.tsv" \
      | sort -k4,4 > "${WORK_DIR}/per_gene.tsv"

      cat "${WORK_DIR}/per_gene.tsv" >> "${PER_GENE_TSV}"

      ########################################################
      # category summary
      ########################################################
      awk 'BEGIN{FS=OFS="\t"}
        {
          n++
          sum_gl+=$5; sum_cl+=$6
          sum_gc+=$7; sum_cc+=$9
          sum_gs+=$11; sum_cs+=$13
          sum_gd+=$15; sum_cd+=$18
          sum_gdc+=$21; sum_gdf+=$22
          sum_cdc+=$24; sum_cdf+=$25

          # weighted gerp means by deleterious count
          if($15>0){ w_gmean_num += $27*$15; w_gmean_den += $15 }
          if($18>0){ w_cmean_num += $29*$18; w_cmean_den += $18 }

          if($28 > max_gmax) max_gmax = $28
          if($30 > max_cmax) max_cmax = $30
        }
        END{
          gcp=(sum_gl>0)?sum_gc/sum_gl*100:0
          ccp=(sum_cl>0)?sum_cc/sum_cl*100:0

          gsd=(sum_gl>0)?sum_gs/sum_gl:0
          csd=(sum_cl>0)?sum_cs/sum_cl:0

          gdr=(sum_gs>0)?sum_gd/sum_gs:0
          cdr=(sum_cs>0)?sum_cd/sum_cs:0

          gdd=(sum_gl>0)?sum_gd/sum_gl:0
          cdd=(sum_cl>0)?sum_cd/sum_cl:0

          gddd=(sum_gl>0)?sum_gdc/sum_gl:0
          cddd=(sum_cl>0)?sum_cdc/sum_cl:0

          wgmean=(w_gmean_den>0)?w_gmean_num/w_gmean_den:0
          wcmean=(w_cmean_den>0)?w_cmean_num/w_cmean_den:0

          printf "%s\t%s\t%s\t%d\t%d\t%d\t%d\t%.6f\t%d\t%.6f\t%d\t%.6f\t%d\t%.6f\t%d\t%.6f\t%.6f\t%d\t%.6f\t%.6f\t%d\t%.10f\t%.6f\t%d\t%.10f\t%.6f\t%.10f\t%.10f\t%.10f\t%.10f\n", \
            "'"${SUB}"'","'"${CAT}"'","'"${SHORT_CLASS}"'",\
            n,sum_gl,sum_cl,\
            sum_gc,gcp,\
            sum_cc,ccp,\
            sum_gs,gsd,\
            sum_cs,csd,\
            sum_gd,gdr,gdd,\
            sum_cd,cdr,cdd,\
            sum_gdc,sum_gdf,gddd,\
            sum_cdc,sum_cdf,cddd,\
            wgmean,max_gmax,wcmean,max_cmax
        }' "${WORK_DIR}/per_gene.tsv" >> "${SUMMARY_TSV}"
    done
  done

  echo "[INFO] Wrote ${CLASS_DIR}"
done

echo
echo "[INFO] DONE all gt2/gt4/gt6"