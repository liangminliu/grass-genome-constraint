#!/bin/bash
#SBATCH --job-name=step1_parse_vcf
#SBATCH --nodes=1
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=10
#SBATCH --mem=800G
#SBATCH --partition=FAT1
#SBATCH --output=logs/step1_parse_vcf.%j.log
#SBATCH --error=logs/step1_parse_vcf.%j.err

set -euo pipefail

############################################
# Inputs
############################################
REF_FA="Atau.fa"
VCF_GZ="141sp.filtered.bi-allelic.snp.vcf.gz"

SIF="$HOME/liuliangmin/4.may/software/Reseq_genek.sif"

PY_SCRIPT="./mod_polar_1_parse.vartbl.py"
CONVERT_SCRIPT="./convert_tsv_format.py"

POLAR_INPUT_MODE="acgt"
NALLELE_FIXED=128

############################################
# Setup
############################################
cd "$SLURM_SUBMIT_DIR"
mkdir -p logs

TMPDIR="${SLURM_TMPDIR:-$PWD/tmp}"
mkdir -p "$TMPDIR"

echo "[INFO] Working dir     : $PWD"
echo "[INFO] Temp dir        : $TMPDIR"
echo "[INFO] Reference fasta : $REF_FA"
echo "[INFO] Input VCF (gz)  : $VCF_GZ"

############################################
# 0) Sanity checks
############################################
[[ -s "$REF_FA" ]] || { echo "[ERROR] Missing $REF_FA"; exit 1; }
[[ -s "$VCF_GZ" ]] || { echo "[ERROR] Missing $VCF_GZ"; exit 1; }

############################################
# 1) Reference index + dict
############################################
if [[ ! -s "${REF_FA}.fai" ]]; then
  echo "[INFO] Building reference .fai"
  singularity exec --bind "$PWD:$PWD" "$SIF" \
    samtools faidx "$REF_FA"
fi

ref_base="${REF_FA%.fa}"
ref_base="${ref_base%.fasta}"
DICT="${ref_base}.dict"

if [[ ! -s "$DICT" ]]; then
  echo "[INFO] Building reference .dict"
  singularity exec --bind "$PWD:$PWD" "$SIF" \
    gatk CreateSequenceDictionary \
      -R "$REF_FA" \
      -O "$DICT"
fi

############################################
# 2) Detect ultra-long contigs (TBI incompatible)
############################################
TBI_MAX=536870911

echo "[INFO] Checking contig lengths (TBI limit = $TBI_MAX)"
awk -v m="$TBI_MAX" '
  $2 > m {print "[WARN] Ultra-long contig:", $1, $2}
' "${REF_FA}.fai" || true

############################################
# 3) Convert bgzip VCF → plain VCF
############################################
VCF_PLAIN="${TMPDIR}/$(basename "${VCF_GZ%.gz}")"

if [[ ! -s "$VCF_PLAIN" ]]; then
  echo "[INFO] Decompressing VCF → plain text"
  gunzip -c "$VCF_GZ" > "$VCF_PLAIN"
fi

[[ -s "$VCF_PLAIN" ]] || {
  echo "[ERROR] Failed to create plain VCF"
  exit 1
}

############################################
# 4) Build tribble index (.idx)
############################################
IDX="${VCF_PLAIN}.idx"

if [[ ! -s "$IDX" ]]; then
  echo "[INFO] Building tribble index (.idx)"
  singularity exec \
    --bind "$PWD:$PWD" \
    --bind "$TMPDIR:$TMPDIR" \
    "$SIF" \
    gatk IndexFeatureFile \
      -I "$VCF_PLAIN" \
    1> logs/indexfeaturefile.stdout.log \
    2> logs/indexfeaturefile.stderr.log || {
      echo "[ERROR] IndexFeatureFile failed"
      tail -n 50 logs/indexfeaturefile.stderr.log
      exit 1
    }
fi

[[ -s "$IDX" ]] || {
  echo "[ERROR] tribble index not found: $IDX"
  exit 1
}

############################################
# 5) VariantsToTable (guaranteed no Tabix)
############################################
echo "[INFO] Running VariantsToTable"

singularity exec \
  --bind "$PWD:$PWD" \
  --bind "$TMPDIR:$TMPDIR" \
  "$SIF" \
  gatk VariantsToTable \
    --java-options "-Xms500g -Xmx500g" \
    -V "$VCF_PLAIN" \
    -R "$REF_FA" \
    -F CHROM -F POS -F REF -F ALT \
    -F NSAMPLES -F NCALLED -F AN \
    -F HET -F HOM-REF -F HOM-VAR \
    -GF GT \
    -O table.tsv \
  1> logs/variants_to_table.stdout.log \
  2> logs/variants_to_table.stderr.log || {
    echo "[ERROR] VariantsToTable failed"
    tail -n 50 logs/variants_to_table.stderr.log
    exit 1
  }

[[ -s table.tsv ]] || {
  echo "[ERROR] table.tsv not generated"
  exit 1
}

############################################
# 6) Compute average AN (unchanged logic)
############################################
avg_AN=$(awk 'NR>1 {sum+=$7; n++} END {if(n>0) print int(sum/n); else print 0}' table.tsv)
echo "[INFO] Average AN = $avg_AN"

############################################
# 7) Optional genotype conversion
############################################
polar_input="table.tsv"
if [[ "$POLAR_INPUT_MODE" == "numeric" ]]; then
  echo "[INFO] Converting genotype letters → numeric"
  python3 "$CONVERT_SCRIPT"
  polar_input="table_numeric.tsv"
fi

############################################
# 8) Polar parsing
############################################
echo "[INFO] Running polar parse"
python3 "$PY_SCRIPT" \
  -tab "$polar_input" \
  -Nallele "$NALLELE_FIXED"

############################################
# 9) Summary
############################################
echo "[INFO] Generated ACGT files:"
ls -lh *.acgt.format.tsv 2>/dev/null || true

echo "[INFO] DONE (plain VCF + tribble .idx pipeline)"
