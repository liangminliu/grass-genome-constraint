#!/bin/bash
#SBATCH --job-name=snp_annotate_array
#SBATCH --output=logs/annotate_%A_%a.out  # %A=array job ID, %a=array task index
#SBATCH --error=logs/annotate_%A_%a.err
#SBATCH --partition=parallel
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=4  # Reduced since each task handles one BED file
#SBATCH --array=1-20%20  # N=number of BED files, %20 limits to 20 concurrent tasks

# 设置路径变量
VCF="63sp.filtered.bi-allelic.snp.renamed.vcf.gz"
BED_LIST="bed_list.txt"

# 创建输出目录
mkdir -p output_bed output_vcf 

# 获取BED文件总数和当前处理的BED文件
BED_FILES=($(cat $BED_LIST))
TOTAL_BEDS=${#BED_FILES[@]}
CURRENT_BED=${BED_FILES[$SLURM_ARRAY_TASK_ID-1]}
BASENAME=$(basename "$CURRENT_BED" .bed)

# 仅在第一个任务运行时创建统计文件头
if [ "$SLURM_ARRAY_TASK_ID" -eq 1 ]; then
    STATS_FILE="output_bed/intersect_stats.tsv"
    echo -e "BED_File\tTotal_SNPs\tUnique_SNPs" > $STATS_FILE
fi

echo "Processing $CURRENT_BED (Task $SLURM_ARRAY_TASK_ID/$TOTAL_BEDS)..."

# 1. 输出 BED：交集（VCF位点 + BED注释）
INTERSECT_FILE="output_bed/${BASENAME}.intersect.bed"
bedtools intersect -wa -wb \
    -a <(singularity exec ~/liuliangmin/4.may/software/Reseq_genek.sif bcftools query -f'%CHROM\t%POS0\t%POS\t%ID\n' $VCF) \
    -b "$CURRENT_BED" \
    > $INTERSECT_FILE

# 2. 统计结果
TOTAL_SNPS=$(wc -l < $INTERSECT_FILE)
UNIQUE_SNPS=$(cut -f4 $INTERSECT_FILE | sort | uniq | wc -l)

# 将统计结果追加到表格
echo -e "${BASENAME}\t${TOTAL_SNPS}\t${UNIQUE_SNPS}" >> $STATS_FILE

# 3. 输出新的VCF（保留原格式）：
#singularity exec ~/liuliangmin/4.may/software/Reseq_genek.sif bcftools view     -R "$CURRENT_BED"     -Oz -o output_vcf/${BASENAME}.vcf.gz     $VCF

# 4. VCF索引
#singularity exec ~/liuliangmin/4.may/software/Reseq_genek.sif bcftools index output_vcf/${BASENAME}.vcf.gz

# 最后一个任务打印完成信息
if [ "$SLURM_ARRAY_TASK_ID" -eq "$TOTAL_BEDS" ]; then
    echo "All BED files processed."
    echo "Statistics saved to $STATS_FILE"
fi