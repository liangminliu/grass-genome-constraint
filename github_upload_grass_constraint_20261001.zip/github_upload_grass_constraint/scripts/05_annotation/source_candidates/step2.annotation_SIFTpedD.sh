#!/bin/bash
#BSUB -J snpEff_pedD
#BSUB -q Q96C1T_X12
#BSUB -n 20
#BSUB -o snpEff_pedD.%J.out
#BSUB -e snpEff_pedD.%J.err

set -euo pipefail

mkdir -p SIFT0.05

singularity exec ~/workspace/4.reseq-chr/software/Reseq_genek.sif \
  java -jar /opt/snpEff/snpEff.jar \
  -c ./snpEff.config \
  -ud 5000 \
  -csvStats SIFT0.05/pedD.csv \
  -htmlStats SIFT0.05/pedD.html \
  -o vcf \
  ped \
  SIFT0.05/pedD_gt4_snps.vcf.gz \
  > SIFT0.05/pedD_gt4.snp.ann.vcf