#!/bin/bash
#SBATCH --job-name=snpEff
#SBATCH --output=snpEff.%A_%a.out
#SBATCH --error=snpEff.%A_%a.err
#SBATCH --cpus-per-task=20
#SBATCH --partition=parallel

singularity exec  ~/liuliangmin/4.may/software/Reseq_genek.sif java -jar /opt/snpEff/snpEff.jar -c  ./snpEff.config -ud 5000 -csvStats Atau.csv -htmlStats Atau.html -o vcf  Atau  141sp.filtered.bi-allelic.snp.vcf.gz > 141sp.filtered.bi-allelic.snp.ann.vcf