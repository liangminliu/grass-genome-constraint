#!/usr/bin/env bash
#SBATCH --job-name=ped_PolVeg_deleterious
#SBATCH --partition=parallel
#SBATCH --nodes=1
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=8
#SBATCH --array=1-3
#SBATCH --output=logs/ped_PolVeg_deleterious_%A_%a.out
#SBATCH --error=logs/ped_PolVeg_deleterious_%A_%a.err

set -euo pipefail

############################################################
# 0. Fixed inputs
############################################################

GERP_STAT_ROOT="ped_PolVeg_GERP_stats"
GENE_SNP_INTERSECT="genes.intersect.bed"
CDS_SNP_INTERSECT="CDS_jcvi.intersect.bed"

OUT_ROOT="ped_PolVeg_gene_deleterious_stats"
mkdir -p logs "${OUT_ROOT}"

############################################################
# 1. GERP thresholds (array)
############################################################

CLASSES=("gt2" "gt4" "gt6")
IDX=$((SLURM_ARRAY_TASK_ID - 1))

if [[ ${IDX} -lt 0 || ${IDX} -ge ${#CLASSES[@]} ]]; then
  echo "[ERROR] Bad SLURM_ARRAY_TASK_ID=${SLURM_ARRAY_TASK_ID}" >&2
  exit 1
fi

CLASS="${CLASSES[$IDX]}"
GERP_DIR="gerp_${CLASS}"

echo "[INFO] Threshold = ${CLASS}"

############################################################
# 2. Check common inputs
############################################################

[[ -s "${GENE_SNP_INTERSECT}" ]] || { echo "[ERROR] Missing ${GENE_SNP_INTERSECT}" >&2; exit 1; }
[[ -s "${CDS_SNP_INTERSECT}" ]]  || { echo "[ERROR] Missing ${CDS_SNP_INTERSECT}"  >&2; exit 1; }

############################################################
# 3. Target sets and subgenomes
############################################################

TARGET_NAMES=("Ped_Pol" "Ped_Veg")

for TARGET in "${TARGET_NAMES[@]}"; do
  echo
  echo "=========================================================="
  echo "[INFO] Target set = ${TARGET}"
  echo "=========================================================="

  for SUB in pedC pedD; do

    echo "[INFO] Subgenome = ${SUB}"

    ##########################################################
    # Input files
    ##########################################################

    PER_GENE_STAT="${GERP_STAT_ROOT}/${GERP_DIR}/${TARGET}/${SUB}/per_gene_stats.tsv"
    GENE_DEL_BED="${SUB}_${CLASS}_genes_detailed.bed"
    CDS_DEL_BED="${SUB}_${CLASS}_CDS_jcvi_detailed.bed"

    [[ -s "${PER_GENE_STAT}" ]] || { echo "[ERROR] Missing ${PER_GENE_STAT}" >&2; exit 1; }
    [[ -s "${GENE_DEL_BED}"   ]] || { echo "[ERROR] Missing ${GENE_DEL_BED}" >&2; exit 1; }
    [[ -s "${CDS_DEL_BED}"    ]] || { echo "[ERROR] Missing ${CDS_DEL_BED}" >&2; exit 1; }

    ##########################################################
    # Output dir
    ##########################################################

    OUT_DIR="${OUT_ROOT}/${CLASS}/${TARGET}/${SUB}"
    mkdir -p "${OUT_DIR}"

    ##########################################################
    # 4. gene_len & cds_len
    #    keep only gene_id, gene_len, cds_len
    ##########################################################

    awk 'BEGIN{FS=OFS="\t"}
      NR==1 {next}
      {
        print $1, $2, $3
      }' "${PER_GENE_STAT}" \
    | LC_ALL=C sort -k1,1 \
    > "${OUT_DIR}/gene_cds_len.tsv"

    ##########################################################
    # 5. target gene list (anchor genes)
    ##########################################################

    awk 'BEGIN{FS=OFS="\t"}{print $1}' "${OUT_DIR}/gene_cds_len.tsv" \
    > "${OUT_DIR}/target_gene_ids.txt"

    echo "[INFO] ${TARGET} ${SUB} target genes = $(wc -l < "${OUT_DIR}/target_gene_ids.txt")"

    ##########################################################
    # 6. gene_snp_total
    #
    # genes.intersect.bed:
    #   original script used column 8 as gene id
    #   normalize to gene-level id
    #   only keep target genes
    ##########################################################

    awk 'BEGIN{FS=OFS="\t"}
      NR==FNR{
        target[$1]=1
        next
      }
      {
        gene=$8
        gsub(/\r/, "", gene)
        sub(/:.*/, "", gene)
        sub(/\..*/, "", gene)
        if (!(gene in target)) next

        key=$1"\t"$2"\t"$3"\t"gene
        if(!seen[key]++) c[gene]++
      }
      END{
        for(g in c) print g, c[g]
      }' "${OUT_DIR}/target_gene_ids.txt" "${GENE_SNP_INTERSECT}" \
    | LC_ALL=C sort -k1,1 \
    > "${OUT_DIR}/gene_snp_total.tsv"

    ##########################################################
    # 7. cds_snp_total
    ##########################################################

    awk 'BEGIN{FS=OFS="\t"}
      NR==FNR{
        target[$1]=1
        next
      }
      {
        gene=$8
        gsub(/\r/, "", gene)
        sub(/:.*/, "", gene)
        sub(/\..*/, "", gene)
        if (!(gene in target)) next

        key=$1"\t"$2"\t"$3"\t"gene
        if(!seen[key]++) c[gene]++
      }
      END{
        for(g in c) print g, c[g]
      }' "${OUT_DIR}/target_gene_ids.txt" "${CDS_SNP_INTERSECT}" \
    | LC_ALL=C sort -k1,1 \
    > "${OUT_DIR}/cds_snp_total.tsv"

    ##########################################################
    # 8. gene_deleterious_snp
    #
    # detailed bed:
    #   original script used column 11 as gene id
    ##########################################################

    awk 'BEGIN{FS=OFS="\t"}
      NR==FNR{
        target[$1]=1
        next
      }
      {
        gene=$11
        gsub(/\r/, "", gene)
        sub(/:.*/, "", gene)
        sub(/\..*/, "", gene)
        if (!(gene in target)) next

        key=$1"\t"$2"\t"$3"\t"gene
        if(!seen[key]++) c[gene]++
      }
      END{
        for(g in c) print g, c[g]
      }' "${OUT_DIR}/target_gene_ids.txt" "${GENE_DEL_BED}" \
    | LC_ALL=C sort -k1,1 \
    > "${OUT_DIR}/gene_deleterious_snp.tsv"

    ##########################################################
    # 9. cds_deleterious_snp
    ##########################################################

    awk 'BEGIN{FS=OFS="\t"}
      NR==FNR{
        target[$1]=1
        next
      }
      {
        gene=$11
        gsub(/\r/, "", gene)
        sub(/:.*/, "", gene)
        sub(/\..*/, "", gene)
        if (!(gene in target)) next

        key=$1"\t"$2"\t"$3"\t"gene
        if(!seen[key]++) c[gene]++
      }
      END{
        for(g in c) print g, c[g]
      }' "${OUT_DIR}/target_gene_ids.txt" "${CDS_DEL_BED}" \
    | LC_ALL=C sort -k1,1 \
    > "${OUT_DIR}/cds_deleterious_snp.tsv"

    ##########################################################
    # 10. Merge & calculate ratios
    ##########################################################

    awk 'BEGIN{FS=OFS="\t"}
    ARGIND==1{
      gene_len[$1]=$2
      cds_len[$1]=$3
      genes[$1]=1
      next
    }
    ARGIND==2{
      gene_snp[$1]=$2
      next
    }
    ARGIND==3{
      gene_del[$1]=$2
      next
    }
    ARGIND==4{
      cds_snp[$1]=$2
      next
    }
    ARGIND==5{
      cds_del[$1]=$2
      next
    }
    END{
      print "gene_id","gene_len","gene_snp_total","gene_snp_ratio", \
            "gene_deleterious_snp","gene_deleterious_ratio", \
            "cds_len","cds_snp_total","cds_snp_ratio", \
            "cds_deleterious_snp","cds_deleterious_ratio"

      for(g in genes){
        gl = (g in gene_len) ? gene_len[g] : 0
        cl = (g in cds_len)  ? cds_len[g]  : 0
        gs = (g in gene_snp) ? gene_snp[g] : 0
        gd = (g in gene_del) ? gene_del[g] : 0
        cs = (g in cds_snp)  ? cds_snp[g]  : 0
        cd = (g in cds_del)  ? cds_del[g]  : 0

        gsr = (gl > 0) ? gs / gl : 0
        gdr = (gs > 0) ? gd / gs : 0
        csr = (cl > 0) ? cs / cl : 0
        cdr = (cs > 0) ? cd / cs : 0

        printf "%s\t%d\t%d\t%.6f\t%d\t%.6f\t%d\t%d\t%.6f\t%d\t%.6f\n", \
               g, gl, gs, gsr, gd, gdr, cl, cs, csr, cd, cdr
      }
    }' \
    "${OUT_DIR}/gene_cds_len.tsv" \
    "${OUT_DIR}/gene_snp_total.tsv" \
    "${OUT_DIR}/gene_deleterious_snp.tsv" \
    "${OUT_DIR}/cds_snp_total.tsv" \
    "${OUT_DIR}/cds_deleterious_snp.tsv" \
    > "${OUT_DIR}/gene_deleterious_stats.tsv"

    ##########################################################
    # 11. Minimal sanity prints
    ##########################################################

    echo "[INFO] Wrote: ${OUT_DIR}/gene_deleterious_stats.tsv"
    echo "[INFO] gene_cds_len           : $(wc -l < "${OUT_DIR}/gene_cds_len.tsv")"
    echo "[INFO] gene_snp_total         : $(wc -l < "${OUT_DIR}/gene_snp_total.tsv")"
    echo "[INFO] cds_snp_total          : $(wc -l < "${OUT_DIR}/cds_snp_total.tsv")"
    echo "[INFO] gene_deleterious_snp   : $(wc -l < "${OUT_DIR}/gene_deleterious_snp.tsv")"
    echo "[INFO] cds_deleterious_snp    : $(wc -l < "${OUT_DIR}/cds_deleterious_snp.tsv")"
    echo "[INFO] final rows             : $(tail -n +2 "${OUT_DIR}/gene_deleterious_stats.tsv" | wc -l)"

  done
done

echo "[INFO] DONE ${CLASS}"