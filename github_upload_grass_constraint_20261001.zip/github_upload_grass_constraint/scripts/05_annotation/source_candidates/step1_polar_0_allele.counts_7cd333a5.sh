#!/bin/bash
#SBATCH --job-name=step1_parse_vcf
#SBATCH --nodes=1
#SBATCH --ntasks=40
#SBATCH --output=step1_parse_vcf.%j.log
#SBATCH --error=step1_parse_vcf.%j.err
#SBATCH --partition=parallel

#ref=ped.fa
#vcf=63sp.filtered.bi-allelic.snp.renamed.vcf.gz
#vcf_index=63sp.filtered.bi-allelic.snp.renamed.vcf.gz.tbi
#SIF=~/liuliangmin/4.may/software/Reseq_genek.sif
PY_SCRIPT=./mod_polar_1_parse.vartbl.py  # polar_1_parse.vartbl.py 脚本位置
# ==============================

cd "$SLURM_SUBMIT_DIR" || exit 1
py_name="$PY_SCRIPT"


#singularity exec "$SIF" samtools faidx ped.fa 
#singularity exec "$SIF" gatk CreateSequenceDictionary \
   # --REFERENCE ped.fa \
    #--OUTPUT ped.dict
# 1. 提取 genotype counts（GATK4 语法）
#singularity exec "$SIF" gatk VariantsToTable \
#    --java-options "-DGATK_STACKTRACE_ON_USER_EXCEPTION=true -Xms160g -Xmx160g" \
 #   --V "$vcf_name" \
   # --R "$ref_name" \
   # -F CHROM -F POS -F REF -F ALT \
    #-F NSAMPLES -F NCALLED -F AN -F HET -F HOM-REF -F HOM-VAR \
    #-GF GT \
    #-O table.tsv

#if [ ! -s table.tsv ]; then
    #echo "Error: table.tsv not generated!"
    #exit 1
#fi

# 2. 获取平均等位基因数
n=$(awk '{sum+=$7} END {if(NR>1) print int(sum/(NR-1)); else print 0}' table.tsv)
echo "Average number of called alleles: $n"
#Average number of called alleles: 125

## 备份原始文件
#cp table.tsv input.table.tsv

## 转换为数字格式
#python3 convert_tsv_format.py

# 3. population 模式 或 polarisation key 模式
## population 模式：
# python3 "$py_name" -tab table.tsv -Nallele "$n"

## polarisation key 模式（固定 56）：
python3 "$py_name" -tab table.tsv -Nallele 128

# 4. 输出统计
echo "Number of sites in ACGT input:"
wc -l *.acgt.format.tsv

echo "Number of variants in input VCF:"
zcat "$vcf_name" | grep -v "^#" | wc -l

echo "Chromosome distribution in ACGT file:"
cut -f1 *.acgt.format.tsv | sort | uniq -c | sort -k2

echo "Parsing completed."