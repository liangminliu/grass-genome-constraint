#!/bin/bash
#SBATCH --job-name=snpEff_pedC
#SBATCH --output=snpEff_pedC.%A_%a.out
#SBATCH --error=snpEff_pedC.%A_%a.err
#SBATCH --cpus-per-task=20
#SBATCH --partition=parallel

singularity exec  ~/liuliangmin/4.may/software/Reseq_genek.sif java -jar /opt/snpEff/snpEff.jar -c  ./snpEff.config -ud 5000 -csvStats 63sp_C/pedC.csv -htmlStats 63sp_C/pedC.html -o vcf  ped  63sp_C/C_subgenome_complete.vcf.gz > 63sp_C/63sp.filtered.pedC.snp.ann.vcf