#!/bin/bash
#BSUB -J ped_CD_sift_MAF
#BSUB -q Q64C1T_X4
#BSUB -n 10
#BSUB -o logs/ped_CD_sift_MAF.%J.out
#BSUB -e logs/ped_CD_sift_MAF.%J.err

set -euo pipefail

mkdir -p logs
mkdir -p results

VCF_C="C_annot/pedC.sift_lt0.05.vcf.gz"
VCF_D="D_annot/pedD.sift_lt0.05.vcf.gz"

PREFIX_C="results/pedC.sift_lt0.05"
PREFIX_D="results/pedD.sift_lt0.05"
OUT_PREFIX="results/ped.sift_lt0.05"

echo "[INFO] job started at $(date)"
echo "[INFO] host: $(hostname)"
echo "[INFO] workdir: $(pwd)"

# frequency calculation
if [[ ! -f "${PREFIX_C}.frq" ]]; then
    bash 01_calc_maf_vcftools.sh "${VCF_C}" "${PREFIX_C}"
else
    echo "[INFO] found existing ${PREFIX_C}.frq, skip vcftools"
fi

if [[ ! -f "${PREFIX_D}.frq" ]]; then
    bash 01_calc_maf_vcftools.sh "${VCF_D}" "${PREFIX_D}"
else
    echo "[INFO] found existing ${PREFIX_D}.frq, skip vcftools"
fi

# plotting
# 0.005  -> finer bins
# count  -> y-axis as counts
# FALSE  -> remove MAF=0 fixed sites
Rscript 02_plot_maf_hist.R \
    "${PREFIX_C}.frq" \
    "${PREFIX_D}.frq" \
    "${OUT_PREFIX}" \
    0.005 count FALSE

echo "[INFO] finished at $(date)"