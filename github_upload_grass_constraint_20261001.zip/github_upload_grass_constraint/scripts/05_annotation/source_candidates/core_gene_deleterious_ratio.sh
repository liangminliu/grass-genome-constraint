#!/bin/bash
#SBATCH --job-name=core_del_ratio
#SBATCH --partition=parallel
#SBATCH --nodes=1
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=4
#SBATCH --array=1-3
#SBATCH --output=logs/core_del_ratio_%A_%a.out
#SBATCH --error=logs/core_del_ratio_%A_%a.err

set -euo pipefail

############################################################
# 0. 固定输入（已确认语义）
############################################################
PAN="core_5sp_1to1.SG.pan"

# 分母：所有 CDS 上的 SNP（不分阈值）
ALL_CDS_SNP="CDS_jcvi.intersect.bed"

# 分子：有害突变（已按阈值）
# 当前目录下已有 symlink：
#   pedC_gt2_CDS_jcvi_detailed.bed
#   pedD_gt2_CDS_jcvi_detailed.bed
#   pedC_gt4_CDS_jcvi_detailed.bed ...
#   pedC_gt6_CDS_jcvi_detailed.bed ...

OUTDIR="core_gene_deleterious_ratio"
mkdir -p logs "${OUTDIR}"

############################################################
# 1. GERP 阈值（array）
############################################################
THRESHOLDS=("gt2" "gt4" "gt6")
IDX=$((SLURM_ARRAY_TASK_ID-1))
TH=${THRESHOLDS[$IDX]}
echo "[INFO] GERP threshold = ${TH}"

############################################################
# 2. 工具函数：core SNP 计数
############################################################
count_core_snps () {
  local core_gene_list=$1
  local bed=$2

  awk -v CORE="${core_gene_list}" '
    BEGIN{FS=OFS="\t"}
    FNR==NR { core[$1]=1; next }
    {
      gene=$(NF-2)
      sub(/^ped[CD]_/, "", gene)
      sub(/:.*/, "", gene)
      sub(/\..*/, "", gene)

      if (gene in core) {
        key=$1"\t"$2"\t"$3
        if (!seen[key]++) n++
      }
    }
    END{print n+0}
  ' "${core_gene_list}" "${bed}"
}

############################################################
# 3. 主循环：pedC / pedD
############################################################
for SUB in pedC pedD; do
  echo "[INFO] Subgenome = ${SUB}"

  ##########################################################
  # 3.1 core gene list
  ##########################################################
  if [[ "${SUB}" == "pedC" ]]; then COL=7; else COL=8; fi
  CORE_GENES="${OUTDIR}/core_${SUB}_genes.txt"

  awk -v c=${COL} 'BEGIN{FS="\t"}{
    g=$c
    sub(/^ped[CD]_/, "", g)
    print g
  }' "${PAN}" | sort -u > "${CORE_GENES}"

  ##########################################################
  # 3.2 分母：core 基因内全部 CDS SNP
  ##########################################################
  SNP_TOTAL=$(count_core_snps "${CORE_GENES}" "${ALL_CDS_SNP}")

  ##########################################################
  # 3.3 分子：core 基因内有害突变
  ##########################################################
  DEL_FILE="${SUB}_${TH}_CDS_jcvi_detailed.bed"
  if [[ ! -s "${DEL_FILE}" ]]; then
    echo "[ERROR] Missing ${DEL_FILE}" >&2
    exit 1
  fi

  SNP_DEL=$(count_core_snps "${CORE_GENES}" "${DEL_FILE}")

  ##########################################################
  # 3.4 比例
  ##########################################################
  RATIO=$(awk -v d=${SNP_DEL} -v t=${SNP_TOTAL} \
    'BEGIN{ if(t>0) printf "%.8f", d/t; else print "0.00000000"}')

  ##########################################################
  # 3.5 输出
  ##########################################################
  OUT="${OUTDIR}/core_deleterious_ratio.tsv"
  if [[ ! -f "${OUT}" ]]; then
    echo -e "subgenome\tgerp_threshold\tcore_cds_snp\tcore_deleterious_snp\tratio" > "${OUT}"
  fi

  echo -e "${SUB}\t${TH}\t${SNP_TOTAL}\t${SNP_DEL}\t${RATIO}" >> "${OUT}"

done

echo "[INFO] DONE threshold ${TH}"
