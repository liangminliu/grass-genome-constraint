#!/usr/bin/env Rscript

suppressPackageStartupMessages({
  library(dplyr)
  library(readr)
  library(stringr)
  library(tidyr)
  library(ggplot2)
  library(ggsignif)
  library(patchwork)
})

## =========================================================
## Parameters
## =========================================================
PAN_FILE <- "core_5sp_1to1.SG.pan"
THRESHOLDS <- c("gt2", "gt4", "gt6")

OUT_PREFIX <- "SG_cross_species_deleterious"
OUT_PDF    <- paste0(OUT_PREFIX, "_gray_violin_box_v2.pdf")

## =========================================================
## 1. Read pan file
## =========================================================
pan <- read_tsv(PAN_FILE, col_names = FALSE, show_col_types = FALSE)
colnames(pan) <- c(
  "SG_ID", "n_sp", "n_copy", "flag",
  "Atau", "Osat", "pedC", "pedD", "Zmay"
)

pan_sg <- pan %>%
  transmute(
    SG_ID,
    Atau = str_remove(Atau, "^Atau_"),
    pedC = str_remove(pedC, "^pedC_"),
    pedD = str_remove(pedD, "^pedD_"),
    Zmay = str_remove(Zmay, "^Zmay_")
  )

## =========================================================
## 2. Helper
## =========================================================
read_del <- function(file) {
  read_tsv(file, show_col_types = FALSE) %>%
    select(gene_id, deleterious_ratio)
}

## =========================================================
## 3. Core analysis per threshold
## =========================================================
analyze_one_threshold <- function(TH) {

  Atau <- read_del(paste0("Atau_", TH, "_gene_deleterious.tsv"))
  Zmay <- read_del(paste0("Zmay_", TH, "_gene_deleterious.tsv"))
  pedC <- read_del(paste0("pedC_", TH, "_gene_deleterious_stats.tsv"))
  pedD <- read_del(paste0("pedD_", TH, "_gene_deleterious_stats.tsv"))

  df <- pan_sg %>%
    left_join(Atau, by = c("Atau" = "gene_id")) %>%
    rename(Atau_ratio = deleterious_ratio) %>%
    left_join(Zmay, by = c("Zmay" = "gene_id")) %>%
    rename(Zmay_ratio = deleterious_ratio) %>%
    left_join(pedC, by = c("pedC" = "gene_id")) %>%
    rename(pedC_ratio = deleterious_ratio) %>%
    left_join(pedD, by = c("pedD" = "gene_id")) %>%
    rename(pedD_ratio = deleterious_ratio) %>%
    filter(
      !is.na(Atau_ratio),
      !is.na(Zmay_ratio),
      !is.na(pedC_ratio),
      !is.na(pedD_ratio)
    ) %>%
    mutate(
      ped_ratio = (pedC_ratio + pedD_ratio) / 2,
      threshold = TH
    )

  write_tsv(df, paste0(OUT_PREFIX, "_", TH, ".tsv"))

  df %>%
    select(SG_ID, threshold,
           Atau_ratio, ped_ratio, Zmay_ratio) %>%
    pivot_longer(
      cols = c(Atau_ratio, ped_ratio, Zmay_ratio),
      names_to = "species",
      values_to = "deleterious_ratio"
    ) %>%
    mutate(
      species = recode(
        species,
        Atau_ratio = "A. tauschii",
        ped_ratio  = "P. edulis",
        Zmay_ratio = "Z. mays"
      )
    )
}

## =========================================================
## 4. Run all thresholds
## =========================================================
plot_df_all <- bind_rows(
  lapply(THRESHOLDS, analyze_one_threshold)
)

## =========================================================
## 5. Unified y-axis (with bottom padding)
## =========================================================
Y_MAX <- max(plot_df_all$deleterious_ratio, na.rm = TRUE)

Y_LIM <- c(0, Y_MAX * 1.25)

## =========================================================
## 6. Plot function (final polished style)
## =========================================================
make_panel <- function(df_sub, TH) {

  ggplot(
    df_sub,
    aes(x = species, y = deleterious_ratio)
  ) +
    geom_violin(
      fill = "grey70",
      color = NA,
      trim = TRUE,
      scale = "width"
    ) +
    geom_boxplot(
      width = 0.18,
      fill = "white",
      color = "black",
      linewidth = 0.6,
      outlier.shape = NA
    ) +
    geom_signif(
      comparisons = list(
        c("A. tauschii", "P. edulis"),
        c("P. edulis",  "Z. mays"),
        c("A. tauschii", "Z. mays")
      ),
      test = "wilcox.test",
      map_signif_level = TRUE,
      step_increase = 0.10,
      textsize = 4
    ) +
    scale_y_continuous(
      limits = Y_LIM,
      expand = expansion(mult = c(0.05, 0))  # <<< 关键修改
    ) +
    labs(
      title = paste0("GERP > ", gsub("gt", "", TH)),
      x = NULL,
      y = "Deleterious mutation ratio"
    ) +
    theme_bw(base_size = 13) +
    theme(
      panel.border = element_rect(color = "black", linewidth = 0.8),
      panel.grid.major = element_line(color = "grey92", linewidth = 0.4),
      panel.grid.minor = element_blank(),
      axis.text.x = element_text(size = 11),
      axis.text.y = element_text(size = 11),
      axis.title.y = element_text(size = 13),
      plot.title = element_text(
        hjust = 0.5,
        face = "bold",
        size = 14
      ),
      legend.position = "none"
    )
}

## =========================================================
## 7. Combine panels
## =========================================================
p_list <- lapply(
  THRESHOLDS,
  function(TH) {
    make_panel(
      plot_df_all %>% filter(threshold == TH),
      TH
    )
  }
)

final_plot <- wrap_plots(p_list, nrow = 1)

ggsave(
  OUT_PDF,
  final_plot,
  width = 11,
  height = 4
)

message(">>> DONE")
message("Tables: ", paste0(OUT_PREFIX, "_{gt2,gt4,gt6}.tsv"))
message("Figure: ", OUT_PDF)
