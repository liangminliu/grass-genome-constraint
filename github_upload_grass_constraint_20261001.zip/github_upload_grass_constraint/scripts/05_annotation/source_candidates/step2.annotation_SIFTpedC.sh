#!/bin/bash
#BSUB -J snpEff_pedC
#BSUB -q Q96C1T_X12
#BSUB -n 20
#BSUB -o snpEff_pedC.%J.out
#BSUB -e snpEff_pedC.%J.err

set -euo pipefail

mkdir -p SIFT0.05

singularity exec ~/workspace/4.reseq-chr/software/Reseq_genek.sif \
  java -jar /opt/snpEff/snpEff.jar \
  -c ./snpEff.config \
  -ud 5000 \
  -csvStats SIFT0.05/pedC.csv \
  -htmlStats SIFT0.05/pedC.html \
  -o vcf \
  ped \
  SIFT0.05/pedC_gt4_snps.vcf.gz \
  > SIFT0.05/pedC_gt4.snp.ann.vcf