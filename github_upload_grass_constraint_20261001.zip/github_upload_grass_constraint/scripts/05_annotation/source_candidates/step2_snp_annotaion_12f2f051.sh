#!/bin/bash
#SBATCH --job-name=snp_annotate_array
#SBATCH --output=logs/annotate_%A_%a.out  # %A=array job ID, %a=array task index
#SBATCH --error=logs/annotate_%A_%a.err
#SBATCH --partition=parallel
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=4  # Reduced since each task handles one BED file
#SBATCH --array=1-2%2  # N=number of BED files, %20 limits to 20 concurrent tasks

#这个脚本用于对多个BED文件进行SNP注释，生成交集BED文件和对应的VCF文件。

# 设置路径变量
VCF="./2.1_vcf.filter/all.filtered.bi-allelic.miss0.5.snp.vcf.gz"
BED_LIST="4-d_bed_list.txt"

# 创建输出目录
mkdir -p output_bed output_vcf logs

# 获取BED文件总数和当前处理的BED文件
BED_FILES=($(cat $BED_LIST))
TOTAL_BEDS=${#BED_FILES[@]}
CURRENT_BED=${BED_FILES[$SLURM_ARRAY_TASK_ID-1]}
BASENAME=$(basename "$CURRENT_BED" .bed)

echo "Processing $CURRENT_BED (Task $SLURM_ARRAY_TASK_ID/$TOTAL_BEDS)..."

# 1. 输出 BED：交集（VCF位点 + BED注释）
INTERSECT_FILE="output_bed/${BASENAME}.intersect.bed"
bedtools intersect -wa -wb \
    -a <(singularity exec ~/liuliangmin/4.may/software/Reseq_genek.sif bcftools query -f'%CHROM\t%POS0\t%POS\t%ID\n' $VCF) \
    -b "$CURRENT_BED" \
    > $INTERSECT_FILE

# 2. 输出新的VCF（保留原格式）
singularity exec ~/liuliangmin/4.may/software/Reseq_genek.sif bcftools view \
    -R "$CURRENT_BED" \
    -Oz -o output_vcf/${BASENAME}.vcf.gz \
    $VCF

# 3. VCF索引
singularity exec ~/liuliangmin/4.may/software/Reseq_genek.sif bcftools index output_vcf/${BASENAME}.vcf.gz

echo "Completed processing $CURRENT_BED"