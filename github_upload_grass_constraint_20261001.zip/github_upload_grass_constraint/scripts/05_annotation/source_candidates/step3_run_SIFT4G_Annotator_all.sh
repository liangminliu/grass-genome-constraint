#!/bin/bash
#SBATCH --job-name=SIFT4G_Annot_ALL
#SBATCH --output=SIFT4G_Annot_ALL_%j.out
#SBATCH --error=SIFT4G_Annot_ALL_%j.err
#SBATCH --cpus-per-task=24
#SBATCH --mem=180G
#SBATCH --partition=parallel

# ============================================================
# SIFT4G Annotator for ALL chromosomes (PED 全基因组)
# ============================================================

set -euo pipefail

# ---------- 软件与数据库路径 ----------
SIFT4G_JAR="/gpfs/hpc/home/kib_unit/lidezhu/zf/sift4g/SIFT4G_Annotator.jar"
DB_DIR="/gpfs/hpc/home/kib_unit/lidezhu/liuliangmin/5.deleterious/06_SIFT/scripts_to_build_SIFT_db/test_files/PED/PED.V2.full"
MEMORY="120G"

# ---------- 输入与输出路径 ----------
VCF_DIR="/gpfs/hpc/home/kib_unit/lidezhu/liuliangmin/5.deleterious/06_SIFT/SIFI_annotator"
INPUT_VCF="${VCF_DIR}/63sp.filtered.mainChr.vcf.gz"

OUT_BASE="${VCF_DIR}/SIFT4G_results"
OUTPUT_DIR="${OUT_BASE}/ALL_annot"
mkdir -p "${OUTPUT_DIR}" "${OUT_BASE}/logs"

echo "====================================================="
echo "[INFO] Host: $(hostname)"
echo "[INFO] Date: $(date)"
echo "[INFO] Input VCF: ${INPUT_VCF}"
echo "[INFO] Database:  ${DB_DIR}"
echo "[INFO] Output Dir: ${OUTPUT_DIR}"
echo "====================================================="

# ---------- 检查输入 ----------
if [[ ! -f "${INPUT_VCF}" ]]; then
    echo "[ERROR] 找不到输入文件: ${INPUT_VCF}"
    exit 1
fi

if [[ ! -d "${DB_DIR}" ]]; then
    echo "[ERROR] 找不到数据库目录: ${DB_DIR}"
    exit 1
fi

# ---------- 如果是 .vcf.gz，则自动解压 ----------
TMP_VCF="${OUTPUT_DIR}/$(basename ${INPUT_VCF%.gz})"
if [[ "${INPUT_VCF}" == *.vcf.gz ]]; then
    echo "[INFO] 检测到压缩 VCF 文件，正在解压 ..."
    zcat "${INPUT_VCF}" > "${TMP_VCF}"
    echo "[INFO] 已解压到: ${TMP_VCF}"
else
    cp "${INPUT_VCF}" "${TMP_VCF}"
fi

# ---------- 运行 SIFT4G Annotator ----------
echo "[RUN] java -Xms${MEMORY} -Xmx${MEMORY} -jar ${SIFT4G_JAR}"

java -Xms${MEMORY} -Xmx${MEMORY} -jar "${SIFT4G_JAR}" \
    -c \
    -i "${TMP_VCF}" \
    -d "${DB_DIR}" \
    -r "${OUTPUT_DIR}" \
    -t > "${OUTPUT_DIR}/sift4g.log" 2>&1

# ---------- 检查运行状态 ----------
if grep -q "Completed successfully" "${OUTPUT_DIR}/sift4g.log"; then
    echo "[SUCCESS] 全基因组注释完成 ✅"
    echo "[LOG] ${OUTPUT_DIR}/sift4g.log"
else
    echo "[WARNING] 全基因组注释可能未正常结束，请检查日志:"
    echo "          ${OUTPUT_DIR}/sift4g.log"
fi

# ---------- 清理临时文件 ----------
rm -f "${TMP_VCF}"

echo "[DONE] $(date)"
