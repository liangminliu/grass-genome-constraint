#!/bin/bash
#SBATCH --job-name=snpEff_pedD
#SBATCH --output=snpEff_pedD.%A_%a.out
#SBATCH --error=snpEff_pedD.%A_%a.err
#SBATCH --cpus-per-task=20
#SBATCH --partition=parallel

singularity exec  ~/liuliangmin/4.may/software/Reseq_genek.sif java -jar /opt/snpEff/snpEff.jar -c  ./snpEff.config -ud 5000 -csvStats 71sp_D/pedD.csv -htmlStats 71sp_D/pedD.html -o vcf  ped  71sp_D/D_subgenome_complete.vcf.gz > 71sp_D/71sp.filtered.pedD.snp.ann.vcf