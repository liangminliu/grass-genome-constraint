#!/usr/bin/env bash
#SBATCH --job-name=ped_core_deleterious
#SBATCH --partition=parallel
#SBATCH --nodes=1
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=8
#SBATCH --array=1-3
#SBATCH --output=logs/ped_core_deleterious_%A_%a.out
#SBATCH --error=logs/ped_core_deleterious_%A_%a.err

set -euo pipefail

############################################################
# 0. Fixed inputs
############################################################

CORE_STAT_ROOT="ped_target_gene_CDS_GERP_stats"
GENE_SNP_INTERSECT="genes.intersect.bed"
CDS_SNP_INTERSECT="CDS_jcvi.intersect.bed"

OUT_ROOT="ped_core_gene_deleterious_stats"
mkdir -p logs "${OUT_ROOT}"

############################################################
# 1. GERP thresholds (array)
############################################################

CLASSES=("gt2" "gt4" "gt6")
IDX=$((SLURM_ARRAY_TASK_ID - 1))
CLASS="${CLASSES[$IDX]}"

echo "[INFO] Threshold = ${CLASS}"

############################################################
# 2. Subgenomes
############################################################

for SUB in pedC pedD; do

  echo "[INFO] Subgenome = ${SUB}"

  ##########################################################
  # Input files
  ##########################################################

  PER_GENE_STAT="${CORE_STAT_ROOT}/gerp_${CLASS}/${SUB}/per_gene_stats.tsv"
  GENE_DEL_BED="${SUB}_${CLASS}_genes_detailed.bed"
  CDS_DEL_BED="${SUB}_${CLASS}_CDS_jcvi_detailed.bed"

  [[ -s "${PER_GENE_STAT}" ]] || { echo "[ERROR] Missing ${PER_GENE_STAT}" >&2; exit 1; }
  [[ -s "${GENE_SNP_INTERSECT}" ]] || { echo "[ERROR] Missing ${GENE_SNP_INTERSECT}" >&2; exit 1; }
  [[ -s "${CDS_SNP_INTERSECT}" ]] || { echo "[ERROR] Missing ${CDS_SNP_INTERSECT}" >&2; exit 1; }
  [[ -s "${GENE_DEL_BED}" ]] || { echo "[ERROR] Missing ${GENE_DEL_BED}" >&2; exit 1; }
  [[ -s "${CDS_DEL_BED}" ]] || { echo "[ERROR] Missing ${CDS_DEL_BED}" >&2; exit 1; }

  ##########################################################
  # Output dir
  ##########################################################

  OUT_DIR="${OUT_ROOT}/${CLASS}/${SUB}"
  mkdir -p "${OUT_DIR}"

  ##########################################################
  # 3. gene_len & cds_len
  ##########################################################

  awk 'NR>1{print $1,$2,$3}' OFS="\t" \
    "${PER_GENE_STAT}" \
  | LC_ALL=C sort -k1,1 \
  > "${OUT_DIR}/gene_cds_len.tsv"

  ##########################################################
  # 4. gene_snp_total
  ##########################################################

  awk 'BEGIN{OFS="\t"}{
    gene=$8
    sub(/:.*/, "", gene)
    sub(/\..*/, "", gene)
    key=$1"\t"$2"\t"$3"\t"gene
    if(!seen[key]++) c[gene]++
  }
  END{for(g in c) print g,c[g]}' \
  "${GENE_SNP_INTERSECT}" \
  | LC_ALL=C sort -k1,1 \
  > "${OUT_DIR}/gene_snp_total.tsv"

  ##########################################################
  # 5. cds_snp_total
  ##########################################################

  awk 'BEGIN{OFS="\t"}{
    gene=$8
    sub(/:.*/, "", gene)
    sub(/\..*/, "", gene)
    key=$1"\t"$2"\t"$3"\t"gene
    if(!seen[key]++) c[gene]++
  }
  END{for(g in c) print g,c[g]}' \
  "${CDS_SNP_INTERSECT}" \
  | LC_ALL=C sort -k1,1 \
  > "${OUT_DIR}/cds_snp_total.tsv"

  ##########################################################
  # 6. gene_deleterious_snp
  ##########################################################

  awk 'BEGIN{OFS="\t"}{
    gene=$11
    sub(/:.*/, "", gene)
    sub(/\..*/, "", gene)
    key=$1"\t"$2"\t"$3"\t"gene
    if(!seen[key]++) c[gene]++
  }
  END{for(g in c) print g,c[g]}' \
  "${GENE_DEL_BED}" \
  | LC_ALL=C sort -k1,1 \
  > "${OUT_DIR}/gene_deleterious_snp.tsv"

  ##########################################################
  # 7. cds_deleterious_snp
  ##########################################################

  awk 'BEGIN{OFS="\t"}{
    gene=$11
    sub(/:.*/, "", gene)
    sub(/\..*/, "", gene)
    key=$1"\t"$2"\t"$3"\t"gene
    if(!seen[key]++) c[gene]++
  }
  END{for(g in c) print g,c[g]}' \
  "${CDS_DEL_BED}" \
  | LC_ALL=C sort -k1,1 \
  > "${OUT_DIR}/cds_deleterious_snp.tsv"

  ##########################################################
  # 8. Merge & calculate ratios
  ##########################################################

  awk 'BEGIN{FS=OFS="\t"}
  ARGIND==1 && FNR>1{
    gene_len[$1]=$2
    cds_len[$1]=$3
    genes[$1]=1
    next
  }
  ARGIND==2{
    gene_snp[$1]=$2
    next
  }
  ARGIND==3{
    gene_del[$1]=$2
    next
  }
  ARGIND==4{
    cds_snp[$1]=$2
    next
  }
  ARGIND==5{
    cds_del[$1]=$2
    next
  }
  END{
    print "gene_id","gene_len","gene_snp_total","gene_snp_ratio",
          "gene_deleterious_snp","gene_deleterious_ratio",
          "cds_len","cds_snp_total","cds_snp_ratio",
          "cds_deleterious_snp","cds_deleterious_ratio"
    
    for(g in genes){
      gl = gene_len[g]
      cl = cds_len[g]
      gs = (g in gene_snp) ? gene_snp[g] : 0
      gd = (g in gene_del) ? gene_del[g] : 0
      cs = (g in cds_snp) ? cds_snp[g] : 0
      cd = (g in cds_del) ? cds_del[g] : 0
      
      gsr = (gl > 0) ? gs / gl : 0
      gdr = (gs > 0) ? gd / gs : 0
      csr = (cl > 0) ? cs / cl : 0
      cdr = (cs > 0) ? cd / cs : 0
      
      printf "%s\t%d\t%d\t%.6f\t%d\t%.6f\t%d\t%d\t%.6f\t%d\t%.6f\n",
             g, gl, gs, gsr, gd, gdr, cl, cs, csr, cd, cdr
    }
  }' "${OUT_DIR}/gene_cds_len.tsv" \
     "${OUT_DIR}/gene_snp_total.tsv" \
     "${OUT_DIR}/gene_deleterious_snp.tsv" \
     "${OUT_DIR}/cds_snp_total.tsv" \
     "${OUT_DIR}/cds_deleterious_snp.tsv" \
  > "${OUT_DIR}/core_gene_deleterious_stats.tsv"

  echo "[INFO] Wrote: ${OUT_DIR}/core_gene_deleterious_stats.tsv"

done

echo "[INFO] DONE ${CLASS}"