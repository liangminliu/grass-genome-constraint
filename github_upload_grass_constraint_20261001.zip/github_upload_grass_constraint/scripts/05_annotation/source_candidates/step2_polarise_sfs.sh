#!/bin/bash
#SBATCH --job-name=polarise_Zmay_1OG
#SBATCH --partition=parallel
#SBATCH --nodes=1
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=8
#SBATCH --array=1-10
#SBATCH --output=logs/polarise_%A_%a.out
#SBATCH --error=logs/polarise_%A_%a.err

###############################################################################
# est-sfs polarisation pipeline for Zea mays
# STRICT single-outgroup version
# DEBUG / INSPECTABLE VERSION:
#   - use tmp_chrX under current directory
#   - keep all intermediate files
###############################################################################

set -euo pipefail

############################
# Automatically set chromosome
############################
chr="chr${SLURM_ARRAY_TASK_ID}"

############################
# User-defined inputs
############################
wd=$SLURM_SUBMIT_DIR

focfreq="table.acgt.format.tsv"
outgr="Zmay.Sbic.Sita.wga.bed"

outd="est_sfs_results"

############################
# Sanity checks
############################
[[ -f "$wd/$focfreq" ]] || { echo "[ERROR] $focfreq not found"; exit 1; }
[[ -f "$wd/$outgr"   ]] || { echo "[ERROR] $outgr not found"; exit 1; }
command -v bedtools >/dev/null 2>&1 || { echo "[ERROR] bedtools not found"; exit 1; }

mkdir -p "$wd/$outd" "$wd/logs"

echo "===================================================="
echo "[INFO] Chromosome : $chr"
echo "[INFO] Job ID     : ${SLURM_JOB_ID:-NA}"
echo "[INFO] Array ID   : ${SLURM_ARRAY_TASK_ID}"
echo "===================================================="

############################
# Working directory (DEBUG MODE)
############################
WORKDIR="$wd/tmp2_${chr}"
mkdir -p "$WORKDIR"
cd "$WORKDIR"

echo "[INFO] Working directory: $WORKDIR"

############################
# Copy inputs
############################
cp "$wd/$focfreq" .
cp "$wd/$outgr"   .

############################
# Step 1. Filter chromosome
############################
grep "^$chr" "$focfreq" > ${chr}.focal.bed
grep "^$chr" "$outgr"   > ${chr}.outgroup.raw.bed

echo "[INFO] focal SNPs: $(wc -l < ${chr}.focal.bed)"
echo "[INFO] outgroup raw: $(wc -l < ${chr}.outgroup.raw.bed)"

############################
# Step 2. Remove indels & ambiguity from outgroup
############################
awk '$8 ~ /^[ACGT],[ACGT]$/' ${chr}.outgroup.raw.bed \
  | sort -k1,1 -k2,2n \
  > ${chr}.outgroup.noindel.bed

echo "[INFO] outgroup noindel: $(wc -l < ${chr}.outgroup.noindel.bed)"

############################
# Step 3. Intersect focal SNPs with outgroup
############################
bedtools intersect -sorted -loj \
  -a <(sort -k1,1 -k2,2n ${chr}.focal.bed) \
  -b ${chr}.outgroup.noindel.bed \
  > ${chr}.intersected

echo "[INFO] intersected lines: $(wc -l < ${chr}.intersected)"

############################
# Step 4. Build est-sfs input (SINGLE outgroup)
############################
paste \
  <(cut -f4 ${chr}.intersected) \
  <(cut -f12 ${chr}.intersected | awk -F, '
{
  a=c=g=t=0;
  # Extract OUTGROUP allele (second base, Sita)
  outgroup=$2;
  if(outgroup=="A" || outgroup=="a") a=1;
  else if(outgroup=="C" || outgroup=="c") c=1;
  else if(outgroup=="G" || outgroup=="g") g=1;
  else if(outgroup=="T" || outgroup=="t") t=1;
  printf "%d,%d,%d,%d\n", a,c,g,t
}') > ${chr}.est_sfs.input
############################
# Step 5. Report missing outgroup sites (corrected)
############################
missing=$(awk -F'\t' '$2=="0,0,0,0"{n++} END{print n+0}' ${chr}.est_sfs.input)
total=$(wc -l < ${chr}.est_sfs.input)

echo "[INFO] Missing outgroup sites: $missing / $total"

############################
# Step 6. Copy final result
############################
cp ${chr}.est_sfs.input "$wd/$outd/"

echo "[DONE] ${chr} finished."
echo "[DONE] tmp directory kept at: $WORKDIR"
