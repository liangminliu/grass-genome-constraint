#!/bin/bash
#SBATCH --job-name=snpEff_pedC
#SBATCH --output=snpEff_pedC.%A_%a.out
#SBATCH --error=snpEff_pedC.%A_%a.err
#SBATCH --cpus-per-task=20
#SBATCH --partition=parallel

singularity exec  ~/liuliangmin/4.may/software/Reseq_genek.sif java -jar /opt/snpEff/snpEff.jar -c  ./snpEff.config -ud 5000 -csvStats 71sp_C/pedC.csv -htmlStats 71sp_C/pedC.html -o vcf  ped  71sp_C/C_subgenome_complete.vcf.gz > 71sp_C/71sp.filtered.pedC.snp.ann.vcf