#!/bin/bash
#SBATCH --job-name=Zmay_del_ratio
#SBATCH --partition=parallel
#SBATCH --nodes=1
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=2
#SBATCH --array=1-3
#SBATCH --output=logs/Zmay_del_ratio_%A_%a.out
#SBATCH --error=logs/Zmay_del_ratio_%A_%a.err

set -euo pipefail

############################################################
# 0. 输入文件（语义已确认）
############################################################

# 分母：所有 CDS-SNP（不分阈值）
ALL_CDS_SNP="CDS_processed.intersect.bed"

# 分子：有害突变（按 GERP 阈值）
GT2="merged_gt2_CDS_detailed.bed"
GT4="merged_gt4_CDS_detailed.bed"
GT6="merged_gt6_CDS_detailed.bed"

OUTDIR="Zmay_deleterious_ratio"
mkdir -p logs "${OUTDIR}"

############################################################
# 1. array 参数
############################################################
THRESHOLDS=("gt2" "gt4" "gt6")
FILES=("${GT2}" "${GT4}" "${GT6}")

IDX=$((SLURM_ARRAY_TASK_ID - 1))
TH=${THRESHOLDS[$IDX]}
DEL_FILE=${FILES[$IDX]}

echo "[INFO] GERP threshold = ${TH}"
echo "[INFO] Deleterious file = ${DEL_FILE}"

if [[ ! -s "${DEL_FILE}" ]]; then
  echo "[ERROR] Missing ${DEL_FILE}" >&2
  exit 1
fi

############################################################
# 2. 分母：CDS-SNP 总数（1bp 去重）
############################################################
TOTAL_CDS_SNP=$(awk '
  BEGIN{FS=OFS="\t"}
  {
    key=$1"\t"$2"\t"$3
    if(!seen[key]++) n++
  }
  END{print n+0}
' "${ALL_CDS_SNP}")

############################################################
# 3. 分子：有害突变位点数（1bp 去重）
############################################################
DELETERIOUS_SNP=$(awk '
  BEGIN{FS=OFS="\t"}
  {
    key=$1"\t"$2"\t"$3
    if(!seen[key]++) n++
  }
  END{print n+0}
' "${DEL_FILE}")

############################################################
# 4. 比例计算
############################################################
RATIO=$(awk -v d=${DELETERIOUS_SNP} -v t=${TOTAL_CDS_SNP} '
  BEGIN{
    if(t>0) printf "%.8f", d/t;
    else print "0.00000000"
  }')

############################################################
# 5. 输出
############################################################
OUT="${OUTDIR}/Zmay_deleterious_ratio.tsv"
if [[ ! -f "${OUT}" ]]; then
  echo -e "gerp_threshold\tcds_snp_total\tdeleterious_snp\tratio" > "${OUT}"
fi

echo -e "${TH}\t${TOTAL_CDS_SNP}\t${DELETERIOUS_SNP}\t${RATIO}" >> "${OUT}"

echo "[INFO] DONE ${TH}"
