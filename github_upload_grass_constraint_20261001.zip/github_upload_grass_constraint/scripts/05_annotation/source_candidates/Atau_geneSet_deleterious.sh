#!/usr/bin/env bash
#SBATCH --job-name=Atau_geneSet_deleterious
#SBATCH --partition=parallel
#SBATCH --nodes=1
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=6
#SBATCH --array=1-3
#SBATCH --output=logs/Atau_geneSet_del_%A_%a.out
#SBATCH --error=logs/Atau_geneSet_del_%A_%a.err

set -euo pipefail

############################################
# 0. inputs
############################################
ALL_CDS_SNP="CDS_processed.intersect.bed"
CDS_GENE_BED="CDS.gene.bed"

# 来自上一套 GERP gene-set 统计结果
STAT_ROOT="target_gene_CDS_GERP_stats_byList"

# 需要处理的目标基因列表
TARGET_LISTS=(
  "Atau_Pol.list"
  "Atau_Veg.list"
)

declare -A DEL
DEL[gt2]="merged_gt2_CDS_detailed.bed"
DEL[gt4]="merged_gt4_CDS_detailed.bed"
DEL[gt6]="merged_gt6_CDS_detailed.bed"

############################################
# 1. array
############################################
CLS=(gt2 gt4 gt6)
IDX=$((SLURM_ARRAY_TASK_ID - 1))
if [[ $IDX -lt 0 || $IDX -ge ${#CLS[@]} ]]; then
  echo "[ERROR] Bad SLURM_ARRAY_TASK_ID=${SLURM_ARRAY_TASK_ID}" >&2
  exit 1
fi
TH="${CLS[$IDX]}"

OUT_ROOT="Atau_geneSet_deleterious"
mkdir -p logs "${OUT_ROOT}"

echo "[INFO] Threshold: ${TH}"
echo "[INFO] ALL_CDS_SNP: ${ALL_CDS_SNP}"
echo "[INFO] CDS_GENE_BED: ${CDS_GENE_BED}"
echo "[INFO] STAT_ROOT: ${STAT_ROOT}"
echo "[INFO] DEL file: ${DEL[$TH]}"

############################################
# 2. 规范化全基因组 CDS BED
#    统一去掉 gene: 前缀，保证和 list 一致
############################################
CDS_GENE_BED_NORM="${OUT_ROOT}/CDS.gene.normalized.bed"

awk 'BEGIN{OFS="\t"}
{
  g=$4
  sub(/^gene:/, "", g)
  print $1, $2, $3, g
}' "${CDS_GENE_BED}" \
| LC_ALL=C sort -k1,1 -k2,2n -k3,3n -k4,4 \
> "${CDS_GENE_BED_NORM}"

############################################
# 3. 循环处理每个基因列表
############################################
for LIST in "${TARGET_LISTS[@]}"; do
  if [[ ! -s "${LIST}" ]]; then
    echo "[WARN] Skip missing or empty list: ${LIST}"
    continue
  fi

  GROUP=$(basename "${LIST}")
  GROUP=${GROUP%.list}

  OUT="${OUT_ROOT}/${GROUP}/${TH}"
  mkdir -p "${OUT}"

  echo "[INFO] ----------------------------------------"
  echo "[INFO] Processing group: ${GROUP}"
  echo "[INFO] Source list: ${LIST}"
  echo "[INFO] Output dir : ${OUT}"

  ##########################################
  # 3.1 target gene list
  #     去掉 gene: 前缀，去重
  ##########################################
  awk '
  {
    g=$1
    sub(/^gene:/, "", g)
    if(g!="") print g
  }' "${LIST}" \
  | LC_ALL=C sort -u \
  > "${OUT}/target_gene.list"

  N_TARGET=$(wc -l < "${OUT}/target_gene.list")
  echo "[INFO] ${GROUP} target genes: ${N_TARGET}"

  ##########################################
  # 3.2 target CDS bed
  #     从全基因组 CDS 注释中提取目标基因对应 CDS
  #     sort -u 去重，避免重复 block 导致重复 intersect
  ##########################################
  awk 'NR==FNR{a[$1]=1; next} ($4 in a)' \
    "${OUT}/target_gene.list" "${CDS_GENE_BED_NORM}" \
  | LC_ALL=C sort -u \
  > "${OUT}/target_cds.bed"

  N_CDS=$(wc -l < "${OUT}/target_cds.bed")
  echo "[INFO] ${GROUP} target CDS records: ${N_CDS}"

  ##########################################
  # 3.3 CDS SNP total per gene
  #     输出: gene \t count
  #
  #     用 gene_id=$NF 更稳健，因为 -b 是4列BED
  ##########################################
  if [[ -s "${OUT}/target_cds.bed" ]]; then
    bedtools intersect -wa -wb \
      -a "${ALL_CDS_SNP}" \
      -b "${OUT}/target_cds.bed" \
    | awk -v OFS="\t" '
      {
        g=$NF
        k=$1":"$2"-"$3":"g
        if(!seen[k]++) c[g]++
      }
      END{
        for(g in c) print g, c[g]
      }' \
    | LC_ALL=C sort -k1,1 \
    > "${OUT}/cds_snp_total.tsv"
  else
    : > "${OUT}/cds_snp_total.tsv"
  fi

  ##########################################
  # 3.4 deleterious CDS SNP per gene
  #     输出: gene \t count
  ##########################################
  if [[ -s "${OUT}/target_cds.bed" ]]; then
    bedtools intersect -wa -wb \
      -a "${DEL[$TH]}" \
      -b "${OUT}/target_cds.bed" \
    | awk -v OFS="\t" '
      {
        g=$NF
        k=$1":"$2"-"$3":"g
        if(!seen[k]++) c[g]++
      }
      END{
        for(g in c) print g, c[g]
      }' \
    | LC_ALL=C sort -k1,1 \
    > "${OUT}/cds_deleterious_snp.tsv"
  else
    : > "${OUT}/cds_deleterious_snp.tsv"
  fi

  ##########################################
  # 3.5 CDS length per gene
  #     从上一套 GERP gene-set 统计结果中提取第1列 gene_id、第3列 cds_len
  #
  #     per_gene_stats.tsv 列为：
  #     gene_id gene_len cds_len gene_sites gene_pct cds_sites cds_pct
  ##########################################
  PER_GENE_STAT="${STAT_ROOT}/${GROUP}/${TH}/per_gene_stats.tsv"

  if [[ ! -s "${PER_GENE_STAT}" ]]; then
    echo "[ERROR] Missing per_gene_stats.tsv: ${PER_GENE_STAT}" >&2
    exit 1
  fi

  awk -v OFS="\t" 'NR>1{print $1,$3}' "${PER_GENE_STAT}" \
  | LC_ALL=C sort -k1,1 \
  > "${OUT}/cds_len.tsv"

  ##########################################
  # 3.6 以 target_gene.list 为主键全集，依次 join
  ##########################################
  awk -v OFS="\t" '{print $1,0}' "${OUT}/target_gene.list" \
  | LC_ALL=C sort -k1,1 \
  > "${OUT}/base.tsv"

  # gene \t cds_len
  join -t $'\t' -a 1 -e 0 -o 1.1,2.2 \
    "${OUT}/base.tsv" \
    "${OUT}/cds_len.tsv" \
  > "${OUT}/j1_len.tsv"

  # gene \t cds_len \t cds_snp_total
  join -t $'\t' -a 1 -e 0 -o 1.1,1.2,2.2 \
    "${OUT}/j1_len.tsv" \
    "${OUT}/cds_snp_total.tsv" \
  > "${OUT}/j2_total.tsv"

  # gene \t cds_len \t cds_snp_total \t cds_deleterious_snp
  join -t $'\t' -a 1 -e 0 -o 1.1,1.2,1.3,2.2 \
    "${OUT}/j2_total.tsv" \
    "${OUT}/cds_deleterious_snp.tsv" \
  > "${OUT}/j3_del.tsv"

  ##########################################
  # 3.7 final result
  ##########################################
  awk -v OFS="\t" '
  BEGIN{
    print "gene_id","cds_len","cds_snp_total","cds_snp_ratio","cds_deleterious_snp","deleterious_ratio"
  }
  {
    gene=$1
    len=$2+0
    snp=$3+0
    del=$4+0

    snp_ratio = (len>0) ? snp/len : 0
    del_ratio = (snp>0) ? del/snp : 0

    printf "%s\t%d\t%d\t%.8f\t%d\t%.8f\n", gene, len, snp, snp_ratio, del, del_ratio
  }' "${OUT}/j3_del.tsv" \
  > "${OUT}/${GROUP}_${TH}_gene_deleterious.tsv"

  ##########################################
  # 3.8 summary
  ##########################################
  awk -v grp="${GROUP}" -v th="${TH}" -v OFS="\t" '
  BEGIN{
    print "group","threshold","n_genes","sum_cds_len","sum_cds_snp_total","sum_cds_deleterious_snp","cds_snp_ratio_global","deleterious_ratio_global"
  }
  NR==1{next}
  {
    n++
    sum_len += $2
    sum_snp += $3
    sum_del += $5
  }
  END{
    r1 = (sum_len>0) ? sum_snp/sum_len : 0
    r2 = (sum_snp>0) ? sum_del/sum_snp : 0
    printf "%s\t%s\t%d\t%d\t%d\t%d\t%.8f\t%.8f\n", grp, th, n, sum_len, sum_snp, sum_del, r1, r2
  }' "${OUT}/${GROUP}_${TH}_gene_deleterious.tsv" \
  > "${OUT}/${GROUP}_${TH}_summary.tsv"

  ##########################################
  # 3.9 cleanup
  ##########################################
  rm -f \
    "${OUT}/base.tsv" \
    "${OUT}/j1_len.tsv" \
    "${OUT}/j2_total.tsv" \
    "${OUT}/j3_del.tsv"

  echo "[DONE] ${GROUP} ${TH}"
  echo "[INFO] Main output   : ${OUT}/${GROUP}_${TH}_gene_deleterious.tsv"
  echo "[INFO] Summary output: ${OUT}/${GROUP}_${TH}_summary.tsv"
done

echo "[INFO] All groups finished for ${TH}"