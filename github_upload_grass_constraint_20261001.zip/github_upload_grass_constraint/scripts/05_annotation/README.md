# Deleterious-variant annotation

Methods: deduplicate filtered biallelic SNPs by chromosome, position, REF and ALT; join reference-coordinate GERP scores; use >2, >4 and >6 cumulative classes; apply SIFT 4G (<0.05) and SnpEff v5.2 functional classes. Results: Fig. 5, S5–S7 and Table S4/S5.

| Order | Selected script | Role |
|---|---|---|
| 1 | `selected/step2_run_SIFT4G_Annotator_subgenomes.sh` | bamboo SIFT annotation candidate |
| 2 | `selected/step2.annotation_SIFT_all.sh` | SIFT/SnpEff annotation candidate |
| 3 | `selected/ped_sift_with_map.py` | map bamboo SIFT predictions to variant calls |

`source_candidates/` contains other species and historical annotation jobs. A single confirmed, species-general GERP-to-VCF join command was not identified. The final SIFT databases, ancestral-state convention, SnpEff databases, allele-frequency bin boundaries and annotation-row denominators remain to be documented.

See `SCRIPT_INDEX.tsv` for every recovered file and its source.
