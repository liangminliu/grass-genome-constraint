#!/bin/bash
#SBATCH --job-name=SIFT4G_Annot
#SBATCH --output=SIFT4G_Annot_%A_%a.out
#SBATCH --error=SIFT4G_Annot_%A_%a.err
#SBATCH --array=1-2
#SBATCH --cpus-per-task=20
#SBATCH --mem=150G
#SBATCH --partition=parallel

# ===============================================
# SIFT4G Annotator for C / D Subgenomes (PED)
# Author: 刘良敏
# ===============================================

set -euo pipefail

# ---------- 基础路径 ----------
SIFT4G_JAR="/gpfs/hpc/home/kib_unit/lidezhu/zf/sift4g/SIFT4G_Annotator.jar"
DB_DIR="/gpfs/hpc/home/kib_unit/lidezhu/liuliangmin/5.deleterious/06_SIFT/scripts_to_build_SIFT_db/test_files/PED/PED.V2.full"
MEMORY="100G"

# ---------- 输入与输出 ----------
VCF_DIR="/gpfs/hpc/home/kib_unit/lidezhu/liuliangmin/5.deleterious/06_SIFT/SIFI_annotator"
OUT_BASE="${VCF_DIR}/SIFT4G_results"
mkdir -p "${OUT_BASE}/logs"

# ---------- 任务分配 ----------
if [[ ${SLURM_ARRAY_TASK_ID} -eq 1 ]]; then
    SUBGENOME="C"
    INPUT_VCF="${VCF_DIR}/C_subgenome_complete.vcf.gz"
elif [[ ${SLURM_ARRAY_TASK_ID} -eq 2 ]]; then
    SUBGENOME="D"
    INPUT_VCF="${VCF_DIR}/D_subgenome_complete.vcf.gz"
else
    echo "[ERROR] SLURM_ARRAY_TASK_ID ${SLURM_ARRAY_TASK_ID} 未定义对应亚基因组"
    exit 1
fi

OUTPUT_DIR="${OUT_BASE}/${SUBGENOME}_annot"
mkdir -p "${OUTPUT_DIR}"

echo "==============================================="
echo "[INFO] Host: $(hostname)"
echo "[INFO] Date: $(date)"
echo "[INFO] Subgenome: ${SUBGENOME}"
echo "[INFO] Input VCF: ${INPUT_VCF}"
echo "[INFO] Database:  ${DB_DIR}"
echo "[INFO] Output Dir: ${OUTPUT_DIR}"
echo "==============================================="

# ---------- 检查输入 ----------
if [[ ! -f "${INPUT_VCF}" ]]; then
    echo "[ERROR] 找不到输入文件: ${INPUT_VCF}"
    exit 1
fi

# ---------- 如果是 .vcf.gz，自动解压 ----------
TMP_VCF="${OUTPUT_DIR}/$(basename ${INPUT_VCF%.gz})"
if [[ "${INPUT_VCF}" == *.vcf.gz ]]; then
    echo "[INFO] 检测到压缩文件，正在解压 ..."
    zcat "${INPUT_VCF}" > "${TMP_VCF}"
    echo "[INFO] 已解压到: ${TMP_VCF}"
else
    cp "${INPUT_VCF}" "${TMP_VCF}"
fi

# ---------- 运行 SIFT4G Annotator ----------
echo "[RUN] java -Xms${MEMORY} -Xmx${MEMORY} -jar ${SIFT4G_JAR}"

java -Xms${MEMORY} -Xmx${MEMORY} -jar "${SIFT4G_JAR}" \
    -c \
    -i "${TMP_VCF}" \
    -d "${DB_DIR}" \
    -r "${OUTPUT_DIR}" \
    -t > "${OUTPUT_DIR}/sift4g.log" 2>&1

# ---------- 检查结果 ----------
if grep -q "Completed successfully" "${OUTPUT_DIR}/sift4g.log"; then
    echo "[SUCCESS] ${SUBGENOME} 注释完成 ✅"
    echo "[LOG] ${OUTPUT_DIR}/sift4g.log"
else
    echo "[WARNING] ${SUBGENOME} 注释可能未正常结束，请检查日志:"
    echo "          ${OUTPUT_DIR}/sift4g.log"
fi

# ---------- 清理临时文件 ----------
rm -f "${TMP_VCF}"

echo "[DONE] $(date)"
