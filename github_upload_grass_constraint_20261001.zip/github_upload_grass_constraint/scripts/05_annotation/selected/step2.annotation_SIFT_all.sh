#!/bin/bash
#BSUB -J snpEff_SIFT[1-4]
#BSUB -q Q96C1T_X12
#BSUB -n 10
#BSUB -o snpEff_SIFT.%I.%J.out
#BSUB -e snpEff_SIFT.%I.%J.err

set -euo pipefail

## =========================================================
## 1. Parameters
## =========================================================

THREADS="${LSB_DJOB_NUMPROC:-20}"

SIF_IMAGE="${HOME}/workspace/4.reseq-chr/software/Reseq_genek.sif"
SNPEFF_JAR="/opt/snpEff/snpEff.jar"
SNPEFF_CONFIG="./snpEff.config"

## snpEff database name
## 如果 snpEff.config 里面数据库名不是 ped，需要改这里
GENOME_DB="ped"

INDIR="SIFT0.05"
OUTDIR="SIFT0.05/snpeff_annotation"

mkdir -p "${OUTDIR}"

## =========================================================
## 2. Select input according to LSF array index
## =========================================================

case "${LSB_JOBINDEX}" in
  1)
    TAG="pedC.complete_SIFT"
    IN_VCF="${INDIR}/C_subgenome_complete_SIFTpredictions.vcf.gz"
    ;;
  2)
    TAG="pedD.complete_SIFT"
    IN_VCF="${INDIR}/D_subgenome_complete_SIFTpredictions.vcf.gz"
    ;;
  3)
    TAG="pedC.sift_lt0.05"
    IN_VCF="${INDIR}/pedC.sift_lt0.05.vcf.gz"
    ;;
  4)
    TAG="pedD.sift_lt0.05"
    IN_VCF="${INDIR}/pedD.sift_lt0.05.vcf.gz"
    ;;
  *)
    echo "[ERROR] Unsupported LSB_JOBINDEX: ${LSB_JOBINDEX}" >&2
    exit 1
    ;;
esac

OUT_VCF="${OUTDIR}/${TAG}.snpEff.ann.vcf.gz"
OUT_CSV="${OUTDIR}/${TAG}.snpEff.csv"
OUT_HTML="${OUTDIR}/${TAG}.snpEff.html"
OUT_LOG="${OUTDIR}/${TAG}.snpEff.log"

echo "============================================================"
echo "[INFO] Job index : ${LSB_JOBINDEX}"
echo "[INFO] Tag       : ${TAG}"
echo "[INFO] Input VCF : ${IN_VCF}"
echo "[INFO] Output VCF: ${OUT_VCF}"
echo "============================================================"

## =========================================================
## 3. Check input
## =========================================================

if [[ ! -s "${IN_VCF}" ]]; then
  echo "[ERROR] Input VCF not found or empty: ${IN_VCF}" >&2
  exit 1
fi

if [[ ! -s "${SNPEFF_CONFIG}" ]]; then
  echo "[ERROR] snpEff config not found: ${SNPEFF_CONFIG}" >&2
  exit 1
fi

if [[ ! -s "${SIF_IMAGE}" ]]; then
  echo "[ERROR] Singularity image not found: ${SIF_IMAGE}" >&2
  exit 1
fi

command -v bgzip >/dev/null 2>&1 || {
  echo "[ERROR] bgzip not found in PATH" >&2
  exit 1
}

command -v tabix >/dev/null 2>&1 || {
  echo "[ERROR] tabix not found in PATH" >&2
  exit 1
}

## =========================================================
## 4. Run snpEff annotation
## =========================================================
## 说明：
## - 输入 VCF 已经含有 SIFT 预测信息；
## - 这里用 snpEff 进一步添加基因功能注释 ANN 字段；
## - -ud 5000 表示上下游 5 kb 注释；
## - 输出压缩为 bgzip 格式，方便后续 tabix / bcftools 使用。
## =========================================================

singularity exec "${SIF_IMAGE}" \
  java -jar "${SNPEFF_JAR}" \
  -c "${SNPEFF_CONFIG}" \
  -ud 5000 \
  -csvStats "${OUT_CSV}" \
  -htmlStats "${OUT_HTML}" \
  -o vcf \
  "${GENOME_DB}" \
  "${IN_VCF}" \
  2> "${OUT_LOG}" \
  | bgzip -@ "${THREADS}" -c > "${OUT_VCF}"

tabix -f -p vcf "${OUT_VCF}"

echo "[INFO] Finished: ${TAG}"
echo "[INFO] Annotated VCF: ${OUT_VCF}"
echo "[INFO] Index        : ${OUT_VCF}.tbi"
echo "[INFO] CSV stats    : ${OUT_CSV}"
echo "[INFO] HTML stats   : ${OUT_HTML}"
echo "[INFO] Log          : ${OUT_LOG}"