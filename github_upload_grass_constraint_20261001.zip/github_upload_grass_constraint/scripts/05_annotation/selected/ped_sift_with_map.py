#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import argparse
import re
import pandas as pd


def infer_subgenome(gene):
    """
    支持:
      Ped01Cg00010
      Ped09CXg15160
      pedC_Ped09Cg25950
      pedD_Ped05Dg21000
    """
    gene = str(gene).strip()

    # 去掉 pedC_/pedD_ 前缀后再判断
    gene2 = re.sub(r"^(pedC_|pedD_)", "", gene, flags=re.IGNORECASE)

    if re.match(r"^Ped\d{2}C", gene2, re.IGNORECASE):
        return "pedC"
    if re.match(r"^Ped\d{2}D", gene2, re.IGNORECASE):
        return "pedD"
    return "NA"


def normalize_gene_id(gene):
    """
    把 pedC_Ped09Cg25950 -> Ped09Cg25950
       pedD_Ped05Dg21000 -> Ped05Dg21000
    保持和 SIFT 的 GENE_ID 一致
    """
    gene = str(gene).strip()
    gene = re.sub(r"^(pedC_|pedD_)", "", gene, flags=re.IGNORECASE)
    return gene


def infer_gene_tag(gene):
    gene = str(gene).strip()
    gene2 = normalize_gene_id(gene)
    m = re.match(r"^Ped\d{2}(C|D)(X?g)", gene2, re.IGNORECASE)
    if m:
        return f"{m.group(1).upper()}{m.group(2)}"
    return "NA"


def main():
    ap = argparse.ArgumentParser(
        description="Count per-gene nonsynonymous and deleterious SIFT sites, then merge with ped gene mapping and retained pairs."
    )
    ap.add_argument("--sift", required=True,
                    help="63sp.filtered.mainChr_SIFTannotations.xls (tab-delimited)")
    ap.add_argument("--map", required=True,
                    help="ped_gene_expanded.tsv")
    ap.add_argument("--pairs", required=True,
                    help="ped_retained_pairs.tsv")
    ap.add_argument("--gene_out", default="ped_sift_gene_counts.with_map.tsv",
                    help="Output: gene-level table")
    ap.add_argument("--class_out", default="ped_sift_category_summary.tsv",
                    help="Output: category-level summary table")
    ap.add_argument("--paired_out", default="ped_sift_paired_comparison.tsv",
                    help="Output: paired pedC/pedD comparison table")
    args = ap.parse_args()

    # =========================================================
    # 1. Read SIFT annotation
    # =========================================================
    df = pd.read_csv(args.sift, sep="\t", dtype=str)
    df.columns = [c.strip().upper() for c in df.columns]

    need_cols = [
        "CHROM", "POS", "REF_ALLELE", "ALT_ALLELE",
        "GENE_ID", "REGION", "VARIANT_TYPE", "SIFT_PREDICTION"
    ]
    missing = [c for c in need_cols if c not in df.columns]
    if missing:
        raise ValueError(f"Missing required columns: {missing}")

    # =========================================================
    # 2. Filter CDS + NONSYNONYMOUS
    # =========================================================
    f = df[
        (df["REGION"].astype(str).str.upper() == "CDS") &
        (df["VARIANT_TYPE"].astype(str).str.upper() == "NONSYNONYMOUS")
    ].copy()

    # 唯一变异事件：每个基因的每个位点/等位
    f["KEY"] = (
        f["GENE_ID"].astype(str) + "|" +
        f["CHROM"].astype(str) + "|" +
        f["POS"].astype(str) + "|" +
        f["REF_ALLELE"].astype(str) + "|" +
        f["ALT_ALLELE"].astype(str)
    )
    f = f.drop_duplicates(subset=["KEY"])

    # =========================================================
    # 3. Per-gene SIFT counts
    # =========================================================
    g = f.groupby("GENE_ID", as_index=False).agg(
        n_nonsyn=("KEY", "count"),
        n_del_sift=("SIFT_PREDICTION", lambda x: (x.astype(str).str.upper() == "DELETERIOUS").sum())
    )

    g.rename(columns={"GENE_ID": "gene_id_raw"}, inplace=True)
    g["gene_id"] = g["gene_id_raw"].map(normalize_gene_id)
    g["del_ratio_sift"] = g["n_del_sift"] / g["n_nonsyn"]
    g["subgenome_from_gene"] = g["gene_id"].map(infer_subgenome)
    g["gene_tag"] = g["gene_id"].map(infer_gene_tag)

    # =========================================================
    # 4. Read ped_gene_expanded.tsv
    # =========================================================
    mp = pd.read_csv(args.map, sep="\t", dtype=str)
    mp.columns = [c.strip() for c in mp.columns]

    need_map = ["gene_id", "subgenome", "SG_ID", "category"]
    missing_map = [c for c in need_map if c not in mp.columns]
    if missing_map:
        raise ValueError(f"Mapping file missing columns: {missing_map}")

    mp["gene_id_raw"] = mp["gene_id"].astype(str)
    mp["gene_id"] = mp["gene_id_raw"].map(normalize_gene_id)

    # merge
    gene_tbl = mp.merge(g, on="gene_id", how="left", suffixes=("_map", "_sift"))

    gene_tbl["has_sift_stat"] = gene_tbl["n_nonsyn"].notna()

    # 如果 map 里 subgenome 缺失，就用 gene id 推断
    gene_tbl["subgenome_final"] = gene_tbl["subgenome"]
    gene_tbl.loc[
        gene_tbl["subgenome_final"].isna() | (gene_tbl["subgenome_final"].astype(str).str.strip() == ""),
        "subgenome_final"
    ] = gene_tbl["subgenome_from_gene"]

    # =========================================================
    # 5. Category summary
    # =========================================================
    class_summary = gene_tbl.groupby(["category", "subgenome_final"], as_index=False).agg(
        n_genes_total=("gene_id", "count"),
        n_genes_with_sift=("has_sift_stat", lambda x: int(x.sum())),
        mean_n_nonsyn=("n_nonsyn", "mean"),
        median_n_nonsyn=("n_nonsyn", "median"),
        mean_n_del_sift=("n_del_sift", "mean"),
        median_n_del_sift=("n_del_sift", "median"),
        mean_del_ratio_sift=("del_ratio_sift", "mean"),
        median_del_ratio_sift=("del_ratio_sift", "median")
    )

    # =========================================================
    # 6. Read retained pairs and build paired table
    # =========================================================
    pairs = pd.read_csv(args.pairs, sep="\t", dtype=str)
    pairs.columns = [c.strip() for c in pairs.columns]

    need_pairs = ["SG_ID", "pedC_gene", "pedD_gene"]
    missing_pairs = [c for c in need_pairs if c not in pairs.columns]
    if missing_pairs:
        raise ValueError(f"Pairs file missing columns: {missing_pairs}")

    pairs["pedC_gene_norm"] = pairs["pedC_gene"].map(normalize_gene_id)
    pairs["pedD_gene_norm"] = pairs["pedD_gene"].map(normalize_gene_id)

    ctbl = g.rename(columns={
        "gene_id": "pedC_gene_norm",
        "gene_id_raw": "pedC_gene_id_raw",
        "n_nonsyn": "pedC_n_nonsyn",
        "n_del_sift": "pedC_n_del_sift",
        "del_ratio_sift": "pedC_del_ratio_sift",
        "gene_tag": "pedC_gene_tag"
    })[
        ["pedC_gene_norm", "pedC_gene_id_raw", "pedC_n_nonsyn", "pedC_n_del_sift", "pedC_del_ratio_sift", "pedC_gene_tag"]
    ]

    dtbl = g.rename(columns={
        "gene_id": "pedD_gene_norm",
        "gene_id_raw": "pedD_gene_id_raw",
        "n_nonsyn": "pedD_n_nonsyn",
        "n_del_sift": "pedD_n_del_sift",
        "del_ratio_sift": "pedD_del_ratio_sift",
        "gene_tag": "pedD_gene_tag"
    })[
        ["pedD_gene_norm", "pedD_gene_id_raw", "pedD_n_nonsyn", "pedD_n_del_sift", "pedD_del_ratio_sift", "pedD_gene_tag"]
    ]

    paired_tbl = pairs.merge(ctbl, on="pedC_gene_norm", how="left")
    paired_tbl = paired_tbl.merge(dtbl, on="pedD_gene_norm", how="left")

    # category 信息补进去
    pair_cat = mp[["SG_ID", "category"]].drop_duplicates()
    paired_tbl = paired_tbl.merge(pair_cat, on="SG_ID", how="left")

    paired_tbl["delta_del_ratio_C_minus_D"] = paired_tbl["pedC_del_ratio_sift"] - paired_tbl["pedD_del_ratio_sift"]
    paired_tbl["delta_n_del_C_minus_D"] = paired_tbl["pedC_n_del_sift"] - paired_tbl["pedD_n_del_sift"]
    paired_tbl["delta_n_nonsyn_C_minus_D"] = paired_tbl["pedC_n_nonsyn"] - paired_tbl["pedD_n_nonsyn"]

    # =========================================================
    # 7. Write outputs
    # =========================================================
    gene_tbl.to_csv(args.gene_out, sep="\t", index=False)
    class_summary.to_csv(args.class_out, sep="\t", index=False)
    paired_tbl.to_csv(args.paired_out, sep="\t", index=False)

    print("[INFO] Done.")
    print(f"[INFO] gene-level table   : {args.gene_out}")
    print(f"[INFO] category summary  : {args.class_out}")
    print(f"[INFO] paired comparison : {args.paired_out}")
    print(f"[INFO] genes in map      : {gene_tbl.shape[0]}")
    print(f"[INFO] paired rows       : {paired_tbl.shape[0]}")


if __name__ == "__main__":
    main()