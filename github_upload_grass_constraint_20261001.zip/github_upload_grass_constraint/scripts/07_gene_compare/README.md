# Synteny-based gene comparisons

Methods: strict-core, relaxed-syntenic and non-syntenic classes; pool both bamboo gene counts and CDS lengths within each matched group; compare 5,108 complete groups using Friedman and paired Wilcoxon tests. Species gene-class comparisons use Kruskal–Wallis and unpaired Wilcoxon tests. Results: Fig. 7, S9–S10 and Table S7.

| Order | Selected script | Role |
|---|---|---|
| 1 | `selected/synpan_build.pl`, `selected/classify_synpan_sg.py` | orthogroup and gene-class construction |
| 2 | `selected/build_orthogroup_GERP_master.R` | matched-group metric assembly |
| 3 | `selected/plot_cross_species_strict_GERP_multi_panel.R`, `selected/plot_strict_core_cross_species_SNP_deleterious.R` | cross-species comparison candidates |
| 4 | `selected/plot_ped_gene_class_GERP_multi_panel_coreAllGenes.R`, `selected/plot_Zmay_gene_class_GERP_multi_panel.R`, `selected/plot_Atau_gene_class_GERP_multi_panel.R` | within-species class comparisons |
| 5 | `selected/plot_ped_gene_class_SNP_deleterious.R`, `selected/plot_Zmay_gene_class_SNP_deleterious_density.R`, `selected/plot_Atau_gene_class_SNP_deleterious_density_all_rawScale_final.R` | species-specific SNP/candidate-variant panels |
| 6 | `selected/two_gene_sets_combined.sh`, `selected/zmay_two_gene_sets_combined_single_lsf_array.sh`, `selected/Atau_two_gene_sets_combined_stats.sh` | species-specific gene-set integration |

`source_candidates/` retains alternative display/statistics scripts. The 5,108-row input, 668 SNP-positive matched subset, two zero-filled *A. tauschii* records and every plotted bracket must be checked against Table S7 before calling these the exact final figure-generating commands. Bamboo C/D pooling is a metric-calculation detail, not a separate focal-species interpretation.

The N-drive LSF log confirms that the cross-species and species-class plotting commands completed, but log completion does not establish that those files match the final manuscript image. The late `all_rawScale_final` and `final_zoom_main_full_supp` variants are included as candidate final displays, with source hashes in `SCRIPT_INDEX.tsv`.

See `SCRIPT_INDEX.tsv` for every recovered file and its source.
