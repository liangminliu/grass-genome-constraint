#!/usr/bin/env Rscript

suppressPackageStartupMessages({
  library(dplyr)
  library(tidyr)
  library(ggplot2)
  library(ggsignif)
  library(patchwork)
  library(grid)
})

## =========================================================
## 1. Parameters
## =========================================================
PAN_FILE <- "core_5sp_1to1.SG.pan"

THRESHOLDS <- c("gt2", "gt4", "gt6")
DATA_TYPES <- c("ALL", "SNPpos", "SNP0")

OUTDIR    <- "Atau_gene_class_snp_deleterious_density_results"
TABLE_DIR <- file.path(OUTDIR, "tables")
STAT_DIR  <- file.path(OUTDIR, "stats")
FIG_DIR   <- file.path(OUTDIR, "figures")

dir.create(TABLE_DIR, recursive = TRUE, showWarnings = FALSE)
dir.create(STAT_DIR,  recursive = TRUE, showWarnings = FALSE)
dir.create(FIG_DIR,   recursive = TRUE, showWarnings = FALSE)

OTHER_FILE   <- "Atau_other_syntenic.genes.txt"
PRIVATE_FILE <- "Atau_candidate_nonsyntenic_private.genes.txt"

show_ns_lines <- FALSE

class_order <- c("Core", "Syntenic", "Nonsyntenic")

class_full_names <- c(
  "Core"        = "strict_perfect_copy_syntenic_core",
  "Syntenic"    = "broad_syntenic_excluding_strict_core",
  "Nonsyntenic" = "candidate_nonsyntenic_private"
)

class_fill <- c(
  "Core"        = "#9DBFD2",
  "Syntenic"    = "#B7B0CF",
  "Nonsyntenic" = "#D8A0A5"
)

## =========================================================
## 2. Basic helpers
## =========================================================
read_tsv_base <- function(fp, header = TRUE) {
  if (!file.exists(fp)) {
    stop("Missing input file: ", fp, call. = FALSE)
  }

  read.delim(
    fp,
    header = header,
    sep = "\t",
    stringsAsFactors = FALSE,
    check.names = FALSE,
    quote = "",
    comment.char = ""
  )
}

write_tsv_base <- function(df, fp) {
  write.table(
    df,
    file = fp,
    sep = "\t",
    quote = FALSE,
    row.names = FALSE,
    col.names = TRUE
  )
}

strip_Atau_prefix <- function(x) {
  x <- as.character(x)
  x <- sub("^Atau_", "", x)
  x <- sub("^Aegilops_tauschii_", "", x)
  x
}

p_to_star <- function(p) {
  if (is.na(p)) return("ns")
  if (p < 0.001) return("***")
  if (p < 0.01)  return("**")
  if (p < 0.05)  return("*")
  "ns"
}

build_core_file <- function(thr) {
  paste0("Atau_", thr, "_core_gene_deleterious.tsv")
}

build_combined_file <- function(thr) {
  paste0("Atau_gerp_", thr, "_combined.tsv")
}

## =========================================================
## 3. Gene-class map
## =========================================================
read_gene_list <- function(fp) {
  x <- scan(fp, what = character(), quiet = TRUE)
  x <- strip_Atau_prefix(x)
  x <- x[!is.na(x) & x != "" & x != "-"]
  unique(x)
}

read_core_genes_from_pan <- function() {
  pan <- read_tsv_base(PAN_FILE, header = FALSE)

  if (ncol(pan) < 9) {
    stop("core_5sp_1to1.SG.pan should have at least 9 columns.", call. = FALSE)
  }

  core <- pan %>%
    transmute(
      SG = as.character(V1),
      Atau_gene = strip_Atau_prefix(V5)
    ) %>%
    filter(
      !is.na(SG),
      !is.na(Atau_gene),
      Atau_gene != "",
      Atau_gene != "-"
    ) %>%
    distinct(Atau_gene, .keep_all = TRUE)

  cat("[OK] Strict core Atau genes from SG pan: ", nrow(core), "\n", sep = "")

  core
}

build_gene_class_map <- function() {
  core_tbl <- read_core_genes_from_pan()
  core_genes <- core_tbl$Atau_gene

  other_genes   <- read_gene_list(OTHER_FILE)
  private_genes <- read_gene_list(PRIVATE_FILE)

  other_clean <- setdiff(other_genes, core_genes)
  private_clean <- setdiff(private_genes, unique(c(core_genes, other_clean)))

  gene_class <- bind_rows(
    data.frame(
      gene_id = core_genes,
      gene_class = "Core",
      stringsAsFactors = FALSE
    ),
    data.frame(
      gene_id = other_clean,
      gene_class = "Syntenic",
      stringsAsFactors = FALSE
    ),
    data.frame(
      gene_id = private_clean,
      gene_class = "Nonsyntenic",
      stringsAsFactors = FALSE
    )
  ) %>%
    distinct(gene_id, .keep_all = TRUE) %>%
    mutate(
      gene_class = factor(gene_class, levels = class_order)
    )

  cat("[OK] Gene class map:\n")
  print(table(gene_class$gene_class, useNA = "ifany"))

  gene_class
}

## =========================================================
## 4. Read Core table
## =========================================================
read_core_stats <- function(thr, gene_class_map) {
  fp <- build_core_file(thr)

  df <- read_tsv_base(fp, header = TRUE)

  required_cols <- c(
    "gene_id",
    "cds_len",
    "cds_snp_total",
    "cds_deleterious_snp"
  )

  miss <- setdiff(required_cols, colnames(df))
  if (length(miss) > 0) {
    stop("Missing columns in ", fp, ": ", paste(miss, collapse = ", "), call. = FALSE)
  }

  core_genes <- gene_class_map %>%
    filter(gene_class == "Core") %>%
    pull(gene_id)

  df %>%
    transmute(
      threshold = thr,
      gene_class = "Core",
      gene_id = strip_Atau_prefix(gene_id),
      cds_len = suppressWarnings(as.numeric(cds_len)),
      cds_snp_total = suppressWarnings(as.numeric(cds_snp_total)),
      cds_deleterious_snp = suppressWarnings(as.numeric(cds_deleterious_snp)),
      source = fp
    ) %>%
    filter(
      gene_id %in% core_genes,
      !is.na(cds_len),
      cds_len > 0,
      !is.na(cds_snp_total),
      !is.na(cds_deleterious_snp)
    )
}

## =========================================================
## 5. Read Syntenic / Nonsyntenic table
## =========================================================
read_noncore_stats <- function(thr, gene_class_map) {
  fp <- build_combined_file(thr)

  df <- read_tsv_base(fp, header = TRUE)

  required_cols <- c(
    "group",
    "gene_id",
    "cds_len",
    "cds_snp_total",
    "cds_deleterious_snp"
  )

  miss <- setdiff(required_cols, colnames(df))
  if (length(miss) > 0) {
    stop("Missing columns in ", fp, ": ", paste(miss, collapse = ", "), call. = FALSE)
  }

  noncore_map <- gene_class_map %>%
    filter(gene_class %in% c("Syntenic", "Nonsyntenic"))

  df %>%
    mutate(
      gene_id = strip_Atau_prefix(gene_id),
      group_class = case_when(
        group == "other_syntenic" ~ "Syntenic",
        group == "candidate_nonsyntenic_private" ~ "Nonsyntenic",
        TRUE ~ NA_character_
      )
    ) %>%
    filter(!is.na(group_class)) %>%
    inner_join(noncore_map, by = "gene_id") %>%
    filter(as.character(gene_class) == group_class) %>%
    transmute(
      threshold = thr,
      gene_class = as.character(gene_class),
      gene_id = gene_id,
      cds_len = suppressWarnings(as.numeric(cds_len)),
      cds_snp_total = suppressWarnings(as.numeric(cds_snp_total)),
      cds_deleterious_snp = suppressWarnings(as.numeric(cds_deleterious_snp)),
      source = paste0(fp, ":", group)
    ) %>%
    filter(
      !is.na(cds_len),
      cds_len > 0,
      !is.na(cds_snp_total),
      !is.na(cds_deleterious_snp)
    )
}

## =========================================================
## 6. Build one threshold table
## =========================================================
build_one_threshold <- function(thr, gene_class_map) {
  core_df <- read_core_stats(thr, gene_class_map)
  noncore_df <- read_noncore_stats(thr, gene_class_map)

  df <- bind_rows(core_df, noncore_df) %>%
    mutate(
      gene_class = factor(gene_class, levels = class_order),

      cds_snp_density = cds_snp_total / cds_len,

      cds_deleterious_ratio = ifelse(
        cds_snp_total > 0,
        cds_deleterious_snp / cds_snp_total,
        0
      ),

      cds_deleterious_density = cds_deleterious_snp / cds_len
    ) %>%
    filter(
      !is.na(gene_class),
      is.finite(cds_snp_density),
      is.finite(cds_deleterious_ratio),
      is.finite(cds_deleterious_density)
    ) %>%
    select(
      threshold,
      gene_class,
      gene_id,
      cds_len,
      cds_snp_total,
      cds_snp_density,
      cds_deleterious_snp,
      cds_deleterious_ratio,
      cds_deleterious_density,
      source
    )

  cat("[INFO] ", thr, " final genes by class:\n", sep = "")
  print(table(df$gene_class, useNA = "ifany"))

  df
}

split_by_snp_class <- function(df) {
  list(
    ALL = df,
    SNPpos = df %>% filter(cds_snp_total > 0),
    SNP0 = df %>% filter(cds_snp_total == 0)
  )
}

## =========================================================
## 7. Statistics
## =========================================================
run_stats_one_metric <- function(df_plot, thr, data_type, metric) {
  df_plot <- df_plot %>%
    filter(!is.na(gene_class), is.finite(.data[[metric]])) %>%
    droplevels()

  observed_levels <- levels(droplevels(df_plot$gene_class))

  if (length(observed_levels) < 2 || nrow(df_plot) < 3) {
    return(tibble(
      threshold = thr,
      data_type = data_type,
      metric = metric,
      test = NA_character_,
      KW_chisq = NA_real_,
      KW_df = NA_real_,
      KW_p = NA_real_,
      Comparison = NA_character_,
      group1 = NA_character_,
      group2 = NA_character_,
      n_group1 = NA_integer_,
      n_group2 = NA_integer_,
      median_group1 = NA_real_,
      median_group2 = NA_real_,
      median_diff_group1_minus_group2 = NA_real_,
      P.raw = NA_real_,
      P.adj = NA_real_,
      label = NA_character_
    ))
  }

  kw <- kruskal.test(df_plot[[metric]] ~ df_plot$gene_class)
  pair_combs <- combn(observed_levels, 2, simplify = FALSE)

  pair_tbl <- lapply(pair_combs, function(cc) {
    g1 <- cc[1]
    g2 <- cc[2]

    x <- df_plot[[metric]][df_plot$gene_class == g1]
    y <- df_plot[[metric]][df_plot$gene_class == g2]

    wt <- tryCatch(
      wilcox.test(x, y, paired = FALSE, exact = FALSE),
      error = function(e) NULL
    )

    tibble(
      threshold = thr,
      data_type = data_type,
      metric = metric,
      test = "Wilcoxon rank-sum test; BH correction",
      KW_chisq = unname(kw$statistic),
      KW_df = unname(kw$parameter),
      KW_p = kw$p.value,
      Comparison = paste0(class_full_names[[g1]], " - ", class_full_names[[g2]]),
      group1 = class_full_names[[g1]],
      group2 = class_full_names[[g2]],
      n_group1 = length(x),
      n_group2 = length(y),
      median_group1 = median(x, na.rm = TRUE),
      median_group2 = median(y, na.rm = TRUE),
      median_diff_group1_minus_group2 =
        median(x, na.rm = TRUE) - median(y, na.rm = TRUE),
      P.raw = ifelse(is.null(wt), NA_real_, wt$p.value)
    )
  }) %>%
    bind_rows() %>%
    mutate(
      P.adj = p.adjust(P.raw, method = "BH"),
      label = vapply(P.adj, p_to_star, character(1))
    )

  pair_tbl
}

summarise_one_table <- function(df, thr, data_type) {
  df %>%
    group_by(threshold, gene_class) %>%
    summarise(
      data_type = data_type,
      n_genes = n(),
      n_snp_pos = sum(cds_snp_total > 0, na.rm = TRUE),
      n_snp0 = sum(cds_snp_total == 0, na.rm = TRUE),

      median_cds_len = median(cds_len, na.rm = TRUE),
      mean_cds_len = mean(cds_len, na.rm = TRUE),

      median_cds_snp_total = median(cds_snp_total, na.rm = TRUE),
      mean_cds_snp_total = mean(cds_snp_total, na.rm = TRUE),

      median_cds_snp_density = median(cds_snp_density, na.rm = TRUE),
      mean_cds_snp_density = mean(cds_snp_density, na.rm = TRUE),

      median_cds_deleterious_snp = median(cds_deleterious_snp, na.rm = TRUE),
      mean_cds_deleterious_snp = mean(cds_deleterious_snp, na.rm = TRUE),

      median_cds_deleterious_ratio = median(cds_deleterious_ratio, na.rm = TRUE),
      mean_cds_deleterious_ratio = mean(cds_deleterious_ratio, na.rm = TRUE),

      median_cds_deleterious_density = median(cds_deleterious_density, na.rm = TRUE),
      mean_cds_deleterious_density = mean(cds_deleterious_density, na.rm = TRUE),
      .groups = "drop"
    ) %>%
    mutate(
      data_type = data_type,
      gene_class_full = class_full_names[as.character(gene_class)]
    ) %>%
    select(
      threshold,
      data_type,
      gene_class,
      gene_class_full,
      everything()
    )
}

## =========================================================
## 8. Plot helpers
## =========================================================
make_sig_df <- function(df_plot, stat_tbl, value_col) {
  df_plot <- df_plot %>%
    filter(is.finite(.data[[value_col]]))

  sig_df <- stat_tbl %>%
    filter(!is.na(group1), !is.na(group2), !is.na(label))

  inv_map <- setNames(names(class_full_names), class_full_names)

  sig_df <- sig_df %>%
    mutate(
      group1_plot = inv_map[group1],
      group2_plot = inv_map[group2]
    )

  if (!show_ns_lines) {
    sig_df <- sig_df %>% filter(label != "ns")
  }

  if (nrow(df_plot) == 0) {
    return(list(sig_df = sig_df[0, ], y_limit = 1))
  }

  y_max <- max(df_plot[[value_col]], na.rm = TRUE)
  y_min <- min(df_plot[[value_col]], na.rm = TRUE)

  if (!is.finite(y_max)) y_max <- 1
  if (!is.finite(y_min)) y_min <- 0

  y_range <- y_max - y_min
  if (!is.finite(y_range) || y_range <= 0) {
    y_range <- max(abs(y_max), 1)
  }

  if (nrow(sig_df) == 0) {
    return(list(
      sig_df = sig_df,
      y_limit = y_max + 0.20 * y_range
    ))
  }

  sig_df <- sig_df %>%
    mutate(
      group1_plot = factor(group1_plot, levels = class_order),
      group2_plot = factor(group2_plot, levels = class_order)
    ) %>%
    arrange(group1_plot, group2_plot) %>%
    mutate(
      y_position = y_max + seq(
        from = 0.14 * y_range,
        by = 0.14 * y_range,
        length.out = n()
      )
    )

  list(
    sig_df = sig_df,
    y_limit = max(sig_df$y_position, na.rm = TRUE) + 0.14 * y_range
  )
}

theme_mbe <- function() {
  theme_classic(base_size = 16) +
    theme(
      plot.title = element_text(
        size = 14,
        face = "plain",
        hjust = 0.5,
        margin = margin(b = 8)
      ),
      axis.text.x = element_text(
        size = 14,
        color = "black",
        margin = margin(t = 5)
      ),
      axis.text.y = element_text(
        size = 13,
        color = "black"
      ),
      axis.title.y = element_text(
        size = 15,
        color = "black",
        margin = margin(r = 8)
      ),
      axis.title.x = element_blank(),

      axis.line = element_line(color = "black", linewidth = 0.55),
      axis.ticks = element_line(color = "black", linewidth = 0.55),
      axis.ticks.length = unit(2.2, "pt"),

      panel.grid.major.y = element_line(
        color = "#E9E9E9",
        linewidth = 0.35
      ),
      panel.grid.minor.y = element_blank(),
      panel.grid.major.x = element_blank(),
      panel.grid.minor.x = element_blank(),

      panel.border = element_rect(
        fill = NA,
        color = "black",
        linewidth = 0.75
      ),

      plot.margin = margin(12, 13, 10, 13)
    )
}

plot_one_panel <- function(df_plot, sig_df, value_col, y_limit,
                           panel_title, ylab,
                           log10_plot = FALSE, pseudo = 1e-6) {

  plot_df <- df_plot %>%
    filter(is.finite(.data[[value_col]])) %>%
    mutate(plot_value = .data[[value_col]])

  sig_plot <- sig_df

  if (log10_plot) {
    plot_df <- plot_df %>%
      mutate(plot_value = log10(plot_value + pseudo)) %>%
      filter(is.finite(plot_value))

    if (nrow(sig_plot) > 0 && nrow(plot_df) > 0) {
      y_max <- max(plot_df$plot_value, na.rm = TRUE)
      sig_plot$y_position <- y_max + seq(
        from = 0.25,
        by = 0.25,
        length.out = nrow(sig_plot)
      )
      y_limit <- max(sig_plot$y_position, na.rm = TRUE) + 0.28
    } else {
      y_limit <- max(plot_df$plot_value, na.rm = TRUE) + 0.28
    }

    if (!is.finite(y_limit)) y_limit <- 1
  }

  ggplot(plot_df, aes(x = gene_class, y = plot_value, fill = gene_class)) +
    geom_violin(
      width = 0.62,
      scale = "width",
      trim = TRUE,
      color = "#5F5F5F",
      linewidth = 0.55,
      alpha = 0.85
    ) +
    geom_boxplot(
      width = 0.105,
      coef = 0.35,
      fill = "white",
      color = "black",
      linewidth = 0.75,
      outlier.shape = NA
    ) +
    {
      if (nrow(sig_plot) > 0) {
        geom_signif(
          data = sig_plot,
          aes(
            xmin = group1_plot,
            xmax = group2_plot,
            annotations = label,
            y_position = y_position
          ),
          manual = TRUE,
          inherit.aes = FALSE,
          textsize = 3.6,
          tip_length = 0.012,
          linewidth = 0.65
        )
      }
    } +
    scale_fill_manual(values = class_fill, guide = "none") +
    scale_x_discrete(limits = class_order, labels = class_order) +
    scale_y_continuous(
      limits = c(NA, y_limit),
      expand = expansion(mult = c(0.02, 0.02))
    ) +
    labs(
      x = NULL,
      y = ylab,
      title = panel_title
    ) +
    coord_cartesian(clip = "off") +
    theme_mbe()
}

safe_ggsave <- function(filename, plot, width, height, dpi = NULL) {
  if (grepl("\\.pdf$", filename, ignore.case = TRUE)) {
    ok <- FALSE

    try({
      ggsave(
        filename = filename,
        plot = plot,
        width = width,
        height = height,
        device = cairo_pdf
      )
      ok <- TRUE
    }, silent = TRUE)

    if (!ok) {
      ggsave(
        filename = filename,
        plot = plot,
        width = width,
        height = height
      )
    }
  } else {
    ggsave(
      filename = filename,
      plot = plot,
      width = width,
      height = height,
      dpi = dpi
    )
  }
}

## =========================================================
## 9. Main workflow
## =========================================================
gene_class_map <- build_gene_class_map()

all_tables <- list()
all_stats <- list()
all_summary <- list()

for (thr in THRESHOLDS) {
  cat("[INFO] Processing threshold: ", thr, "\n", sep = "")

  df_thr <- build_one_threshold(thr, gene_class_map)
  split_list <- split_by_snp_class(df_thr)

  for (dt in DATA_TYPES) {
    df_dt <- split_list[[dt]]

    out_table <- file.path(
      TABLE_DIR,
      paste0("Atau_gene_class_", thr, "_", dt,
             "_SNP_deleterious_density_metrics.tsv")
    )

    write_tsv_base(df_dt, out_table)

    stat_dt <- bind_rows(
      run_stats_one_metric(df_dt, thr, dt, "cds_snp_density"),
      run_stats_one_metric(df_dt, thr, dt, "cds_deleterious_ratio"),
      run_stats_one_metric(df_dt, thr, dt, "cds_deleterious_density")
    )

    out_stat <- file.path(
      STAT_DIR,
      paste0("Atau_gene_class_", thr, "_", dt,
             "_SNP_deleterious_density_stats.tsv")
    )

    write_tsv_base(stat_dt, out_stat)

    summary_dt <- summarise_one_table(df_dt, thr, dt)

    out_summary <- file.path(
      TABLE_DIR,
      paste0("Atau_gene_class_", thr, "_", dt,
             "_summary.tsv")
    )

    write_tsv_base(summary_dt, out_summary)

    all_tables[[paste(thr, dt, sep = "_")]] <- df_dt
    all_stats[[paste(thr, dt, sep = "_")]] <- stat_dt
    all_summary[[paste(thr, dt, sep = "_")]] <- summary_dt

    cat("[OK] ", thr, " ", dt, ": n_genes = ", nrow(df_dt), "\n", sep = "")
    print(table(df_dt$gene_class, useNA = "ifany"))
  }
}

combined_metrics <- bind_rows(all_tables, .id = "threshold_data_type")
combined_stats   <- bind_rows(all_stats)
combined_summary <- bind_rows(all_summary)

write_tsv_base(
  combined_metrics,
  file.path(TABLE_DIR, "Atau_gene_class_ALL_thresholds_ALL_data_types_metrics.tsv")
)

write_tsv_base(
  combined_stats,
  file.path(STAT_DIR, "Atau_gene_class_ALL_thresholds_ALL_data_types_stats.tsv")
)

write_tsv_base(
  combined_summary,
  file.path(TABLE_DIR, "Atau_gene_class_ALL_thresholds_ALL_data_types_summary.tsv")
)

## =========================================================
## 10. Plot 1: SNP density + deleterious ratio
## =========================================================
for (dt in DATA_TYPES) {
  cat("[INFO] Plotting ratio figure, data type: ", dt, "\n", sep = "")

  df_snp <- all_tables[[paste("gt4", dt, sep = "_")]]

  stat_snp <- combined_stats %>%
    filter(
      threshold == "gt4",
      data_type == dt,
      metric == "cds_snp_density"
    )

  sig_snp <- make_sig_df(
    df_plot = df_snp,
    stat_tbl = stat_snp,
    value_col = "cds_snp_density"
  )

  pA <- plot_one_panel(
    df_plot = df_snp,
    sig_df = sig_snp$sig_df,
    value_col = "cds_snp_density",
    y_limit = sig_snp$y_limit,
    panel_title = paste0("A  SNP density (", dt, ")"),
    ylab = expression(log[10]("CDS SNP density" + 10^-6)),
    log10_plot = TRUE,
    pseudo = 1e-6
  )

  p_list <- list()

  title_map <- c(
    gt2 = paste0("B  Deleterious ratio, GERP > 2 (", dt, ")"),
    gt4 = paste0("C  Deleterious ratio, GERP > 4 (", dt, ")"),
    gt6 = paste0("D  Deleterious ratio, GERP > 6 (", dt, ")")
  )

  for (thr in THRESHOLDS) {
    df_del <- all_tables[[paste(thr, dt, sep = "_")]]

    stat_del <- combined_stats %>%
      filter(
        threshold == thr,
        data_type == dt,
        metric == "cds_deleterious_ratio"
      )

    sig_del <- make_sig_df(
      df_plot = df_del,
      stat_tbl = stat_del,
      value_col = "cds_deleterious_ratio"
    )

    p_list[[thr]] <- plot_one_panel(
      df_plot = df_del,
      sig_df = sig_del$sig_df,
      value_col = "cds_deleterious_ratio",
      y_limit = max(1, sig_del$y_limit),
      panel_title = title_map[[thr]],
      ylab = "CDS deleterious SNP ratio",
      log10_plot = FALSE
    )
  }

  fig <- (pA | p_list[["gt2"]]) /
    (p_list[["gt4"]] | p_list[["gt6"]]) +
    plot_layout(guides = "collect")

  out_pdf <- file.path(
    FIG_DIR,
    paste0("Fig_Atau_gene_class_", dt,
           "_SNP_density_deleterious_ratio.pdf")
  )

  out_png <- file.path(
    FIG_DIR,
    paste0("Fig_Atau_gene_class_", dt,
           "_SNP_density_deleterious_ratio.png")
  )

  safe_ggsave(out_pdf, fig, width = 9.2, height = 7.2)
  safe_ggsave(out_png, fig, width = 9.2, height = 7.2, dpi = 300)
}

## =========================================================
## 11. Plot 2: deleterious density
## =========================================================
for (dt in DATA_TYPES) {
  cat("[INFO] Plotting deleterious density figure, data type: ", dt, "\n", sep = "")

  p_list <- list()

  title_map <- c(
    gt2 = paste0("A  Deleterious density, GERP > 2 (", dt, ")"),
    gt4 = paste0("B  Deleterious density, GERP > 4 (", dt, ")"),
    gt6 = paste0("C  Deleterious density, GERP > 6 (", dt, ")")
  )

  for (thr in THRESHOLDS) {
    df_den <- all_tables[[paste(thr, dt, sep = "_")]]

    stat_den <- combined_stats %>%
      filter(
        threshold == thr,
        data_type == dt,
        metric == "cds_deleterious_density"
      )

    sig_den <- make_sig_df(
      df_plot = df_den,
      stat_tbl = stat_den,
      value_col = "cds_deleterious_density"
    )

    p_list[[thr]] <- plot_one_panel(
      df_plot = df_den,
      sig_df = sig_den$sig_df,
      value_col = "cds_deleterious_density",
      y_limit = sig_den$y_limit,
      panel_title = title_map[[thr]],
      ylab = expression(log[10]("CDS deleterious density" + 10^-6)),
      log10_plot = TRUE,
      pseudo = 1e-6
    )
  }

  fig_den <- p_list[["gt2"]] + p_list[["gt4"]] + p_list[["gt6"]] +
    plot_layout(ncol = 3, guides = "collect")

  out_pdf <- file.path(
    FIG_DIR,
    paste0("Fig_Atau_gene_class_", dt,
           "_deleterious_density.pdf")
  )

  out_png <- file.path(
    FIG_DIR,
    paste0("Fig_Atau_gene_class_", dt,
           "_deleterious_density.png")
  )

  safe_ggsave(out_pdf, fig_den, width = 13.2, height = 4.85)
  safe_ggsave(out_png, fig_den, width = 13.2, height = 4.85, dpi = 300)
}

cat("[DONE] All results written to: ", OUTDIR, "\n", sep = "")