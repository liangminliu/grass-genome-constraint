#!/usr/bin/env bash
#BSUB -J plot_Atau_GERP
#BSUB -q Q48C2T_X1
#BSUB -n 4
#BSUB -o plot_Atau_GERP.%J.out
#BSUB -e plot_Atau_GERP.%J.err

set -euo pipefail

echo "[INFO] Job started at: $(date)"
echo "[INFO] Host: $(hostname)"
echo "[INFO] Workdir: $PWD"

# 如需 conda 环境，取消注释并修改环境名
# source ~/miniforge3/etc/profile.d/conda.sh
# conda activate 

SCRIPT="plot_strict_core_cross_species_SNP_deleterious.R"

if [[ ! -s "${SCRIPT}" ]]; then
    echo "[ERROR] R script not found or empty: ${SCRIPT}" >&2
    exit 1
fi

command -v Rscript >/dev/null 2>&1 || {
    echo "[ERROR] Rscript not found in PATH" >&2
    exit 1
}

#Rscript "${SCRIPT}"
Rscript  plot_Atau_gene_class_SNP_deleterious_density_all_rawScale_final.R&
Rscript  &
 Rscript  & 
  Rscript  &

wait
echo "[INFO] Job finished at: $(date)"
