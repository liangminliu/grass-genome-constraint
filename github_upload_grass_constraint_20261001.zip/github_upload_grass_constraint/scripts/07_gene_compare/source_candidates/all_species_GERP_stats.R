#!/usr/bin/env Rscript

## =========================================================
## Cross-species comparison of CDS constrained proportion
## ped (C+D), Z. mays, A. tauschii
## GERP threshold selectable
## FINAL publication-ready version
## =========================================================

suppressPackageStartupMessages({
  library(dplyr)
  library(readr)
  library(ggplot2)
  library(dunn.test)
  library(ggsignif)
})

## =========================================================
## 1. Parameters
## =========================================================
threshold <- "gt2"   # gt2 / gt4 / gt6

## =========================================================
## 2. Input files
## =========================================================
files <- list(
  pedC = paste0(
    "2.1.ped/ped_target_gene_CDS_GERP_stats/gerp_", threshold,
    "/pedC/per_gene_stats.tsv"
  ),
  pedD = paste0(
    "2.1.ped/ped_target_gene_CDS_GERP_stats/gerp_", threshold,
    "/pedD/per_gene_stats.tsv"
  ),
  Zmay = paste0(
    "2.2.Zmay/Zmay_target_gene_CDS_GERP_stats/",
    threshold, "/per_gene_stats.tsv"
  ),
  Atau = paste0(
    "2.3.Atau/target_gene_CDS_GERP_stats/",
    threshold, "/per_gene_stats.tsv"
  )
)

## =========================================================
## 3. Read data
## =========================================================
df_all <- lapply(names(files), function(sp) {
  if (!file.exists(files[[sp]])) {
    stop("Missing file: ", files[[sp]])
  }
  read_tsv(files[[sp]], show_col_types = FALSE) %>%
    mutate(species_raw = sp)
}) %>% bind_rows()

## =========================================================
## 4. Merge species
## =========================================================
df_species <- df_all %>%
  mutate(
    species = case_when(
      species_raw %in% c("pedC", "pedD") ~ "P.edulis",
      species_raw == "Zmay"               ~ "Z.mays",
      species_raw == "Atau"               ~ "A.tauschii"
    )
  )

df_species$species <- factor(
  df_species$species,
  levels = c("P.edulis", "Z.mays","A.tauschii" )
)

## =========================================================
## 5. Plot data
## =========================================================
df_plot <- df_species %>%
  select(species, cds_pct) %>%
  filter(!is.na(cds_pct))

## =========================================================
## 6. Kruskal–Wallis
## =========================================================
kw <- kruskal.test(cds_pct ~ species, data = df_plot)
print(kw)

## =========================================================
## 7. Dunn test
## =========================================================
dt <- dunn.test(
  x = df_plot$cds_pct,
  g = df_plot$species,
  method = "bh",
  kw = FALSE,
  list = TRUE
)

sig_df <- tibble(
  Comparison = dt$comparisons,
  P.adj      = dt$P.adjusted
) %>%
  mutate(
    group1 = sub(" -.*", "", Comparison),
    group2 = sub(".*- ", "", Comparison),
    label = case_when(
      P.adj < 0.001 ~ "***",
      P.adj < 0.01  ~ "**",
      P.adj < 0.05  ~ "*",
      TRUE          ~ "ns"
    )
  )

## =========================================================
## 8. Compute y positions and panel upper limit
## =========================================================
y_data_max <- max(df_plot$cds_pct, na.rm = TRUE)

sig_df$y_position <- y_data_max + seq(
  from = 3,
  by   = 3,
  length.out = nrow(sig_df)
)

y_panel_max <- max(sig_df$y_position) + 3

## =========================================================
## 9. Plot
## =========================================================
p <- ggplot(df_plot, aes(species, cds_pct)) +

  ## violin (瘦，不连轴)
  geom_violin(
    width = 0.45,
    scale = "width",
    trim  = TRUE,
    fill  = "#D9D9D9",
    color = "#6E6E6E",
    linewidth = 0.8
  ) +

  ## boxplot（短 whisker）
  geom_boxplot(
    width = 0.06,
    coef  = 0.4,
    fill  = "white",
    color = "black",
    linewidth = 1,
    outlier.shape = NA
  ) +

  ## significance
  geom_signif(
    data = sig_df,
    aes(
      xmin = group1,
      xmax = group2,
      annotations = label,
      y_position = y_position
    ),
    manual = TRUE,
    textsize = 4,
    tip_length = 0.01,
    linewidth = 0.8
  ) +

  ## y axis: 明确扩展到包含星号
  scale_y_continuous(
    limits = c(0, y_panel_max),
    breaks = seq(0, 100, 25),
    expand = c(0, 0)
  ) +

  labs(
    x = NULL,
    y = "CDS constrained sites (%)"
  ) +

  theme_classic(base_size = 16) +
  theme(
    axis.text.x = element_text(face = "italic", size = 16),
    axis.text.y = element_text(size = 14),
    axis.title.y = element_text(size = 16),

    ## panel border 包住一切
    panel.border = element_rect(
      fill = NA,
      color = "black",
      linewidth = 1
    ),

    plot.margin = margin(14, 14, 10, 14)
  )

## =========================================================
## 10. Save
## =========================================================
out <- paste0("Fig_cross_species_", threshold)

ggsave(paste0(out, ".pdf"), p, width = 4.8, height = 4.8)
ggsave(paste0(out, ".png"), p, width = 4.8, height = 4.8, dpi = 300)

cat("Saved:", out, ".pdf / .png\n")
