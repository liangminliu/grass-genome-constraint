#!/usr/bin/env bash
#SBATCH --job-name=ped_cat_combined
#SBATCH --partition=parallel
#SBATCH --nodes=1
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=10
#SBATCH --array=1-4
#SBATCH --output=logs/ped_cat_combined_%A_%a.out
#SBATCH --error=logs/ped_cat_combined_%A_%a.err

set -euo pipefail
module load bedtools 2>/dev/null || true

############################################################
# 0. Inputs
############################################################
GENE_EXPANDED="ped_gene_expanded.tsv"

GENE_BED="genes.bed"               # chr start end gene_id
CDS_BED="CDS_jcvi.bed"             # chr start end cds/transcript_id

INTERSECT_ROOT="intersect_results" # genome-wide GERP intersect results

GENE_SNP_INTERSECT="genes.intersect.bed"
CDS_SNP_INTERSECT="CDS_jcvi.intersect.bed"

OUT_ROOT="ped_category_combined_stats"
mkdir -p logs "${OUT_ROOT}"

############################################################
# 1. Threshold array
############################################################
CLASSES=("gerp_gt0" "gerp_gt2" "gerp_gt4" "gerp_gt6")
IDX=$((SLURM_ARRAY_TASK_ID - 1))

if [[ ${IDX} -lt 0 || ${IDX} -ge ${#CLASSES[@]} ]]; then
  echo "[ERROR] Bad SLURM_ARRAY_TASK_ID=${SLURM_ARRAY_TASK_ID}" >&2
  exit 1
fi

CLASS="${CLASSES[$IDX]}"
SHORT_CLASS="${CLASS#gerp_}"   # gt0 / gt2 / gt4 / gt6

echo "[INFO] Threshold = ${CLASS}"

############################################################
# 2. Check common inputs
############################################################
[[ -s "${GENE_EXPANDED}"      ]] || { echo "[ERROR] Missing ${GENE_EXPANDED}" >&2; exit 1; }
[[ -s "${GENE_BED}"           ]] || { echo "[ERROR] Missing ${GENE_BED}" >&2; exit 1; }
[[ -s "${CDS_BED}"            ]] || { echo "[ERROR] Missing ${CDS_BED}" >&2; exit 1; }
[[ -s "${GENE_SNP_INTERSECT}" ]] || { echo "[ERROR] Missing ${GENE_SNP_INTERSECT}" >&2; exit 1; }
[[ -s "${CDS_SNP_INTERSECT}"  ]] || { echo "[ERROR] Missing ${CDS_SNP_INTERSECT}" >&2; exit 1; }

############################################################
# 3. Categories
############################################################
CATS=("retained_1to2" "pedC_only" "pedD_only")

############################################################
# 4. Output dirs
############################################################
CLASS_DIR="${OUT_ROOT}/${CLASS}"
TMP_DIR="${CLASS_DIR}/tmp"
mkdir -p "${TMP_DIR}"

FINAL_TSV="${CLASS_DIR}/all_categories_combined.tsv"
SUMMARY_TSV="${CLASS_DIR}/category_summary.tsv"

############################################################
# 5. Clean ped_gene_expanded.tsv (remove CRLF)
############################################################
CLEAN_GENE_EXPANDED="${TMP_DIR}/ped_gene_expanded.clean.tsv"
tr -d '\r' < "${GENE_EXPANDED}" > "${CLEAN_GENE_EXPANDED}"

############################################################
# 6. Final output headers
############################################################
printf "%s\n" \
"subgenome	category	gene_id	gene_len	cds_len	gene_conserved_sites	gene_conserved_pct	cds_conserved_sites	cds_conserved_pct	gene_snp_total	gene_snp_ratio	gene_deleterious_snp	gene_deleterious_ratio	cds_snp_total	cds_snp_ratio	cds_deleterious_snp	cds_deleterious_ratio" \
> "${FINAL_TSV}"

printf "%s\n" \
"subgenome	category	n_genes	sum_gene_len	sum_cds_len	sum_gene_conserved_sites	gene_conserved_pct_weighted	sum_cds_conserved_sites	cds_conserved_pct_weighted	sum_gene_snp_total	gene_snp_ratio	sum_gene_deleterious_snp	gene_deleterious_ratio	sum_cds_snp_total	cds_snp_ratio	sum_cds_deleterious_snp	cds_deleterious_ratio" \
> "${SUMMARY_TSV}"

############################################################
# Helper
############################################################
normalize_gene_id() {
  sed -e 's/^pedC_//' -e 's/^pedD_//'
}

############################################################
# 7. Main
############################################################
for SUB in pedC pedD; do
  echo
  echo "=========================================================="
  echo "[INFO] Subgenome = ${SUB}"
  echo "=========================================================="

  GENE_GERP_ALL="${INTERSECT_ROOT}/${CLASS}/${SUB}_*.genes.intersect.bed"
  CDS_GERP_ALL="${INTERSECT_ROOT}/${CLASS}/${SUB}_*.CDS_jcvi.intersect.bed"

  if ! ls ${GENE_GERP_ALL} >/dev/null 2>&1; then
    echo "[ERROR] Missing ${GENE_GERP_ALL}" >&2
    exit 1
  fi
  if ! ls ${CDS_GERP_ALL} >/dev/null 2>&1; then
    echo "[ERROR] Missing ${CDS_GERP_ALL}" >&2
    exit 1
  fi

  ##########################################################
  # deleterious detailed bed only for gt2/4/6
  ##########################################################
  HAS_DEL=0
  GENE_DEL_BED=""
  CDS_DEL_BED=""
  if [[ "${SHORT_CLASS}" != "gt0" ]]; then
    GENE_DEL_BED="${SUB}_${SHORT_CLASS}_genes_detailed.bed"
    CDS_DEL_BED="${SUB}_${SHORT_CLASS}_CDS_jcvi_detailed.bed"
    [[ -s "${GENE_DEL_BED}" ]] || { echo "[ERROR] Missing ${GENE_DEL_BED}" >&2; exit 1; }
    [[ -s "${CDS_DEL_BED}"  ]] || { echo "[ERROR] Missing ${CDS_DEL_BED}" >&2; exit 1; }
    HAS_DEL=1
  fi

  for CAT in "${CATS[@]}"; do
    # skip impossible combinations
    if [[ "${CAT}" == "pedC_only" && "${SUB}" == "pedD" ]]; then continue; fi
    if [[ "${CAT}" == "pedD_only" && "${SUB}" == "pedC" ]]; then continue; fi

    echo "[INFO] Category = ${CAT}"

    WORK_DIR="${TMP_DIR}/${CAT}/${SUB}"
    mkdir -p "${WORK_DIR}"

    ##########################################################
    # 7.1 gene list from ped_gene_expanded.tsv
    #     robust to CRLF and mixed whitespace
    ##########################################################
    GENE_LIST="${WORK_DIR}/target_gene_ids.txt"

    awk -v sg="${SUB}" -v grp="${CAT}" 'BEGIN{FS="[[:space:]]+"; OFS="\t"}
      NR==1{next}
      {
        gsub(/\r/, "", $0)
        if ($2==sg && $4==grp && toupper($5)=="TRUE") {
          print $1
        }
      }' "${CLEAN_GENE_EXPANDED}" \
    | normalize_gene_id \
    | LC_ALL=C sort -u \
    > "${GENE_LIST}"

    NGENE=$(wc -l < "${GENE_LIST}" || true)
    echo "[INFO] ${SUB} ${CAT} genes = ${NGENE}"
    echo "[DEBUG] first few matched genes:"
    head -n 5 "${GENE_LIST}" || true

    if [[ "${NGENE}" -eq 0 ]]; then
      echo "[WARN] Empty gene set for ${SUB} ${CAT}, skip"
      continue
    fi

    ##########################################################
    # 7.2 target gene / CDS bed
    ##########################################################
    TARGET_GENE_BED="${WORK_DIR}/target_genes.bed"
    TARGET_CDS_BED="${WORK_DIR}/target_CDS.bed"

    awk 'BEGIN{OFS="\t"}{print $1,$2,$3,$4}' "${GENE_BED}" \
    | awk 'NR==FNR{a[$1]=1;next} a[$4]' "${GENE_LIST}" - \
    > "${TARGET_GENE_BED}"

    awk 'BEGIN{OFS="\t"}{
      gene=$4
      sub(/:.*/, "", gene)
      sub(/\..*/, "", gene)
      print $1,$2,$3,gene
    }' "${CDS_BED}" \
    | awk 'NR==FNR{a[$1]=1;next} a[$4]' "${GENE_LIST}" - \
    > "${TARGET_CDS_BED}"

    if [[ ! -s "${TARGET_GENE_BED}" ]]; then
      echo "[WARN] ${SUB} ${CAT} target gene bed is empty, skip"
      continue
    fi
    if [[ ! -s "${TARGET_CDS_BED}" ]]; then
      echo "[WARN] ${SUB} ${CAT} target CDS bed is empty, skip"
      continue
    fi

    ##########################################################
    # 7.3 target conserved sites = genome-wide conserved ∩ target bed
    ##########################################################
    TARGET_GENE_CONS="${WORK_DIR}/target_gene_conserved_sites.bed"
    TARGET_CDS_CONS="${WORK_DIR}/target_CDS_conserved_sites.bed"

    bedtools intersect -wa -a ${GENE_GERP_ALL} -b "${TARGET_GENE_BED}" \
      > "${TARGET_GENE_CONS}"

    bedtools intersect -wa -a ${CDS_GERP_ALL} -b "${TARGET_CDS_BED}" \
      > "${TARGET_CDS_CONS}"

    ##########################################################
    # 7.4 4-col conserved-site bed: chr start end gene_id
    # IMPORTANT: gene_id is $(NF-2), not $NF
    ##########################################################
    TARGET_GENE_SITE_BED="${WORK_DIR}/target_gene_sites.gene.bed"
    TARGET_CDS_SITE_BED="${WORK_DIR}/target_CDS_sites.gene.bed"

    if [[ -s "${TARGET_GENE_CONS}" ]]; then
      awk 'BEGIN{OFS="\t"}{
        gene=$(NF-2)
        print $1,$2,$3,gene
      }' "${TARGET_GENE_CONS}" \
      > "${TARGET_GENE_SITE_BED}"
    else
      : > "${TARGET_GENE_SITE_BED}"
    fi

    if [[ -s "${TARGET_CDS_CONS}" ]]; then
      awk 'BEGIN{OFS="\t"}{
        gene=$(NF-2)
        sub(/:.*/, "", gene)
        sub(/\..*/, "", gene)
        print $1,$2,$3,gene
      }' "${TARGET_CDS_CONS}" \
      > "${TARGET_CDS_SITE_BED}"
    else
      : > "${TARGET_CDS_SITE_BED}"
    fi

    ##########################################################
    # 7.5 gene length
    ##########################################################
    awk 'BEGIN{OFS="\t"}{
      len[$4]+=$3-$2
    } END{
      for(g in len) print g, len[g]
    }' "${TARGET_GENE_BED}" \
    | LC_ALL=C sort -k1,1 \
    > "${WORK_DIR}/gene_length.tsv"

    ##########################################################
    # 7.6 CDS union length
    ##########################################################
    LC_ALL=C sort -k4,4 -k1,1 -k2,2n "${TARGET_CDS_BED}" \
    | awk 'BEGIN{OFS="\t"}
      NR==1{
        cg=$4; cchr=$1; cs=$2; ce=$3; sum=0; next
      }
      {
        g=$4; chr=$1; s=$2; e=$3
        if(g!=cg || chr!=cchr){
          sum += (ce - cs)
          print cg, sum
          cg=g; cchr=chr; cs=s; ce=e; sum=0
          next
        }
        if(s <= ce){
          if(e > ce) ce=e
        } else {
          sum += (ce - cs)
          cs=s; ce=e
        }
      }
      END{
        if(NR>0){
          sum += (ce - cs)
          print cg, sum
        }
      }' \
    | LC_ALL=C sort -k1,1 \
    > "${WORK_DIR}/cds_length.tsv"

    ##########################################################
    # 7.7 conserved site count per gene
    ##########################################################
    if [[ -s "${TARGET_GENE_SITE_BED}" ]]; then
      awk 'BEGIN{OFS="\t"}{
        key=$1"\t"$2"\t"$3"\t"$4
        if(!seen[key]++) c[$4]++
      } END{
        for(g in c) print g, c[g]
      }' "${TARGET_GENE_SITE_BED}" \
      | LC_ALL=C sort -k1,1 \
      > "${WORK_DIR}/gene_conserved_count.tsv"
    else
      : > "${WORK_DIR}/gene_conserved_count.tsv"
    fi

    if [[ -s "${TARGET_CDS_SITE_BED}" ]]; then
      awk 'BEGIN{OFS="\t"}{
        key=$1"\t"$2"\t"$3"\t"$4
        if(!seen[key]++) c[$4]++
      } END{
        for(g in c) print g, c[g]
      }' "${TARGET_CDS_SITE_BED}" \
      | LC_ALL=C sort -k1,1 \
      > "${WORK_DIR}/cds_conserved_count.tsv"
    else
      : > "${WORK_DIR}/cds_conserved_count.tsv"
    fi

    ##########################################################
    # 7.8 total SNP count
    # genes/CDS intersect file: gene id in col8
    ##########################################################
    awk 'BEGIN{FS=OFS="\t"}
      NR==FNR{
        target[$1]=1
        next
      }
      {
        gene=$8
        gsub(/\r/, "", gene)
        sub(/:.*/, "", gene)
        sub(/\..*/, "", gene)
        if (!(gene in target)) next

        key=$1"\t"$2"\t"$3"\t"gene
        if(!seen[key]++) c[gene]++
      }
      END{
        for(g in c) print g, c[g]
      }' "${GENE_LIST}" "${GENE_SNP_INTERSECT}" \
    | LC_ALL=C sort -k1,1 \
    > "${WORK_DIR}/gene_snp_total.tsv"

    awk 'BEGIN{FS=OFS="\t"}
      NR==FNR{
        target[$1]=1
        next
      }
      {
        gene=$8
        gsub(/\r/, "", gene)
        sub(/:.*/, "", gene)
        sub(/\..*/, "", gene)
        if (!(gene in target)) next

        key=$1"\t"$2"\t"$3"\t"gene
        if(!seen[key]++) c[gene]++
      }
      END{
        for(g in c) print g, c[g]
      }' "${GENE_LIST}" "${CDS_SNP_INTERSECT}" \
    | LC_ALL=C sort -k1,1 \
    > "${WORK_DIR}/cds_snp_total.tsv"

    ##########################################################
    # 7.9 deleterious SNP count
    # detailed bed: gene id in col11
    ##########################################################
    if [[ ${HAS_DEL} -eq 1 ]]; then
      awk 'BEGIN{FS=OFS="\t"}
        NR==FNR{
          target[$1]=1
          next
        }
        {
          gene=$11
          gsub(/\r/, "", gene)
          sub(/:.*/, "", gene)
          sub(/\..*/, "", gene)
          if (!(gene in target)) next

          key=$1"\t"$2"\t"$3"\t"gene
          if(!seen[key]++) c[gene]++
        }
        END{
          for(g in c) print g, c[g]
        }' "${GENE_LIST}" "${GENE_DEL_BED}" \
      | LC_ALL=C sort -k1,1 \
      > "${WORK_DIR}/gene_deleterious.tsv"

      awk 'BEGIN{FS=OFS="\t"}
        NR==FNR{
          target[$1]=1
          next
        }
        {
          gene=$11
          gsub(/\r/, "", gene)
          sub(/:.*/, "", gene)
          sub(/\..*/, "", gene)
          if (!(gene in target)) next

          key=$1"\t"$2"\t"$3"\t"gene
          if(!seen[key]++) c[gene]++
        }
        END{
          for(g in c) print g, c[g]
        }' "${GENE_LIST}" "${CDS_DEL_BED}" \
      | LC_ALL=C sort -k1,1 \
      > "${WORK_DIR}/cds_deleterious.tsv"
    else
      : > "${WORK_DIR}/gene_deleterious.tsv"
      : > "${WORK_DIR}/cds_deleterious.tsv"
    fi

    ##########################################################
    # 7.10 merge all per-gene stats
    ##########################################################
    awk -v subg="${SUB}" -v catg="${CAT}" 'BEGIN{
        FS=OFS="\t"
      }
      ARGIND==1{
        gene_len[$1]=$2
        genes[$1]=1
        next
      }
      ARGIND==2{
        cds_len[$1]=$2
        genes[$1]=1
        next
      }
      ARGIND==3{
        gene_cons[$1]=$2
        next
      }
      ARGIND==4{
        cds_cons[$1]=$2
        next
      }
      ARGIND==5{
        gene_snp[$1]=$2
        next
      }
      ARGIND==6{
        cds_snp[$1]=$2
        next
      }
      ARGIND==7{
        gene_del[$1]=$2
        next
      }
      ARGIND==8{
        cds_del[$1]=$2
        next
      }
      END{
        for(g in genes){
          gl = (g in gene_len)  ? gene_len[g]  : 0
          cl = (g in cds_len)   ? cds_len[g]   : 0
          gc = (g in gene_cons) ? gene_cons[g] : 0
          cc = (g in cds_cons)  ? cds_cons[g]  : 0
          gs = (g in gene_snp)  ? gene_snp[g]  : 0
          cs = (g in cds_snp)   ? cds_snp[g]   : 0
          gd = (g in gene_del)  ? gene_del[g]  : 0
          cd = (g in cds_del)   ? cds_del[g]   : 0

          gcp = (gl > 0) ? gc / gl * 100 : 0
          ccp = (cl > 0) ? cc / cl * 100 : 0
          gsr = (gl > 0) ? gs / gl : 0
          csr = (cl > 0) ? cs / cl : 0
          gdr = (gs > 0) ? gd / gs : 0
          cdr = (cs > 0) ? cd / cs : 0

          printf "%s\t%s\t%s\t%d\t%d\t%d\t%.6f\t%d\t%.6f\t%d\t%.6f\t%d\t%.6f\t%d\t%.6f\t%d\t%.6f\n", \
            subg, catg, g, gl, cl, gc, gcp, cc, ccp, gs, gsr, gd, gdr, cs, csr, cd, cdr
        }
      }' \
      "${WORK_DIR}/gene_length.tsv" \
      "${WORK_DIR}/cds_length.tsv" \
      "${WORK_DIR}/gene_conserved_count.tsv" \
      "${WORK_DIR}/cds_conserved_count.tsv" \
      "${WORK_DIR}/gene_snp_total.tsv" \
      "${WORK_DIR}/cds_snp_total.tsv" \
      "${WORK_DIR}/gene_deleterious.tsv" \
      "${WORK_DIR}/cds_deleterious.tsv" \
    | LC_ALL=C sort -k3,3 \
    > "${WORK_DIR}/combined_per_gene.tsv"

    cat "${WORK_DIR}/combined_per_gene.tsv" >> "${FINAL_TSV}"

    ##########################################################
    # 7.11 category-level summary
    ##########################################################
    awk -v subg="${SUB}" -v catg="${CAT}" 'BEGIN{FS=OFS="\t"}
      {
        n++
        sum_gl+=$4
        sum_cl+=$5
        sum_gc+=$6
        sum_cc+=$8
        sum_gs+=$10
        sum_gd+=$12
        sum_cs+=$14
        sum_cd+=$16
      }
      END{
        gcp=(sum_gl>0)?sum_gc/sum_gl*100:0
        ccp=(sum_cl>0)?sum_cc/sum_cl*100:0
        gsr=(sum_gl>0)?sum_gs/sum_gl:0
        csr=(sum_cl>0)?sum_cs/sum_cl:0
        gdr=(sum_gs>0)?sum_gd/sum_gs:0
        cdr=(sum_cs>0)?sum_cd/sum_cs:0

        printf "%s\t%s\t%d\t%d\t%d\t%d\t%.6f\t%d\t%.6f\t%d\t%.6f\t%d\t%.6f\t%d\t%.6f\t%d\t%.6f\n", \
          subg, catg, n, sum_gl, sum_cl, sum_gc, gcp, sum_cc, ccp, sum_gs, gsr, sum_gd, gdr, sum_cs, csr, sum_cd, cdr
      }' "${WORK_DIR}/combined_per_gene.tsv" \
    >> "${SUMMARY_TSV}"

    echo "[INFO] done ${SUB} ${CAT}"
    echo "[INFO] rows appended: $(wc -l < "${WORK_DIR}/combined_per_gene.tsv")"
    echo "[INFO] gene conserved count entries: $(wc -l < "${WORK_DIR}/gene_conserved_count.tsv")"
    echo "[INFO] cds conserved count entries : $(wc -l < "${WORK_DIR}/cds_conserved_count.tsv")"
    echo "[INFO] gene SNP count entries      : $(wc -l < "${WORK_DIR}/gene_snp_total.tsv")"
    echo "[INFO] cds SNP count entries       : $(wc -l < "${WORK_DIR}/cds_snp_total.tsv")"
  done
done

echo
echo "[INFO] Wrote:"
echo "[INFO]   ${FINAL_TSV}"
echo "[INFO]   ${SUMMARY_TSV}"
echo "[INFO] DONE ${CLASS}"