#!/usr/bin/env Rscript

## =========================================================
## Paired comparison: pedC vs pedD
## CDS constrained proportion
## Orthogroup-level pairing
## Paired Wilcoxon + gene-wise connecting lines
## FINAL publication-ready version
## =========================================================

suppressPackageStartupMessages({
  library(dplyr)
  library(readr)
  library(ggplot2)
  library(tidyr)
  library(stringr)
})

## =========================================================
## 1. Parameters
## =========================================================
threshold <- "gt6"   # gt2 / gt4 / gt6

PAN_FILE <- "core_5sp_1to1.SG.pan"

file_pedC <- paste0(
  "2.1.ped/ped_target_gene_CDS_GERP_stats/gerp_",
  threshold, "/pedC/per_gene_stats.tsv"
)

file_pedD <- paste0(
  "2.1.ped/ped_target_gene_CDS_GERP_stats/gerp_",
  threshold, "/pedD/per_gene_stats.tsv"
)

if (!file.exists(file_pedC)) stop("Missing: ", file_pedC)
if (!file.exists(file_pedD)) stop("Missing: ", file_pedD)
if (!file.exists(PAN_FILE))  stop("Missing: ", PAN_FILE)

## =========================================================
## 2. Read PAN → orthogroup ↔ pedC / pedD mapping
## =========================================================
pan <- read_tsv(
  PAN_FILE,
  col_names = FALSE,
  show_col_types = FALSE
) %>%
  transmute(
    orthogroup = X1,
    pedC = str_remove(X7, "^pedC_"),
    pedD = str_remove(X8, "^pedD_")
  ) %>%
  filter(
    !is.na(pedC), pedC != "-",
    !is.na(pedD), pedD != "-"
  )

## =========================================================
## 3. Read per-gene stats
## =========================================================
df_C <- read_tsv(file_pedC, show_col_types = FALSE) %>%
  select(gene_id, cds_pct) %>%
  rename(cds_pct_C = cds_pct)

df_D <- read_tsv(file_pedD, show_col_types = FALSE) %>%
  select(gene_id, cds_pct) %>%
  rename(cds_pct_D = cds_pct)

## =========================================================
## 4. Orthogroup-level strict pairing
## =========================================================
df_pair <- pan %>%
  left_join(df_C, by = c("pedC" = "gene_id")) %>%
  left_join(df_D, by = c("pedD" = "gene_id")) %>%
  select(orthogroup, pedC, pedD, cds_pct_C, cds_pct_D) %>%
  filter(!is.na(cds_pct_C), !is.na(cds_pct_D))

cat("Paired orthogroups:", nrow(df_pair), "\n")

## =========================================================
## 5. Paired Wilcoxon test
## =========================================================
wilc <- wilcox.test(
  df_pair$cds_pct_C,
  df_pair$cds_pct_D,
  paired = TRUE,
  exact  = FALSE
)

cat("\nPaired Wilcoxon test:\n")
print(wilc)

## ---- FIX: robust p_label (no if/else parsing issues) ----
p_label <- dplyr::case_when(
  wilc$p.value < 0.001 ~ "***",
  wilc$p.value < 0.01  ~ "**",
  wilc$p.value < 0.05  ~ "*",
  TRUE                 ~ "ns"
)

## =========================================================
## 6. Long format for plotting
## =========================================================
df_long <- df_pair %>%
  mutate(pair_id = row_number()) %>%
  pivot_longer(
    cols = c(cds_pct_C, cds_pct_D),
    names_to = "subgenome",
    values_to = "cds_pct"
  ) %>%
  mutate(
    subgenome = recode(
      subgenome,
      cds_pct_C = "pedC",
      cds_pct_D = "pedD"
    ),
    subgenome = factor(subgenome, levels = c("pedC", "pedD"))
  )

## =========================================================
## 7. Plot (paired violin + box + lines)
## =========================================================
y_max <- max(df_long$cds_pct, na.rm = TRUE)

p <- ggplot(df_long, aes(x = subgenome, y = cds_pct)) +

  geom_line(
    aes(group = pair_id),
    color = "grey70",
    linewidth = 0.3,
    alpha = 0.4
  ) +

  geom_violin(
    width = 0.38,
    scale = "width",
    trim  = TRUE,
    fill  = "#D9D9D9",
    color = "#6E6E6E",
    linewidth = 0.8
  ) +

  geom_boxplot(
    width = 0.06,
    fill = "white",
    color = "black",
    linewidth = 1,
    outlier.shape = NA
  ) +

  geom_segment(
    aes(x = 1, xend = 2,
        y = y_max + 3, yend = y_max + 3),
    linewidth = 0.8
  ) +
  geom_text(
    aes(x = 1.5, y = y_max + 5, label = p_label),
    size = 6
  ) +

  scale_y_continuous(
    limits = c(0, y_max + 8),
    breaks = seq(0, 100, 25),
    expand = c(0, 0)
  ) +

  labs(
    x = NULL,
    y = "CDS constrained sites (%)"
  ) +

  theme_classic(base_size = 16) +
  theme(
    axis.text.x = element_text(face = "italic", size = 16),
    axis.text.y = element_text(size = 14),
    axis.title.y = element_text(size = 16),
    panel.border = element_rect(fill = NA, color = "black", linewidth = 1),
    plot.margin = margin(12, 12, 10, 12)
  )

## =========================================================
## 8. Save
## =========================================================
out_prefix <- paste0("Fig_pedC_vs_pedD_paired_orthogroup_", threshold)

ggsave(
  paste0(out_prefix, ".pdf"),
  p,
  width = 3.6,
  height = 4.8,
  device = cairo_pdf
)

ggsave(
  paste0(out_prefix, ".png"),
  p,
  width = 3.6,
  height = 4.8,
  dpi = 300
)

cat("\nDone:\n", out_prefix, ".pdf / .png\n", sep = "")
