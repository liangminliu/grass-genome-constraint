#!/usr/bin/env Rscript

suppressPackageStartupMessages({
  library(dplyr)
  library(readr)
  library(stringr)
  library(ggplot2)
  library(ggsignif)
})

## =========================================================
## Parameters
## =========================================================
PAN_FILE <- "core_5sp_1to1.SG.pan"
BASE_DIR <- "ped_target_gene_CDS_GERP_stats"

THRESHOLDS <- c("gerp_gt2", "gerp_gt4", "gerp_gt6")
N_BOOT <- 1000
EPS <- 1e-6

OUT_PAIR  <- "CDS_constraint_homeolog_pair_table.tsv"
OUT_COUNT <- "CDS_constraint_counts_by_threshold.tsv"
OUT_FIG   <- "Fig_CDS_constraint_violin_box_gt2_gt4_gt6.pdf"

set.seed(123)

## =========================================================
## 1. Read pan file
## =========================================================
pan <- read_tsv(PAN_FILE, col_names = FALSE, show_col_types = FALSE)
colnames(pan) <- c(
  "SG_ID", "n_sp", "n_copy", "flag",
  "Atau", "Osat",
  "pedC", "pedD",
  "Zmay"
)

homeolog <- pan %>%
  transmute(
    SG_ID,
    geneC = str_remove(pedC, "^pedC_"),
    geneD = str_remove(pedD, "^pedD_")
  )

## =========================================================
## 2. Loop over GERP thresholds
## =========================================================
pair_list  <- list()
count_list <- list()
boot_list  <- list()

for (th in THRESHOLDS) {

  message("[INFO] Processing ", th)

  datC <- read_tsv(
    file.path(BASE_DIR, th, "pedC/per_gene_stats.tsv"),
    show_col_types = FALSE
  ) %>% select(gene_id, cds_pct_C = cds_pct)

  datD <- read_tsv(
    file.path(BASE_DIR, th, "pedD/per_gene_stats.tsv"),
    show_col_types = FALSE
  ) %>% select(gene_id, cds_pct_D = cds_pct)

  df <- homeolog %>%
    left_join(datC, by = c("geneC" = "gene_id")) %>%
    left_join(datD, by = c("geneD" = "gene_id")) %>%
    filter(!is.na(cds_pct_C), !is.na(cds_pct_D)) %>%
    mutate(
      threshold = th,
      Delta = log2((cds_pct_C + EPS) / (cds_pct_D + EPS)),
      C_status = ifelse(Delta > 0, "C_constrained", "C_less_constrained"),
      D_status = ifelse(Delta < 0, "D_constrained", "D_less_constrained")
    )

  pair_list[[th]] <- df

  ## ---- count constrained gene pairs ----
  count_list[[th]] <- df %>%
    summarise(
      threshold = th,
      C_constrained = sum(Delta > 0),
      D_constrained = sum(Delta < 0),
      total_pairs   = n()
    )

  ## ---- bootstrap constrained proportion ----
  boot <- lapply(seq_len(N_BOOT), function(i) {
    samp <- df %>% slice_sample(n = nrow(df), replace = TRUE)
    tibble(
      threshold = th,
      iter = i,
      category = c("C_constrained", "D_constrained"),
      proportion = c(
        mean(samp$Delta > 0) * 100,
        mean(samp$Delta < 0) * 100
      )
    )
  })

  boot_list[[th]] <- bind_rows(boot)
}

pair_df  <- bind_rows(pair_list)
count_df <- bind_rows(count_list)
boot_df  <- bind_rows(boot_list)

write_tsv(pair_df,  OUT_PAIR)
write_tsv(count_df, OUT_COUNT)

## =========================================================
## 3. Prepare plotting data
## =========================================================
boot_df$threshold <- factor(
  boot_df$threshold,
  levels = THRESHOLDS,
  labels = c("GERP > 2", "GERP > 4", "GERP > 6")
)

boot_df$category <- factor(
  boot_df$category,
  levels = c("C_constrained", "D_constrained")
)

## =========================================================
## 4. Violin + boxplot (full border, shared Y, light grid)
## =========================================================
p <- ggplot(
  boot_df,
  aes(x = category, y = proportion, fill = category)
) +
  geom_violin(
    trim = TRUE,
    width = 0.85,
    color = NA,
    alpha = 0.95
  ) +
  geom_boxplot(
    width = 0.18,
    outlier.shape = NA,
    linewidth = 0.6,
    fill = "white",
    color = "black"
  ) +
  facet_wrap(~ threshold, nrow = 1, scales = "fixed") +
  labs(
    x = NULL,
    y = "Constrained gene proportion (%)"
  ) +
  scale_fill_manual(values = c(
    "C_constrained" = "#4C9ED9",  # blue
    "D_constrained" = "#4CAF50"   # green
  )) +
  theme_bw(base_size = 12) +
  theme(
    panel.border = element_rect(
      color = "black",
      linewidth = 0.8,
      fill = NA
    ),
    panel.grid.major.y = element_line(
      color = "grey85",
      linewidth = 0.5
    ),
    panel.grid.minor.y = element_blank(),
    panel.grid.major.x = element_blank(),
    panel.grid.minor.x = element_blank(),
    strip.background = element_blank(),
    strip.text = element_text(size = 13, face = "bold"),
    axis.text = element_text(size = 11),
    axis.title.y = element_text(size = 13),
    legend.position = "top",
    legend.title = element_blank(),
    legend.text = element_text(size = 11)
  )

## ---- significance (two-sided Wilcoxon) ----
p <- p + geom_signif(
  comparisons = list(c("C_constrained", "D_constrained")),
  test = "wilcox.test",
  map_signif_level = TRUE,
  textsize = 4,
  y_position = max(boot_df$proportion) * 1.06
)

ggsave(
  OUT_FIG,
  p,
  width = 9.5,
  height = 4.2
)

message("[INFO] All analyses and plotting finished successfully.")
