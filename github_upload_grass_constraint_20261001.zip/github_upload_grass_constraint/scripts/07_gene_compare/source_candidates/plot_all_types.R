#!/usr/bin/env Rscript

suppressPackageStartupMessages({
  library(tidyverse)
  library(ggsignif)
  library(patchwork)
})

# =========================================================
# Config
# =========================================================
THRESHOLDS <- c("gt2", "gt4", "gt6")
DATA_TYPES <- c("ALL", "SNPpos", "SNP0")
species_levels <- c("ped", "Zmay", "Atau")

file_map <- c(
  "ALL"    = "SG_%s_cds_and_deleterious_ratio_table.tsv",
  "SNPpos" = "SG_%s_SNPpos_cds_and_deleterious_ratio_table.tsv",
  "SNP0"   = "SG_%s_SNP0_cds_and_deleterious_ratio_table.tsv"
)

# =========================================================
# p-value to stars
# =========================================================
p_to_star <- function(p) {
  case_when(
    is.na(p)    ~ "NA",
    p < 1e-4    ~ "****",
    p < 1e-3    ~ "***",
    p < 1e-2    ~ "**",
    p < 0.05    ~ "*",
    TRUE        ~ "ns"
  )
}

# =========================================================
# Safe paired Wilcoxon
# =========================================================
safe_paired_wilcox <- function(x, y) {
  idx <- complete.cases(x, y)
  x <- x[idx]
  y <- y[idx]

  if (length(x) < 3) return(NA_real_)

  out <- tryCatch(
    wilcox.test(x, y, paired = TRUE)$p.value,
    error = function(e) NA_real_
  )
  out
}

# =========================================================
# Plot function
# =========================================================
plot_metric <- function(df, metric_prefix, ylab, log_scale = FALSE, pseudo = NULL) {

  cols <- c(
    paste0("ped_", metric_prefix),
    paste0("Zmay_", metric_prefix),
    paste0("Atau_", metric_prefix)
  )

  df_plot <- df |>
    select(all_of(cols)) |>
    setNames(species_levels)

  # plot values
  df_long <- df_plot |>
    pivot_longer(
      everything(),
      names_to = "species",
      values_to = "value"
    ) |>
    mutate(species = factor(species, levels = species_levels))

  if (log_scale) {
    if (is.null(pseudo)) {
      # 只保留正值
      df_long <- df_long |>
        filter(value > 0)
    } else {
      # 加 pseudo-count 保留 0
      df_long <- df_long |>
        mutate(value = value + pseudo)
    }
  }

  p <- ggplot(df_long, aes(species, value)) +
    geom_boxplot(
      width = 0.6,
      outlier.shape = NA,
      size = 0.4
    ) +
    theme_classic(base_size = 11) +
    theme(
      axis.text = element_text(color = "black"),
      axis.title = element_text(color = "black"),
      strip.background = element_blank(),
      strip.text = element_text(face = "bold")
    ) +
    labs(y = ylab, x = NULL)

  if (log_scale) {
    p <- p + scale_y_log10()
  }

  # stats are computed on original values, not transformed values
  pvals <- c(
    safe_paired_wilcox(df_plot$ped,  df_plot$Zmay),
    safe_paired_wilcox(df_plot$ped,  df_plot$Atau),
    safe_paired_wilcox(df_plot$Zmay, df_plot$Atau)
  )

  y_max <- max(df_long$value, na.rm = TRUE)
  if (!is.finite(y_max) || y_max <= 0) y_max <- 1

  p <- p +
    geom_signif(
      comparisons = list(
        c("ped", "Zmay"),
        c("ped", "Atau"),
        c("Zmay", "Atau")
      ),
      annotations = sapply(pvals, p_to_star),
      y_position = c(y_max * 1.12, y_max * 1.24, y_max * 1.36),
      tip_length = 0.01,
      textsize = 3,
      vjust = 0.2
    )

  p
}

# =========================================================
# Main loop
# =========================================================
for (data_type in DATA_TYPES) {

  message("Processing ", data_type)
  plot_rows <- list()

  for (thr in THRESHOLDS) {

    message("  Threshold ", thr)

    # ------------------------------------------
    # cds_ratio always uses ALL
    # ------------------------------------------
    df_all_for_cds <- read_tsv(
      sprintf(file_map["ALL"], thr),
      show_col_types = FALSE
    )

    # ------------------------------------------
    # deleterious metrics use current data_type
    # ------------------------------------------
    df_del <- read_tsv(
      sprintf(file_map[data_type], thr),
      show_col_types = FALSE
    )

    # SNP density: must reflect real distribution, including zeros
    # use pseudo-count for log10 plotting
    p1 <- plot_metric(
      df_all_for_cds,
      metric_prefix = "cds_ratio",
      ylab = paste0("SNP density\n", thr),
      log_scale = TRUE,
      pseudo = 1e-6
    )

    # deleterious per site
    p2 <- plot_metric(
      df_del,
      metric_prefix = "del_per_site",
      ylab = paste0("Deleterious per site\n", thr),
      log_scale = TRUE,
      pseudo = 1e-6
    )

    # deleterious fraction
    p3 <- plot_metric(
      df_del,
      metric_prefix = "del_ratio",
      ylab = paste0("Deleterious fraction\n", thr),
      log_scale = FALSE
    )

    plot_rows[[thr]] <- p1 + p2 + p3
  }

  final_plot <- plot_rows[[1]] / plot_rows[[2]] / plot_rows[[3]]

  ggsave(
    filename = paste0("Figure_MBE_", data_type, ".pdf"),
    plot = final_plot,
    width = 9,
    height = 12,
    dpi = 300
  )
}