#!/usr/bin/env Rscript

suppressPackageStartupMessages({
  library(tidyverse)
  library(ggsignif)
  library(patchwork)
})

# =========================================================
# 0. Config
# =========================================================
input_dir <- "."
out_dir   <- "plots_flower_veg_publication_ready"
dir.create(out_dir, showWarnings = FALSE, recursive = TRUE)

threshold_levels <- c("gt2", "gt4", "gt6")
type_levels      <- c("Pol", "Veg")
species_levels   <- c("Atau", "ped", "Zmay")

type_labels <- c(
  "Pol" = "Flowering",
  "Veg" = "Vegetative"
)

metric_labels <- c(
  "gene_pct" = "Constrained proportion in gene (%)",
  "cds_pct"  = "Constrained proportion in CDS (%)"
)

species_labels <- c(
  "Atau" = "A. tauschii",
  "ped"  = "P. edulis",
  "Zmay" = "Z. mays"
)

subgenome_labels <- c(
  "pedC" = "pedC",
  "pedD" = "pedD"
)

# ---------------------------------------------------------
# plot parameters
# ---------------------------------------------------------
violin_fill   <- "grey88"
violin_color  <- "grey45"
box_fill      <- "white"
box_color     <- "black"
line_width    <- 0.45
box_width     <- 0.20

# =========================================================
# 1. Helper functions
# =========================================================
parse_filename <- function(x) {
  b <- basename(x)
  m <- stringr::str_match(
    b,
    "^(Atau|pedC|pedD|Zmay)_(Pol|Veg)_(gt[0-9]+)_per_gene_stats\\.tsv$"
  )
  if (any(is.na(m))) return(NULL)

  tibble(
    file = x,
    raw_species = m[, 2],
    type = m[, 3],
    threshold = m[, 4]
  )
}

safe_wilcox <- function(df) {
  x <- df$value[df$type == "Pol"]
  y <- df$value[df$type == "Veg"]

  if (length(x) < 2 || length(y) < 2) {
    return(tibble(
      n_pol = length(x),
      n_veg = length(y),
      median_pol = median(x, na.rm = TRUE),
      median_veg = median(y, na.rm = TRUE),
      mean_pol = mean(x, na.rm = TRUE),
      mean_veg = mean(y, na.rm = TRUE),
      delta_median = median(x, na.rm = TRUE) - median(y, na.rm = TRUE),
      p_value = NA_real_
    ))
  }

  wt <- suppressWarnings(wilcox.test(x, y, paired = FALSE, exact = FALSE))

  tibble(
    n_pol = length(x),
    n_veg = length(y),
    median_pol = median(x, na.rm = TRUE),
    median_veg = median(y, na.rm = TRUE),
    mean_pol = mean(x, na.rm = TRUE),
    mean_veg = mean(y, na.rm = TRUE),
    delta_median = median(x, na.rm = TRUE) - median(y, na.rm = TRUE),
    p_value = wt$p.value
  )
}

make_sig_df <- function(df_plot, df_stat, group_var = "species") {
  group_sym <- rlang::sym(group_var)

  y_tbl <- df_plot %>%
    group_by(!!group_sym, threshold, metric) %>%
    summarise(
      y_max = max(value, na.rm = TRUE),
      y_min = min(value, na.rm = TRUE),
      .groups = "drop"
    ) %>%
    mutate(
      span = pmax(y_max - y_min, 5),
      xmin = 1,
      xmax = 2,
      y_position = y_max + 0.06 * span + 2.0
    )

  left_join(df_stat, y_tbl, by = c(group_var, "threshold", "metric"))
}

get_ylim_for_metric <- function(metric_name, df_plot, df_sig) {
  ymax_data <- df_plot %>%
    filter(metric == metric_name) %>%
    summarise(v = max(value, na.rm = TRUE)) %>%
    pull(v)

  ymax_sig <- df_sig %>%
    filter(metric == metric_name) %>%
    summarise(v = max(y_position, na.rm = TRUE)) %>%
    pull(v)

  upper <- max(ymax_data, ymax_sig, na.rm = TRUE) + 3
  c(0, upper)
}

# =========================================================
# 2. Read input
# =========================================================
files <- list.files(
  path = input_dir,
  pattern = "_per_gene_stats\\.tsv$",
  full.names = TRUE
)

if (length(files) == 0) {
  stop("No *_per_gene_stats.tsv files found in current directory.")
}

meta <- bind_rows(lapply(files, parse_filename))

if (nrow(meta) == 0) {
  stop("No files matched expected pattern: Species_Type_Threshold_per_gene_stats.tsv")
}

meta <- meta %>%
  filter(threshold %in% threshold_levels)

if (nrow(meta) == 0) {
  stop("No gt2 / gt4 / gt6 files found.")
}

read_one <- function(file, raw_species, type, threshold) {
  df <- readr::read_tsv(file, show_col_types = FALSE)

  required_cols <- c(
    "gene_id", "gene_len", "cds_len",
    "gene_sites", "gene_pct", "cds_sites", "cds_pct"
  )
  miss <- setdiff(required_cols, colnames(df))
  if (length(miss) > 0) {
    stop("Missing columns in ", basename(file), ": ", paste(miss, collapse = ", "))
  }

  df %>%
    mutate(
      raw_species = raw_species,
      type = type,
      threshold = threshold,
      subgenome = case_when(
        raw_species == "pedC" ~ "pedC",
        raw_species == "pedD" ~ "pedD",
        TRUE ~ NA_character_
      ),
      species = case_when(
        raw_species %in% c("pedC", "pedD") ~ "ped",
        TRUE ~ raw_species
      )
    )
}

dat <- purrr::pmap_dfr(meta, read_one) %>%
  mutate(
    threshold = factor(threshold, levels = threshold_levels),
    type = factor(type, levels = type_levels),
    species = factor(species, levels = species_levels),
    raw_species = factor(raw_species, levels = c("Atau", "pedC", "pedD", "Zmay"))
  )

plot_df <- dat %>%
  select(gene_id, raw_species, species, subgenome, type, threshold, gene_pct, cds_pct) %>%
  pivot_longer(
    cols = c(gene_pct, cds_pct),
    names_to = "metric",
    values_to = "value"
  ) %>%
  mutate(metric = factor(metric, levels = c("gene_pct", "cds_pct")))

# =========================================================
# 3. Main stats: three-species figure
# =========================================================
stat_tbl <- plot_df %>%
  group_by(species, threshold, metric) %>%
  group_modify(~safe_wilcox(.x)) %>%
  ungroup() %>%
  mutate(
    p_adj = p.adjust(p_value, method = "BH"),
    signif = case_when(
      is.na(p_adj)  ~ "NA",
      p_adj < 0.001 ~ "***",
      p_adj < 0.01  ~ "**",
      p_adj < 0.05  ~ "*",
      TRUE          ~ "ns"
    ),
    species_label = species_labels[as.character(species)],
    metric_label  = metric_labels[as.character(metric)]
  )

readr::write_tsv(
  stat_tbl,
  file.path(out_dir, "Pol_vs_Veg_wilcox_statistics_main.tsv")
)

sig_df <- make_sig_df(plot_df, stat_tbl, group_var = "species")

ylim_gene <- get_ylim_for_metric("gene_pct", plot_df, sig_df)
ylim_cds  <- get_ylim_for_metric("cds_pct",  plot_df, sig_df)

# =========================================================
# 4. Publication-ready theme
# =========================================================
theme_pub <- theme_bw(base_size = 12.5) +
  theme(
    panel.grid.major.y = element_line(color = "grey88", linewidth = 0.35),
    panel.grid.major.x = element_blank(),
    panel.grid.minor = element_blank(),
    strip.background = element_rect(fill = "white", color = "black", linewidth = 0.8),
    strip.text = element_text(face = "bold", size = 11.5, color = "black"),
    axis.text.x = element_text(size = 10.5, color = "black"),
    axis.text.y = element_text(size = 10.5, color = "black"),
    axis.title.x = element_text(size = 12.5, face = "bold", color = "black"),
    axis.title.y = element_text(size = 12.5, face = "bold", color = "black"),
    plot.title = element_text(size = 14, face = "bold", hjust = 0.5, color = "black"),
    plot.subtitle = element_text(size = 11, hjust = 0.5, color = "black"),
    panel.border = element_rect(color = "black", fill = NA, linewidth = 0.8),
    axis.line = element_blank(),
    legend.position = "none",
    plot.margin = margin(8, 10, 8, 10)
  )

# =========================================================
# 5. Main plotting function
# =========================================================
make_main_plot <- function(metric_name, ylim_vec, show_title = TRUE) {
  dfm  <- plot_df %>% filter(metric == metric_name)
  sigm <- sig_df  %>% filter(metric == metric_name)

  p <- ggplot(dfm, aes(x = type, y = value)) +
    geom_violin(
      trim = TRUE,
      fill = violin_fill,
      color = violin_color,
      linewidth = line_width,
      scale = "width"
    ) +
    geom_boxplot(
      width = box_width,
      outlier.shape = NA,
      fill = box_fill,
      color = box_color,
      linewidth = 0.5
    ) +
    geom_signif(
      data = sigm,
      aes(
        xmin = xmin,
        xmax = xmax,
        annotations = signif,
        y_position = y_position
      ),
      inherit.aes = FALSE,
      manual = TRUE,
      tip_length = 0.012,
      textsize = 4.8,
      vjust = 0.25,
      size = 0.5
    ) +
    facet_grid(
      threshold ~ species,
      labeller = labeller(
        species = as_labeller(species_labels)
      )
    ) +
    scale_x_discrete(labels = type_labels) +
    coord_cartesian(ylim = ylim_vec, clip = "on") +
    labs(
      x = NULL,
      y = metric_labels[[metric_name]]
    ) +
    theme_pub

  if (show_title) {
    p <- p + labs(
      title = ifelse(
        metric_name == "cds_pct",
        "Constrained proportion in CDS",
        "Constrained proportion in gene"
      )
    )
  }

  p
}

# =========================================================
# 6. Create main figures
# =========================================================
p_main_gene <- make_main_plot("gene_pct", ylim_gene, show_title = TRUE)
p_main_cds  <- make_main_plot("cds_pct",  ylim_cds,  show_title = TRUE)

# combined
p_combined <- p_main_gene / p_main_cds + plot_layout(heights = c(1, 1))

# main export
ggsave(
  file.path(out_dir, "main_gene_pct_publication_ready.pdf"),
  p_main_gene, width = 10.5, height = 7.9
)
ggsave(
  file.path(out_dir, "main_gene_pct_publication_ready.png"),
  p_main_gene, width = 10.5, height = 7.9, dpi = 600
)

ggsave(
  file.path(out_dir, "main_cds_pct_publication_ready.pdf"),
  p_main_cds, width = 10.5, height = 7.9
)
ggsave(
  file.path(out_dir, "main_cds_pct_publication_ready.png"),
  p_main_cds, width = 10.5, height = 7.9, dpi = 600
)

ggsave(
  file.path(out_dir, "main_combined_publication_ready.pdf"),
  p_combined, width = 10.5, height = 13.8
)
ggsave(
  file.path(out_dir, "main_combined_publication_ready.png"),
  p_combined, width = 10.5, height = 13.8, dpi = 600
)

# =========================================================
# 7. Supplementary bamboo subgenome figure
# =========================================================
ped_df <- dat %>%
  filter(raw_species %in% c("pedC", "pedD")) %>%
  select(gene_id, raw_species, type, threshold, gene_pct, cds_pct) %>%
  pivot_longer(
    cols = c(gene_pct, cds_pct),
    names_to = "metric",
    values_to = "value"
  ) %>%
  mutate(
    threshold = factor(threshold, levels = threshold_levels),
    type = factor(type, levels = type_levels),
    raw_species = factor(raw_species, levels = c("pedC", "pedD")),
    metric = factor(metric, levels = c("gene_pct", "cds_pct"))
  )

ped_stat <- ped_df %>%
  group_by(raw_species, threshold, metric) %>%
  group_modify(~safe_wilcox(.x)) %>%
  ungroup() %>%
  mutate(
    p_adj = p.adjust(p_value, method = "BH"),
    signif = case_when(
      is.na(p_adj)  ~ "NA",
      p_adj < 0.001 ~ "***",
      p_adj < 0.01  ~ "**",
      p_adj < 0.05  ~ "*",
      TRUE          ~ "ns"
    )
  )

readr::write_tsv(
  ped_stat,
  file.path(out_dir, "Pol_vs_Veg_wilcox_statistics_ped_subgenome.tsv")
)

ped_sig <- make_sig_df(
  ped_df %>% rename(species = raw_species),
  ped_stat %>% rename(species = raw_species),
  group_var = "species"
) %>%
  rename(raw_species = species)

ylim_ped_gene <- get_ylim_for_metric("gene_pct", ped_df, ped_sig)
ylim_ped_cds  <- get_ylim_for_metric("cds_pct",  ped_df, ped_sig)

make_ped_plot <- function(metric_name, ylim_vec, show_title = TRUE) {
  dfm  <- ped_df %>% filter(metric == metric_name)
  sigm <- ped_sig %>% filter(metric == metric_name)

  p <- ggplot(dfm, aes(x = type, y = value)) +
    geom_violin(
      trim = TRUE,
      fill = violin_fill,
      color = violin_color,
      linewidth = line_width,
      scale = "width"
    ) +
    geom_boxplot(
      width = box_width,
      outlier.shape = NA,
      fill = box_fill,
      color = box_color,
      linewidth = 0.5
    ) +
    geom_signif(
      data = sigm,
      aes(
        xmin = xmin,
        xmax = xmax,
        annotations = signif,
        y_position = y_position
      ),
      inherit.aes = FALSE,
      manual = TRUE,
      tip_length = 0.012,
      textsize = 4.8,
      vjust = 0.25,
      size = 0.5
    ) +
    facet_grid(
      threshold ~ raw_species,
      labeller = labeller(raw_species = as_labeller(subgenome_labels))
    ) +
    scale_x_discrete(labels = type_labels) +
    coord_cartesian(ylim = ylim_vec, clip = "on") +
    labs(
      x = NULL,
      y = metric_labels[[metric_name]]
    ) +
    theme_pub

  if (show_title) {
    p <- p + labs(
      title = ifelse(
        metric_name == "cds_pct",
        "Bamboo subgenomes: constrained proportion in CDS",
        "Bamboo subgenomes: constrained proportion in gene"
      )
    )
  }

  p
}

p_ped_gene <- make_ped_plot("gene_pct", ylim_ped_gene, show_title = TRUE)
p_ped_cds  <- make_ped_plot("cds_pct",  ylim_ped_cds,  show_title = TRUE)

ggsave(
  file.path(out_dir, "ped_subgenome_gene_pct_publication_ready.pdf"),
  p_ped_gene, width = 7.5, height = 7.8
)
ggsave(
  file.path(out_dir, "ped_subgenome_gene_pct_publication_ready.png"),
  p_ped_gene, width = 7.5, height = 7.8, dpi = 600
)

ggsave(
  file.path(out_dir, "ped_subgenome_cds_pct_publication_ready.pdf"),
  p_ped_cds, width = 7.5, height = 7.8
)
ggsave(
  file.path(out_dir, "ped_subgenome_cds_pct_publication_ready.png"),
  p_ped_cds, width = 7.5, height = 7.8, dpi = 600
)

# =========================================================
# 8. Optional journal-style title-free versions
#    for multi-panel assembly
# =========================================================
p_main_cds_notitle <- make_main_plot("cds_pct", ylim_cds, show_title = FALSE)
p_main_gene_notitle <- make_main_plot("gene_pct", ylim_gene, show_title = FALSE)

ggsave(
  file.path(out_dir, "main_cds_pct_notitle_publication_ready.pdf"),
  p_main_cds_notitle, width = 10.5, height = 7.7
)
ggsave(
  file.path(out_dir, "main_gene_pct_notitle_publication_ready.pdf"),
  p_main_gene_notitle, width = 10.5, height = 7.7
)

message("[INFO] Done.")
message("[INFO] Output directory: ", out_dir)