#!/usr/bin/env Rscript

suppressPackageStartupMessages({
  library(tidyverse)
  library(patchwork)
})

# =========================================================
# 0. Config
# =========================================================
input_dir <- "."
out_dir   <- "plots_flower_veg_snp_deleterious_publication_ready_fix"
dir.create(out_dir, showWarnings = FALSE, recursive = TRUE)

threshold_levels <- c("gt2", "gt4", "gt6")
type_levels      <- c("Pol", "Veg")
species_levels   <- c("Atau", "ped", "Zmay")

type_labels <- c(
  "Pol" = "Flowering",
  "Veg" = "Vegetative"
)

species_labels <- c(
  "Atau" = "A. tauschii",
  "ped"  = "P. edulis",
  "Zmay" = "Z. mays"
)

subgenome_labels <- c(
  "pedC" = "pedC",
  "pedD" = "pedD"
)

metric_labels <- c(
  "cds_snp_ratio"           = "CDS SNP variation ratio",
  "cds_del_ratio_snp_only"  = "Deleterious SNP proportion in CDS SNPs",
  "cds_del_ratio_all_sites" = "Deleterious SNP proportion in CDS SNPs"
)

metric_titles <- c(
  "cds_snp_ratio"           = "CDS SNP variation ratio",
  "cds_del_ratio_snp_only"  = "Deleterious SNP proportion in CDS SNPs",
  "cds_del_ratio_all_sites" = "Deleterious SNP proportion in CDS SNPs"
)

metric_subtitles <- c(
  "cds_snp_ratio"           = NA,
  "cds_del_ratio_snp_only"  = "Only genes with at least one CDS SNP are included",
  "cds_del_ratio_all_sites" = "All genes are included; genes with zero CDS SNP contribute zero values"
)

violin_fill   <- "grey88"
violin_color  <- "grey45"
box_fill      <- "white"
box_color     <- "black"
line_width    <- 0.45
box_width     <- 0.20

# =========================================================
# 1. Helpers
# =========================================================
parse_filename <- function(x) {
  b <- basename(x)
  m <- stringr::str_match(
    b,
    "^(Atau|pedC|pedD|Zmay|zmay)_(Pol|Veg)_(gt[0-9]+)_gene_deleterious\\.tsv$"
  )
  if (any(is.na(m))) return(NULL)

  tibble(
    file = x,
    raw_species = m[, 2],
    type = m[, 3],
    threshold = m[, 4]
  )
}

safe_wilcox <- function(df) {
  x <- df$value[df$type == "Pol"]
  y <- df$value[df$type == "Veg"]

  if (length(x) < 2 || length(y) < 2) {
    return(tibble(
      n_pol = length(x),
      n_veg = length(y),
      median_pol = median(x, na.rm = TRUE),
      median_veg = median(y, na.rm = TRUE),
      mean_pol = mean(x, na.rm = TRUE),
      mean_veg = mean(y, na.rm = TRUE),
      delta_median = median(x, na.rm = TRUE) - median(y, na.rm = TRUE),
      p_value = NA_real_
    ))
  }

  wt <- suppressWarnings(wilcox.test(x, y, paired = FALSE, exact = FALSE))

  tibble(
    n_pol = length(x),
    n_veg = length(y),
    median_pol = median(x, na.rm = TRUE),
    median_veg = median(y, na.rm = TRUE),
    mean_pol = mean(x, na.rm = TRUE),
    mean_veg = mean(y, na.rm = TRUE),
    delta_median = median(x, na.rm = TRUE) - median(y, na.rm = TRUE),
    p_value = wt$p.value
  )
}

p_to_signif <- function(p) {
  case_when(
    is.na(p)   ~ "NA",
    p < 0.001  ~ "***",
    p < 0.01   ~ "**",
    p < 0.05   ~ "*",
    TRUE       ~ "ns"
  )
}

make_sig_df_main <- function(df_plot, df_stat) {
  y_tbl <- df_plot %>%
    group_by(species, threshold, metric) %>%
    summarise(
      y_max = max(value, na.rm = TRUE),
      y_min = min(value, na.rm = TRUE),
      .groups = "drop"
    ) %>%
    mutate(
      span = pmax(y_max - y_min, 1e-6),
      x_left = 1,
      x_right = 2,
      y = y_max + 0.06 * span + 0.02 * y_max + 0.005,
      tip = pmax(0.01 * y_max, 0.003),
      label_y = y + pmax(0.012 * y_max, 0.006)
    )

  left_join(df_stat, y_tbl, by = c("species", "threshold", "metric"))
}

make_sig_df_ped <- function(df_plot, df_stat) {
  y_tbl <- df_plot %>%
    group_by(raw_species, threshold, metric) %>%
    summarise(
      y_max = max(value, na.rm = TRUE),
      y_min = min(value, na.rm = TRUE),
      .groups = "drop"
    ) %>%
    mutate(
      span = pmax(y_max - y_min, 1e-6),
      x_left = 1,
      x_right = 2,
      y = y_max + 0.06 * span + 0.02 * y_max + 0.005,
      tip = pmax(0.01 * y_max, 0.003),
      label_y = y + pmax(0.012 * y_max, 0.006)
    )

  left_join(df_stat, y_tbl, by = c("raw_species", "threshold", "metric"))
}

get_ylim_for_metric <- function(metric_name, df_plot, df_sig, group_var = c("species", "raw_species")) {
  ymax_data <- df_plot %>%
    filter(metric == metric_name) %>%
    summarise(v = max(value, na.rm = TRUE)) %>%
    pull(v)

  ymax_sig <- df_sig %>%
    filter(metric == metric_name) %>%
    summarise(v = max(label_y, na.rm = TRUE)) %>%
    pull(v)

  upper <- max(ymax_data, ymax_sig, na.rm = TRUE)

  if (metric_name == "cds_snp_ratio") {
    upper <- upper * 1.05 + 0.002
  } else {
    upper <- upper * 1.04 + 0.02
  }

  c(0, upper)
}

theme_pub <- theme_bw(base_size = 12.5) +
  theme(
    panel.grid.major.y = element_line(color = "grey88", linewidth = 0.35),
    panel.grid.major.x = element_blank(),
    panel.grid.minor = element_blank(),
    strip.background = element_rect(fill = "white", color = "black", linewidth = 0.8),
    strip.text = element_text(face = "bold", size = 11.5, color = "black"),
    axis.text.x = element_text(size = 10.5, color = "black"),
    axis.text.y = element_text(size = 10.5, color = "black"),
    axis.title.x = element_text(size = 12.5, face = "bold", color = "black"),
    axis.title.y = element_text(size = 12.5, face = "bold", color = "black"),
    plot.title = element_text(size = 14, face = "bold", hjust = 0.5, color = "black"),
    plot.subtitle = element_text(size = 11, hjust = 0.5, color = "black"),
    panel.border = element_rect(color = "black", fill = NA, linewidth = 0.8),
    axis.line = element_blank(),
    legend.position = "none",
    plot.margin = margin(8, 10, 8, 10)
  )

add_brackets <- function(p, sigm, facet_mode = c("main", "ped")) {
  facet_mode <- match.arg(facet_mode)

  if (nrow(sigm) == 0) return(p)

  if (facet_mode == "main") {
    p +
      geom_segment(
        data = sigm,
        aes(x = x_left, xend = x_right, y = y, yend = y),
        inherit.aes = FALSE,
        linewidth = 0.5
      ) +
      geom_segment(
        data = sigm,
        aes(x = x_left, xend = x_left, y = y, yend = y - tip),
        inherit.aes = FALSE,
        linewidth = 0.5
      ) +
      geom_segment(
        data = sigm,
        aes(x = x_right, xend = x_right, y = y, yend = y - tip),
        inherit.aes = FALSE,
        linewidth = 0.5
      ) +
      geom_text(
        data = sigm,
        aes(x = 1.5, y = label_y, label = signif),
        inherit.aes = FALSE,
        size = 4.8 / 2.845,
        fontface = "bold"
      )
  } else {
    p +
      geom_segment(
        data = sigm,
        aes(x = x_left, xend = x_right, y = y, yend = y),
        inherit.aes = FALSE,
        linewidth = 0.5
      ) +
      geom_segment(
        data = sigm,
        aes(x = x_left, xend = x_left, y = y, yend = y - tip),
        inherit.aes = FALSE,
        linewidth = 0.5
      ) +
      geom_segment(
        data = sigm,
        aes(x = x_right, xend = x_right, y = y, yend = y - tip),
        inherit.aes = FALSE,
        linewidth = 0.5
      ) +
      geom_text(
        data = sigm,
        aes(x = 1.5, y = label_y, label = signif),
        inherit.aes = FALSE,
        size = 4.8 / 2.845,
        fontface = "bold"
      )
  }
}

# =========================================================
# 2. Read files
# =========================================================
files <- list.files(
  path = input_dir,
  pattern = "_gene_deleterious\\.tsv$",
  full.names = TRUE
)

if (length(files) == 0) {
  stop("No *_gene_deleterious.tsv files found in current directory.")
}

meta <- bind_rows(lapply(files, parse_filename))

if (nrow(meta) == 0) {
  stop("No files matched expected pattern: Species_Type_Threshold_gene_deleterious.tsv")
}

meta <- meta %>%
  filter(threshold %in% threshold_levels)

if (nrow(meta) == 0) {
  stop("No gt2 / gt4 / gt6 files found.")
}

read_one <- function(file, raw_species, type, threshold) {
  df <- readr::read_tsv(file, show_col_types = FALSE)

  raw_species_std <- case_when(
    raw_species %in% c("Zmay", "zmay") ~ "Zmay",
    TRUE ~ raw_species
  )

  if ("cds_deleterious_ratio" %in% colnames(df)) {
    df2 <- df %>%
      transmute(
        gene_id = gene_id,
        cds_len = cds_len,
        cds_snp_total = cds_snp_total,
        cds_snp_ratio = cds_snp_ratio,
        cds_deleterious_snp = cds_deleterious_snp,
        cds_del_ratio = cds_deleterious_ratio
      )
  } else if ("deleterious_ratio" %in% colnames(df)) {
    df2 <- df %>%
      transmute(
        gene_id = gene_id,
        cds_len = cds_len,
        cds_snp_total = cds_snp_total,
        cds_snp_ratio = cds_snp_ratio,
        cds_deleterious_snp = cds_deleterious_snp,
        cds_del_ratio = deleterious_ratio
      )
  } else {
    stop("Cannot find deleterious ratio column in: ", basename(file))
  }

  df2 %>%
    mutate(
      raw_species = raw_species_std,
      type = type,
      threshold = threshold,
      subgenome = case_when(
        raw_species_std == "pedC" ~ "pedC",
        raw_species_std == "pedD" ~ "pedD",
        TRUE ~ NA_character_
      ),
      species = case_when(
        raw_species_std %in% c("pedC", "pedD") ~ "ped",
        TRUE ~ raw_species_std
      )
    )
}

dat <- purrr::pmap_dfr(meta, read_one) %>%
  mutate(
    threshold = factor(threshold, levels = threshold_levels),
    type = factor(type, levels = type_levels),
    species = factor(species, levels = species_levels),
    raw_species = factor(raw_species, levels = c("Atau", "pedC", "pedD", "Zmay"))
  )

# =========================================================
# 3. Build plotting datasets
# =========================================================
plot_snp_df <- dat %>%
  transmute(
    gene_id, raw_species, species, subgenome, type, threshold,
    metric = "cds_snp_ratio",
    value = cds_snp_ratio,
    cds_snp_total = cds_snp_total
  )

plot_del_snp_only_df <- dat %>%
  filter(cds_snp_total > 0) %>%
  transmute(
    gene_id, raw_species, species, subgenome, type, threshold,
    metric = "cds_del_ratio_snp_only",
    value = cds_del_ratio,
    cds_snp_total = cds_snp_total
  )

plot_del_all_sites_df <- dat %>%
  transmute(
    gene_id, raw_species, species, subgenome, type, threshold,
    metric = "cds_del_ratio_all_sites",
    value = cds_del_ratio,
    cds_snp_total = cds_snp_total
  )

plot_df <- bind_rows(
  plot_snp_df,
  plot_del_snp_only_df,
  plot_del_all_sites_df
) %>%
  mutate(
    metric = factor(metric, levels = c("cds_snp_ratio", "cds_del_ratio_snp_only", "cds_del_ratio_all_sites"))
  )

# =========================================================
# 4. Main stats
# =========================================================
stat_tbl <- plot_df %>%
  group_by(species, threshold, metric) %>%
  group_modify(~safe_wilcox(.x)) %>%
  ungroup() %>%
  mutate(
    p_adj = p.adjust(p_value, method = "BH"),
    signif = p_to_signif(p_adj)
  )

readr::write_tsv(
  stat_tbl,
  file.path(out_dir, "Pol_vs_Veg_wilcox_statistics_main.tsv")
)

del_counts_tbl <- bind_rows(
  plot_del_snp_only_df %>%
    group_by(species, threshold, type) %>%
    summarise(n_gene = n(), .groups = "drop") %>%
    mutate(dataset = "cds_del_ratio_snp_only"),
  plot_del_all_sites_df %>%
    group_by(species, threshold, type) %>%
    summarise(n_gene = n(), .groups = "drop") %>%
    mutate(dataset = "cds_del_ratio_all_sites")
)

readr::write_tsv(
  del_counts_tbl,
  file.path(out_dir, "cds_deleterious_ratio_gene_counts.tsv")
)

sig_df <- make_sig_df_main(plot_df, stat_tbl)

ylim_snp          <- get_ylim_for_metric("cds_snp_ratio", plot_df, sig_df)
ylim_del_snp_only <- get_ylim_for_metric("cds_del_ratio_snp_only", plot_df, sig_df)
ylim_del_all      <- get_ylim_for_metric("cds_del_ratio_all_sites", plot_df, sig_df)

# =========================================================
# 5. Main plotting function
# =========================================================
make_main_plot <- function(metric_name, ylim_vec, show_title = TRUE) {
  dfm  <- plot_df %>% filter(metric == metric_name)
  sigm <- sig_df  %>% filter(metric == metric_name)

  p <- ggplot(dfm, aes(x = type, y = value)) +
    geom_violin(
      trim = TRUE,
      fill = violin_fill,
      color = violin_color,
      linewidth = line_width,
      scale = "width"
    ) +
    geom_boxplot(
      width = box_width,
      outlier.shape = NA,
      fill = box_fill,
      color = box_color,
      linewidth = 0.5
    ) +
    facet_grid(
      threshold ~ species,
      labeller = labeller(species = as_labeller(species_labels))
    ) +
    scale_x_discrete(labels = type_labels) +
    coord_cartesian(ylim = ylim_vec, clip = "on") +
    labs(
      x = NULL,
      y = metric_labels[[metric_name]]
    ) +
    theme_pub

  p <- add_brackets(p, sigm, facet_mode = "main")

  if (show_title) {
    p <- p + labs(
      title = metric_titles[[metric_name]],
      subtitle = metric_subtitles[[metric_name]]
    )
  }

  p
}

# =========================================================
# 6. Main figures
# =========================================================
p_main_snp          <- make_main_plot("cds_snp_ratio", ylim_snp, TRUE)
p_main_del_snp_only <- make_main_plot("cds_del_ratio_snp_only", ylim_del_snp_only, TRUE)
p_main_del_all      <- make_main_plot("cds_del_ratio_all_sites", ylim_del_all, TRUE)

p_combined_all <- p_main_snp / p_main_del_snp_only / p_main_del_all + plot_layout(heights = c(1, 1, 1))

ggsave(file.path(out_dir, "main_cds_snp_ratio_publication_ready.pdf"), p_main_snp, width = 10.5, height = 7.9)
ggsave(file.path(out_dir, "main_cds_snp_ratio_publication_ready.png"), p_main_snp, width = 10.5, height = 7.9, dpi = 600)

ggsave(file.path(out_dir, "main_cds_deleterious_ratio_snp_only_publication_ready.pdf"), p_main_del_snp_only, width = 10.5, height = 7.9)
ggsave(file.path(out_dir, "main_cds_deleterious_ratio_snp_only_publication_ready.png"), p_main_del_snp_only, width = 10.5, height = 7.9, dpi = 600)

ggsave(file.path(out_dir, "main_cds_deleterious_ratio_all_sites_publication_ready.pdf"), p_main_del_all, width = 10.5, height = 7.9)
ggsave(file.path(out_dir, "main_cds_deleterious_ratio_all_sites_publication_ready.png"), p_main_del_all, width = 10.5, height = 7.9, dpi = 600)

ggsave(file.path(out_dir, "main_combined_snp_deleterious_three_panels_publication_ready.pdf"), p_combined_all, width = 10.5, height = 20.4)
ggsave(file.path(out_dir, "main_combined_snp_deleterious_three_panels_publication_ready.png"), p_combined_all, width = 10.5, height = 20.4, dpi = 600)

# =========================================================
# 7. ped subgenome
# =========================================================
ped_plot_df <- plot_df %>%
  filter(raw_species %in% c("pedC", "pedD"))

ped_stat <- ped_plot_df %>%
  group_by(raw_species, threshold, metric) %>%
  group_modify(~safe_wilcox(.x)) %>%
  ungroup() %>%
  mutate(
    p_adj = p.adjust(p_value, method = "BH"),
    signif = p_to_signif(p_adj)
  )

readr::write_tsv(
  ped_stat,
  file.path(out_dir, "Pol_vs_Veg_wilcox_statistics_ped_subgenome.tsv")
)

ped_sig <- make_sig_df_ped(ped_plot_df, ped_stat)

ylim_ped_snp          <- get_ylim_for_metric("cds_snp_ratio", ped_plot_df, ped_sig)
ylim_ped_del_snp_only <- get_ylim_for_metric("cds_del_ratio_snp_only", ped_plot_df, ped_sig)
ylim_ped_del_all      <- get_ylim_for_metric("cds_del_ratio_all_sites", ped_plot_df, ped_sig)

make_ped_plot <- function(metric_name, ylim_vec, show_title = TRUE) {
  dfm  <- ped_plot_df %>% filter(metric == metric_name)
  sigm <- ped_sig      %>% filter(metric == metric_name)

  p <- ggplot(dfm, aes(x = type, y = value)) +
    geom_violin(
      trim = TRUE,
      fill = violin_fill,
      color = violin_color,
      linewidth = line_width,
      scale = "width"
    ) +
    geom_boxplot(
      width = box_width,
      outlier.shape = NA,
      fill = box_fill,
      color = box_color,
      linewidth = 0.5
    ) +
    facet_grid(
      threshold ~ raw_species,
      labeller = labeller(raw_species = as_labeller(subgenome_labels))
    ) +
    scale_x_discrete(labels = type_labels) +
    coord_cartesian(ylim = ylim_vec, clip = "on") +
    labs(
      x = NULL,
      y = metric_labels[[metric_name]]
    ) +
    theme_pub

  p <- add_brackets(p, sigm, facet_mode = "ped")

  if (show_title) {
    p <- p + labs(
      title = paste0("Bamboo subgenomes: ", metric_titles[[metric_name]]),
      subtitle = metric_subtitles[[metric_name]]
    )
  }

  p
}

p_ped_snp          <- make_ped_plot("cds_snp_ratio", ylim_ped_snp, TRUE)
p_ped_del_snp_only <- make_ped_plot("cds_del_ratio_snp_only", ylim_ped_del_snp_only, TRUE)
p_ped_del_all      <- make_ped_plot("cds_del_ratio_all_sites", ylim_ped_del_all, TRUE)

ggsave(file.path(out_dir, "ped_subgenome_cds_snp_ratio_publication_ready.pdf"), p_ped_snp, width = 7.5, height = 7.8)
ggsave(file.path(out_dir, "ped_subgenome_cds_snp_ratio_publication_ready.png"), p_ped_snp, width = 7.5, height = 7.8, dpi = 600)

ggsave(file.path(out_dir, "ped_subgenome_cds_deleterious_ratio_snp_only_publication_ready.pdf"), p_ped_del_snp_only, width = 7.5, height = 7.8)
ggsave(file.path(out_dir, "ped_subgenome_cds_deleterious_ratio_snp_only_publication_ready.png"), p_ped_del_snp_only, width = 7.5, height = 7.8, dpi = 600)

ggsave(file.path(out_dir, "ped_subgenome_cds_deleterious_ratio_all_sites_publication_ready.pdf"), p_ped_del_all, width = 7.5, height = 7.8)
ggsave(file.path(out_dir, "ped_subgenome_cds_deleterious_ratio_all_sites_publication_ready.png"), p_ped_del_all, width = 7.5, height = 7.8, dpi = 600)

message("[INFO] Done.")
message("[INFO] Output directory: ", out_dir)