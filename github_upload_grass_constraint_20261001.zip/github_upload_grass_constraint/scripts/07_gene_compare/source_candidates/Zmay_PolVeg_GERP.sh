#!/usr/bin/env bash
#SBATCH --job-name=Zmay_gerp_PolVeg
#SBATCH --partition=parallel
#SBATCH --nodes=1
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=10
#SBATCH --array=1-4
#SBATCH --output=logs/Zmay_gerp_PolVeg_%A_%a.out
#SBATCH --error=logs/Zmay_gerp_PolVeg_%A_%a.err

set -euo pipefail
module load bedtools 2>/dev/null || true

############################################################
# 0. 输入文件配置
############################################################
POL_LIST="Zmay_Pol.list"
VEG_LIST="Zmay_Veg.list"

BASE_GERP_DIR="/gpfs/hpc/home/kib_unit/lidezhu/liuliangmin/2.msa/Zmay/Zmay_v5_results/GERP_output/02.constrain_stat/gerp_conservation_results"

GENE_BED="genes.merged.bed"
CDS_BED_DIR="CDS_gene_merged"   # 目录，内含多个 *.bed

OUT_ROOT="Zmay_PolVeg_CDS_GERP_stats"
mkdir -p logs "${OUT_ROOT}"

############################################################
# 1. array 参数（gt0 / gt2 / gt4 / gt6）
############################################################
classes=("gt0" "gt2" "gt4" "gt6")
idx=$((SLURM_ARRAY_TASK_ID - 1))
if [[ $idx -lt 0 || $idx -ge ${#classes[@]} ]]; then
  echo "[ERROR] Bad SLURM_ARRAY_TASK_ID=${SLURM_ARRAY_TASK_ID}" >&2
  exit 1
fi
Class="${classes[$idx]}"

echo "[INFO] Processing threshold: ${Class}"

############################################################
# 2. 检查输入文件
############################################################
GENE_GERP="${BASE_GERP_DIR}/${Class}/bed_files/genes_conserved_sites.bed"
CDS_GERP="${BASE_GERP_DIR}/${Class}/bed_files/CDS_conserved_sites.bed"

[[ -s "${POL_LIST}" ]] || { echo "[ERROR] Missing ${POL_LIST}" >&2; exit 1; }
[[ -s "${VEG_LIST}" ]] || { echo "[ERROR] Missing ${VEG_LIST}" >&2; exit 1; }
[[ -s "${GENE_BED}" ]] || { echo "[ERROR] Missing ${GENE_BED}" >&2; exit 1; }
[[ -s "${GENE_GERP}" ]] || { echo "[ERROR] Missing ${GENE_GERP}" >&2; exit 1; }
[[ -s "${CDS_GERP}" ]] || { echo "[ERROR] Missing ${CDS_GERP}" >&2; exit 1; }

if ! ls "${CDS_BED_DIR}"/*.bed >/dev/null 2>&1; then
  echo "[ERROR] No *.bed files found in ${CDS_BED_DIR}" >&2
  exit 1
fi

############################################################
# 3. 基础 bed 规范化（每个阈值做一次）
############################################################
WORK_BASE="${OUT_ROOT}/_shared_${Class}"
mkdir -p "${WORK_BASE}"

GENE4="${WORK_BASE}/genes.4col.bed"
CDS4="${WORK_BASE}/CDS.4col.bed"

# genes.merged.bed: 取前4列 chr start end gene_id
awk 'BEGIN{OFS="\t"} NF>=4 {print $1,$2,$3,$4}' "${GENE_BED}" \
  | sort -k1,1 -k2,2n -k3,3n -k4,4 \
  > "${GENE4}"

# 合并 CDS bed，取前4列
cat "${CDS_BED_DIR}"/*.bed \
  | awk 'BEGIN{OFS="\t"} NF>=4 {print $1,$2,$3,$4}' \
  | sort -k1,1 -k2,2n -k3,3n -k4,4 \
  > "${CDS4}"

############################################################
# 4. 函数：标准化 gene list
############################################################
prepare_gene_list() {
  local in_list="$1"
  local out_list="$2"

  awk 'NF>0 {
    g=$1
    sub(/\r$/,"",g)
    if(g!="") print g
  }' "${in_list}" \
    | sed '/^[[:space:]]*$/d' \
    | sort -u \
    > "${out_list}"
}

############################################################
# 5. 函数：计算单个基因集
############################################################
run_one_set() {
  local SET_NAME="$1"
  local LIST_SOURCE="$2"

  local SET_ROOT="${OUT_ROOT}/${SET_NAME}/${Class}"
  local BED_DIR="${SET_ROOT}/bed_files"
  local STAT_DIR="${SET_ROOT}/stats"
  mkdir -p "${BED_DIR}" "${STAT_DIR}"

  local TARGET_GENE_LIST="${SET_ROOT}/target_gene_ids.txt"

  echo "[INFO] ===== Set: ${SET_NAME} | Threshold: ${Class} ====="

  ##########################################################
  # 5.1 生成 target gene list
  ##########################################################
  prepare_gene_list "${LIST_SOURCE}" "${TARGET_GENE_LIST}"

  if [[ ! -s "${TARGET_GENE_LIST}" ]]; then
    echo "[WARN] ${SET_NAME}: target gene list is empty, skipping." >&2
    return 0
  fi

  echo "[INFO] ${SET_NAME}: target genes = $(wc -l < "${TARGET_GENE_LIST}")"

  ##########################################################
  # 5.2 过滤目标 gene / CDS bed
  ##########################################################
  local TARGET_GENE_BED="${BED_DIR}/target_genes.bed"
  local TARGET_CDS_BED="${BED_DIR}/target_CDS.bed"

  awk 'NR==FNR{a[$1]=1;next} ($4 in a)' \
    "${TARGET_GENE_LIST}" "${GENE4}" \
    > "${TARGET_GENE_BED}"

  awk 'NR==FNR{a[$1]=1;next} ($4 in a)' \
    "${TARGET_GENE_LIST}" "${CDS4}" \
    > "${TARGET_CDS_BED}"

  echo "[INFO] ${SET_NAME}: target_genes.bed lines = $(wc -l < "${TARGET_GENE_BED}")"
  echo "[INFO] ${SET_NAME}: target_CDS.bed   lines = $(wc -l < "${TARGET_CDS_BED}")"

  ##########################################################
  # 5.3 GERP 位点 ∩ target gene / CDS
  ##########################################################
  local GENE_CONS="${BED_DIR}/gene_conserved_sites.bed"
  local CDS_CONS="${BED_DIR}/CDS_conserved_sites.bed"

  if [[ -s "${TARGET_GENE_BED}" ]]; then
    bedtools intersect -wa -wb \
      -a "${GENE_GERP}" \
      -b "${TARGET_GENE_BED}" \
      > "${GENE_CONS}"
  else
    : > "${GENE_CONS}"
  fi

  if [[ -s "${TARGET_CDS_BED}" ]]; then
    bedtools intersect -wa -wb \
      -a "${CDS_GERP}" \
      -b "${TARGET_CDS_BED}" \
      > "${CDS_CONS}"
  else
    : > "${CDS_CONS}"
  fi

  ##########################################################
  # 5.4 gene length
  ##########################################################
  if [[ -s "${TARGET_GENE_BED}" ]]; then
    awk 'BEGIN{OFS="\t"} {print $4, $3-$2}' "${TARGET_GENE_BED}" \
      | sort -k1,1 \
      > "${STAT_DIR}/gene_length.tsv"
  else
    : > "${STAT_DIR}/gene_length.tsv"
  fi

  ##########################################################
  # 5.5 CDS union length（按 gene）
  ##########################################################
  local TARGET_CDS_SORTED="${STAT_DIR}/target_CDS.byGene.sorted.bed"

  if [[ -s "${TARGET_CDS_BED}" ]]; then
    sort -k4,4 -k1,1 -k2,2n -k3,3n "${TARGET_CDS_BED}" > "${TARGET_CDS_SORTED}"

    awk '
    BEGIN{OFS="\t"}
    {
      g=$4; chr=$1; s=$2; e=$3
      if(NR==1){
        cg=g; cchr=chr; cs=s; ce=e; sum=0
        next
      }
      if(g!=cg || chr!=cchr){
        sum += (ce - cs)
        print cg, sum
        cg=g; cchr=chr; cs=s; ce=e; sum=0
        next
      }
      if(s <= ce){
        if(e > ce) ce=e
      } else {
        sum += (ce - cs)
        cs=s; ce=e
      }
    }
    END{
      if(NR>0){
        sum += (ce - cs)
        print cg, sum
      }
    }' "${TARGET_CDS_SORTED}" \
    | sort -k1,1 \
    > "${STAT_DIR}/cds_length.tsv"
  else
    : > "${STAT_DIR}/cds_length.tsv"
  fi

  ##########################################################
  # 5.6 gene / CDS 保守位点数（按 1bp 位点 + gene_id 去重）
  ##########################################################
  if [[ -s "${GENE_CONS}" ]]; then
    awk 'BEGIN{OFS="\t"}{
      gid=$NF
      key=$1"\t"$2"\t"$3"\t"gid
      if(!seen[key]++) c[gid]++
    }
    END{
      for(g in c) print g, c[g]
    }' "${GENE_CONS}" \
    | sort -k1,1 \
    > "${STAT_DIR}/gene_site_count.tsv"
  else
    : > "${STAT_DIR}/gene_site_count.tsv"
  fi

  if [[ -s "${CDS_CONS}" ]]; then
    awk 'BEGIN{OFS="\t"}{
      gid=$NF
      key=$1"\t"$2"\t"$3"\t"gid
      if(!seen[key]++) c[gid]++
    }
    END{
      for(g in c) print g, c[g]
    }' "${CDS_CONS}" \
    | sort -k1,1 \
    > "${STAT_DIR}/cds_site_count.tsv"
  else
    : > "${STAT_DIR}/cds_site_count.tsv"
  fi

  ##########################################################
  # 5.7 合并最终 per-gene 统计
  ##########################################################
  join -t $'\t' -a 1 -e 0 -o 1.1,1.2,2.2 \
    "${STAT_DIR}/gene_length.tsv" "${STAT_DIR}/cds_length.tsv" \
    > "${STAT_DIR}/tmp_lengths.tsv"

  join -t $'\t' -a 1 -e 0 -o 1.1,1.2,2.2 \
    "${STAT_DIR}/gene_site_count.tsv" "${STAT_DIR}/cds_site_count.tsv" \
    > "${STAT_DIR}/tmp_sites.tsv"

  join -t $'\t' -a 1 -e 0 \
    "${STAT_DIR}/tmp_lengths.tsv" "${STAT_DIR}/tmp_sites.tsv" \
  | awk 'BEGIN{
      OFS="\t";
      print "gene_id","gene_len","cds_len","gene_sites","gene_pct","cds_sites","cds_pct"
    }
    {
      gl=$2+0
      cl=$3+0
      gs=$4+0
      cs=$5+0
      gp=(gl>0)?gs/gl*100:0
      cp=(cl>0)?cs/cl*100:0
      printf "%s\t%d\t%d\t%d\t%.6f\t%d\t%.6f\n",$1,gl,cl,gs,gp,cs,cp
    }' \
    > "${SET_ROOT}/per_gene_stats.tsv"

  rm -f \
    "${STAT_DIR}/tmp_lengths.tsv" \
    "${STAT_DIR}/tmp_sites.tsv" \
    "${TARGET_CDS_SORTED}"

  echo "[INFO] ${SET_NAME}: finished -> ${SET_ROOT}/per_gene_stats.tsv"
}

############################################################
# 6. 运行两个基因集
############################################################
run_one_set "Pol" "${POL_LIST}"
run_one_set "Veg" "${VEG_LIST}"

echo "[INFO] All done for threshold ${Class}"