#!/usr/bin/env Rscript

## =========================================================
## Quasibinomial GLM of CDS constraint
## Core genes (SG-based pairing, FIXED gene_id mapping)
## =========================================================

suppressPackageStartupMessages({
  library(dplyr)
  library(readr)
  library(tidyr)
  library(broom)
})

## =====================
## 1. Parameters
## =====================
threshold <- "gt2"
pan_file  <- "core_5sp_1to1.SG.pan"

## =====================
## 2. Read pan file
## =====================
pan <- read_tsv(
  pan_file,
  col_names = c(
    "SG", "nsp", "ngene", "flag",
    "Atau", "Osat", "pedC", "pedD", "Zmay"
  ),
  show_col_types = FALSE
)

## =====================
## 3. Read per-gene stats
## =====================
read_stats <- function(path, species_tag) {
  read_tsv(path, show_col_types = FALSE) %>%
    select(gene_id, cds_len, cds_sites) %>%
    mutate(species = species_tag)
}

stats <- bind_rows(
  read_stats(
    paste0(
      "2.1.ped/ped_target_gene_CDS_GERP_stats/gerp_", threshold,
      "/pedC/per_gene_stats.tsv"
    ),
    "pedC"
  ),
  read_stats(
    paste0(
      "2.1.ped/ped_target_gene_CDS_GERP_stats/gerp_", threshold,
      "/pedD/per_gene_stats.tsv"
    ),
    "pedD"
  ),
  read_stats(
    paste0(
      "2.2.Zmay/Zmay_target_gene_CDS_GERP_stats/",
      threshold, "/per_gene_stats.tsv"
    ),
    "Zmay"
  ),
  read_stats(
    paste0(
      "2.3.Atau/target_gene_CDS_GERP_stats/",
      threshold, "/per_gene_stats.tsv"
    ),
    "Atau"
  )
)

## =====================
## 4. Map genes to SG (STRIP PREFIX)
## =====================
map_long <- pan %>%
  select(SG, Atau, pedC, pedD, Zmay) %>%
  pivot_longer(
    cols = -SG,
    names_to  = "species",
    values_to = "gene_id_raw"
  ) %>%
  mutate(
    gene_id = sub("^[^_]+_", "", gene_id_raw)  # <<< 核心修复
  ) %>%
  select(SG, species, gene_id)

## =====================
## 5. Join stats
## =====================
df <- map_long %>%
  left_join(stats, by = c("gene_id", "species")) %>%
  filter(!is.na(cds_len), cds_len > 0)

cat("Joined rows:", nrow(df), "\n")

## =====================
## 6. Merge pedC + pedD
## =====================
df_glm <- df %>%
  mutate(
    species2 = case_when(
      species %in% c("pedC", "pedD") ~ "P.edulis",
      species == "Atau"              ~ "A.tauschii",
      species == "Zmay"              ~ "Z.mays"
    )
  ) %>%
  group_by(SG, species2) %>%
  summarise(
    cds_len   = sum(cds_len),
    cds_sites = sum(cds_sites),
    .groups = "drop"
  )

## =====================
## 7. Keep SG with >=2 species
## =====================
df_glm <- df_glm %>%
  group_by(SG) %>%
  filter(n_distinct(species2) >= 2) %>%
  ungroup()

df_glm$species2 <- factor(
  df_glm$species2,
  levels = c("A.tauschii", "P.edulis", "Z.mays")
)

cat("SG used in GLM:", length(unique(df_glm$SG)), "\n")
cat("Species levels:", levels(droplevels(df_glm$species2)), "\n")

## =====================
## 8. Fit GLM
## =====================
fit <- glm(
  cbind(cds_sites, cds_len - cds_sites) ~ species2 + SG,
  family = quasibinomial,
  data   = df_glm
)

summary(fit)

## =====================
## 9. Extract species effects
## =====================
res <- tidy(fit, conf.int = TRUE) %>%
  filter(grepl("^species2", term)) %>%
  mutate(
    contrast = sub("^species2", "", term),
    OR       = exp(estimate),
    OR_low   = exp(conf.low),
    OR_high  = exp(conf.high)
  ) %>%
  select(
    contrast,
    estimate,
    std.error,
    statistic,
    p.value,
    OR,
    OR_low,
    OR_high
  )

print(res)

write_tsv(
  res,
  paste0("GLM_quasibinomial_coreSG_", threshold, ".tsv")
)
