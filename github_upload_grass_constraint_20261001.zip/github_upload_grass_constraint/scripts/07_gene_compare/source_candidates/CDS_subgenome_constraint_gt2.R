#!/usr/bin/env Rscript

suppressPackageStartupMessages({
  library(dplyr)
  library(readr)
  library(stringr)
  library(ggplot2)
  library(ggsignif)
})

## =========================================================
## Parameters
## =========================================================
PAN_FILE <- "core_5sp_1to1.SG.pan"
BASE_DIR <- "ped_target_gene_CDS_GERP_stats/gerp_gt2"

N_BOOT <- 1000
EPS    <- 1e-6

OUT_PAIR <- "CDS_constraint_homeolog_pair_table.tsv"
OUT_BOOT <- "CDS_constraint_bootstrap_proportion.tsv"
OUT_SUM  <- "CDS_constraint_bootstrap_summary.tsv"
OUT_FIG  <- "Fig_CDS_constraint_bias_gerp_gt2.pdf"

## =========================================================
## 1. Read pan file (fixed structure)
## =========================================================
pan <- read_tsv(PAN_FILE, col_names = FALSE, show_col_types = FALSE)
colnames(pan) <- c(
  "SG_ID", "n_sp", "n_copy", "flag",
  "Atau", "Osat",
  "pedC", "pedD",
  "Zmay"
)

homeolog <- pan %>%
  transmute(
    SG_ID,
    geneC = str_remove(pedC, "^pedC_"),
    geneD = str_remove(pedD, "^pedD_")
  )

## =========================================================
## 2. Read per-gene CDS GERP stats
## =========================================================
datC <- read_tsv(
  file.path(BASE_DIR, "pedC/per_gene_stats.tsv"),
  show_col_types = FALSE
) %>% select(gene_id, cds_pct_C = cds_pct)

datD <- read_tsv(
  file.path(BASE_DIR, "pedD/per_gene_stats.tsv"),
  show_col_types = FALSE
) %>% select(gene_id, cds_pct_D = cds_pct)

## =========================================================
## 3. Join & compute Delta + status
## =========================================================
df <- homeolog %>%
  left_join(datC, by = c("geneC" = "gene_id")) %>%
  left_join(datD, by = c("geneD" = "gene_id")) %>%
  filter(!is.na(cds_pct_C), !is.na(cds_pct_D)) %>%
  mutate(
    Delta = log2((cds_pct_C + EPS) / (cds_pct_D + EPS)),

    C_status = case_when(
      Delta > 0 ~ "C_constrained",
      Delta < 0 ~ "C_less_constrained",
      TRUE      ~ "Balanced"
    ),

    D_status = case_when(
      Delta < 0 ~ "D_constrained",
      Delta > 0 ~ "D_less_constrained",
      TRUE      ~ "Balanced"
    )
  )

write_tsv(df, OUT_PAIR)
message("[INFO] Homeolog pair table written to: ", OUT_PAIR)
message("[INFO] Paired genes used: ", nrow(df))

## =========================================================
## 4. Bootstrap biased proportion
## =========================================================
set.seed(123)

boot_list <- lapply(seq_len(N_BOOT), function(i) {

  samp <- df %>% slice_sample(n = nrow(df), replace = TRUE)

  tibble(
    iter = i,
    category = c(
      "C_constrained",
      "D_constrained",
      "C_less_constrained",
      "D_less_constrained"
    ),
    proportion = c(
      mean(samp$Delta > 0) * 100,  # C constrained
      mean(samp$Delta < 0) * 100,  # D constrained
      mean(samp$Delta < 0) * 100,  # C less constrained
      mean(samp$Delta > 0) * 100   # D less constrained
    )
  )
})

plot_df <- bind_rows(boot_list)
write_tsv(plot_df, OUT_BOOT)

## =========================================================
## 5. Summary table
## =========================================================
summary_tbl <- plot_df %>%
  group_by(category) %>%
  summarise(
    mean_prop   = mean(proportion),
    median_prop = median(proportion),
    sd_prop     = sd(proportion),
    .groups = "drop"
  )

write_tsv(summary_tbl, OUT_SUM)

## =========================================================
## 6. Plot (paper-style)
## =========================================================
plot_df$category <- factor(
  plot_df$category,
  levels = c(
    "C_constrained",
    "D_constrained",
    "C_less_constrained",
    "D_less_constrained"
  )
)

p <- ggplot(
  plot_df,
  aes(x = category, y = proportion,
      fill = category, color = category)
) +
  geom_boxplot(outlier.shape = NA, width = 0.6) +
  geom_jitter(width = 0.2, size = 0.6, alpha = 0.4) +
  labs(
    x = NULL,
    y = "Biased proportion (%)",
    title = "CDS constraint bias between pedC and pedD (GERP > 2)"
  ) +
  scale_fill_manual(values = c(
    "C_constrained"        = "#1B9E77",
    "D_constrained"        = "#D95F02",
    "C_less_constrained"   = "#66C2A5",
    "D_less_constrained"   = "#FC8D62"
  )) +
  scale_color_manual(values = c(
    "C_constrained"        = "#1B9E77",
    "D_constrained"        = "#D95F02",
    "C_less_constrained"   = "#66C2A5",
    "D_less_constrained"   = "#FC8D62"
  )) +
  theme_classic(base_size = 12)

## significance: constrained
p <- p + geom_signif(
  comparisons = list(c("C_constrained", "D_constrained")),
  test = "wilcox.test",
  map_signif_level = TRUE,
  y_position = max(plot_df$proportion) * 1.05
)

## significance: less constrained
p <- p + geom_signif(
  comparisons = list(c("C_less_constrained", "D_less_constrained")),
  test = "wilcox.test",
  map_signif_level = TRUE,
  y_position = max(plot_df$proportion) * 1.15
)

ggsave(OUT_FIG, p, width = 7, height = 4)
message("[INFO] Figure written to: ", OUT_FIG)
