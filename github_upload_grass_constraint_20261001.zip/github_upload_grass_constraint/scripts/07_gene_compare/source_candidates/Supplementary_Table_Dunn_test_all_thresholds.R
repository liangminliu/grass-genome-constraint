thresholds <- c("gt0", "gt2", "gt4", "gt6")

supp_dunn <- lapply(thresholds, function(th) {

  df <- read_one_threshold(th)

  dt <- dunn.test(df$cds_pct, df$species, method = "bh",
                  kw = FALSE, list = TRUE)

  tibble(
    threshold = th,
    comparison = dt$comparisons,
    Z = dt$Z,
    p_adj = dt$P.adjusted
  )
}) %>% bind_rows()

write_tsv(
  supp_dunn,
  "Supplementary_Table_Dunn_test_all_thresholds.tsv"
)
