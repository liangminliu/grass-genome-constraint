#!/usr/bin/env bash
#SBATCH --job-name=Atau_ENSRNA_recalc
#SBATCH --partition=parallel
#SBATCH --nodes=1
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=8
#SBATCH --array=1-4
#SBATCH --output=logs/Atau_ENSRNA_recalc_%A_%a.out
#SBATCH --error=logs/Atau_ENSRNA_recalc_%A_%a.err

set -euo pipefail
module load bedtools 2>/dev/null || true

############################################################
# 0. 输入文件
############################################################
GFF="/gpfs/hpc/home/kib_unit/lidezhu/liuliangmin/2.msa/Atau_msa/results/GERP_output/01.constrained_category/Atau.filtered.gff"

TARGET_LISTS=(
  "Atau_Pol.list"
  "Atau_Veg.list"
)

# 所有 exon SNP 位点（只取前3列）
ALL_EXON_SNP="/gpfs/hpc/home/kib_unit/lidezhu/liuliangmin/2.msa/Atau_msa/pop/02.deleterious/output_bed/exons_processed.intersect.bed"

# 各阈值位点（只取前3列）
declare -A TH_SITE
TH_SITE[gt0]="/gpfs/hpc/home/kib_unit/lidezhu/liuliangmin/2.msa/Atau_msa/pop/02.deleterious/merged_gt0/functional_analysis/merged_gt0_exons_detailed.bed"
TH_SITE[gt2]="/gpfs/hpc/home/kib_unit/lidezhu/liuliangmin/2.msa/Atau_msa/pop/02.deleterious/merged_gt2/functional_analysis/merged_gt2_exons_detailed.bed"
TH_SITE[gt4]="/gpfs/hpc/home/kib_unit/lidezhu/liuliangmin/2.msa/Atau_msa/pop/02.deleterious/merged_gt4/functional_analysis/merged_gt4_exons_detailed.bed"
TH_SITE[gt6]="/gpfs/hpc/home/kib_unit/lidezhu/liuliangmin/2.msa/Atau_msa/pop/02.deleterious/merged_gt6/functional_analysis/merged_gt6_exons_detailed.bed"

OUT_ROOT="Atau_ENSRNA_recalc_byGFF"
mkdir -p logs "${OUT_ROOT}"

############################################################
# 1. array 参数
############################################################
CLASSES=("gt0" "gt2" "gt4" "gt6")
IDX=$((SLURM_ARRAY_TASK_ID - 1))
if [[ $IDX -lt 0 || $IDX -ge ${#CLASSES[@]} ]]; then
  echo "[ERROR] Bad SLURM_ARRAY_TASK_ID=${SLURM_ARRAY_TASK_ID}" >&2
  exit 1
fi
TH="${CLASSES[$IDX]}"

echo "[INFO] Threshold = ${TH}"

if [[ ! -s "${GFF}" ]]; then
  echo "[ERROR] GFF not found: ${GFF}" >&2
  exit 1
fi
if [[ ! -s "${ALL_EXON_SNP}" ]]; then
  echo "[ERROR] ALL_EXON_SNP not found: ${ALL_EXON_SNP}" >&2
  exit 1
fi
if [[ ! -s "${TH_SITE[$TH]}" ]]; then
  echo "[ERROR] Threshold site file not found: ${TH_SITE[$TH]}" >&2
  exit 1
fi

############################################################
# 2. 从 GFF 构建全量 gene bed / exon bed
#    gene_len  <- gene 或 ncRNA_gene
#    cds_len   <- merged exon length (proxy)
############################################################

# 2.1 gene bed: chr start end gene_id
awk -F'\t' '
BEGIN{OFS="\t"}
function get_attr(s, key,    n, i, a, b){
  n=split(s, a, ";")
  for(i=1; i<=n; i++){
    split(a[i], b, "=")
    if(b[1]==key) return b[2]
  }
  return ""
}
$0 !~ /^#/ && ($3=="gene" || $3=="ncRNA_gene") {
  gid=get_attr($9, "gene_id")
  if(gid==""){
    gid=get_attr($9, "ID")
    sub(/^gene:/, "", gid)
  }
  if(gid!=""){
    print $1, $4-1, $5, gid
  }
}' "${GFF}" \
| LC_ALL=C sort -k1,1 -k2,2n -k3,3n -k4,4 \
> "${OUT_ROOT}/all_gene_from_gff.bed"

# 2.2 transcript -> gene
awk -F'\t' '
BEGIN{OFS="\t"}
function get_attr(s, key,    n, i, a, b){
  n=split(s, a, ";")
  for(i=1; i<=n; i++){
    split(a[i], b, "=")
    if(b[1]==key) return b[2]
  }
  return ""
}
$0 !~ /^#/ && $3!="gene" && $3!="ncRNA_gene" && $3!="exon" {
  tid=get_attr($9, "transcript_id")
  if(tid==""){
    tid=get_attr($9, "ID")
    sub(/^transcript:/, "", tid)
  }
  parent=get_attr($9, "Parent")
  sub(/^gene:/, "", parent)
  if(tid!="" && parent!=""){
    print tid, parent
  }
}' "${GFF}" \
| LC_ALL=C sort -u \
> "${OUT_ROOT}/transcript2gene.tsv"

# 2.3 exon bed with gene_id
awk -F'\t' '
BEGIN{OFS="\t"}
function get_attr(s, key,    n, i, a, b){
  n=split(s, a, ";")
  for(i=1; i<=n; i++){
    split(a[i], b, "=")
    if(b[1]==key) return b[2]
  }
  return ""
}
NR==FNR{
  t2g[$1]=$2
  next
}
$0 !~ /^#/ && $3=="exon"{
  parent=get_attr($9, "Parent")
  split(parent, pp, ",")
  tid=pp[1]
  sub(/^transcript:/, "", tid)
  if(tid in t2g){
    print $1, $4-1, $5, t2g[tid]
  }
}' "${OUT_ROOT}/transcript2gene.tsv" "${GFF}" \
| LC_ALL=C sort -k1,1 -k2,2n -k3,3n -k4,4 \
> "${OUT_ROOT}/all_exon_from_gff.bed"

############################################################
# 3. 抽取“总 exon SNP 位点集”和“各阈值位点集”
#    统一只保留 chr/start/end，去重
############################################################
awk 'BEGIN{OFS="\t"}{print $1,$2,$3}' "${ALL_EXON_SNP}" \
| LC_ALL=C sort -u \
> "${OUT_ROOT}/all_exon_snp_sites.bed"

awk 'BEGIN{OFS="\t"}{print $1,$2,$3}' "${TH_SITE[$TH]}" \
| LC_ALL=C sort -u \
> "${OUT_ROOT}/${TH}_sites.bed"

############################################################
# 4. 循环处理 Atau_Pol / Atau_Veg 中 ENSRNA 条目
############################################################
for LIST in "${TARGET_LISTS[@]}"; do
  if [[ ! -s "${LIST}" ]]; then
    echo "[WARN] Missing list: ${LIST}"
    continue
  fi

  GROUP=$(basename "${LIST}")
  GROUP=${GROUP%.list}

  OUT_DIR="${OUT_ROOT}/${GROUP}/${TH}"
  BED_DIR="${OUT_DIR}/bed_files"
  STAT_DIR="${OUT_DIR}/stats"
  mkdir -p "${BED_DIR}" "${STAT_DIR}"

  echo "[INFO] ----------------------------------------"
  echo "[INFO] Processing ${GROUP} / ${TH}"

  ##########################################################
  # 4.1 提取 ENSRNA gene_id
  ##########################################################
  TARGET_GENE_LIST="${OUT_DIR}/target_ENSRNA_gene_ids.txt"

  awk -F'|' '
  {
    x=$1
    sub(/^gene:/, "", x)
    if(x ~ /^ENSRNA/) print x
  }' "${LIST}" \
  | LC_ALL=C sort -u \
  > "${TARGET_GENE_LIST}"

  N_TARGET=$(wc -l < "${TARGET_GENE_LIST}")
  echo "[INFO] ENSRNA targets = ${N_TARGET}"

  if [[ "${N_TARGET}" -eq 0 ]]; then
    echo "[WARN] No ENSRNA entry in ${LIST}, skip"
    continue
  fi

  ##########################################################
  # 4.2 构建目标 gene bed / exon bed
  ##########################################################
  TARGET_GENE_BED="${BED_DIR}/target_gene.bed"
  TARGET_EXON_BED_RAW="${BED_DIR}/target_exon.raw.bed"
  TARGET_EXON_BED="${BED_DIR}/target_exon.merged.bed"

  awk 'NR==FNR{a[$1]=1; next} ($4 in a)' \
    "${TARGET_GENE_LIST}" "${OUT_ROOT}/all_gene_from_gff.bed" \
    > "${TARGET_GENE_BED}"

  awk 'NR==FNR{a[$1]=1; next} ($4 in a)' \
    "${TARGET_GENE_LIST}" "${OUT_ROOT}/all_exon_from_gff.bed" \
    > "${TARGET_EXON_BED_RAW}"

  # 按 gene 合并 exon
  sort -k4,4 -k1,1 -k2,2n "${TARGET_EXON_BED_RAW}" \
  | awk '
    BEGIN{OFS="\t"}
    {
      g=$4; chr=$1; s=$2; e=$3
      if(NR==1){
        cg=g; cchr=chr; cs=s; ce=e
        next
      }
      if(g!=cg || chr!=cchr){
        print cchr, cs, ce, cg
        cg=g; cchr=chr; cs=s; ce=e
        next
      }
      if(s <= ce){
        if(e > ce) ce=e
      } else {
        print cchr, cs, ce, cg
        cs=s; ce=e
      }
    }
    END{
      if(NR>0) print cchr, cs, ce, cg
    }' \
  > "${TARGET_EXON_BED}"

  ##########################################################
  # 4.3 gene_len / cds_len(proxy=merged exon len)
  ##########################################################
  awk 'BEGIN{OFS="\t"}{print $4, $3-$2}' "${TARGET_GENE_BED}" \
  | LC_ALL=C sort -k1,1 \
  > "${STAT_DIR}/gene_length.tsv"

  awk 'BEGIN{OFS="\t"}{print $4, $3-$2}' "${TARGET_EXON_BED}" \
  | LC_ALL=C sort -k1,1 \
  > "${STAT_DIR}/exon_block_length.tsv"

  awk '
  BEGIN{OFS="\t"}
  { len[$1] += $2 }
  END{
    for(g in len) print g, len[g]
  }' "${STAT_DIR}/exon_block_length.tsv" \
  | LC_ALL=C sort -k1,1 \
  > "${STAT_DIR}/cds_length.tsv"

  ##########################################################
  # 4.4 阈值位点统计：gene_sites / cds_sites
  #     site集合来自 ${TH}_sites.bed
  ##########################################################
  GENE_SITE_INTERSECT="${BED_DIR}/gene_site_intersect.bed"
  EXON_SITE_INTERSECT="${BED_DIR}/exon_site_intersect.bed"

  if [[ -s "${TARGET_GENE_BED}" ]]; then
    bedtools intersect -wa -wb \
      -a "${OUT_ROOT}/${TH}_sites.bed" \
      -b "${TARGET_GENE_BED}" \
      > "${GENE_SITE_INTERSECT}"
  else
    : > "${GENE_SITE_INTERSECT}"
  fi

  if [[ -s "${TARGET_EXON_BED}" ]]; then
    bedtools intersect -wa -wb \
      -a "${OUT_ROOT}/${TH}_sites.bed" \
      -b "${TARGET_EXON_BED}" \
      > "${EXON_SITE_INTERSECT}"
  else
    : > "${EXON_SITE_INTERSECT}"
  fi

  if [[ -s "${GENE_SITE_INTERSECT}" ]]; then
    awk 'BEGIN{OFS="\t"}
    {
      gid=$NF
      key=$1"\t"$2"\t"$3"\t"gid
      if(!seen[key]++) c[gid]++
    }
    END{
      for(g in c) print g, c[g]
    }' "${GENE_SITE_INTERSECT}" \
    | LC_ALL=C sort -k1,1 \
    > "${STAT_DIR}/gene_site_count.tsv"
  else
    : > "${STAT_DIR}/gene_site_count.tsv"
  fi

  if [[ -s "${EXON_SITE_INTERSECT}" ]]; then
    awk 'BEGIN{OFS="\t"}
    {
      gid=$NF
      key=$1"\t"$2"\t"$3"\t"gid
      if(!seen[key]++) c[gid]++
    }
    END{
      for(g in c) print g, c[g]
    }' "${EXON_SITE_INTERSECT}" \
    | LC_ALL=C sort -k1,1 \
    > "${STAT_DIR}/cds_site_count.tsv"
  else
    : > "${STAT_DIR}/cds_site_count.tsv"
  fi

  ##########################################################
  # 4.5 输出保守/阈值位点结果表
  ##########################################################
  awk '
  BEGIN{
    OFS="\t"
    print "gene_id","gene_len","cds_len","gene_sites","gene_pct","cds_sites","cds_pct"
  }
  FNR==NR {order[++n]=$1; next}
  ARGIND==2 {gene_len[$1]=$2; next}
  ARGIND==3 {cds_len[$1]=$2; next}
  ARGIND==4 {gene_sites[$1]=$2; next}
  ARGIND==5 {cds_sites[$1]=$2; next}
  END{
    for(i=1;i<=n;i++){
      g=order[i]
      gl=(g in gene_len)?gene_len[g]:0
      cl=(g in cds_len)?cds_len[g]:0
      gs=(g in gene_sites)?gene_sites[g]:0
      cs=(g in cds_sites)?cds_sites[g]:0
      gp=(gl>0)?gs/gl*100:0
      cp=(cl>0)?cs/cl*100:0
      printf "%s\t%d\t%d\t%d\t%.6f\t%d\t%.6f\n", g, gl, cl, gs, gp, cs, cp
    }
  }' \
  "${TARGET_GENE_LIST}" \
  "${STAT_DIR}/gene_length.tsv" \
  "${STAT_DIR}/cds_length.tsv" \
  "${STAT_DIR}/gene_site_count.tsv" \
  "${STAT_DIR}/cds_site_count.tsv" \
  > "${OUT_DIR}/per_gene_stats.tsv"

  ##########################################################
  # 4.6 总 exon SNP 统计：cds_snp_total
  ##########################################################
  ALL_SNP_INTERSECT="${BED_DIR}/all_snp_exon_intersect.bed"

  if [[ -s "${TARGET_EXON_BED}" ]]; then
    bedtools intersect -wa -wb \
      -a "${OUT_ROOT}/all_exon_snp_sites.bed" \
      -b "${TARGET_EXON_BED}" \
      > "${ALL_SNP_INTERSECT}"
  else
    : > "${ALL_SNP_INTERSECT}"
  fi

  if [[ -s "${ALL_SNP_INTERSECT}" ]]; then
    awk 'BEGIN{OFS="\t"}
    {
      gid=$NF
      key=$1"\t"$2"\t"$3"\t"gid
      if(!seen[key]++) c[gid]++
    }
    END{
      for(g in c) print g, c[g]
    }' "${ALL_SNP_INTERSECT}" \
    | LC_ALL=C sort -k1,1 \
    > "${STAT_DIR}/cds_snp_total.tsv"
  else
    : > "${STAT_DIR}/cds_snp_total.tsv"
  fi

  ##########################################################
  # 4.7 gt2/gt4/gt6 输出 deleterious 结果
  #     cds_deleterious_snp = 当前阈值位点 ∩ merged exon
  ##########################################################
  if [[ "${TH}" != "gt0" ]]; then
    cp "${STAT_DIR}/cds_site_count.tsv" "${STAT_DIR}/cds_deleterious_snp.tsv"

    awk '
    BEGIN{
      OFS="\t"
      print "gene_id","cds_len","cds_snp_total","cds_snp_ratio","cds_deleterious_snp","deleterious_ratio"
    }
    FNR==NR {order[++n]=$1; next}
    ARGIND==2 {cds_len[$1]=$2; next}
    ARGIND==3 {snp[$1]=$2; next}
    ARGIND==4 {del[$1]=$2; next}
    END{
      for(i=1;i<=n;i++){
        g=order[i]
        cl=(g in cds_len)?cds_len[g]:0
        sn=(g in snp)?snp[g]:0
        de=(g in del)?del[g]:0
        sr=(cl>0)?sn/cl:0
        dr=(sn>0)?de/sn:0
        printf "%s\t%d\t%d\t%.8f\t%d\t%.8f\n", g, cl, sn, sr, de, dr
      }
    }' \
    "${TARGET_GENE_LIST}" \
    "${STAT_DIR}/cds_length.tsv" \
    "${STAT_DIR}/cds_snp_total.tsv" \
    "${STAT_DIR}/cds_deleterious_snp.tsv" \
    > "${OUT_DIR}/${GROUP}_${TH}_gene_deleterious.tsv"
  fi

  ##########################################################
  # 4.8 简单 summary
  ##########################################################
  awk -v grp="${GROUP}" -v th="${TH}" '
  BEGIN{
    OFS="\t"
    print "group","threshold","n_genes","sum_gene_len","sum_cds_len","sum_gene_sites","sum_cds_sites","gene_pct_global","cds_pct_global"
  }
  NR==1{next}
  {
    n++
    sgl += $2
    scl += $3
    sgs += $4
    scs += $6
  }
  END{
    gp=(sgl>0)?sgs/sgl*100:0
    cp=(scl>0)?scs/scl*100:0
    printf "%s\t%s\t%d\t%d\t%d\t%d\t%d\t%.6f\t%.6f\n", grp, th, n, sgl, scl, sgs, scs, gp, cp
  }' "${OUT_DIR}/per_gene_stats.tsv" \
  > "${OUT_DIR}/${GROUP}_${TH}_conserved_summary.tsv"

  if [[ "${TH}" != "gt0" ]]; then
    awk -v grp="${GROUP}" -v th="${TH}" '
    BEGIN{
      OFS="\t"
      print "group","threshold","n_genes","sum_cds_len","sum_cds_snp_total","sum_cds_deleterious_snp","cds_snp_ratio_global","deleterious_ratio_global"
    }
    NR==1{next}
    {
      n++
      scl += $2
      ssn += $3
      sde += $5
    }
    END{
      sr=(scl>0)?ssn/scl:0
      dr=(ssn>0)?sde/ssn:0
      printf "%s\t%s\t%d\t%d\t%d\t%d\t%.8f\t%.8f\n", grp, th, n, scl, ssn, sde, sr, dr
    }' "${OUT_DIR}/${GROUP}_${TH}_gene_deleterious.tsv" \
    > "${OUT_DIR}/${GROUP}_${TH}_deleterious_summary.tsv"
  fi

  echo "[INFO] Finished ${GROUP} / ${TH}"
  echo "[INFO] Conserved-like output : ${OUT_DIR}/per_gene_stats.tsv"
  if [[ "${TH}" != "gt0" ]]; then
    echo "[INFO] Deleterious output    : ${OUT_DIR}/${GROUP}_${TH}_gene_deleterious.tsv"
  fi
done

echo "[INFO] All done for ${TH}"