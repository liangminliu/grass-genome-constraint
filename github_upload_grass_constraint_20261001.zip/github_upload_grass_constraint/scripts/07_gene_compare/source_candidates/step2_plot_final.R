#!/usr/bin/env Rscript

suppressPackageStartupMessages({
  library(tidyverse)
  library(ggsignif)
  library(patchwork)
  library(grid)
})

# =========================================================
# Config
# =========================================================
THRESHOLDS <- c("gt2", "gt4", "gt6")
DATA_TYPES <- c("ALL", "SNPpos", "SNP0")

# species order: Aegilops tauschii -> Phyllostachys edulis -> Zea mays
species_levels <- c("Atau", "ped", "Zmay")

species_labels <- c(
  "Atau" = "A. tauschii",
  "ped"  = "P. edulis",
  "Zmay" = "Z. mays"
)

file_map <- c(
  "ALL"    = "SG_%s_cds_and_deleterious_ratio_table.tsv",
  "SNPpos" = "SG_%s_SNPpos_cds_and_deleterious_ratio_table.tsv",
  "SNP0"   = "SG_%s_SNP0_cds_and_deleterious_ratio_table.tsv"
)

# =========================================================
# p-value -> significance stars
# =========================================================
p_to_star <- function(p) {
  case_when(
    is.na(p) ~ "NA",
    p < 1e-4 ~ "****",
    p < 1e-3 ~ "***",
    p < 1e-2 ~ "**",
    p < 0.05 ~ "*",
    TRUE ~ "ns"
  )
}

# =========================================================
# Safe paired Wilcoxon
# =========================================================
safe_paired_wilcox <- function(x, y) {
  idx <- complete.cases(x, y)
  x <- x[idx]
  y <- y[idx]

  if (length(x) < 3) return(NA_real_)

  tryCatch(
    wilcox.test(x, y, paired = TRUE)$p.value,
    error = function(e) NA_real_
  )
}

# =========================================================
# Theme
# =========================================================
theme_mbe_boxviolin <- function() {
  theme_bw(base_size = 12) +
    theme(
      panel.border = element_rect(color = "black", fill = NA, linewidth = 0.7),
      panel.grid.major = element_line(color = "grey88", linewidth = 0.35),
      panel.grid.minor = element_line(color = "grey94", linewidth = 0.25),
      axis.text = element_text(color = "black", size = 10),
      axis.text.x = element_text(
        face = "italic",
        size = 10,
        margin = margin(t = 4)
      ),
      axis.title = element_text(color = "black", size = 11),
      plot.title = element_text(face = "bold", size = 12, hjust = 0.5),
      plot.margin = margin(8, 10, 8, 8)
    )
}

# =========================================================
# Read only required columns from current input format
# =========================================================
read_metric_df <- function(file, metric_prefix) {
  needed_cols <- c(
    paste0("Atau_", metric_prefix),
    paste0("ped_",  metric_prefix),
    paste0("Zmay_", metric_prefix)
  )

  df <- read_tsv(file, show_col_types = FALSE) |>
    select(all_of(needed_cols))

  # 强制转 numeric，避免潜在类型漂移
  df <- df |>
    mutate(across(everything(), as.numeric))

  df
}

# =========================================================
# violin + boxplot
# mode:
#   "raw"         -> use original values
#   "log10_pseudo"-> use log10(value + pseudo) for plotting
# stats are always computed on ORIGINAL values
# =========================================================
plot_metric <- function(df, metric_prefix, ylab, title_text,
                        mode = "raw", pseudo = 1e-6) {

  cols <- c(
    paste0("Atau_", metric_prefix),
    paste0("ped_",  metric_prefix),
    paste0("Zmay_", metric_prefix)
  )

  df_plot <- df |>
    select(all_of(cols)) |>
    setNames(species_levels)

  # plotting dataframe
  df_long <- df_plot |>
    pivot_longer(
      everything(),
      names_to = "species",
      values_to = "value_raw"
    ) |>
    mutate(
      species = factor(species, levels = species_levels),
      plot_value = case_when(
        mode == "log10_pseudo" ~ log10(value_raw + pseudo),
        TRUE ~ value_raw
      )
    ) |>
    filter(is.finite(plot_value))

  p <- ggplot(df_long, aes(x = species, y = plot_value)) +
    geom_violin(
      width = 0.78,
      trim = TRUE,
      color = "black",
      fill = "grey85",
      linewidth = 0.4,
      na.rm = TRUE
    ) +
    geom_boxplot(
      width = 0.15,
      outlier.shape = NA,
      linewidth = 0.4,
      fill = "white",
      na.rm = TRUE
    ) +
    scale_x_discrete(labels = species_labels) +
    labs(
      x = NULL,
      y = ylab,
      title = title_text
    ) +
    theme_mbe_boxviolin()

  # significance from ORIGINAL values
  pvals <- c(
    safe_paired_wilcox(df_plot$Atau, df_plot$ped),
    safe_paired_wilcox(df_plot$Atau, df_plot$Zmay),
    safe_paired_wilcox(df_plot$ped,  df_plot$Zmay)
  )

  y_max <- max(df_long$plot_value, na.rm = TRUE)
  y_min <- min(df_long$plot_value, na.rm = TRUE)
  y_range <- y_max - y_min

  if (!is.finite(y_range) || y_range <= 0) {
    y_range <- max(abs(y_max), 1)
  }

  y_pos <- c(
    y_max + 0.10 * y_range,
    y_max + 0.22 * y_range,
    y_max + 0.34 * y_range
  )

  p <- p +
    geom_signif(
      comparisons = list(
        c("Atau", "ped"),
        c("Atau", "Zmay"),
        c("ped",  "Zmay")
      ),
      annotations = sapply(pvals, p_to_star),
      y_position = y_pos,
      tip_length = 0.01,
      textsize = 3.2,
      vjust = 0.25,
      linewidth = 0.35
    ) +
    coord_cartesian(
      ylim = c(y_min, y_max + 0.46 * y_range),
      clip = "off"
    )

  p
}

# =========================================================
# Main loop
# =========================================================
for (data_type in DATA_TYPES) {

  message("Processing ", data_type)

  # ------------------------------------------
  # Panel A: SNP density
  # use ALL + gt4 only once
  # IMPORTANT:
  # plot on log10(value + pseudo), not scale_y_log10()
  # ------------------------------------------
  snp_file <- sprintf(file_map["ALL"], "gt4")
  df_snp <- read_metric_df(snp_file, "cds_ratio")

  p_snp <- plot_metric(
    df = df_snp,
    metric_prefix = "cds_ratio",
    ylab = expression(log[10]("SNP density" + 10^-6)),
    title_text = "A  SNP density",
    mode = "log10_pseudo",
    pseudo = 1e-6
  )

  # ------------------------------------------
  # Panels B-D: deleterious ratio
  # ------------------------------------------
  p_list <- list()

  panel_titles <- c(
    "gt2" = "B  Deleterious ratio (GERP > 2)",
    "gt4" = "C  Deleterious ratio (GERP > 4)",
    "gt6" = "D  Deleterious ratio (GERP > 6)"
  )

  for (thr in THRESHOLDS) {
    del_file <- sprintf(file_map[data_type], thr)
    df_del <- read_metric_df(del_file, "del_ratio")

    p_list[[thr]] <- plot_metric(
      df = df_del,
      metric_prefix = "del_ratio",
      ylab = "Deleterious ratio",
      title_text = panel_titles[[thr]],
      mode = "raw"
    )
  }

  final_plot <- (p_snp | p_list[["gt2"]]) /
                (p_list[["gt4"]] | p_list[["gt6"]])

  ggsave(
    filename = paste0("Figure_MBE_", data_type, "_4panel.pdf"),
    plot = final_plot,
    width = 11,
    height = 9,
    dpi = 300
  )
}