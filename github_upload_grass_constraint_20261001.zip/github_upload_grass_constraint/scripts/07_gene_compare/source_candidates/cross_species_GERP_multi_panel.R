#!/usr/bin/env Rscript

## =========================================================
## Multi-panel (A–C) cross-species comparison of CDS constrained proportion
## Species: A. tauschii, P. edulis (pedC+pedD), Z. mays
## Panels: GERP gt2 / gt4 / gt6
## Stats : Kruskal–Wallis + Dunn (BH) per threshold
## Output:
##   1) Main-text multi-panel figure (PDF/PNG)
##   2) Supplementary Dunn full results table (TSV) for gt0/gt2/gt4/gt6
## =========================================================

suppressPackageStartupMessages({
  library(dplyr)
  library(readr)
  library(ggplot2)
  library(dunn.test)   # lightweight Dunn test
  library(ggsignif)    # significance annotation
  library(patchwork)   # multi-panel A–C
})

## =========================================================
## 1. Parameters (ONLY change here)
## =========================================================
panels_thresholds <- c("gt2", "gt4", "gt6")          # A–C panels
supp_thresholds   <- c("gt0", "gt2", "gt4", "gt6")  # Supplementary table (4×)

show_ns_lines <- FALSE   # TRUE to draw "ns" bars too (usually keep FALSE)
out_fig_prefix <- "Fig_cross_species_multi_gt2_gt4_gt6"
out_supp_tsv    <- "Supplementary_Dunn_cross_species_CDS.tsv"

## =========================================================
## 2. Input file builder (fixed structure)
## =========================================================
build_files <- function(threshold) {
  list(
    pedC = paste0(
      "2.1.ped/ped_target_gene_CDS_GERP_stats/gerp_", threshold,
      "/pedC/per_gene_stats.tsv"
    ),
    pedD = paste0(
      "2.1.ped/ped_target_gene_CDS_GERP_stats/gerp_", threshold,
      "/pedD/per_gene_stats.tsv"
    ),
    Zmay = paste0(
      "2.2.Zmay/Zmay_target_gene_CDS_GERP_stats/",
      threshold, "/per_gene_stats.tsv"
    ),
    Atau = paste0(
      "2.3.Atau/target_gene_CDS_GERP_stats/",
      threshold, "/per_gene_stats.tsv"
    )
  )
}

## =========================================================
## 3. Helpers
## =========================================================
p_to_star <- function(p) {
  if (is.na(p)) return("ns")
  if (p < 0.001) return("***")
  if (p < 0.01)  return("**")
  if (p < 0.05)  return("*")
  "ns"
}

read_one_threshold <- function(threshold) {
  files <- build_files(threshold)

  df_all <- lapply(names(files), function(sp) {
    fp <- files[[sp]]
    if (!file.exists(fp)) stop("Missing file: ", fp)

    read_tsv(fp, show_col_types = FALSE) %>%
      mutate(species_raw = sp)
  }) %>% bind_rows()

  df_species <- df_all %>%
    mutate(
      species = case_when(
        species_raw %in% c("pedC", "pedD") ~ "P.edulis",
        species_raw == "Zmay"             ~ "Z.mays",
        species_raw == "Atau"             ~ "A.tauschii",
        TRUE ~ NA_character_
      ),
      cds_pct = suppressWarnings(as.numeric(cds_pct))
    ) %>%
    filter(!is.na(species), !is.na(cds_pct)) %>%
    mutate(
      species = factor(species, levels = c("A.tauschii", "P.edulis", "Z.mays")),
      threshold = threshold
    )

  df_species
}

run_stats_one_threshold <- function(df_plot, threshold) {
  df_plot <- df_plot %>%
    filter(!is.na(species), !is.na(cds_pct)) %>%
    droplevels()

  k_levels <- nlevels(df_plot$species)

  ## Kruskal–Wallis (only meaningful when >= 2 groups)
  kw <- if (k_levels >= 2) kruskal.test(cds_pct ~ species, data = df_plot) else NULL

  ## Pairwise:
  ## - if 3 groups: Dunn test (BH)
  ## - if 2 groups: Wilcoxon rank-sum (BH not relevant; single p)
  if (k_levels >= 3) {
    dt <- dunn.test(
      x = df_plot$cds_pct,
      g = df_plot$species,
      method = "bh",
      kw = FALSE,
      list = TRUE
    )

    dunn_tbl <- tibble(
      threshold  = threshold,
      test       = "Dunn (BH)",
      Comparison = dt$comparisons,
      Z          = dt$Z,
      P.raw      = dt$P,
      P.adj      = dt$P.adjusted
    ) %>%
      mutate(
        group1 = sub(" -.*", "", Comparison),
        group2 = sub(".*- ", "", Comparison),
        label  = vapply(P.adj, p_to_star, character(1))
      )

    list(kw = kw, pairwise_tbl = dunn_tbl)

  } else if (k_levels == 2) {
    lv <- levels(df_plot$species)
    p <- wilcox.test(cds_pct ~ species, data = df_plot, exact = FALSE)$p.value

    pair_tbl <- tibble(
      threshold  = threshold,
      test       = "Wilcoxon rank-sum",
      Comparison = paste0(lv[1], " - ", lv[2]),
      Z          = NA_real_,
      P.raw      = p,
      P.adj      = p,
      group1     = lv[1],
      group2     = lv[2],
      label      = p_to_star(p)
    )

    list(kw = kw, pairwise_tbl = pair_tbl)

  } else {
    pair_tbl <- tibble(
      threshold  = threshold,
      test       = "NA",
      Comparison = NA_character_,
      Z          = NA_real_,
      P.raw      = NA_real_,
      P.adj      = NA_real_,
      group1     = NA_character_,
      group2     = NA_character_,
      label      = NA_character_
    )
    list(kw = kw, pairwise_tbl = pair_tbl)
  }
}

make_sig_df <- function(df_plot, pairwise_tbl) {
  df_plot <- df_plot %>% droplevels()

  sig_df <- pairwise_tbl %>%
    filter(!is.na(group1), !is.na(group2))

  if (!show_ns_lines) {
    sig_df <- sig_df %>% filter(label != "ns")
  }

  if (nrow(sig_df) == 0) {
    return(list(sig_df = sig_df, y_panel_max = max(df_plot$cds_pct, na.rm = TRUE)))
  }

  y_data_max <- max(df_plot$cds_pct, na.rm = TRUE)
  sig_df <- sig_df %>%
    mutate(
      y_position = y_data_max + seq(from = 3, by = 3, length.out = n())
    )

  y_panel_max <- max(sig_df$y_position, na.rm = TRUE) + 3
  list(sig_df = sig_df, y_panel_max = y_panel_max)
}

plot_one_panel <- function(df_plot, sig_df, y_limit, panel_title) {
  ggplot(df_plot, aes(x = species, y = cds_pct)) +

    ## violin (narrower, no axis-touching artifacts)
    geom_violin(
      width = 0.42,
      scale = "width",
      trim  = TRUE,
      fill  = "#D9D9D9",
      color = "#6E6E6E",
      linewidth = 0.8
    ) +

    ## box (small)
    geom_boxplot(
      width = 0.055,
      coef  = 0.35,
      fill  = "white",
      color = "black",
      linewidth = 1,
      outlier.shape = NA
    ) +

    ## significance
    { if (nrow(sig_df) > 0)
      geom_signif(
        data = sig_df,
        aes(
          xmin = group1,
          xmax = group2,
          annotations = label,
          y_position = y_position
        ),
        manual = TRUE,
        textsize = 3.6,
        tip_length = 0.01,
        linewidth = 0.7
      ) } +

    scale_y_continuous(
      limits = c(0, y_limit),
      breaks = seq(0, 100, 25),
      expand = c(0, 0)
    ) +

    labs(
      x = NULL,
      y = "CDS constrained sites (%)",
      title = panel_title
    ) +

    theme_classic(base_size = 16) +
    theme(
      plot.title = element_text(size = 14, face = "plain", hjust = 0.5),
      axis.text.x = element_text(face = "italic", size = 16),
      axis.text.y = element_text(size = 14),
      axis.title.y = element_text(size = 16),

      panel.border = element_rect(fill = NA, color = "black", linewidth = 1),

      plot.margin = margin(12, 12, 10, 12)
    )
}

safe_ggsave <- function(filename, plot, width, height, dpi = NULL) {
  ## Try cairo_pdf for better embedding, fallback to default pdf if cairo not available
  if (grepl("\\.pdf$", filename, ignore.case = TRUE)) {
    ok <- FALSE
    try({
      ggsave(filename, plot, width = width, height = height, device = cairo_pdf)
      ok <- TRUE
    }, silent = TRUE)
    if (!ok) ggsave(filename, plot, width = width, height = height)
  } else {
    if (is.null(dpi)) ggsave(filename, plot, width = width, height = height)
    else ggsave(filename, plot, width = width, height = height, dpi = dpi)
  }
}

## =========================================================
## 4. Build Supplementary table (gt0/gt2/gt4/gt6) — full results
## =========================================================
supp_list <- lapply(supp_thresholds, function(th) {
  df_th <- read_one_threshold(th)
  st <- run_stats_one_threshold(df_th, th)

  kw_p <- if (!is.null(st$kw)) st$kw$p.value else NA_real_
  kw_chi <- if (!is.null(st$kw)) unname(st$kw$statistic) else NA_real_
  kw_df <- if (!is.null(st$kw)) unname(st$kw$parameter) else NA_real_

  st$pairwise_tbl %>%
    mutate(
      KW_chisq = kw_chi,
      KW_df    = kw_df,
      KW_p     = kw_p
    ) %>%
    select(
      threshold, test, KW_chisq, KW_df, KW_p,
      Comparison, group1, group2, Z, P.raw, P.adj, label
    )
})

supp_tbl <- bind_rows(supp_list)

write_tsv(supp_tbl, out_supp_tsv)
cat("Wrote Supplementary Dunn/Wilcoxon table: ", out_supp_tsv, "\n", sep = "")

## =========================================================
## 5. Multi-panel figure (A–C): gt2/gt4/gt6
## =========================================================
panel_objs <- lapply(panels_thresholds, function(th) {
  df_th <- read_one_threshold(th)
  st <- run_stats_one_threshold(df_th, th)
  sig_info <- make_sig_df(df_th, st$pairwise_tbl)
  list(df = df_th, sig_df = sig_info$sig_df, y_panel_max = sig_info$y_panel_max)
})

## Use a GLOBAL y-limit so all panels align; must also include any significance bars
global_y <- max(vapply(panel_objs, function(x) x$y_panel_max, numeric(1)), na.rm = TRUE)
global_y <- max(global_y, 105)  # keep a clean upper headroom (safe even if stars high)

titles <- c(gt2 = "GERP > 2", gt4 = "GERP > 4", gt6 = "GERP > 6")

plots <- lapply(seq_along(panels_thresholds), function(i) {
  th <- panels_thresholds[i]
  plot_one_panel(
    df_plot    = panel_objs[[i]]$df,
    sig_df     = panel_objs[[i]]$sig_df,
    y_limit    = global_y,
    panel_title = titles[[th]]
  )
})

## Combine A–C
p_multi <- plots[[1]] + plots[[2]] + plots[[3]] +
  plot_layout(ncol = 3, guides = "collect") +
  plot_annotation(tag_levels = "A")

## Save multi-panel
safe_ggsave(paste0(out_fig_prefix, ".pdf"), p_multi, width = 14.0, height = 4.9)
safe_ggsave(paste0(out_fig_prefix, ".png"), p_multi, width = 14.0, height = 4.9, dpi = 300)

cat("Saved multi-panel figure: ",
    out_fig_prefix, ".pdf / .png\n", sep = "")
