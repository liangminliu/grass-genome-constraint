#!/usr/bin/env Rscript

suppressPackageStartupMessages({
  library(dplyr)
  library(readr)
  library(stringr)
  library(tidyr)
  library(ggplot2)
  library(ggsignif)
})

PAN_FILE <- "core_5sp_1to1.SG.pan"
THRESHOLDS <- c("gt2", "gt4", "gt6")

# =========================================================
# Helper: p value to significance label
# =========================================================
p_to_signif <- function(p) {
  if (is.na(p)) {
    "NA"
  } else if (p < 0.001) {
    "***"
  } else if (p < 0.01) {
    "**"
  } else if (p < 0.05) {
    "*"
  } else {
    "ns"
  }
}

# =========================================================
# Helper: paired Wilcoxon for plotting
# =========================================================
paired_wilcox_for_plot <- function(df) {

  pairs <- list(
    c("ped", "Atau"),
    c("ped", "Zmay"),
    c("Atau", "Zmay")
  )

  purrr::map_dfr(pairs, \(p) {

    x <- df |>
      filter(species == p[1]) |>
      arrange(SG_ID) |>
      pull(value)

    y <- df |>
      filter(species == p[2]) |>
      arrange(SG_ID) |>
      pull(value)

    idx <- complete.cases(x, y)

    if (sum(idx) < 3) {
      p_val <- NA_real_
    } else {
      p_val <- wilcox.test(x[idx], y[idx], paired = TRUE)$p.value
    }

    tibble(
      group1 = p[1],
      group2 = p[2],
      p_value = p_val,
      label = p_to_signif(p_val)
    )
  })
}

# =========================================================
# 1. Read pan file
# =========================================================
pan <- read_tsv(PAN_FILE, col_names = FALSE, show_col_types = FALSE)

colnames(pan) <- c(
  "SG_ID", "n_sp", "n_copy", "flag",
  "Atau", "Osat", "pedC", "pedD", "Zmay"
)

pan_clean <- pan |>
  transmute(
    SG_ID,
    Atau = str_remove(Atau, "^Atau_"),
    pedC = str_remove(pedC, "^pedC_"),
    pedD = str_remove(pedD, "^pedD_"),
    Zmay = str_remove(Zmay, "^Zmay_")
  )

# =========================================================
# 2. Loop over thresholds
# =========================================================
for (thr in THRESHOLDS) {

  message("Processing ", thr)

  # -----------------------------
  # Read species data
  # -----------------------------
  Atau <- read_tsv(
    paste0("Atau_", thr, "_core_gene_deleterious.tsv"),
    show_col_types = FALSE
  ) |>
    select(gene_id, cds_len, cds_snp_total, cds_deleterious_snp) |>
    rename_with(~ paste0("Atau_", .x), -gene_id)

  pedC <- read_tsv(
    paste0("pedC_", thr, "_gene_deleterious_stats.tsv"),
    show_col_types = FALSE
  ) |>
    select(gene_id, cds_len, cds_snp_total, cds_deleterious_snp) |>
    rename_with(~ paste0("pedC_", .x), -gene_id)

  pedD <- read_tsv(
    paste0("pedD_", thr, "_gene_deleterious_stats.tsv"),
    show_col_types = FALSE
  ) |>
    select(gene_id, cds_len, cds_snp_total, cds_deleterious_snp) |>
    rename_with(~ paste0("pedD_", .x), -gene_id)

  Zmay <- read_tsv(
    paste0("zmay_", thr, ".gene_deleterious_stats.core1to1.tsv"),
    show_col_types = FALSE
  ) |>
    select(gene_id, cds_len, cds_snp_total, cds_deleterious_snp) |>
    rename_with(~ paste0("Zmay_", .x), -gene_id)

  # -----------------------------
  # Merge
  # -----------------------------
  df <- pan_clean |>
    left_join(Atau, by = c("Atau" = "gene_id")) |>
    left_join(pedC, by = c("pedC" = "gene_id")) |>
    left_join(pedD, by = c("pedD" = "gene_id")) |>
    left_join(Zmay, by = c("Zmay" = "gene_id"))

  # -----------------------------
  # Calculate metrics
  # -----------------------------
  df_metrics <- df |>
    mutate(
      ped_cds_len = pedC_cds_len + pedD_cds_len,
      ped_cds_snp = pedC_cds_snp_total + pedD_cds_snp_total,
      ped_cds_del = pedC_cds_deleterious_snp + pedD_cds_deleterious_snp,

      Atau_cds_ratio = Atau_cds_snp_total / Atau_cds_len,
      Zmay_cds_ratio = Zmay_cds_snp_total / Zmay_cds_len,
      ped_cds_ratio  = ped_cds_snp / ped_cds_len,

      Atau_del_ratio = if_else(
        Atau_cds_snp_total == 0, 0,
        Atau_cds_deleterious_snp / Atau_cds_snp_total
      ),
      Zmay_del_ratio = if_else(
        Zmay_cds_snp_total == 0, 0,
        Zmay_cds_deleterious_snp / Zmay_cds_snp_total
      ),
      ped_del_ratio = if_else(
        ped_cds_snp == 0, 0,
        ped_cds_del / ped_cds_snp
      )
    )

  # =========================================================
  # Long format
  # =========================================================
  df_long <- df_metrics |>
    select(
      SG_ID,
      ped_cds_ratio, Atau_cds_ratio, Zmay_cds_ratio,
      ped_del_ratio, Atau_del_ratio, Zmay_del_ratio
    ) |>
    pivot_longer(
      -SG_ID,
      names_to = c("species", "metric"),
      names_pattern = "(ped|Atau|Zmay)_(cds_ratio|del_ratio)",
      values_to = "value"
    )

  # =========================================================
  # Plot function (ggsignif)
  # =========================================================
  plot_with_signif <- function(df_plot, metric_name, ylab, outfile) {

    stat_df <- paired_wilcox_for_plot(df_plot)

    y_max <- max(df_plot$value, na.rm = TRUE)
    step <- y_max * 0.08

    signif_df <- stat_df |>
      mutate(
        xmin = group1,
        xmax = group2,
        y_position = y_max + row_number() * step,
        annotations = label
      )

    p <- ggplot(df_plot, aes(x = species, y = value)) +
      geom_boxplot(outlier.shape = NA) +
      geom_jitter(width = 0.15, alpha = 0.4, size = 0.8) +
      geom_signif(
        data = signif_df,
        manual = TRUE,
        aes(
          xmin = xmin,
          xmax = xmax,
          annotations = annotations,
          y_position = y_position
        ),
        textsize = 4
      ) +
      labs(
        title = paste(metric_name, "(", thr, ")"),
        x = NULL,
        y = ylab
      ) +
      theme_bw()

    ggsave(outfile, p, width = 5, height = 5)
  }

  # =========================================================
  # CDS ratio
  # =========================================================
  plot_with_signif(
    df_long |> filter(metric == "cds_ratio"),
    "CDS SNP ratio",
    "CDS SNP / CDS length",
    paste0("SG_", thr, "_cds_ratio_with_significance.pdf")
  )

  # =========================================================
  # Deleterious ratio
  # =========================================================
  plot_with_signif(
    df_long |> filter(metric == "del_ratio"),
    "Deleterious SNP ratio",
    "Deleterious SNP / CDS SNP",
    paste0("SG_", thr, "_deleterious_ratio_with_significance.pdf")
  )
}
