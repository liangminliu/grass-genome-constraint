#!/bin/bash
#SBATCH --job-name=ped_PolVeg_GERP
#SBATCH --partition=parallel
#SBATCH --nodes=1
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=10
#SBATCH --array=1-4
#SBATCH --output=logs/ped_PolVeg_GERP_%A_%a.out
#SBATCH --error=logs/ped_PolVeg_GERP_%A_%a.err

set -euo pipefail
module load bedtools 2>/dev/null || true

############################################################
# 0. Inputs
############################################################
INTERSECT_ROOT="intersect_results"
GENE_BED="genes.bed"
CDS_BED="CDS_jcvi.bed"

POL_LIST="Ped_Pol.list"
VEG_LIST="Ped_Veg.list"

OUT_ROOT="ped_PolVeg_GERP_stats"
mkdir -p logs "${OUT_ROOT}"

############################################################
# 1. Thresholds
############################################################
CLASSES=("gerp_gt0" "gerp_gt2" "gerp_gt4" "gerp_gt6")

IDX=$((SLURM_ARRAY_TASK_ID - 1))
if [[ ${IDX} -lt 0 || ${IDX} -ge ${#CLASSES[@]} ]]; then
  echo "[ERROR] Bad SLURM_ARRAY_TASK_ID=${SLURM_ARRAY_TASK_ID}" >&2
  exit 1
fi
CLASS="${CLASSES[$IDX]}"
echo "[INFO] Threshold = ${CLASS}"

############################################################
# 2. Check inputs
############################################################
for f in "${GENE_BED}" "${CDS_BED}" "${POL_LIST}" "${VEG_LIST}"; do
  if [[ ! -s "${f}" ]]; then
    echo "[ERROR] Missing or empty file: ${f}" >&2
    exit 1
  fi
done

############################################################
# 3. Target sets
############################################################
TARGET_NAMES=("Ped_Pol" "Ped_Veg")
TARGET_FILES=("${POL_LIST}" "${VEG_LIST}")

for i in "${!TARGET_NAMES[@]}"; do
  SET_NAME="${TARGET_NAMES[$i]}"
  SET_FILE="${TARGET_FILES[$i]}"

  echo
  echo "=========================================================="
  echo "[INFO] Processing target set = ${SET_NAME}"
  echo "[INFO] Target file = ${SET_FILE}"
  echo "=========================================================="

  SET_OUT_DIR="${OUT_ROOT}/${CLASS}/${SET_NAME}"
  mkdir -p "${SET_OUT_DIR}"

  ##########################################################
  # 3.1 Clean target gene list
  ##########################################################
  TARGET_ALL="${SET_OUT_DIR}/${SET_NAME}.all_genes.txt"
  awk '
    NF > 0 {
      g=$1
      gsub(/\r/, "", g)
      sub(/^[[:space:]]+/, "", g)
      sub(/[[:space:]]+$/, "", g)
      if (g != "") print g
    }
  ' "${SET_FILE}" | sort -u > "${TARGET_ALL}"

  echo "[INFO] ${SET_NAME} all genes = $(wc -l < "${TARGET_ALL}")"

  ##########################################################
  # 3.2 Split target genes into pedC / pedD
  #     direct rule:
  #       Ped..C* -> pedC
  #       Ped..D* -> pedD
  ##########################################################
  TARGET_C="${SET_OUT_DIR}/${SET_NAME}.pedC.genes.txt"
  TARGET_D="${SET_OUT_DIR}/${SET_NAME}.pedD.genes.txt"
  TARGET_BAD="${SET_OUT_DIR}/${SET_NAME}.unrecognized_gene_ids.txt"

  : > "${TARGET_C}"
  : > "${TARGET_D}"
  : > "${TARGET_BAD}"

  awk '
    {
      g=$1
      gsub(/\r/, "", g)
      sub(/^[[:space:]]+/, "", g)
      sub(/[[:space:]]+$/, "", g)

      if (g ~ /^Ped[0-9]+C/) { print g > cfile; next }
      if (g ~ /^Ped[0-9]+D/) { print g > dfile; next }

      print g > badfile
    }
  ' cfile="${TARGET_C}" dfile="${TARGET_D}" badfile="${TARGET_BAD}" "${TARGET_ALL}"

  echo "[INFO] ${SET_NAME} pedC genes = $(wc -l < "${TARGET_C}")"
  echo "[INFO] ${SET_NAME} pedD genes = $(wc -l < "${TARGET_D}")"
  echo "[INFO] ${SET_NAME} unrecognized IDs = $(wc -l < "${TARGET_BAD}")"

  if [[ -s "${TARGET_BAD}" ]]; then
    echo "[WARN] First 10 unrecognized IDs:"
    head -10 "${TARGET_BAD}" | sed 's/^/[WARN]   /'
  fi

  ##########################################################
  # 4. Process by subgenome
  ##########################################################
  for SUB in pedC pedD; do
    echo
    echo "[INFO] Subgenome = ${SUB}"

    if [[ "${SUB}" == "pedC" ]]; then
      TARGET_LIST="${TARGET_C}"
    else
      TARGET_LIST="${TARGET_D}"
    fi

    OUT_DIR="${SET_OUT_DIR}/${SUB}"
    BED_DIR="${OUT_DIR}/bed_files"
    STAT_DIR="${OUT_DIR}/stats"
    mkdir -p "${BED_DIR}" "${STAT_DIR}"

    N_TARGET=$(wc -l < "${TARGET_LIST}")
    if [[ "${N_TARGET}" -eq 0 ]]; then
      echo "[WARN] No target genes for ${SET_NAME} ${SUB}; skip."
      continue
    fi

    echo "[INFO] ${SET_NAME} ${SUB} target genes = ${N_TARGET}"

    ########################################################
    # 4.1 Target gene / target CDS bed
    ########################################################
    TARGET_GENE_BED="${BED_DIR}/${SET_NAME}_${SUB}_genes.bed"
    TARGET_CDS_BED="${BED_DIR}/${SET_NAME}_${SUB}_CDS.bed"

    awk 'BEGIN{OFS="\t"}{
      gene=$4
      gsub(/\r/, "", gene)
      sub(/^[[:space:]]+/, "", gene)
      sub(/[[:space:]]+$/, "", gene)
      print $1,$2,$3,gene
    }' "${GENE_BED}" \
    | awk 'NR==FNR{a[$1]=1; next} a[$4]' "${TARGET_LIST}" - \
    > "${TARGET_GENE_BED}"

    awk 'BEGIN{OFS="\t"}{
      gene=$4
      gsub(/\r/, "", gene)
      sub(/^[[:space:]]+/, "", gene)
      sub(/[[:space:]]+$/, "", gene)
      sub(/:.*/, "", gene)
      sub(/\..*/, "", gene)
      print $1,$2,$3,gene
    }' "${CDS_BED}" \
    | awk 'NR==FNR{a[$1]=1; next} a[$4]' "${TARGET_LIST}" - \
    > "${TARGET_CDS_BED}"

    echo "[INFO] ${SET_NAME} ${SUB} target gene BED lines = $(wc -l < "${TARGET_GENE_BED}")"
    echo "[INFO] ${SET_NAME} ${SUB} target CDS  BED lines = $(wc -l < "${TARGET_CDS_BED}")"

    ########################################################
    # 4.2 Genome-wide conserved sites for this threshold/sub
    ########################################################
    GENE_GERP_ALL="${INTERSECT_ROOT}/${CLASS}/${SUB}_*.genes.intersect.bed"
    CDS_GERP_ALL="${INTERSECT_ROOT}/${CLASS}/${SUB}_*.CDS_jcvi.intersect.bed"

    if ! ls ${GENE_GERP_ALL} >/dev/null 2>&1; then
      echo "[ERROR] Missing ${GENE_GERP_ALL}" >&2
      exit 1
    fi
    if ! ls ${CDS_GERP_ALL} >/dev/null 2>&1; then
      echo "[ERROR] Missing ${CDS_GERP_ALL}" >&2
      exit 1
    fi

    ########################################################
    # 4.3 Target conserved sites = genome-wide conserved sites
    #     intersect target gene/CDS bed
    ########################################################
    TARGET_GENE_CONS="${BED_DIR}/${SET_NAME}_${SUB}_gene_conserved_sites.bed"
    TARGET_CDS_CONS="${BED_DIR}/${SET_NAME}_${SUB}_CDS_conserved_sites.bed"

    bedtools intersect -wa -a ${GENE_GERP_ALL} -b "${TARGET_GENE_BED}" \
      > "${TARGET_GENE_CONS}"

    bedtools intersect -wa -a ${CDS_GERP_ALL} -b "${TARGET_CDS_BED}" \
      > "${TARGET_CDS_CONS}"

    ########################################################
    # 4.4 Convert conserved-site BED to gene-level 4-col BED
    ########################################################
    TARGET_GENE_SITE_BED="${BED_DIR}/${SET_NAME}_${SUB}_gene_sites.gene.bed"
    TARGET_CDS_SITE_BED="${BED_DIR}/${SET_NAME}_${SUB}_CDS_sites.gene.bed"

    awk 'BEGIN{OFS="\t"}{
      gene=$(NF-2)
      gsub(/\r/, "", gene)
      sub(/^[[:space:]]+/, "", gene)
      sub(/[[:space:]]+$/, "", gene)
      print $1,$2,$3,gene
    }' "${TARGET_GENE_CONS}" > "${TARGET_GENE_SITE_BED}"

    awk 'BEGIN{OFS="\t"}{
      gene=$(NF-2)
      gsub(/\r/, "", gene)
      sub(/^[[:space:]]+/, "", gene)
      sub(/[[:space:]]+$/, "", gene)
      sub(/:.*/, "", gene)
      sub(/\..*/, "", gene)
      print $1,$2,$3,gene
    }' "${TARGET_CDS_CONS}" > "${TARGET_CDS_SITE_BED}"

    ########################################################
    # 4.5 Length stats
    ########################################################
    awk 'BEGIN{OFS="\t"}{
      len[$4] += ($3 - $2)
    } END{
      for (g in len) print g, len[g]
    }' "${TARGET_GENE_BED}" \
    | sort -k1,1 > "${STAT_DIR}/gene_length.tsv"

    if [[ -s "${TARGET_CDS_BED}" ]]; then
      sort -k4,4 -k1,1 -k2,2n "${TARGET_CDS_BED}" \
      | awk 'BEGIN{OFS="\t"}
        NR==1{
          cg=$4; cchr=$1; cs=$2; ce=$3; sum=0; next
        }
        {
          g=$4; chr=$1; s=$2; e=$3
          if (g != cg || chr != cchr) {
            sum += (ce - cs)
            print cg, sum
            cg=g; cchr=chr; cs=s; ce=e; sum=0
            next
          }
          if (s <= ce) {
            if (e > ce) ce=e
          } else {
            sum += (ce - cs)
            cs=s; ce=e
          }
        }
        END{
          if (NR > 0) {
            sum += (ce - cs)
            print cg, sum
          }
        }' \
      | sort -k1,1 > "${STAT_DIR}/cds_length.tsv"
    else
      : > "${STAT_DIR}/cds_length.tsv"
    fi

    ########################################################
    # 4.6 Site counts (dedup by chr,start,end,gene)
    ########################################################
    if [[ -s "${TARGET_GENE_SITE_BED}" ]]; then
      awk 'BEGIN{OFS="\t"}{
        key = $1"\t"$2"\t"$3"\t"$4
        if (!seen[key]++) c[$4]++
      } END{
        for (g in c) print g, c[g]
      }' "${TARGET_GENE_SITE_BED}" \
      | sort -k1,1 > "${STAT_DIR}/gene_site_count.tsv"
    else
      : > "${STAT_DIR}/gene_site_count.tsv"
    fi

    if [[ -s "${TARGET_CDS_SITE_BED}" ]]; then
      awk 'BEGIN{OFS="\t"}{
        key = $1"\t"$2"\t"$3"\t"$4
        if (!seen[key]++) c[$4]++
      } END{
        for (g in c) print g, c[g]
      }' "${TARGET_CDS_SITE_BED}" \
      | sort -k1,1 > "${STAT_DIR}/cds_site_count.tsv"
    else
      : > "${STAT_DIR}/cds_site_count.tsv"
    fi

    ########################################################
    # 4.7 Merge per-gene stats
    ########################################################
    join -t $'\t' -a 1 -e 0 -o 1.1,1.2,2.2 \
      "${STAT_DIR}/gene_length.tsv" "${STAT_DIR}/cds_length.tsv" \
      > "${STAT_DIR}/tmp_len.tsv"

    join -t $'\t' -a 1 -e 0 -o 1.1,1.2,2.2 \
      "${STAT_DIR}/gene_length.tsv" "${STAT_DIR}/gene_site_count.tsv" \
      > "${STAT_DIR}/tmp_gene_site.tsv"

    join -t $'\t' -a 1 -e 0 -o 1.1,1.2,2.2 \
      "${STAT_DIR}/gene_length.tsv" "${STAT_DIR}/cds_site_count.tsv" \
      > "${STAT_DIR}/tmp_cds_site.tsv"

    join -t $'\t' -a 1 -e 0 \
      "${STAT_DIR}/tmp_len.tsv" "${STAT_DIR}/tmp_gene_site.tsv" \
      > "${STAT_DIR}/tmp_len_gene.tsv"

    join -t $'\t' -a 1 -e 0 \
      "${STAT_DIR}/tmp_len_gene.tsv" "${STAT_DIR}/tmp_cds_site.tsv" \
    | awk 'BEGIN{
        OFS="\t";
        print "gene_id","gene_len","cds_len","gene_sites","gene_pct","cds_sites","cds_pct"
      }{
        gid=$1
        gl=$2+0
        cl=$3+0
        gs=$5+0
        cs=$7+0
        gp=(gl>0)?gs/gl*100:0
        cp=(cl>0)?cs/cl*100:0
        printf "%s\t%d\t%d\t%d\t%.6f\t%d\t%.6f\n", gid, gl, cl, gs, gp, cs, cp
      }' \
    > "${OUT_DIR}/per_gene_stats.tsv"

    rm -f \
      "${STAT_DIR}/tmp_len.tsv" \
      "${STAT_DIR}/tmp_gene_site.tsv" \
      "${STAT_DIR}/tmp_cds_site.tsv" \
      "${STAT_DIR}/tmp_len_gene.tsv"

    ########################################################
    # 4.8 Minimal sanity checks
    ########################################################
    echo "[INFO] ${SET_NAME} ${SUB} ${CLASS} gene conserved lines = $(wc -l < "${TARGET_GENE_SITE_BED}")"
    echo "[INFO] ${SET_NAME} ${SUB} ${CLASS} cds  conserved lines = $(wc -l < "${TARGET_CDS_SITE_BED}")"
    echo "[INFO] ${SET_NAME} ${SUB} ${CLASS} gene_site_count entries = $(wc -l < "${STAT_DIR}/gene_site_count.tsv")"
    echo "[INFO] ${SET_NAME} ${SUB} ${CLASS} cds_site_count  entries = $(wc -l < "${STAT_DIR}/cds_site_count.tsv")"
    echo "[INFO] ${SET_NAME} ${SUB} ${CLASS} output rows = $(tail -n +2 "${OUT_DIR}/per_gene_stats.tsv" | wc -l)"
  done
done

echo "[INFO] DONE ${CLASS}"