#!/usr/bin/env Rscript

suppressPackageStartupMessages({
  library(dplyr)
  library(ggplot2)
  library(ggsignif)
  library(patchwork)
  library(scales)
  library(grid)
})

## =========================================================
## Re-plot existing ped deleterious density results
## Raw deleterious SNPs per Mb
## No recalculation of original metrics
## =========================================================

OUTDIR    <- "ped_gene_class_snp_deleterious_density_by_SG"
TABLE_DIR <- file.path(OUTDIR, "tables")
STAT_DIR  <- file.path(OUTDIR, "stats")
FIG_DIR   <- file.path(OUTDIR, "figures")

dir.create(FIG_DIR, recursive = TRUE, showWarnings = FALSE)
dir.create(TABLE_DIR, recursive = TRUE, showWarnings = FALSE)

THRESHOLDS <- c("gt2", "gt4", "gt6")
DATA_TYPES <- c("ALL", "SNP0", "SNPpos")

class_order <- c("Core", "Syntenic", "Nonsyntenic")

class_full_names <- c(
  "Core"        = "strict_perfect_copy_syntenic_core_SG",
  "Syntenic"    = "broad_syntenic_excluding_strict_core_gene",
  "Nonsyntenic" = "candidate_nonsyntenic_private_gene"
)

class_fill <- c(
  "Core"        = "#96CCEA",
  "Syntenic"    = "#B2A3DD",
  "Nonsyntenic" = "#ED949A"
)

show_ns_lines <- FALSE

dt_label_map <- c(
  "ALL"    = "ALL",
  "SNP0"   = "SNP = 0",
  "SNPpos" = "SNP > 0"
)

thr_label_map <- c(
  "gt2" = "GERP > 2",
  "gt4" = "GERP > 4",
  "gt6" = "GERP > 6"
)

panel_tag_map <- c(
  "gt2" = "A",
  "gt4" = "B",
  "gt6" = "C"
)

## =========================================================
## Basic I/O
## =========================================================

read_tsv_base <- function(fp) {
  if (!file.exists(fp)) {
    stop("Missing file: ", fp, call. = FALSE)
  }

  read.delim(
    fp,
    header = TRUE,
    sep = "\t",
    stringsAsFactors = FALSE,
    check.names = FALSE,
    quote = "",
    comment.char = ""
  )
}

write_tsv_base <- function(df, fp) {
  write.table(
    df,
    fp,
    sep = "\t",
    quote = FALSE,
    row.names = FALSE,
    col.names = TRUE
  )
}

safe_ggsave <- function(filename, plot, width, height, dpi = NULL) {
  if (grepl("\\.pdf$", filename, ignore.case = TRUE)) {
    ok <- FALSE

    try({
      ggsave(
        filename = filename,
        plot = plot,
        width = width,
        height = height,
        device = cairo_pdf
      )
      ok <- TRUE
    }, silent = TRUE)

    if (!ok) {
      ggsave(
        filename = filename,
        plot = plot,
        width = width,
        height = height
      )
    }
  } else {
    ggsave(
      filename = filename,
      plot = plot,
      width = width,
      height = height,
      dpi = dpi
    )
  }
}

## =========================================================
## Theme
## =========================================================

theme_mbe <- function() {
  theme_classic(base_size = 16) +
    theme(
      plot.title = element_text(
        size = 13.5,
        face = "plain",
        hjust = 0.5,
        margin = margin(b = 8)
      ),
      axis.text.x = element_text(
        size = 13.5,
        color = "black",
        margin = margin(t = 5)
      ),
      axis.text.y = element_text(
        size = 13,
        color = "black"
      ),
      axis.title.y = element_text(
        size = 15,
        color = "black",
        margin = margin(r = 8)
      ),
      axis.title.x = element_blank(),
      axis.line = element_line(
        color = "black",
        linewidth = 0.55
      ),
      axis.ticks = element_line(
        color = "black",
        linewidth = 0.55
      ),
      axis.ticks.length = unit(2.2, "pt"),
      panel.grid.major.y = element_line(
        color = "#E9E9E9",
        linewidth = 0.35
      ),
      panel.grid.minor.y = element_blank(),
      panel.grid.major.x = element_blank(),
      panel.grid.minor.x = element_blank(),
      panel.border = element_rect(
        fill = NA,
        color = "black",
        linewidth = 0.75
      ),
      plot.margin = margin(12, 13, 10, 13)
    )
}

## =========================================================
## Helper functions
## =========================================================

choose_exponent <- function(x) {
  x <- x[is.finite(x)]

  if (length(x) == 0) return(0)

  xmax <- max(x, na.rm = TRUE)

  if (!is.finite(xmax) || xmax <= 0) {
    return(0)
  }

  floor(log10(xmax))
}

make_scaled_breaks <- function(ymax_scaled, n = 5) {
  if (!is.finite(ymax_scaled) || ymax_scaled <= 0) {
    return(c(0, 1))
  }

  br <- pretty(c(0, ymax_scaled), n = n)
  br <- br[br >= 0]

  if (length(br) < 2) {
    br <- c(0, ymax_scaled)
  }

  br
}

make_y_title_expr <- function(exp10) {
  if (exp10 == 0) {
    return(expression("CDS deleterious SNPs per Mb"))
  } else {
    return(bquote("CDS deleterious SNPs per Mb (" %*% 10^.(exp10) * ")"))
  }
}

## =========================================================
## Read existing metric tables
## =========================================================

read_metric_one <- function(thr, dt) {
  fp <- file.path(
    TABLE_DIR,
    paste0(
      "ped_gene_class_",
      thr,
      "_",
      dt,
      "_SNP_deleterious_density_metrics.tsv"
    )
  )

  df <- read_tsv_base(fp)

  required_cols <- c(
    "threshold",
    "gene_class",
    "cds_len",
    "cds_snp_total",
    "cds_deleterious_snp",
    "cds_deleterious_density"
  )

  miss <- setdiff(required_cols, colnames(df))

  if (length(miss) > 0) {
    stop(
      "Missing columns in ",
      fp,
      ": ",
      paste(miss, collapse = ", "),
      call. = FALSE
    )
  }

  df %>%
    mutate(
      threshold = thr,
      data_type = dt,
      gene_class = factor(gene_class, levels = class_order),

      cds_len = suppressWarnings(as.numeric(cds_len)),
      cds_snp_total = suppressWarnings(as.numeric(cds_snp_total)),
      cds_deleterious_snp = suppressWarnings(as.numeric(cds_deleterious_snp)),
      cds_deleterious_density = suppressWarnings(as.numeric(cds_deleterious_density)),

      ## Original density is deleterious SNPs per bp.
      ## Convert to deleterious SNPs per Mb.
      cds_deleterious_perMb = cds_deleterious_density * 1e6
    ) %>%
    filter(
      !is.na(gene_class),
      is.finite(cds_deleterious_density),
      is.finite(cds_deleterious_perMb)
    )
}

metrics_all <- bind_rows(
  lapply(THRESHOLDS, function(thr) {
    bind_rows(
      lapply(DATA_TYPES, function(dt) {
        read_metric_one(thr, dt)
      })
    )
  })
)

cat("[INFO] Loaded metric rows:\n")
print(table(metrics_all$data_type, metrics_all$threshold))

## =========================================================
## Read existing statistical results
## =========================================================

stat_fp_all <- file.path(
  STAT_DIR,
  "ped_gene_class_ALL_thresholds_ALL_data_types_stats.tsv"
)

if (file.exists(stat_fp_all)) {
  stats_all <- read_tsv_base(stat_fp_all)
} else {
  stats_all <- bind_rows(
    lapply(THRESHOLDS, function(thr) {
      bind_rows(
        lapply(DATA_TYPES, function(dt) {
          fp <- file.path(
            STAT_DIR,
            paste0(
              "ped_gene_class_",
              thr,
              "_",
              dt,
              "_SNP_deleterious_density_stats.tsv"
            )
          )

          read_tsv_base(fp)
        })
      )
    })
  )
}

stats_den <- stats_all %>%
  filter(
    threshold %in% THRESHOLDS,
    data_type %in% DATA_TYPES,
    metric == "cds_deleterious_density"
  )

## =========================================================
## Keep zero-fraction summary table for ALL
## =========================================================

zero_summary_all <- metrics_all %>%
  filter(data_type == "ALL") %>%
  group_by(threshold, gene_class) %>%
  summarise(
    n_units = n(),
    n_zero_deleterious = sum(cds_deleterious_snp == 0, na.rm = TRUE),
    prop_zero_deleterious = n_zero_deleterious / n_units,
    median_deleterious_perMb = median(cds_deleterious_perMb, na.rm = TRUE),
    mean_deleterious_perMb = mean(cds_deleterious_perMb, na.rm = TRUE),
    .groups = "drop"
  )

write_tsv_base(
  zero_summary_all,
  file.path(
    TABLE_DIR,
    "ped_gene_class_ALL_deleterious_density_zero_fraction.replot.tsv"
  )
)

zero_summary_each_dt <- metrics_all %>%
  group_by(data_type, threshold, gene_class) %>%
  summarise(
    n_units = n(),
    n_zero_deleterious = sum(cds_deleterious_snp == 0, na.rm = TRUE),
    prop_zero_deleterious = n_zero_deleterious / n_units,
    median_deleterious_perMb = median(cds_deleterious_perMb, na.rm = TRUE),
    mean_deleterious_perMb = mean(cds_deleterious_perMb, na.rm = TRUE),
    .groups = "drop"
  )

write_tsv_base(
  zero_summary_each_dt,
  file.path(
    TABLE_DIR,
    "ped_gene_class_all_data_types_deleterious_density_zero_fraction.replot.tsv"
  )
)

cat("[INFO] Zero-fraction summary for ALL:\n")
print(zero_summary_all)

## =========================================================
## Significance brackets
## =========================================================

make_sig_df <- function(df_plot, stat_tbl, y_col_scaled) {
  inv_map <- setNames(names(class_full_names), class_full_names)

  sig_df <- stat_tbl %>%
    filter(
      !is.na(group1),
      !is.na(group2),
      !is.na(label)
    ) %>%
    mutate(
      group1_plot = inv_map[group1],
      group2_plot = inv_map[group2]
    ) %>%
    filter(
      !is.na(group1_plot),
      !is.na(group2_plot)
    )

  if (!show_ns_lines) {
    sig_df <- sig_df %>% filter(label != "ns")
  }

  if (nrow(sig_df) == 0 || nrow(df_plot) == 0) {
    return(sig_df[0, ])
  }

  y_max <- max(df_plot[[y_col_scaled]], na.rm = TRUE)
  y_min <- min(df_plot[[y_col_scaled]], na.rm = TRUE)
  y_range <- y_max - y_min

  if (!is.finite(y_range) || y_range <= 0) {
    y_range <- ifelse(
      is.finite(y_max) && y_max > 0,
      0.5 * y_max,
      1
    )
  }

  sig_df %>%
    mutate(
      group1_plot = factor(group1_plot, levels = class_order),
      group2_plot = factor(group2_plot, levels = class_order)
    ) %>%
    arrange(group1_plot, group2_plot) %>%
    mutate(
      y_position = y_max + seq(
        from = 0.07 * y_range,
        by = 0.07 * y_range,
        length.out = n()
      )
    )
}

## =========================================================
## Plot one panel
## Bottom negative padding is used to lift violin/boxplots above x-axis.
## Breaks still start from zero; no negative tick is displayed.
## =========================================================

plot_one_panel <- function(df_plot,
                           stat_tbl,
                           exp10,
                           panel_title) {

  scale_factor <- 10^exp10

  plot_df <- df_plot %>%
    mutate(
      plot_value = cds_deleterious_perMb / scale_factor
    )

  sig_df <- make_sig_df(
    df_plot = plot_df,
    stat_tbl = stat_tbl,
    y_col_scaled = "plot_value"
  )

  y_max <- max(plot_df$plot_value, na.rm = TRUE)
  y_min <- min(plot_df$plot_value, na.rm = TRUE)
  y_range <- y_max - y_min

  if (!is.finite(y_range) || y_range <= 0) {
    y_range <- ifelse(
      is.finite(y_max) && y_max > 0,
      0.5 * y_max,
      1
    )
  }

  if (nrow(sig_df) > 0) {
    y_limit <- max(sig_df$y_position, na.rm = TRUE) + 0.045 * y_range
  } else {
    y_limit <- y_max + 0.08 * y_range
  }

  if (!is.finite(y_limit) || y_limit <= 0) {
    y_limit <- 1
  }

  ## Bottom padding: lift violin and boxplot away from x-axis.
  lower_pad <- 0.065 * y_limit
  lower_limit <- -lower_pad
  upper_limit <- y_limit

  breaks_scaled <- make_scaled_breaks(upper_limit, n = 5)
  breaks_scaled <- breaks_scaled[
    breaks_scaled >= 0 &
      breaks_scaled <= upper_limit * 1.001
  ]

  ggplot(
    plot_df,
    aes(
      x = gene_class,
      y = plot_value,
      fill = gene_class
    )
  ) +
    geom_violin(
      width = 0.62,
      scale = "width",
      trim = TRUE,
      color = "#5F5F5F",
      linewidth = 0.55,
      alpha = 0.85
    ) +
    geom_boxplot(
      width = 0.105,
      coef = 0.35,
      fill = "white",
      color = "black",
      linewidth = 0.75,
      outlier.shape = NA
    ) +
    {
      if (nrow(sig_df) > 0) {
        geom_signif(
          data = sig_df,
          aes(
            xmin = group1_plot,
            xmax = group2_plot,
            annotations = label,
            y_position = y_position
          ),
          manual = TRUE,
          inherit.aes = FALSE,
          textsize = 3.6,
          tip_length = 0.012,
          linewidth = 0.65
        )
      }
    } +
    scale_fill_manual(
      values = class_fill,
      guide = "none"
    ) +
    scale_x_discrete(
      limits = class_order,
      labels = class_order
    ) +
    scale_y_continuous(
      limits = c(lower_limit, upper_limit),
      breaks = breaks_scaled,
      labels = function(x) {
        format(x, trim = TRUE, scientific = FALSE)
      },
      expand = expansion(mult = c(0, 0))
    ) +
    labs(
      x = NULL,
      y = make_y_title_expr(exp10),
      title = panel_title
    ) +
    coord_cartesian(clip = "off") +
    theme_mbe()
}

## =========================================================
## Main plotting loop
## Three figures will be generated:
## ALL, SNP0, SNPpos
## =========================================================

for (dt in DATA_TYPES) {

  df_dt_all <- metrics_all %>%
    filter(data_type == dt)

  ## Use one common exponent for each 3-panel figure.
  exp10_common <- choose_exponent(df_dt_all$cds_deleterious_perMb)

  p_list <- list()

  for (thr in THRESHOLDS) {
    df_thr <- metrics_all %>%
      filter(
        data_type == dt,
        threshold == thr
      )

    stat_thr <- stats_den %>%
      filter(
        data_type == dt,
        threshold == thr
      )

    panel_title <- paste0(
      panel_tag_map[[thr]],
      "  ",
      thr_label_map[[thr]],
      " (",
      dt_label_map[[dt]],
      ")"
    )

    p_list[[thr]] <- plot_one_panel(
      df_plot = df_thr,
      stat_tbl = stat_thr,
      exp10 = exp10_common,
      panel_title = panel_title
    )
  }

  fig_dt <- p_list[["gt2"]] + p_list[["gt4"]] + p_list[["gt6"]] +
    plot_layout(ncol = 3, guides = "collect") +
    plot_annotation(
      title = "Raw CDS deleterious density",
      theme = theme(
        plot.title = element_text(
          size = 16,
          face = "plain",
          hjust = 0.5,
          margin = margin(b = 4)
        )
      )
    )

  out_pdf <- file.path(
    FIG_DIR,
    paste0(
      "Fig_ped_gene_class_",
      dt,
      "_deleterious_density_perMb_raw_scientific.replot.pdf"
    )
  )

  out_png <- file.path(
    FIG_DIR,
    paste0(
      "Fig_ped_gene_class_",
      dt,
      "_deleterious_density_perMb_raw_scientific.replot.png"
    )
  )

  safe_ggsave(
    out_pdf,
    fig_dt,
    width = 14.2,
    height = 5.05
  )

  safe_ggsave(
    out_png,
    fig_dt,
    width = 14.2,
    height = 5.05,
    dpi = 300
  )

  cat("[DONE] ", dt, " figure:\n", sep = "")
  cat("  ", out_pdf, "\n", sep = "")
  cat("  ", out_png, "\n", sep = "")
}

cat("[DONE] Zero-fraction table kept:\n")
cat(
  "  ",
  file.path(
    TABLE_DIR,
    "ped_gene_class_ALL_deleterious_density_zero_fraction.replot.tsv"
  ),
  "\n",
  sep = ""
)

cat("[DONE] Additional zero-fraction table:\n")
cat(
  "  ",
  file.path(
    TABLE_DIR,
    "ped_gene_class_all_data_types_deleterious_density_zero_fraction.replot.tsv"
  ),
  "\n",
  sep = ""
)