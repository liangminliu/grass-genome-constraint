#!/usr/bin/env Rscript
suppressPackageStartupMessages({
  library(dplyr)
  library(readr)
  library(stringr)
  library(tidyr)
})

PAN_FILE <- "core_5sp_1to1.SG.pan"
THRESHOLDS <- c("gt2", "gt4", "gt6")

# =========================================================
# 1. Read pan file
# =========================================================
pan <- read_tsv(PAN_FILE, col_names = FALSE, show_col_types = FALSE)
colnames(pan) <- c(
  "SG_ID", "n_sp", "n_copy", "flag",
  "Atau", "Osat", "pedC", "pedD", "Zmay"
)

pan_clean <- pan |>
  transmute(
    SG_ID,
    Atau = str_remove(Atau, "^Atau_"),
    pedC = str_remove(pedC, "^pedC_"),
    pedD = str_remove(pedD, "^pedD_"),
    Zmay = str_remove(Zmay, "^Zmay_")
  )

# =========================================================
# Paired Wilcoxon summary function
# =========================================================
paired_wilcox_summary <- function(df) {

  get_stat <- function(x, y) {
    idx <- complete.cases(x, y)
    n <- sum(idx)

    if (n < 3) {
      return(tibble(
        median_group1 = NA_real_,
        median_group2 = NA_real_,
        median_diff   = NA_real_,
        n_pair        = n,
        p_value       = NA_real_
      ))
    }

    tibble(
      median_group1 = median(x[idx]),
      median_group2 = median(y[idx]),
      median_diff   = median(x[idx] - y[idx]),
      n_pair        = n,
      p_value       = wilcox.test(x[idx], y[idx], paired = TRUE)$p.value
    )
  }

  bind_rows(
    # SNP density
    get_stat(df$ped_cds_ratio,  df$Atau_cds_ratio)  |> mutate(comparison = "cds_ratio_ped_vs_Atau"),
    get_stat(df$ped_cds_ratio,  df$Zmay_cds_ratio)  |> mutate(comparison = "cds_ratio_ped_vs_Zmay"),
    get_stat(df$Atau_cds_ratio, df$Zmay_cds_ratio)  |> mutate(comparison = "cds_ratio_Atau_vs_Zmay"),

    # deleterious / SNP
    get_stat(df$ped_del_ratio,  df$Atau_del_ratio)  |> mutate(comparison = "del_ratio_ped_vs_Atau"),
    get_stat(df$ped_del_ratio,  df$Zmay_del_ratio)  |> mutate(comparison = "del_ratio_ped_vs_Zmay"),
    get_stat(df$Atau_del_ratio, df$Zmay_del_ratio)  |> mutate(comparison = "del_ratio_Atau_vs_Zmay"),

    # deleterious / site  (NEW)
    get_stat(df$ped_del_per_site,  df$Atau_del_per_site)  |> mutate(comparison = "del_per_site_ped_vs_Atau"),
    get_stat(df$ped_del_per_site,  df$Zmay_del_per_site)  |> mutate(comparison = "del_per_site_ped_vs_Zmay"),
    get_stat(df$Atau_del_per_site, df$Zmay_del_per_site)  |> mutate(comparison = "del_per_site_Atau_vs_Zmay")
  ) |>
    select(
      comparison,
      median_group1,
      median_group2,
      median_diff,
      n_pair,
      p_value
    )
}

# =========================================================
# 2. Loop over thresholds
# =========================================================
for (thr in THRESHOLDS) {

  message("Processing ", thr)

  Atau <- read_tsv(
    paste0("Atau_", thr, "_core_gene_deleterious.tsv"),
    show_col_types = FALSE
  ) |>
    select(gene_id, cds_len, cds_snp_total, cds_deleterious_snp) |>
    rename_with(~ paste0("Atau_", .x), -gene_id)

  pedC <- read_tsv(
    paste0("pedC_", thr, "_gene_deleterious_stats.tsv"),
    show_col_types = FALSE
  ) |>
    select(gene_id, cds_len, cds_snp_total, cds_deleterious_snp) |>
    rename_with(~ paste0("pedC_", .x), -gene_id)

  pedD <- read_tsv(
    paste0("pedD_", thr, "_gene_deleterious_stats.tsv"),
    show_col_types = FALSE
  ) |>
    select(gene_id, cds_len, cds_snp_total, cds_deleterious_snp) |>
    rename_with(~ paste0("pedD_", .x), -gene_id)

  Zmay <- read_tsv(
    paste0("zmay_", thr, ".gene_deleterious_stats.core1to1.tsv"),
    show_col_types = FALSE
  ) |>
    select(gene_id, cds_len, cds_snp_total, cds_deleterious_snp) |>
    rename_with(~ paste0("Zmay_", .x), -gene_id)

  df <- pan_clean |>
    left_join(Atau, by = c("Atau" = "gene_id")) |>
    left_join(pedC, by = c("pedC" = "gene_id")) |>
    left_join(pedD, by = c("pedD" = "gene_id")) |>
    left_join(Zmay, by = c("Zmay" = "gene_id"))

  df_metrics <- df |>
    mutate(
      ped_cds_len = pedC_cds_len + pedD_cds_len,
      ped_cds_snp = pedC_cds_snp_total + pedD_cds_snp_total,
      ped_cds_del = pedC_cds_deleterious_snp + pedD_cds_deleterious_snp,

      # SNP density
      Atau_cds_ratio = Atau_cds_snp_total / Atau_cds_len,
      Zmay_cds_ratio = Zmay_cds_snp_total / Zmay_cds_len,
      ped_cds_ratio  = ped_cds_snp / ped_cds_len,

      # deleterious / SNP
      Atau_del_ratio = if_else(Atau_cds_snp_total == 0, 0,
                               Atau_cds_deleterious_snp / Atau_cds_snp_total),
      Zmay_del_ratio = if_else(Zmay_cds_snp_total == 0, 0,
                               Zmay_cds_deleterious_snp / Zmay_cds_snp_total),
      ped_del_ratio  = if_else(ped_cds_snp == 0, 0,
                               ped_cds_del / ped_cds_snp),

      # NEW: deleterious / site
      Atau_del_per_site = Atau_cds_deleterious_snp / Atau_cds_len,
      Zmay_del_per_site = Zmay_cds_deleterious_snp / Zmay_cds_len,
      ped_del_per_site  = ped_cds_del / ped_cds_len
    )

  df_all <- df_metrics |>
    select(
      SG_ID,
      Atau_cds_snp_total, Zmay_cds_snp_total, ped_cds_snp,
      Atau_cds_ratio, Zmay_cds_ratio, ped_cds_ratio,
      Atau_del_ratio, Zmay_del_ratio, ped_del_ratio,
      Atau_del_per_site, Zmay_del_per_site, ped_del_per_site
    )

  df_snp_pos <- df_all |>
    filter(
      Atau_cds_snp_total > 0,
      Zmay_cds_snp_total > 0,
      ped_cds_snp > 0
    )

  df_snp0 <- df_all |>
    filter(
      Atau_cds_snp_total == 0 |
      Zmay_cds_snp_total == 0 |
      ped_cds_snp == 0
    )

  write_tsv(df_all,     paste0("SG_", thr, "_cds_and_deleterious_ratio_table.tsv"))
  write_tsv(df_snp_pos, paste0("SG_", thr, "_SNPpos_cds_and_deleterious_ratio_table.tsv"))
  write_tsv(df_snp0,    paste0("SG_", thr, "_SNP0_cds_and_deleterious_ratio_table.tsv"))

  write_tsv(paired_wilcox_summary(df_all),
            paste0("SG_", thr, "_ALL_paired_wilcox.tsv"))

  write_tsv(paired_wilcox_summary(df_snp_pos),
            paste0("SG_", thr, "_SNPpos_paired_wilcox.tsv"))

  write_tsv(paired_wilcox_summary(df_snp0),
            paste0("SG_", thr, "_SNP0_paired_wilcox.tsv"))
}
