#!/usr/bin/env Rscript

suppressPackageStartupMessages({
  library(dplyr)
  library(readr)
  library(ggplot2)
  library(tidyr)
  library(patchwork)
})

## =========================================================
## 1. Parameters
## =========================================================
thresholds  <- c("gt2", "gt4", "gt6")
panel_tags <- c("A", "B", "C")

PAN_FILE <- "core_5sp_1to1.SG.pan"

## =========================================================
## 2. Read orthogroup mapping (pedC / pedD)
## =========================================================
pan <- read_tsv(
  PAN_FILE,
  col_names = FALSE,
  show_col_types = FALSE
) %>%
  transmute(
    orthogroup = X1,
    pedC_gene  = sub("^pedC_", "", X7),
    pedD_gene  = sub("^pedD_", "", X8)
  )

## =========================================================
## 3. Build one panel
## =========================================================
build_panel <- function(threshold, panel_label) {

  file_C <- paste0(
    "2.1.ped/ped_target_gene_CDS_GERP_stats/gerp_",
    threshold, "/pedC/per_gene_stats.tsv"
  )
  file_D <- paste0(
    "2.1.ped/ped_target_gene_CDS_GERP_stats/gerp_",
    threshold, "/pedD/per_gene_stats.tsv"
  )

  df_C <- read_tsv(file_C, show_col_types = FALSE) %>%
    select(gene_id, cds_pct) %>%
    rename(pedC_gene = gene_id, cds_pct_C = cds_pct)

  df_D <- read_tsv(file_D, show_col_types = FALSE) %>%
    select(gene_id, cds_pct) %>%
    rename(pedD_gene = gene_id, cds_pct_D = cds_pct)

  ## ---------------------------------
  ## orthogroup-level pairing (KEY FIX)
  ## ---------------------------------
  df_pair <- pan %>%
    inner_join(df_C, by = "pedC_gene") %>%
    inner_join(df_D, by = "pedD_gene") %>%
    select(orthogroup, cds_pct_C, cds_pct_D) %>%
    filter(
      !is.na(cds_pct_C),
      !is.na(cds_pct_D)
    )

  cat(sprintf("[%s] Paired orthogroups: %d\n",
              threshold, nrow(df_pair)))

  ## 防御性检查（避免你刚才的报错）
  if (nrow(df_pair) < 5) {
    stop("[FATAL] Too few paired orthogroups for ", threshold)
  }

  ## ---------------------------------
  ## Paired Wilcoxon
  ## ---------------------------------
  wilc <- wilcox.test(
    df_pair$cds_pct_C,
    df_pair$cds_pct_D,
    paired = TRUE,
    exact  = FALSE
  )

  p_label <- if (wilc$p.value < 0.001) "***"
  else if (wilc$p.value < 0.01) "**"
  else if (wilc$p.value < 0.05) "*"
  else "ns"

  ## ---------------------------------
  ## Long format
  ## ---------------------------------
  df_long <- df_pair %>%
    mutate(pair_id = row_number()) %>%
    pivot_longer(
      cols = c(cds_pct_C, cds_pct_D),
      names_to = "subgenome",
      values_to = "cds_pct"
    ) %>%
    mutate(
      subgenome = recode(
        subgenome,
        cds_pct_C = "pedC",
        cds_pct_D = "pedD"
      ),
      subgenome = factor(subgenome, levels = c("pedC", "pedD"))
    )

  y_max <- max(df_long$cds_pct, na.rm = TRUE)

  y_label <- if (panel_label == "A") {
    "CDS constrained sites (%)"
  } else NULL

  ## ---------------------------------
  ## Plot
  ## ---------------------------------
  ggplot(df_long, aes(subgenome, cds_pct)) +

    geom_line(
      aes(group = pair_id),
      color = "grey70",
      linewidth = 0.3,
      alpha = 0.4
    ) +
    geom_violin(
      width = 0.38,
      scale = "width",
      fill = "#D9D9D9",
      color = "#6E6E6E",
      linewidth = 0.8
    ) +
    geom_boxplot(
      width = 0.06,
      fill = "white",
      color = "black",
      linewidth = 1,
      outlier.shape = NA
    ) +
    geom_segment(
      aes(x = 1, xend = 2,
          y = y_max + 3, yend = y_max + 3),
      linewidth = 0.8
    ) +
    geom_text(
      aes(x = 1.5, y = y_max + 5, label = p_label),
      size = 6
    ) +
    scale_y_continuous(
      limits = c(0, y_max + 8),
      breaks = seq(0, 100, 25),
      expand = c(0, 0)
    ) +
    labs(
      x = NULL,
      y = y_label,
      title = paste0("GERP > ", sub("gt", "", threshold))
    ) +
    theme_classic(base_size = 16) +
    theme(
      plot.title = element_text(hjust = 0.5),
      axis.text.x = element_text(face = "italic"),
      panel.border = element_rect(fill = NA, color = "black")
    )
}

## =========================================================
## 4. Multi-panel
## =========================================================
plots <- Map(build_panel, thresholds, panel_tags)

final_plot <- wrap_plots(plots, nrow = 1) +
  plot_annotation(tag_levels = panel_tags)

ggsave(
  "Fig_pedC_vs_pedD_paired_GERP_gt2_gt4_gt6.pdf",
  final_plot,
  width = 10.5,
  height = 4.8,
  device = cairo_pdf
)

ggsave(
  "Fig_pedC_vs_pedD_paired_GERP_gt2_gt4_gt6.png",
  final_plot,
  width = 10.5,
  height = 4.8,
  dpi = 300
)

cat("\nDone.\n")
