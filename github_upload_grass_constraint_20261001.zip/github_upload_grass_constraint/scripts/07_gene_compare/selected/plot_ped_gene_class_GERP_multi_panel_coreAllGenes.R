#!/usr/bin/env Rscript

## =========================================================
## P. edulis within-species comparison of CDS GERP conservation
##
## Gene classes:
##   1) Core:
##      strict perfect-copy syntenic core genes from
##      core_5sp_1to1.SG.pan pedC + pedD columns.
##      IMPORTANT:
##      Core is counted at gene level, not SG-pair level.
##      Therefore, pedC and pedD genes are both kept as separate
##      gene observations, giving approximately 2 × N_SG core genes.
##
##   2) Syntenic:
##      broad syntenic genes excluding strict core
##
##   3) Nonsyntenic:
##      candidate nonsyntenic/private genes
##
## Plot labels:
##   Core
##   Syntenic
##   Nonsyntenic
##
## Statistics:
##   Kruskal-Wallis test
##   pairwise Wilcoxon rank-sum test with BH correction
##
## Input:
##   ../../../01.OG_gene/core_5sp_1to1.SG.pan
##   ped_other_syntenic.genes.txt
##   ped_candidate_nonsyntenic_private.genes.txt
##   ped.gerp_gt2_combined.tsv
##   ped.gerp_gt4_combined.tsv
##   ped.gerp_gt6_combined.tsv
##   pedC_gerp_gt2_CDS_per_gene.tsv
##   pedD_gerp_gt2_CDS_per_gene.tsv
##   pedC_gerp_gt4_CDS_per_gene.tsv
##   pedD_gerp_gt4_CDS_per_gene.tsv
##   pedC_gerp_gt6_CDS_per_gene.tsv
##   pedD_gerp_gt6_CDS_per_gene.tsv
##
## Output:
##   Fig_ped_gene_class_GERP_gt2_gt4_gt6_coreAllGenes.pdf
##   Fig_ped_gene_class_GERP_gt2_gt4_gt6_coreAllGenes.png
##   Supplementary_ped_gene_class_Wilcoxon_GERP_coreAllGenes.tsv
##   Ped_gene_class_counts_by_threshold_coreAllGenes.tsv
## =========================================================

suppressPackageStartupMessages({
  library(dplyr)
  library(ggplot2)
  library(ggsignif)
  library(patchwork)
})

## =========================================================
## 1. Parameters
## =========================================================
PAN_FILE     <- "../../../01.OG_gene/core_5sp_1to1.SG.pan"
OTHER_FILE   <- "ped_other_syntenic.genes.txt"
PRIVATE_FILE <- "ped_candidate_nonsyntenic_private.genes.txt"

panels_thresholds <- c("gt2", "gt4", "gt6")
supp_thresholds   <- c("gt2", "gt4", "gt6")

show_ns_lines <- FALSE

## New output names; will NOT overwrite previous results
out_fig_prefix <- "Fig_ped_gene_class_GERP_gt2_gt4_gt6_coreAllGenes"
out_supp_tsv   <- "Supplementary_ped_gene_class_Wilcoxon_GERP_coreAllGenes.tsv"
out_count_tsv  <- "Ped_gene_class_counts_by_threshold_coreAllGenes.tsv"

## Short labels for plotting
class_order <- c("Core", "Syntenic", "Nonsyntenic")

## Full names for output table
class_full_names <- c(
  "Core"        = "strict_perfect_copy_syntenic_core_all_genes",
  "Syntenic"    = "broad_syntenic_excluding_strict_core",
  "Nonsyntenic" = "candidate_nonsyntenic_private"
)

## MBE-like low-saturation palette
class_fill <- c(
  "Core"        = "#9DBFD2",
  "Syntenic"    = "#B7B0CF",
  "Nonsyntenic" = "#D8A0A5"
)

## =========================================================
## 2. File builders
## =========================================================
build_combined_file <- function(threshold) {
  paste0("ped.gerp_", threshold, "_combined.tsv")
}

build_pedC_file <- function(threshold) {
  paste0("pedC_gerp_", threshold, "_CDS_per_gene.tsv")
}

build_pedD_file <- function(threshold) {
  paste0("pedD_gerp_", threshold, "_CDS_per_gene.tsv")
}

## =========================================================
## 3. Base TSV read/write helpers
## =========================================================
read_tsv_base <- function(fp, header = TRUE) {
  read.delim(
    file = fp,
    header = header,
    sep = "\t",
    stringsAsFactors = FALSE,
    check.names = FALSE,
    quote = "",
    comment.char = ""
  )
}

write_tsv_base <- function(df, fp) {
  write.table(
    df,
    file = fp,
    sep = "\t",
    quote = FALSE,
    row.names = FALSE,
    col.names = TRUE
  )
}

strip_species_prefix <- function(x) {
  x <- as.character(x)
  x <- sub("^pedC_", "", x)
  x <- sub("^pedD_", "", x)
  x <- sub("^P.edulis_", "", x)
  x
}

p_to_star <- function(p) {
  if (is.na(p)) return("ns")
  if (p < 0.001) return("***")
  if (p < 0.01)  return("**")
  if (p < 0.05)  return("*")
  "ns"
}

## =========================================================
## 4. Read gene lists
## =========================================================
read_gene_list <- function(fp) {
  if (!file.exists(fp)) {
    stop("Missing gene list file: ", fp, call. = FALSE)
  }

  x <- scan(
    fp,
    what = character(),
    quiet = TRUE
  )

  x <- strip_species_prefix(x)
  x <- x[!is.na(x) & x != "" & x != "-"]

  unique(x)
}

read_strict_core_genes_from_pan <- function(pan_file) {
  if (!file.exists(pan_file)) {
    stop("Missing SG pan file: ", pan_file, call. = FALSE)
  }

  pan <- read_tsv_base(pan_file, header = FALSE)

  if (ncol(pan) < 9) {
    stop(
      "SG pan file should have at least 9 columns. ",
      "Expected pedC in column 7 and pedD in column 8.",
      call. = FALSE
    )
  }

  ## Keep pedC and pedD as separate genes.
  ## This is gene-level core, not SG-pair-level core.
  pedC <- strip_species_prefix(pan[[7]])
  pedD <- strip_species_prefix(pan[[8]])

  genes <- unique(c(pedC, pedD))
  genes <- genes[!is.na(genes) & genes != "" & genes != "-"]

  cat("[OK] Strict core genes from SG pan, pedC + pedD all genes: ",
      length(genes), "\n", sep = "")

  genes
}

build_gene_class_map <- function() {
  strict_genes  <- read_strict_core_genes_from_pan(PAN_FILE)
  other_genes   <- read_gene_list(OTHER_FILE)
  private_genes <- read_gene_list(PRIVATE_FILE)

  ## Ensure mutually exclusive classes
  other_excluding_strict <- setdiff(other_genes, strict_genes)

  private_clean <- setdiff(
    private_genes,
    unique(c(strict_genes, other_excluding_strict))
  )

  gene_class <- bind_rows(
    data.frame(
      gene_id_norm = strict_genes,
      gene_class = "Core",
      stringsAsFactors = FALSE
    ),
    data.frame(
      gene_id_norm = other_excluding_strict,
      gene_class = "Syntenic",
      stringsAsFactors = FALSE
    ),
    data.frame(
      gene_id_norm = private_clean,
      gene_class = "Nonsyntenic",
      stringsAsFactors = FALSE
    )
  ) %>%
    distinct(gene_id_norm, .keep_all = TRUE) %>%
    mutate(
      gene_class = factor(gene_class, levels = class_order)
    )

  cat("[OK] Gene class map:\n")
  print(table(gene_class$gene_class, useNA = "ifany"))

  gene_class
}

## =========================================================
## 5. Extract CDS constrained percentage from stats table
## =========================================================
get_cds_pct_column <- function(df, fp) {
  if ("cds_conserved_pct" %in% colnames(df)) {
    return(suppressWarnings(as.numeric(df$cds_conserved_pct)))
  }

  if ("cds_pct" %in% colnames(df)) {
    return(suppressWarnings(as.numeric(df$cds_pct)))
  }

  if (all(c("cds_conserved_sites", "cds_len") %in% colnames(df))) {
    cds_sites <- suppressWarnings(as.numeric(df$cds_conserved_sites))
    cds_len   <- suppressWarnings(as.numeric(df$cds_len))
    return(100 * cds_sites / cds_len)
  }

  if (all(c("cds_sites", "cds_len") %in% colnames(df))) {
    cds_sites <- suppressWarnings(as.numeric(df$cds_sites))
    cds_len   <- suppressWarnings(as.numeric(df$cds_len))
    return(100 * cds_sites / cds_len)
  }

  stop(
    "Cannot find CDS constrained percentage columns in file: ",
    fp,
    "\nNeed one of: cds_conserved_pct, cds_pct, ",
    "or cds_conserved_sites/cds_len, or cds_sites/cds_len.",
    call. = FALSE
  )
}

get_cds_len_column <- function(df) {
  if ("cds_len" %in% colnames(df)) {
    return(suppressWarnings(as.numeric(df$cds_len)))
  }
  rep(NA_real_, nrow(df))
}

## =========================================================
## 6. Read non-core combined stats
##    Used only for Syntenic and Nonsyntenic classes.
## =========================================================
read_combined_stats <- function(threshold) {
  fp <- build_combined_file(threshold)

  if (!file.exists(fp)) {
    warning("Combined file not found: ", fp)
    return(NULL)
  }

  df <- read_tsv_base(fp, header = TRUE)

  if (!"gene_id" %in% colnames(df)) {
    stop("Missing gene_id column in combined file: ", fp, call. = FALSE)
  }

  out <- data.frame(
    gene_id_norm = strip_species_prefix(df$gene_id),
    cds_len = get_cds_len_column(df),
    cds_conserved_pct = get_cds_pct_column(df, fp),
    source = "combined_non_core",
    stringsAsFactors = FALSE
  ) %>%
    filter(
      !is.na(gene_id_norm),
      gene_id_norm != "",
      !is.na(cds_conserved_pct)
    )

  ## Remove invalid CDS entries when cds_len is available
  if (any(!is.na(out$cds_len))) {
    out <- out %>%
      filter(!is.na(cds_len), cds_len > 0)
  }

  out
}

## =========================================================
## 7. Read Core stats from pedC and pedD per-gene files
##    Core is gene-level, not SG-pair-level.
## =========================================================
read_per_subgenome_stats_one <- function(fp, source_label) {
  if (!file.exists(fp)) {
    stop("Missing core per-gene file: ", fp, call. = FALSE)
  }

  df <- read_tsv_base(fp, header = TRUE)

  if (!"gene_id" %in% colnames(df)) {
    colnames(df)[1] <- "gene_id"
  }

  out <- data.frame(
    gene_id_norm = strip_species_prefix(df$gene_id),
    cds_len = get_cds_len_column(df),
    cds_conserved_pct = get_cds_pct_column(df, fp),
    source = source_label,
    stringsAsFactors = FALSE
  ) %>%
    filter(
      !is.na(gene_id_norm),
      gene_id_norm != "",
      !is.na(cds_conserved_pct)
    )

  if (any(!is.na(out$cds_len))) {
    out <- out %>%
      filter(!is.na(cds_len), cds_len > 0)
  }

  out
}

read_core_stats_for_threshold <- function(threshold) {
  pedC <- read_per_subgenome_stats_one(
    build_pedC_file(threshold),
    paste0("pedC_core_", threshold)
  )

  pedD <- read_per_subgenome_stats_one(
    build_pedD_file(threshold),
    paste0("pedD_core_", threshold)
  )

  core_stats <- bind_rows(pedC, pedD)

  if (nrow(core_stats) == 0) {
    stop(
      "No usable pedC/pedD core per-gene stats found for threshold: ",
      threshold,
      call. = FALSE
    )
  }

  ## If a gene is duplicated within a per-gene table, average it.
  ## Normally pedC/pedD gene IDs are unique after prefix stripping.
  core_stats <- core_stats %>%
    group_by(gene_id_norm) %>%
    summarise(
      cds_len = first(cds_len),
      cds_conserved_pct = mean(cds_conserved_pct, na.rm = TRUE),
      source = paste(unique(source), collapse = ";"),
      .groups = "drop"
    )

  core_stats
}

## =========================================================
## 8. Build plotting table for one threshold
## =========================================================
read_one_threshold <- function(threshold, gene_class_map) {
  core_stats <- read_core_stats_for_threshold(threshold)
  noncore_stats <- read_combined_stats(threshold)

  core_df <- core_stats %>%
    inner_join(gene_class_map, by = "gene_id_norm") %>%
    filter(gene_class == "Core") %>%
    mutate(
      threshold = threshold,
      gene_class = factor(gene_class, levels = class_order)
    )

  noncore_df <- noncore_stats %>%
    inner_join(gene_class_map, by = "gene_id_norm") %>%
    filter(gene_class %in% c("Syntenic", "Nonsyntenic")) %>%
    mutate(
      threshold = threshold,
      gene_class = factor(gene_class, levels = class_order)
    )

  df <- bind_rows(core_df, noncore_df) %>%
    filter(!is.na(gene_class), !is.na(cds_conserved_pct))

  if (nrow(df) == 0) {
    stop(
      "No genes matched gene-class map for threshold: ",
      threshold,
      call. = FALSE
    )
  }

  cat("[INFO] ", threshold, " matched genes by class:\n", sep = "")
  print(table(df$gene_class, useNA = "ifany"))

  df
}

## =========================================================
## 9. Statistics: independent gene classes
## =========================================================
run_stats_one_threshold <- function(df_plot, threshold) {
  df_plot <- df_plot %>%
    filter(!is.na(gene_class), !is.na(cds_conserved_pct)) %>%
    droplevels()

  observed_levels <- levels(droplevels(df_plot$gene_class))

  if (length(observed_levels) < 2) {
    stop(
      "Need at least two gene classes for statistical test at threshold: ",
      threshold,
      call. = FALSE
    )
  }

  kw <- kruskal.test(cds_conserved_pct ~ gene_class, data = df_plot)

  pair_combs <- combn(observed_levels, 2, simplify = FALSE)

  pair_tbl <- lapply(pair_combs, function(cc) {
    g1 <- cc[1]
    g2 <- cc[2]

    sub_df <- df_plot %>%
      filter(gene_class %in% c(g1, g2)) %>%
      droplevels()

    x <- sub_df$cds_conserved_pct[sub_df$gene_class == g1]
    y <- sub_df$cds_conserved_pct[sub_df$gene_class == g2]

    wt <- wilcox.test(
      x,
      y,
      paired = FALSE,
      exact = FALSE
    )

    tibble(
      threshold = threshold,
      test = "Wilcoxon rank-sum (BH)",
      Comparison = paste0(
        class_full_names[[g1]],
        " - ",
        class_full_names[[g2]]
      ),
      group1 = class_full_names[[g1]],
      group2 = class_full_names[[g2]],
      n_group1 = length(x),
      n_group2 = length(y),
      median_group1 = median(x, na.rm = TRUE),
      median_group2 = median(y, na.rm = TRUE),
      median_diff_group1_minus_group2 =
        median(x, na.rm = TRUE) - median(y, na.rm = TRUE),
      P.raw = wt$p.value
    )
  }) %>%
    bind_rows() %>%
    mutate(
      P.adj = p.adjust(P.raw, method = "BH"),
      label = vapply(P.adj, p_to_star, character(1)),
      KW_chisq = unname(kw$statistic),
      KW_df    = unname(kw$parameter),
      KW_p     = kw$p.value
    ) %>%
    select(
      threshold,
      test,
      KW_chisq,
      KW_df,
      KW_p,
      Comparison,
      group1,
      group2,
      n_group1,
      n_group2,
      median_group1,
      median_group2,
      median_diff_group1_minus_group2,
      P.raw,
      P.adj,
      label
    )

  list(
    kw = kw,
    pairwise_tbl = pair_tbl
  )
}

## =========================================================
## 10. Significance annotation
## =========================================================
make_sig_df <- function(df_plot, pairwise_tbl) {
  sig_df <- pairwise_tbl %>%
    filter(!is.na(group1), !is.na(group2), !is.na(label))

  inv_map <- setNames(names(class_full_names), class_full_names)

  sig_df <- sig_df %>%
    mutate(
      group1_plot = inv_map[group1],
      group2_plot = inv_map[group2]
    )

  if (!show_ns_lines) {
    sig_df <- sig_df %>% filter(label != "ns")
  }

  y_data_max <- max(df_plot$cds_conserved_pct, na.rm = TRUE)

  if (nrow(sig_df) == 0) {
    return(list(
      sig_df = sig_df,
      y_panel_max = max(105, y_data_max + 8)
    ))
  }

  ## Keep significance bars and labels inside the panel.
  ## cds_conserved_pct is a percentage, so y_base is anchored around 100.
  y_base <- max(100, y_data_max)

  sig_df <- sig_df %>%
    mutate(
      group1_plot = factor(group1_plot, levels = class_order),
      group2_plot = factor(group2_plot, levels = class_order)
    ) %>%
    arrange(group1_plot, group2_plot) %>%
    mutate(
      y_position = y_base + seq(from = 2.8, by = 3.0, length.out = n())
    )

  ## Extra headroom above the top star.
  y_panel_max <- max(sig_df$y_position, na.rm = TRUE) + 8.5

  list(
    sig_df = sig_df,
    y_panel_max = y_panel_max
  )
}

## =========================================================
## 11. Plot one panel
## =========================================================
plot_one_panel <- function(df_plot, sig_df, y_limit, panel_title) {
  ggplot(df_plot, aes(x = gene_class, y = cds_conserved_pct, fill = gene_class)) +

    geom_violin(
      width = 0.62,
      scale = "width",
      trim = TRUE,
      color = "#5F5F5F",
      linewidth = 0.55,
      alpha = 0.85
    ) +

    geom_boxplot(
      width = 0.105,
      coef = 0.35,
      fill = "white",
      color = "black",
      linewidth = 0.75,
      outlier.shape = NA
    ) +

    {
      if (nrow(sig_df) > 0) {
        geom_signif(
          data = sig_df,
          aes(
            xmin = group1_plot,
            xmax = group2_plot,
            annotations = label,
            y_position = y_position
          ),
          manual = TRUE,
          inherit.aes = FALSE,
          textsize = 3.7,
          tip_length = 0.010,
          linewidth = 0.65
        )
      }
    } +

    scale_fill_manual(
      values = class_fill,
      guide = "none"
    ) +

    scale_x_discrete(
      limits = class_order,
      labels = class_order
    ) +

    scale_y_continuous(
      limits = c(0, y_limit),
      breaks = seq(0, 100, 25),
      expand = c(0, 0)
    ) +

    labs(
      x = NULL,
      y = "CDS constrained sites (%)",
      title = panel_title
    ) +

    theme_classic(base_size = 16) +
    theme(
      plot.title = element_text(
        size = 15,
        face = "plain",
        hjust = 0.5,
        margin = margin(b = 8)
      ),

      axis.text.x = element_text(
        size = 14,
        color = "black",
        margin = margin(t = 5)
      ),
      axis.text.y = element_text(
        size = 13.5,
        color = "black"
      ),
      axis.title.y = element_text(
        size = 15,
        color = "black",
        margin = margin(r = 8)
      ),

      axis.line = element_line(
        color = "black",
        linewidth = 0.55
      ),
      axis.ticks = element_line(
        color = "black",
        linewidth = 0.55
      ),
      axis.ticks.length = unit(2.2, "pt"),

      ## MBE-style light horizontal grid only
      panel.grid.major.y = element_line(
        color = "#E9E9E9",
        linewidth = 0.35
      ),
      panel.grid.minor.y = element_blank(),
      panel.grid.major.x = element_blank(),
      panel.grid.minor.x = element_blank(),

      panel.border = element_rect(
        fill = NA,
        color = "black",
        linewidth = 0.75
      ),

      plot.margin = margin(12, 13, 10, 13)
    )
}

safe_ggsave <- function(filename, plot, width, height, dpi = NULL) {
  if (grepl("\\.pdf$", filename, ignore.case = TRUE)) {
    ok <- FALSE

    try({
      ggsave(
        filename = filename,
        plot = plot,
        width = width,
        height = height,
        device = cairo_pdf
      )
      ok <- TRUE
    }, silent = TRUE)

    if (!ok) {
      ggsave(
        filename = filename,
        plot = plot,
        width = width,
        height = height
      )
    }

  } else {
    if (is.null(dpi)) {
      ggsave(
        filename = filename,
        plot = plot,
        width = width,
        height = height
      )
    } else {
      ggsave(
        filename = filename,
        plot = plot,
        width = width,
        height = height,
        dpi = dpi
      )
    }
  }
}

## =========================================================
## 12. Main workflow
## =========================================================
all_thresholds <- unique(c(panels_thresholds, supp_thresholds))

gene_class_map <- build_gene_class_map()

## Build supplementary statistics
supp_list <- lapply(supp_thresholds, function(th) {
  cat("[INFO] Running statistics for threshold: ", th, "\n", sep = "")

  df_th <- read_one_threshold(th, gene_class_map)
  st <- run_stats_one_threshold(df_th, th)

  st$pairwise_tbl
})

supp_tbl <- bind_rows(supp_list)

write_tsv_base(supp_tbl, out_supp_tsv)

cat("[OK] Wrote statistics table: ",
    out_supp_tsv, "\n", sep = "")

## Count table
count_tbl <- lapply(all_thresholds, function(th) {
  df_th <- read_one_threshold(th, gene_class_map)

  df_th %>%
    group_by(threshold, gene_class) %>%
    summarise(
      n_genes = n(),
      median_cds_conserved_pct = median(cds_conserved_pct, na.rm = TRUE),
      mean_cds_conserved_pct = mean(cds_conserved_pct, na.rm = TRUE),
      .groups = "drop"
    )
}) %>%
  bind_rows() %>%
  mutate(
    gene_class_full = class_full_names[as.character(gene_class)]
  ) %>%
  select(
    threshold,
    gene_class,
    gene_class_full,
    n_genes,
    median_cds_conserved_pct,
    mean_cds_conserved_pct
  )

write_tsv_base(count_tbl, out_count_tsv)

cat("[OK] Wrote count/summary table: ",
    out_count_tsv, "\n", sep = "")

## Build figure panels
panel_objs <- lapply(panels_thresholds, function(th) {
  cat("[INFO] Building figure panel for threshold: ", th, "\n", sep = "")

  df_th <- read_one_threshold(th, gene_class_map)
  st <- run_stats_one_threshold(df_th, th)
  sig_info <- make_sig_df(df_th, st$pairwise_tbl)

  list(
    df = df_th,
    stats = st$pairwise_tbl,
    sig_df = sig_info$sig_df,
    y_panel_max = sig_info$y_panel_max
  )
})

global_y <- max(
  vapply(panel_objs, function(x) x$y_panel_max, numeric(1)),
  na.rm = TRUE
)

## Enough space for the top significance label.
## Axis tick labels remain 0-100 only.
global_y <- max(global_y, 118)

titles <- c(
  gt2 = "GERP > 2",
  gt4 = "GERP > 4",
  gt6 = "GERP > 6"
)

plots <- lapply(seq_along(panels_thresholds), function(i) {
  th <- panels_thresholds[i]

  plot_one_panel(
    df_plot = panel_objs[[i]]$df,
    sig_df = panel_objs[[i]]$sig_df,
    y_limit = global_y,
    panel_title = titles[[th]]
  )
})

p_multi <- plots[[1]] + plots[[2]] + plots[[3]] +
  plot_layout(ncol = 3, guides = "collect") +
  plot_annotation(tag_levels = "A") &
  theme(
    plot.tag = element_text(
      size = 22,
      face = "plain",
      color = "black"
    )
  )

safe_ggsave(
  filename = paste0(out_fig_prefix, ".pdf"),
  plot = p_multi,
  width = 13.2,
  height = 4.85
)

safe_ggsave(
  filename = paste0(out_fig_prefix, ".png"),
  plot = p_multi,
  width = 13.2,
  height = 4.85,
  dpi = 300
)

cat("[OK] Saved figure: ",
    out_fig_prefix, ".pdf / .png\n", sep = "")

cat("[DONE]\n")