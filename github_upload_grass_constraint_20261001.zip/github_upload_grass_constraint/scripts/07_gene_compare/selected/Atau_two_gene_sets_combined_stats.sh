#!/usr/bin/env bash
#BSUB -J "Atau_2GeneSets_full16[1-3]%3"
#BSUB -q Q96C1T_X12
#BSUB -n 8
#BSUB -o logs/Atau_2GeneSets_full16.%J.%I.out
#BSUB -e logs/Atau_2GeneSets_full16.%J.%I.err

set -euo pipefail
module load bedtools 2>/dev/null || true
mkdir -p logs

############################################################
# 0. fixed paths
############################################################
BASE_GERP_DIR="/ds3200_1/users_root/liuliangmin/workspace/PHD/2.msa/Atau_msa/results/GERP_output/02.constrain_stat/gerp_conservation_results"

LIST1="/ds3200_1/users_root/liuliangmin/workspace/PHD/7.synpan/01.OG_gene/results_synpan_class/01_species_level/Atau/other_syntenic.genes.txt"
LIST2="/ds3200_1/users_root/liuliangmin/workspace/PHD/7.synpan/01.OG_gene/results_synpan_class/01_species_level/Atau/candidate_nonsyntenic_private.genes.txt"

GENE_BED="/ds3200_1/users_root/liuliangmin/workspace/PHD/2.msa/Atau_msa/results/GERP_output/01.constrained_category/genes.bed"
CDS_MERGED_BED="/ds3200_1/users_root/liuliangmin/workspace/PHD/2.msa/Atau_msa/results/GERP_output/01.constrained_category/CDS.gene.merged.bed"
CDS_RAW_BED="/ds3200_1/users_root/liuliangmin/workspace/PHD/2.msa/Atau_msa/results/GERP_output/01.constrained_category/CDS.gene.bed"

ALL_CDS_SNP="/ds3200_1/users_root/liuliangmin/workspace/PHD/2.msa/Atau_msa/pop/02.deleterious/output_bed/CDS_processed.intersect.bed"
ALL_GENE_SNP="/ds3200_1/users_root/liuliangmin/workspace/PHD/2.msa/Atau_msa/pop/02.deleterious/output_bed/genes_processed.intersect.bed"

DEL_CDS_GT2="/ds3200_1/users_root/liuliangmin/workspace/PHD/2.msa/Atau_msa/pop/02.deleterious/merged_gt2/functional_analysis/merged_gt2_CDS_detailed.bed"
DEL_CDS_GT4="/ds3200_1/users_root/liuliangmin/workspace/PHD/2.msa/Atau_msa/pop/02.deleterious/merged_gt4/functional_analysis/merged_gt4_CDS_detailed.bed"
DEL_CDS_GT6="/ds3200_1/users_root/liuliangmin/workspace/PHD/2.msa/Atau_msa/pop/02.deleterious/merged_gt6/functional_analysis/merged_gt6_CDS_detailed.bed"

DEL_GENE_GT2="/ds3200_1/users_root/liuliangmin/workspace/PHD/2.msa/Atau_msa/pop/02.deleterious/merged_gt2/functional_analysis/merged_gt2_genes_detailed.bed"
DEL_GENE_GT4="/ds3200_1/users_root/liuliangmin/workspace/PHD/2.msa/Atau_msa/pop/02.deleterious/merged_gt4/functional_analysis/merged_gt4_genes_detailed.bed"
DEL_GENE_GT6="/ds3200_1/users_root/liuliangmin/workspace/PHD/2.msa/Atau_msa/pop/02.deleterious/merged_gt6/functional_analysis/merged_gt6_genes_detailed.bed"

LIST_PREFIX="Atau_"
OUT_ROOT="two_gene_sets_combined_stats"
mkdir -p "${OUT_ROOT}"

############################################################
# 1. array threshold
############################################################
CLASSES=(gt2 gt4 gt6)
IDX=$((LSB_JOBINDEX - 1))
if [[ ${IDX} -lt 0 || ${IDX} -ge ${#CLASSES[@]} ]]; then
  echo "[ERROR] Bad LSB_JOBINDEX=${LSB_JOBINDEX}" >&2
  exit 1
fi
TH="${CLASSES[$IDX]}"

OUT_DIR="${OUT_ROOT}/gerp_${TH}"
TMP_DIR="${OUT_DIR}/tmp"
mkdir -p "${OUT_DIR}" "${TMP_DIR}"

############################################################
# 2. helper functions
############################################################
pick_first_existing() {
  local f
  for f in "$@"; do
    if [[ -n "$f" && -s "$f" ]]; then
      echo "$f"
      return 0
    fi
  done
  return 1
}

normalize_gene_list() {
  local infile="$1"
  local outfile="$2"
  awk -v p="${LIST_PREFIX}" '
    {
      g=$1
      sub(/^gene:/, "", g)
      sub("^" p, "", g)
      if (g != "") print g
    }' "$infile" \
  | LC_ALL=C sort -u > "$outfile"
}

sanitize_bed() {
  local inbed="$1"
  local outbed="$2"

  awk 'BEGIN{OFS="\t"}
    $2 ~ /^[0-9]+$/ && $3 ~ /^[0-9]+$/ && $2 >= 0 && $3 >= $2 {
      print
    }' "$inbed" \
  | LC_ALL=C sort -k1,1 -k2,2n -k3,3n > "$outbed"
}

merge_len_by_gene() {
  local inbed="$1"
  local outtsv="$2"

  if [[ ! -s "$inbed" ]]; then
    : > "$outtsv"
    return 0
  fi

  LC_ALL=C sort -k4,4 -k1,1 -k2,2n "$inbed" \
  | awk 'BEGIN{OFS="\t"}
    {
      g=$4; chr=$1; s=$2; e=$3
      if (NR==1) {
        cg=g; cchr=chr; cs=s; ce=e; sum=0
        next
      }
      if (g!=cg || chr!=cchr) {
        sum += (ce-cs)
        print cg, sum
        cg=g; cchr=chr; cs=s; ce=e; sum=0
        next
      }
      if (s <= ce) {
        if (e > ce) ce=e
      } else {
        sum += (ce-cs)
        cs=s; ce=e
      }
    }
    END{
      if (NR>0) {
        sum += (ce-cs)
        print cg, sum
      }
    }' \
  | LC_ALL=C sort -k1,1 > "$outtsv"
}

count_unique_sites_by_gene() {
  local abed="$1"
  local bbed="$2"
  local outtsv="$3"

  if [[ ! -s "$abed" || ! -s "$bbed" ]]; then
    : > "$outtsv"
    return 0
  fi

  local a_sorted="${outtsv%.tsv}.A.sorted.bed"
  local b_sorted="${outtsv%.tsv}.B.sorted.bed"

  sanitize_bed "$abed" "$a_sorted"
  sanitize_bed "$bbed" "$b_sorted"

  if [[ ! -s "$a_sorted" || ! -s "$b_sorted" ]]; then
    : > "$outtsv"
    rm -f "$a_sorted" "$b_sorted"
    return 0
  fi

  bedtools intersect -sorted -wa -wb -a "$a_sorted" -b "$b_sorted" \
  | awk 'BEGIN{OFS="\t"}
    {
      gid=$NF
      key=$1":"$2"-"$3":"gid
      if (!seen[key]++) c[gid]++
    }
    END{
      for (g in c) print g, c[g]
    }' \
  | LC_ALL=C sort -k1,1 > "$outtsv"

  rm -f "$a_sorted" "$b_sorted"
}

############################################################
# 3. select current files
############################################################
GENE_GERP=$(pick_first_existing \
  "${BASE_GERP_DIR}/${TH}/bed_files/genes_GERP_feature.bed" \
  "${BASE_GERP_DIR}/${TH}/bed_files/genes_conserved_sites.bed")

CDS_GERP=$(pick_first_existing \
  "${BASE_GERP_DIR}/${TH}/bed_files/CDS_GERP_feature.bed" \
  "${BASE_GERP_DIR}/${TH}/bed_files/CDS_conserved_sites.bed")

case "$TH" in
  gt2)
    DEL_CDS="$DEL_CDS_GT2"
    DEL_GENE="$DEL_GENE_GT2"
    ;;
  gt4)
    DEL_CDS="$DEL_CDS_GT4"
    DEL_GENE="$DEL_GENE_GT4"
    ;;
  gt6)
    DEL_CDS="$DEL_CDS_GT6"
    DEL_GENE="$DEL_GENE_GT6"
    ;;
  *)
    echo "[ERROR] Unsupported threshold: $TH" >&2
    exit 1
    ;;
esac

############################################################
# 4. required checks
############################################################
for req in \
  "$GENE_BED" "$CDS_MERGED_BED" "$CDS_RAW_BED" \
  "$LIST1" "$LIST2" \
  "$GENE_GERP" "$CDS_GERP" \
  "$ALL_CDS_SNP" "$ALL_GENE_SNP" \
  "$DEL_CDS" "$DEL_GENE"
do
  if [[ ! -s "$req" ]]; then
    echo "[ERROR] Missing required file: $req" >&2
    exit 1
  fi
done

echo "[INFO] Threshold      : ${TH}"
echo "[INFO] GENE_GERP      : ${GENE_GERP}"
echo "[INFO] CDS_GERP       : ${CDS_GERP}"
echo "[INFO] ALL_GENE_SNP   : ${ALL_GENE_SNP}"
echo "[INFO] ALL_CDS_SNP    : ${ALL_CDS_SNP}"
echo "[INFO] DEL_GENE       : ${DEL_GENE}"
echo "[INFO] DEL_CDS        : ${DEL_CDS}"

############################################################
# 5. normalize whole-genome BEDs
############################################################
GENE4="${TMP_DIR}/genes.4col.bed"
CDS4_MERGED="${TMP_DIR}/CDS.merged.4col.bed"
CDS4_RAW="${TMP_DIR}/CDS.raw.4col.bed"

awk 'BEGIN{OFS="\t"}{g=$4; sub(/^gene:/, "", g); print $1,$2,$3,g}' "$GENE_BED" \
  | LC_ALL=C sort -k1,1 -k2,2n -k3,3n -k4,4 -u > "$GENE4"

awk 'BEGIN{OFS="\t"}{g=$4; sub(/^gene:/, "", g); print $1,$2,$3,g}' "$CDS_MERGED_BED" \
  | LC_ALL=C sort -k1,1 -k2,2n -k3,3n -k4,4 -u > "$CDS4_MERGED"

awk 'BEGIN{OFS="\t"}{g=$4; sub(/^gene:/, "", g); print $1,$2,$3,g}' "$CDS_RAW_BED" \
  | LC_ALL=C sort -k1,1 -k2,2n -k3,3n -k4,4 -u > "$CDS4_RAW"

############################################################
# 6. init outputs
############################################################
COMBINED_TSV="${OUT_DIR}/all_groups_combined.tsv"
GROUP_SUMMARY_TSV="${OUT_DIR}/group_summary.tsv"
GROUP_ORDER="${TMP_DIR}/group_order.txt"
: > "$GROUP_ORDER"

cat > "$COMBINED_TSV" <<'HDR'
group	gene_id	gene_len	cds_len	gene_conserved_sites	gene_conserved_pct	cds_conserved_sites	cds_conserved_pct	gene_snp_total	gene_snp_ratio	gene_deleterious_snp	gene_deleterious_ratio	cds_snp_total	cds_snp_ratio	cds_deleterious_snp	cds_deleterious_ratio
HDR

############################################################
# 7. process gene sets
############################################################
for LIST in "$LIST1" "$LIST2"; do
  GROUP=$(basename "$LIST")
  GROUP=${GROUP%.genes.txt}
  GROUP=${GROUP%.txt}
  echo "$GROUP" >> "$GROUP_ORDER"

  GDIR="${TMP_DIR}/${GROUP}"
  mkdir -p "$GDIR"

  TARGET_GENE_LIST="${GDIR}/target_gene.list"
  TARGET_GENE_BED="${GDIR}/target_genes.bed"
  TARGET_CDS_BED_MERGED="${GDIR}/target_cds_merged.bed"
  TARGET_CDS_BED_RAW="${GDIR}/target_cds_raw.bed"

  normalize_gene_list "$LIST" "$TARGET_GENE_LIST"

  awk 'NR==FNR{a[$1]=1; next} ($4 in a)' "$TARGET_GENE_LIST" "$GENE4" \
    | LC_ALL=C sort -k1,1 -k2,2n -k3,3n -k4,4 -u > "$TARGET_GENE_BED"

  awk 'NR==FNR{a[$1]=1; next} ($4 in a)' "$TARGET_GENE_LIST" "$CDS4_MERGED" \
    | LC_ALL=C sort -k1,1 -k2,2n -k3,3n -k4,4 -u > "$TARGET_CDS_BED_MERGED"

  awk 'NR==FNR{a[$1]=1; next} ($4 in a)' "$TARGET_GENE_LIST" "$CDS4_RAW" \
    | LC_ALL=C sort -k1,1 -k2,2n -k3,3n -k4,4 -u > "$TARGET_CDS_BED_RAW"

  awk 'BEGIN{OFS="\t"}{print $4,$3-$2}' "$TARGET_GENE_BED" \
    | LC_ALL=C sort -k1,1 > "${GDIR}/gene_len.tsv"

  merge_len_by_gene "$TARGET_CDS_BED_MERGED" "${GDIR}/cds_len.tsv"

  count_unique_sites_by_gene "$GENE_GERP" "$TARGET_GENE_BED" "${GDIR}/gene_conserved.tsv"
  count_unique_sites_by_gene "$CDS_GERP" "$TARGET_CDS_BED_MERGED" "${GDIR}/cds_conserved.tsv"
  count_unique_sites_by_gene "$ALL_GENE_SNP" "$TARGET_GENE_BED" "${GDIR}/gene_snp_total.tsv"
  count_unique_sites_by_gene "$DEL_GENE" "$TARGET_GENE_BED" "${GDIR}/gene_del.tsv"
  count_unique_sites_by_gene "$ALL_CDS_SNP" "$TARGET_CDS_BED_RAW" "${GDIR}/cds_snp_total.tsv"
  count_unique_sites_by_gene "$DEL_CDS" "$TARGET_CDS_BED_RAW" "${GDIR}/cds_del.tsv"

  awk -v OFS="\t" '{print $1,0}' "$TARGET_GENE_LIST" \
    | LC_ALL=C sort -k1,1 > "${GDIR}/base.tsv"

  join -t $'\t' -a 1 -e 0 -o 1.1,2.2 \
    "${GDIR}/base.tsv" "${GDIR}/gene_len.tsv" > "${GDIR}/j1.tsv"

  join -t $'\t' -a 1 -e 0 -o 1.1,1.2,2.2 \
    "${GDIR}/j1.tsv" "${GDIR}/cds_len.tsv" > "${GDIR}/j2.tsv"

  join -t $'\t' -a 1 -e 0 -o 1.1,1.2,1.3,2.2 \
    "${GDIR}/j2.tsv" "${GDIR}/gene_conserved.tsv" > "${GDIR}/j3.tsv"

  join -t $'\t' -a 1 -e 0 -o 1.1,1.2,1.3,1.4,2.2 \
    "${GDIR}/j3.tsv" "${GDIR}/cds_conserved.tsv" > "${GDIR}/j4.tsv"

  join -t $'\t' -a 1 -e 0 -o 1.1,1.2,1.3,1.4,1.5,2.2 \
    "${GDIR}/j4.tsv" "${GDIR}/gene_snp_total.tsv" > "${GDIR}/j5.tsv"

  join -t $'\t' -a 1 -e 0 -o 1.1,1.2,1.3,1.4,1.5,1.6,2.2 \
    "${GDIR}/j5.tsv" "${GDIR}/gene_del.tsv" > "${GDIR}/j6.tsv"

  join -t $'\t' -a 1 -e 0 -o 1.1,1.2,1.3,1.4,1.5,1.6,1.7,2.2 \
    "${GDIR}/j6.tsv" "${GDIR}/cds_snp_total.tsv" > "${GDIR}/j7.tsv"

  join -t $'\t' -a 1 -e 0 -o 1.1,1.2,1.3,1.4,1.5,1.6,1.7,1.8,2.2 \
    "${GDIR}/j7.tsv" "${GDIR}/cds_del.tsv" > "${GDIR}/j8.tsv"

  awk -v grp="$GROUP" '
    BEGIN{OFS="\t"}
    {
      gene=$1
      gl=$2+0
      cl=$3+0
      gcs=$4+0
      ccs=$5+0
      gsnp=$6+0
      gdel=$7+0
      csnp=$8+0
      cdel=$9+0

      gcp=(gl>0)?gcs/gl*100:0
      ccp=(cl>0)?ccs/cl*100:0
      gsr=(gl>0)?gsnp/gl:0
      gdr=(gsnp>0)?gdel/gsnp:0
      csr=(cl>0)?csnp/cl:0
      cdr=(csnp>0)?cdel/csnp:0

      printf "%s\t%s\t%d\t%d\t%d\t%.6f\t%d\t%.6f\t%d\t%.6f\t%d\t%.6f\t%d\t%.6f\t%d\t%.6f\n",
             grp, gene, gl, cl, gcs, gcp, ccs, ccp,
             gsnp, gsr, gdel, gdr,
             csnp, csr, cdel, cdr
    }' "${GDIR}/j8.tsv" >> "$COMBINED_TSV"
done

############################################################
# 8. group summary
############################################################
awk '
  BEGIN{OFS="\t"}
  FNR==NR {
    order[++m]=$1
    next
  }
  NR==1 {next}
  {
    g=$1
    n[g]++
    sum_gl[g]  += $3
    sum_cl[g]  += $4
    sum_gcs[g] += $5
    sum_ccs[g] += $7
    sum_gsnp[g] += $9
    sum_gdel[g] += $11
    sum_csnp[g] += $13
    sum_cdel[g] += $15
  }
  END{
    print "group","n_genes","gene_len","cds_len","gene_conserved_sites","gene_conserved_pct","cds_conserved_sites","cds_conserved_pct","gene_snp_total","gene_snp_ratio","gene_deleterious_snp","gene_deleterious_ratio","cds_snp_total","cds_snp_ratio","cds_deleterious_snp","cds_deleterious_ratio"
    for(i=1;i<=m;i++){
      g=order[i]
      if(!(g in n)) continue

      gcp=(sum_gl[g]>0)?sum_gcs[g]/sum_gl[g]*100:0
      ccp=(sum_cl[g]>0)?sum_ccs[g]/sum_cl[g]*100:0
      gsr=(sum_gl[g]>0)?sum_gsnp[g]/sum_gl[g]:0
      gdr=(sum_gsnp[g]>0)?sum_gdel[g]/sum_gsnp[g]:0
      csr=(sum_cl[g]>0)?sum_csnp[g]/sum_cl[g]:0
      cdr=(sum_csnp[g]>0)?sum_cdel[g]/sum_csnp[g]:0

      printf "%s\t%d\t%d\t%d\t%d\t%.6f\t%d\t%.6f\t%d\t%.6f\t%d\t%.6f\t%d\t%.6f\t%d\t%.6f\n",
             g, n[g], sum_gl[g], sum_cl[g], sum_gcs[g], gcp, sum_ccs[g], ccp,
             sum_gsnp[g], gsr, sum_gdel[g], gdr,
             sum_csnp[g], csr, sum_cdel[g], cdr
    }
  }' "$GROUP_ORDER" "$COMBINED_TSV" > "$GROUP_SUMMARY_TSV"

echo "[DONE] ${OUT_DIR}"
echo "[DONE] ${COMBINED_TSV}"
echo "[DONE] ${GROUP_SUMMARY_TSV}"