#!/usr/bin/env bash
#BSUB -J two_gene_sets_combined[1-4]
#BSUB -q Q96C1T_X12
#BSUB -n 4
#BSUB -o logs/two_gene_sets_combined.%J.%I.out
#BSUB -e logs/two_gene_sets_combined.%J.%I.err

set -euo pipefail
module load bedtools 2>/dev/null || true

THREADS="${LSB_DJOB_NUMPROC:-10}"

############################################################
# 0. Inputs
############################################################
GROUP_FILES=(
  "candidate_nonsyntenic_private.genes.txt"
  "other_syntenic.genes.txt"
)

GENE_BED="genes.bed"               # chr start end gene_id
CDS_BED="CDS_jcvi.bed"             # chr start end cds/transcript_id

INTERSECT_ROOT="intersect_results" # contains gerp_gt*/pedC_*.bed and pedD_*.bed

GENE_SNP_INTERSECT="genes.intersect.bed"      # gene id in col8
CDS_SNP_INTERSECT="CDS_jcvi.intersect.bed"    # gene id in col8

OUT_ROOT="two_gene_sets_combined_stats"
mkdir -p logs "${OUT_ROOT}"

############################################################
# 1. Threshold array
############################################################
CLASSES=("gerp_gt0" "gerp_gt2" "gerp_gt4" "gerp_gt6")
IDX=$((LSB_JOBINDEX - 1))

if [[ ${IDX} -lt 0 || ${IDX} -ge ${#CLASSES[@]} ]]; then
  echo "[ERROR] Bad LSB_JOBINDEX=${LSB_JOBINDEX}" >&2
  exit 1
fi

CLASS="${CLASSES[$IDX]}"
SHORT_CLASS="${CLASS#gerp_}"   # gt0 / gt2 / gt4 / gt6

echo "[INFO] Threshold = ${CLASS}"
echo "[INFO] LSF job ID   = ${LSB_JOBID:-NA}"
echo "[INFO] LSF job index= ${LSB_JOBINDEX:-NA}"
echo "[INFO] Threads      = ${THREADS}"

############################################################
# 2. Check common inputs
############################################################
for f in "${GROUP_FILES[@]}" "${GENE_BED}" "${CDS_BED}" "${GENE_SNP_INTERSECT}" "${CDS_SNP_INTERSECT}"; do
  [[ -s "${f}" ]] || { echo "[ERROR] Missing ${f}" >&2; exit 1; }
done

############################################################
# 3. Output dirs
############################################################
CLASS_DIR="${OUT_ROOT}/${CLASS}"
TMP_DIR="${CLASS_DIR}/tmp"
mkdir -p "${TMP_DIR}"

FINAL_TSV="${CLASS_DIR}/all_groups_combined.tsv"
SUMMARY_TSV="${CLASS_DIR}/group_summary.tsv"

printf "%s\n" \
"group	gene_id	gene_len	cds_len	gene_conserved_sites	gene_conserved_pct	cds_conserved_sites	cds_conserved_pct	gene_snp_total	gene_snp_ratio	gene_deleterious_snp	gene_deleterious_ratio	cds_snp_total	cds_snp_ratio	cds_deleterious_snp	cds_deleterious_ratio" \
> "${FINAL_TSV}"

printf "%s\n" \
"group	n_genes	sum_gene_len	sum_cds_len	sum_gene_conserved_sites	gene_conserved_pct_weighted	sum_cds_conserved_sites	cds_conserved_pct_weighted	sum_gene_snp_total	gene_snp_ratio	sum_gene_deleterious_snp	gene_deleterious_ratio	sum_cds_snp_total	cds_snp_ratio	sum_cds_deleterious_snp	cds_deleterious_ratio" \
> "${SUMMARY_TSV}"

############################################################
# 4. Merge pedC + pedD conserved files for this threshold
############################################################
shopt -s nullglob

GENE_GERP_FILES=(
  "${INTERSECT_ROOT}/${CLASS}"/pedC_*.genes.intersect.bed
  "${INTERSECT_ROOT}/${CLASS}"/pedD_*.genes.intersect.bed
)
CDS_GERP_FILES=(
  "${INTERSECT_ROOT}/${CLASS}"/pedC_*.CDS_jcvi.intersect.bed
  "${INTERSECT_ROOT}/${CLASS}"/pedD_*.CDS_jcvi.intersect.bed
)

[[ ${#GENE_GERP_FILES[@]} -gt 0 ]] || { echo "[ERROR] No gene GERP files for ${CLASS}" >&2; exit 1; }
[[ ${#CDS_GERP_FILES[@]}  -gt 0 ]] || { echo "[ERROR] No CDS GERP files for ${CLASS}"  >&2; exit 1; }

MERGED_GENE_GERP="${TMP_DIR}/merged_all_subgenomes.genes.intersect.bed"
MERGED_CDS_GERP="${TMP_DIR}/merged_all_subgenomes.CDS_jcvi.intersect.bed"

cat "${GENE_GERP_FILES[@]}" > "${MERGED_GENE_GERP}"
cat "${CDS_GERP_FILES[@]}"  > "${MERGED_CDS_GERP}"

############################################################
# 5. Merge pedC + pedD deleterious files for gt2/4/6
############################################################
HAS_DEL=0
MERGED_GENE_DEL="${TMP_DIR}/merged_${SHORT_CLASS}_genes_detailed.bed"
MERGED_CDS_DEL="${TMP_DIR}/merged_${SHORT_CLASS}_CDS_jcvi_detailed.bed"

if [[ "${SHORT_CLASS}" != "gt0" ]]; then
  GENE_DEL_FILES=()
  CDS_DEL_FILES=()

  [[ -s "pedC_${SHORT_CLASS}_genes_detailed.bed" ]] && GENE_DEL_FILES+=("pedC_${SHORT_CLASS}_genes_detailed.bed")
  [[ -s "pedD_${SHORT_CLASS}_genes_detailed.bed" ]] && GENE_DEL_FILES+=("pedD_${SHORT_CLASS}_genes_detailed.bed")
  [[ -s "pedC_${SHORT_CLASS}_CDS_jcvi_detailed.bed" ]] && CDS_DEL_FILES+=("pedC_${SHORT_CLASS}_CDS_jcvi_detailed.bed")
  [[ -s "pedD_${SHORT_CLASS}_CDS_jcvi_detailed.bed" ]] && CDS_DEL_FILES+=("pedD_${SHORT_CLASS}_CDS_jcvi_detailed.bed")

  [[ ${#GENE_DEL_FILES[@]} -gt 0 ]] || { echo "[ERROR] No gene deleterious files for ${SHORT_CLASS}" >&2; exit 1; }
  [[ ${#CDS_DEL_FILES[@]}  -gt 0 ]] || { echo "[ERROR] No CDS deleterious files for ${SHORT_CLASS}"  >&2; exit 1; }

  cat "${GENE_DEL_FILES[@]}" > "${MERGED_GENE_DEL}"
  cat "${CDS_DEL_FILES[@]}"  > "${MERGED_CDS_DEL}"
  HAS_DEL=1
else
  : > "${MERGED_GENE_DEL}"
  : > "${MERGED_CDS_DEL}"
fi

############################################################
# 6. Main loop over gene sets
############################################################
for LIST_FILE in "${GROUP_FILES[@]}"; do
  GROUP="$(basename "${LIST_FILE}")"
  GROUP="${GROUP%.genes.txt}"

  echo
  echo "=========================================================="
  echo "[INFO] Group = ${GROUP}"
  echo "=========================================================="

  WORK_DIR="${TMP_DIR}/${GROUP}"
  mkdir -p "${WORK_DIR}"

  ##########################################################
  # 6.1 target gene list
  ##########################################################
  GENE_LIST="${WORK_DIR}/target_gene_ids.txt"

  tr -d '\r' < "${LIST_FILE}" \
    | sed -e 's/^pedC_//' -e 's/^pedD_//' \
    | LC_ALL=C sort -u \
    > "${GENE_LIST}"

  NGENE=$(wc -l < "${GENE_LIST}" || true)
  echo "[INFO] ${GROUP} genes = ${NGENE}"
  head -n 5 "${GENE_LIST}" || true

  if [[ "${NGENE}" -eq 0 ]]; then
    echo "[WARN] Empty gene set for ${GROUP}, skip"
    continue
  fi

  ##########################################################
  # 6.2 target gene / CDS bed
  ##########################################################
  TARGET_GENE_BED="${WORK_DIR}/target_genes.bed"
  TARGET_CDS_BED="${WORK_DIR}/target_CDS.bed"

  awk 'BEGIN{OFS="\t"}{print $1,$2,$3,$4}' "${GENE_BED}" \
    | awk 'NR==FNR{a[$1]=1;next} a[$4]' "${GENE_LIST}" - \
    > "${TARGET_GENE_BED}"

  awk 'BEGIN{OFS="\t"}{
    gene=$4
    sub(/^pedC_/, "", gene)
    sub(/^pedD_/, "", gene)
    sub(/:.*/, "", gene)
    sub(/\..*/, "", gene)
    print $1,$2,$3,gene
  }' "${CDS_BED}" \
    | awk 'NR==FNR{a[$1]=1;next} a[$4]' "${GENE_LIST}" - \
    > "${TARGET_CDS_BED}"

  if [[ ! -s "${TARGET_GENE_BED}" ]]; then
    echo "[WARN] ${GROUP} target gene bed is empty, skip"
    continue
  fi
  if [[ ! -s "${TARGET_CDS_BED}" ]]; then
    echo "[WARN] ${GROUP} target CDS bed is empty, skip"
    continue
  fi

  ##########################################################
  # 6.3 target conserved sites = merged conserved ∩ target bed
  ##########################################################
  TARGET_GENE_CONS="${WORK_DIR}/target_gene_conserved_sites.bed"
  TARGET_CDS_CONS="${WORK_DIR}/target_CDS_conserved_sites.bed"

  bedtools intersect -wa -a "${MERGED_GENE_GERP}" -b "${TARGET_GENE_BED}" \
    > "${TARGET_GENE_CONS}"

  bedtools intersect -wa -a "${MERGED_CDS_GERP}" -b "${TARGET_CDS_BED}" \
    > "${TARGET_CDS_CONS}"

  ##########################################################
  # 6.4 4-col conserved-site bed: chr start end gene_id
  ##########################################################
  TARGET_GENE_SITE_BED="${WORK_DIR}/target_gene_sites.gene.bed"
  TARGET_CDS_SITE_BED="${WORK_DIR}/target_CDS_sites.gene.bed"

  if [[ -s "${TARGET_GENE_CONS}" ]]; then
    awk 'BEGIN{OFS="\t"}{
      gene=$(NF-2)
      sub(/^pedC_/, "", gene)
      sub(/^pedD_/, "", gene)
      print $1,$2,$3,gene
    }' "${TARGET_GENE_CONS}" > "${TARGET_GENE_SITE_BED}"
  else
    : > "${TARGET_GENE_SITE_BED}"
  fi

  if [[ -s "${TARGET_CDS_CONS}" ]]; then
    awk 'BEGIN{OFS="\t"}{
      gene=$(NF-2)
      sub(/^pedC_/, "", gene)
      sub(/^pedD_/, "", gene)
      sub(/:.*/, "", gene)
      sub(/\..*/, "", gene)
      print $1,$2,$3,gene
    }' "${TARGET_CDS_CONS}" > "${TARGET_CDS_SITE_BED}"
  else
    : > "${TARGET_CDS_SITE_BED}"
  fi

  ##########################################################
  # 6.5 gene length
  ##########################################################
  awk 'BEGIN{OFS="\t"}{
    len[$4]+=$3-$2
  } END{
    for(g in len) print g, len[g]
  }' "${TARGET_GENE_BED}" \
    | LC_ALL=C sort -k1,1 \
    > "${WORK_DIR}/gene_length.tsv"

  ##########################################################
  # 6.6 CDS union length
  ##########################################################
  LC_ALL=C sort -k4,4 -k1,1 -k2,2n "${TARGET_CDS_BED}" \
    | awk 'BEGIN{OFS="\t"}
      NR==1{
        cg=$4; cchr=$1; cs=$2; ce=$3; sum=0; next
      }
      {
        g=$4; chr=$1; s=$2; e=$3
        if(g!=cg || chr!=cchr){
          sum += (ce - cs)
          print cg, sum
          cg=g; cchr=chr; cs=s; ce=e; sum=0
          next
        }
        if(s <= ce){
          if(e > ce) ce=e
        } else {
          sum += (ce - cs)
          cs=s; ce=e
        }
      }
      END{
        if(NR>0){
          sum += (ce - cs)
          print cg, sum
        }
      }' \
    | LC_ALL=C sort -k1,1 \
    > "${WORK_DIR}/cds_length.tsv"

  ##########################################################
  # 6.7 conserved site count per gene
  ##########################################################
  if [[ -s "${TARGET_GENE_SITE_BED}" ]]; then
    awk 'BEGIN{OFS="\t"}{
      key=$1"\t"$2"\t"$3"\t"$4
      if(!seen[key]++) c[$4]++
    } END{
      for(g in c) print g, c[g]
    }' "${TARGET_GENE_SITE_BED}" \
      | LC_ALL=C sort -k1,1 \
      > "${WORK_DIR}/gene_conserved_count.tsv"
  else
    : > "${WORK_DIR}/gene_conserved_count.tsv"
  fi

  if [[ -s "${TARGET_CDS_SITE_BED}" ]]; then
    awk 'BEGIN{OFS="\t"}{
      key=$1"\t"$2"\t"$3"\t"$4
      if(!seen[key]++) c[$4]++
    } END{
      for(g in c) print g, c[g]
    }' "${TARGET_CDS_SITE_BED}" \
      | LC_ALL=C sort -k1,1 \
      > "${WORK_DIR}/cds_conserved_count.tsv"
  else
    : > "${WORK_DIR}/cds_conserved_count.tsv"
  fi

  ##########################################################
  # 6.8 total SNP count
  ##########################################################
  awk 'BEGIN{FS=OFS="\t"}
    NR==FNR{
      target[$1]=1
      next
    }
    {
      gene=$8
      gsub(/\r/, "", gene)
      sub(/^pedC_/, "", gene)
      sub(/^pedD_/, "", gene)
      sub(/:.*/, "", gene)
      sub(/\..*/, "", gene)
      if (!(gene in target)) next

      key=$1 "\t" $2 "\t" $3 "\t" gene
      if(!seen[key]++) c[gene]++
    }
    END{
      for(g in c) print g, c[g]
    }' "${GENE_LIST}" "${GENE_SNP_INTERSECT}" \
    | LC_ALL=C sort -k1,1 \
    > "${WORK_DIR}/gene_snp_total.tsv"

  awk 'BEGIN{FS=OFS="\t"}
    NR==FNR{
      target[$1]=1
      next
    }
    {
      gene=$8
      gsub(/\r/, "", gene)
      sub(/^pedC_/, "", gene)
      sub(/^pedD_/, "", gene)
      sub(/:.*/, "", gene)
      sub(/\..*/, "", gene)
      if (!(gene in target)) next

      key=$1 "\t" $2 "\t" $3 "\t" gene
      if(!seen[key]++) c[gene]++
    }
    END{
      for(g in c) print g, c[g]
    }' "${GENE_LIST}" "${CDS_SNP_INTERSECT}" \
    | LC_ALL=C sort -k1,1 \
    > "${WORK_DIR}/cds_snp_total.tsv"

  ##########################################################
  # 6.9 deleterious SNP count
  ##########################################################
  if [[ ${HAS_DEL} -eq 1 ]]; then
    awk 'BEGIN{FS=OFS="\t"}
      NR==FNR{
        target[$1]=1
        next
      }
      {
        gene=$11
        gsub(/\r/, "", gene)
        sub(/^pedC_/, "", gene)
        sub(/^pedD_/, "", gene)
        sub(/:.*/, "", gene)
        sub(/\..*/, "", gene)
        if (!(gene in target)) next

        key=$1 "\t" $2 "\t" $3 "\t" gene
        if(!seen[key]++) c[gene]++
      }
      END{
        for(g in c) print g, c[g]
      }' "${GENE_LIST}" "${MERGED_GENE_DEL}" \
      | LC_ALL=C sort -k1,1 \
      > "${WORK_DIR}/gene_deleterious.tsv"

    awk 'BEGIN{FS=OFS="\t"}
      NR==FNR{
        target[$1]=1
        next
      }
      {
        gene=$11
        gsub(/\r/, "", gene)
        sub(/^pedC_/, "", gene)
        sub(/^pedD_/, "", gene)
        sub(/:.*/, "", gene)
        sub(/\..*/, "", gene)
        if (!(gene in target)) next

        key=$1 "\t" $2 "\t" $3 "\t" gene
        if(!seen[key]++) c[gene]++
      }
      END{
        for(g in c) print g, c[g]
      }' "${GENE_LIST}" "${MERGED_CDS_DEL}" \
      | LC_ALL=C sort -k1,1 \
      > "${WORK_DIR}/cds_deleterious.tsv"
  else
    : > "${WORK_DIR}/gene_deleterious.tsv"
    : > "${WORK_DIR}/cds_deleterious.tsv"
  fi

  ##########################################################
  # 6.10 merge all per-gene stats
  ##########################################################
  awk -v grp="${GROUP}" 'BEGIN{FS=OFS="\t"}
    ARGIND==1{
      gene_len[$1]=$2
      genes[$1]=1
      next
    }
    ARGIND==2{
      cds_len[$1]=$2
      genes[$1]=1
      next
    }
    ARGIND==3{
      gene_cons[$1]=$2
      next
    }
    ARGIND==4{
      cds_cons[$1]=$2
      next
    }
    ARGIND==5{
      gene_snp[$1]=$2
      next
    }
    ARGIND==6{
      cds_snp[$1]=$2
      next
    }
    ARGIND==7{
      gene_del[$1]=$2
      next
    }
    ARGIND==8{
      cds_del[$1]=$2
      next
    }
    END{
      for(g in genes){
        gl = (g in gene_len)  ? gene_len[g]  : 0
        cl = (g in cds_len)   ? cds_len[g]   : 0
        gc = (g in gene_cons) ? gene_cons[g] : 0
        cc = (g in cds_cons)  ? cds_cons[g]  : 0
        gs = (g in gene_snp)  ? gene_snp[g]  : 0
        cs = (g in cds_snp)   ? cds_snp[g]   : 0
        gd = (g in gene_del)  ? gene_del[g]  : 0
        cd = (g in cds_del)   ? cds_del[g]   : 0

        gcp = (gl > 0) ? gc / gl * 100 : 0
        ccp = (cl > 0) ? cc / cl * 100 : 0
        gsr = (gl > 0) ? gs / gl : 0
        csr = (cl > 0) ? cs / cl : 0
        gdr = (gs > 0) ? gd / gs : 0
        cdr = (cs > 0) ? cd / cs : 0

        printf "%s\t%s\t%d\t%d\t%d\t%.6f\t%d\t%.6f\t%d\t%.6f\t%d\t%.6f\t%d\t%.6f\t%d\t%.6f\n", \
          grp, g, gl, cl, gc, gcp, cc, ccp, gs, gsr, gd, gdr, cs, csr, cd, cdr
      }
    }' \
    "${WORK_DIR}/gene_length.tsv" \
    "${WORK_DIR}/cds_length.tsv" \
    "${WORK_DIR}/gene_conserved_count.tsv" \
    "${WORK_DIR}/cds_conserved_count.tsv" \
    "${WORK_DIR}/gene_snp_total.tsv" \
    "${WORK_DIR}/cds_snp_total.tsv" \
    "${WORK_DIR}/gene_deleterious.tsv" \
    "${WORK_DIR}/cds_deleterious.tsv" \
    | LC_ALL=C sort -k2,2 \
    > "${WORK_DIR}/combined_per_gene.tsv"

  cat "${WORK_DIR}/combined_per_gene.tsv" >> "${FINAL_TSV}"

  ##########################################################
  # 6.11 group-level summary
  ##########################################################
  awk -v grp="${GROUP}" 'BEGIN{FS=OFS="\t"}
    {
      n++
      sum_gl+=$3
      sum_cl+=$4
      sum_gc+=$5
      sum_cc+=$7
      sum_gs+=$9
      sum_gd+=$11
      sum_cs+=$13
      sum_cd+=$15
    }
    END{
      gcp=(sum_gl>0)?sum_gc/sum_gl*100:0
      ccp=(sum_cl>0)?sum_cc/sum_cl*100:0
      gsr=(sum_gl>0)?sum_gs/sum_gl:0
      csr=(sum_cl>0)?sum_cs/sum_cl:0
      gdr=(sum_gs>0)?sum_gd/sum_gs:0
      cdr=(sum_cs>0)?sum_cd/sum_cs:0

      printf "%s\t%d\t%d\t%d\t%d\t%.6f\t%d\t%.6f\t%d\t%.6f\t%d\t%.6f\t%d\t%.6f\t%d\t%.6f\n", \
        grp, n, sum_gl, sum_cl, sum_gc, gcp, sum_cc, ccp, sum_gs, gsr, sum_gd, gdr, sum_cs, csr, sum_cd, cdr
    }' "${WORK_DIR}/combined_per_gene.tsv" \
    >> "${SUMMARY_TSV}"

  echo "[INFO] done ${GROUP}"
  echo "[INFO] rows appended: $(wc -l < "${WORK_DIR}/combined_per_gene.tsv")"
  echo "[INFO] gene conserved count entries: $(wc -l < "${WORK_DIR}/gene_conserved_count.tsv")"
  echo "[INFO] cds conserved count entries : $(wc -l < "${WORK_DIR}/cds_conserved_count.tsv")"
  echo "[INFO] gene SNP count entries      : $(wc -l < "${WORK_DIR}/gene_snp_total.tsv")"
  echo "[INFO] cds SNP count entries       : $(wc -l < "${WORK_DIR}/cds_snp_total.tsv")"
done

echo
echo "[INFO] Wrote:"
echo "[INFO]   ${FINAL_TSV}"
echo "[INFO]   ${SUMMARY_TSV}"
echo "[INFO] DONE ${CLASS}"