#!/usr/bin/env Rscript

suppressPackageStartupMessages({
  library(dplyr)
  library(tidyr)
  library(ggplot2)
  library(ggsignif)
  library(patchwork)
})

PAN_FILE <- "core_5sp_1to1.SG.pan"

THRESHOLDS <- c("gt2", "gt4", "gt6")
DATA_TYPES <- c("ALL", "SNPpos", "SNP0")

species_order <- c("P.edulis", "Z.mays", "A.tauschii")

OUTDIR <- "strict_core_snp_deleterious_results"
TABLE_DIR <- file.path(OUTDIR, "tables")
STAT_DIR  <- file.path(OUTDIR, "stats")
FIG_DIR   <- file.path(OUTDIR, "figures")

dir.create(TABLE_DIR, recursive = TRUE, showWarnings = FALSE)
dir.create(STAT_DIR,  recursive = TRUE, showWarnings = FALSE)
dir.create(FIG_DIR,   recursive = TRUE, showWarnings = FALSE)

show_ns_lines <- FALSE

read_tsv_base <- function(fp, header = TRUE) {
  if (!file.exists(fp)) stop("Missing input file: ", fp, call. = FALSE)

  read.delim(
    fp,
    header = header,
    sep = "\t",
    stringsAsFactors = FALSE,
    check.names = FALSE,
    quote = "",
    comment.char = ""
  )
}

write_tsv_base <- function(df, fp) {
  write.table(
    df,
    fp,
    sep = "\t",
    quote = FALSE,
    row.names = FALSE,
    col.names = TRUE
  )
}

strip_species_prefix <- function(x) {
  x <- as.character(x)
  x <- sub("^Atau_", "", x)
  x <- sub("^Osat_", "", x)
  x <- sub("^osat_", "", x)
  x <- sub("^pedC_", "", x)
  x <- sub("^pedD_", "", x)
  x <- sub("^Zmay_", "", x)
  x
}

p_to_star <- function(p) {
  if (is.na(p)) return("ns")
  if (p < 0.001) return("***")
  if (p < 0.01)  return("**")
  if (p < 0.05)  return("*")
  "ns"
}

build_files <- function(threshold) {
  list(
    Atau = paste0("Atau_", threshold, "_core_gene_deleterious.tsv"),
    pedC = paste0("pedC_", threshold, "_core_gene_deleterious.tsv"),
    pedD = paste0("pedD_", threshold, "_core_gene_deleterious.tsv"),
    Zmay = paste0("Zmay_", threshold, "_core_gene_deleterious.tsv")
  )
}

read_sg_pan <- function(pan_file) {
  pan <- read_tsv_base(pan_file, header = FALSE)

  if (ncol(pan) < 9) {
    stop("SG pan file should contain at least 9 columns.", call. = FALSE)
  }

  pan <- pan[, 1:9]
  colnames(pan) <- c(
    "SG",
    "n_species",
    "n_genes",
    "flag",
    "Atau_gene",
    "Osat_gene",
    "pedC_gene",
    "pedD_gene",
    "Zmay_gene"
  )

  pan %>%
    transmute(
      SG   = as.character(SG),
      Atau = strip_species_prefix(Atau_gene),
      pedC = strip_species_prefix(pedC_gene),
      pedD = strip_species_prefix(pedD_gene),
      Zmay = strip_species_prefix(Zmay_gene)
    ) %>%
    filter(
      !is.na(SG),
      Atau != "-",
      pedC != "-",
      pedD != "-",
      Zmay != "-"
    ) %>%
    distinct(SG, .keep_all = TRUE)
}

read_del_stats <- function(fp, label) {
  df <- read_tsv_base(fp, header = TRUE)

  if (!"gene_id" %in% colnames(df)) {
    colnames(df)[1] <- "gene_id"
  }

  required_cols <- c(
    "gene_id",
    "cds_len",
    "cds_snp_total",
    "cds_deleterious_snp"
  )

  missing_cols <- setdiff(required_cols, colnames(df))
  if (length(missing_cols) > 0) {
    stop(
      "Missing columns in ", fp, ": ",
      paste(missing_cols, collapse = ", "),
      call. = FALSE
    )
  }

  df %>%
    mutate(
      gene_id_norm = strip_species_prefix(gene_id),
      cds_len = suppressWarnings(as.numeric(cds_len)),
      cds_snp_total = suppressWarnings(as.numeric(cds_snp_total)),
      cds_deleterious_snp = suppressWarnings(as.numeric(cds_deleterious_snp))
    ) %>%
    filter(!is.na(gene_id_norm), gene_id_norm != "") %>%
    group_by(gene_id_norm) %>%
    summarise(
      cds_len = mean(cds_len, na.rm = TRUE),
      cds_snp_total = mean(cds_snp_total, na.rm = TRUE),
      cds_deleterious_snp = mean(cds_deleterious_snp, na.rm = TRUE),
      .groups = "drop"
    ) %>%
    rename_with(
      ~ paste0(label, "_", .x),
      c(cds_len, cds_snp_total, cds_deleterious_snp)
    )
}

build_one_threshold <- function(threshold, pan_map) {
  files <- build_files(threshold)

  Atau_df <- read_del_stats(files$Atau, "Atau")
  pedC_df <- read_del_stats(files$pedC, "pedC")
  pedD_df <- read_del_stats(files$pedD, "pedD")
  Zmay_df <- read_del_stats(files$Zmay, "Zmay")

  wide <- pan_map %>%
    left_join(Atau_df, by = c("Atau" = "gene_id_norm")) %>%
    left_join(pedC_df, by = c("pedC" = "gene_id_norm")) %>%
    left_join(pedD_df, by = c("pedD" = "gene_id_norm")) %>%
    left_join(Zmay_df, by = c("Zmay" = "gene_id_norm")) %>%
    mutate(
      ped_cds_len = pedC_cds_len + pedD_cds_len,
      ped_cds_snp_total = pedC_cds_snp_total + pedD_cds_snp_total,
      ped_cds_deleterious_snp =
        pedC_cds_deleterious_snp + pedD_cds_deleterious_snp,

      P.edulis_cds_snp_total = ped_cds_snp_total,
      Z.mays_cds_snp_total = Zmay_cds_snp_total,
      A.tauschii_cds_snp_total = Atau_cds_snp_total,

      P.edulis_SNP_density = ped_cds_snp_total / ped_cds_len,
      Z.mays_SNP_density = Zmay_cds_snp_total / Zmay_cds_len,
      A.tauschii_SNP_density = Atau_cds_snp_total / Atau_cds_len,

      P.edulis_Deleterious_ratio =
        ifelse(ped_cds_snp_total > 0,
               ped_cds_deleterious_snp / ped_cds_snp_total,
               0),

      Z.mays_Deleterious_ratio =
        ifelse(Zmay_cds_snp_total > 0,
               Zmay_cds_deleterious_snp / Zmay_cds_snp_total,
               0),

      A.tauschii_Deleterious_ratio =
        ifelse(Atau_cds_snp_total > 0,
               Atau_cds_deleterious_snp / Atau_cds_snp_total,
               0),

      threshold = threshold
    )

  wide %>%
    select(
      SG,
      threshold,
      Atau,
      pedC,
      pedD,
      Zmay,

      ped_cds_len,
      ped_cds_snp_total,
      ped_cds_deleterious_snp,

      Atau_cds_len,
      Atau_cds_snp_total,
      Atau_cds_deleterious_snp,

      Zmay_cds_len,
      Zmay_cds_snp_total,
      Zmay_cds_deleterious_snp,

      P.edulis_cds_snp_total,
      Z.mays_cds_snp_total,
      A.tauschii_cds_snp_total,

      P.edulis_SNP_density,
      Z.mays_SNP_density,
      A.tauschii_SNP_density,

      P.edulis_Deleterious_ratio,
      Z.mays_Deleterious_ratio,
      A.tauschii_Deleterious_ratio
    )
}

split_by_snp_class <- function(df) {
  df_all <- df

  df_snp_pos <- df %>%
    filter(
      P.edulis_cds_snp_total > 0,
      Z.mays_cds_snp_total > 0,
      A.tauschii_cds_snp_total > 0
    )

  df_snp0 <- df %>%
    filter(
      P.edulis_cds_snp_total == 0 |
        Z.mays_cds_snp_total == 0 |
        A.tauschii_cds_snp_total == 0
    )

  list(
    ALL = df_all,
    SNPpos = df_snp_pos,
    SNP0 = df_snp0
  )
}

run_stats_one_metric <- function(wide_df, threshold, data_type, metric) {
  cols <- paste0(species_order, "_", metric)

  stat_df <- wide_df %>%
    select(SG, all_of(cols)) %>%
    setNames(c("SG", species_order)) %>%
    filter(complete.cases(across(all_of(species_order))))

  if (nrow(stat_df) < 3) {
    return(tibble(
      threshold = threshold,
      data_type = data_type,
      metric = metric,
      test = NA_character_,
      Friedman_chisq = NA_real_,
      Friedman_df = NA_real_,
      Friedman_p = NA_real_,
      Comparison = NA_character_,
      group1 = NA_character_,
      group2 = NA_character_,
      n_pairs = nrow(stat_df),
      median_group1 = NA_real_,
      median_group2 = NA_real_,
      median_diff_group1_minus_group2 = NA_real_,
      P.raw = NA_real_,
      P.adj = NA_real_,
      label = NA_character_
    ))
  }

  mat <- as.matrix(stat_df[, species_order])
  storage.mode(mat) <- "numeric"

  fried <- friedman.test(mat)

  pair_combs <- combn(species_order, 2, simplify = FALSE)

  pair_tbl <- lapply(pair_combs, function(cc) {
    g1 <- cc[1]
    g2 <- cc[2]

    x <- stat_df[[g1]]
    y <- stat_df[[g2]]

    ok <- complete.cases(x, y)
    x <- x[ok]
    y <- y[ok]

    wt <- tryCatch(
      wilcox.test(
        x,
        y,
        paired = TRUE,
        exact = FALSE
      ),
      error = function(e) NULL
    )

    tibble(
      threshold = threshold,
      data_type = data_type,
      metric = metric,
      test = "paired Wilcoxon signed-rank test; BH correction",
      Friedman_chisq = unname(fried$statistic),
      Friedman_df = unname(fried$parameter),
      Friedman_p = fried$p.value,
      Comparison = paste0(g1, " - ", g2),
      group1 = g1,
      group2 = g2,
      n_pairs = length(x),
      median_group1 = median(x, na.rm = TRUE),
      median_group2 = median(y, na.rm = TRUE),
      median_diff_group1_minus_group2 = median(x - y, na.rm = TRUE),
      P.raw = ifelse(is.null(wt), NA_real_, wt$p.value)
    )
  }) %>%
    bind_rows() %>%
    mutate(
      P.adj = p.adjust(P.raw, method = "BH"),
      label = vapply(P.adj, p_to_star, character(1))
    )

  pair_tbl
}

make_long_df <- function(wide_df, metric) {
  cols <- paste0(species_order, "_", metric)

  wide_df %>%
    select(SG, threshold, all_of(cols)) %>%
    setNames(c("SG", "threshold", species_order)) %>%
    pivot_longer(
      cols = all_of(species_order),
      names_to = "species",
      values_to = "value"
    ) %>%
    mutate(
      species = factor(species, levels = species_order),
      value = as.numeric(value)
    ) %>%
    filter(is.finite(value))
}

make_sig_df <- function(df_plot, stat_tbl, y_offset_frac = 0.08) {
  df_plot <- df_plot %>%
    filter(is.finite(value))

  sig_df <- stat_tbl %>%
    filter(!is.na(group1), !is.na(group2), !is.na(label))

  if (!show_ns_lines) {
    sig_df <- sig_df %>% filter(label != "ns")
  }

  if (nrow(df_plot) == 0) {
    return(list(
      sig_df = sig_df[0, ],
      y_limit = 1
    ))
  }

  y_max <- max(df_plot$value, na.rm = TRUE)
  y_min <- min(df_plot$value, na.rm = TRUE)

  if (!is.finite(y_max)) y_max <- 1
  if (!is.finite(y_min)) y_min <- 0

  y_range <- y_max - y_min

  if (!is.finite(y_range) || y_range <= 0) {
    y_range <- max(abs(y_max), 1)
  }

  if (nrow(sig_df) == 0) {
    return(list(
      sig_df = sig_df,
      y_limit = y_max + 0.15 * y_range
    ))
  }

  sig_df <- sig_df %>%
    mutate(
      group1 = factor(group1, levels = species_order),
      group2 = factor(group2, levels = species_order)
    ) %>%
    arrange(group1, group2) %>%
    mutate(
      y_position = y_max + seq(
        from = y_offset_frac * y_range,
        by = y_offset_frac * y_range,
        length.out = n()
      )
    )

  list(
    sig_df = sig_df,
    y_limit = max(sig_df$y_position, na.rm = TRUE) + 0.08 * y_range
  )
}

theme_mbe <- function() {
  theme_classic(base_size = 16) +
    theme(
      plot.title = element_text(size = 14, face = "plain", hjust = 0.5),
      axis.text.x = element_text(face = "italic", size = 15, color = "black"),
      axis.text.y = element_text(size = 13, color = "black"),
      axis.title.y = element_text(size = 15, color = "black"),
      axis.title.x = element_blank(),

      panel.grid.major.y = element_line(
        color = "#E6E6E6",
        linewidth = 0.35
      ),
      panel.grid.minor.y = element_blank(),
      panel.grid.major.x = element_blank(),
      panel.grid.minor.x = element_blank(),

      panel.border = element_rect(
        fill = NA,
        color = "black",
        linewidth = 1
      ),

      plot.margin = margin(12, 12, 10, 12)
    )
}

plot_one_panel <- function(df_plot, sig_df, y_limit, title_text,
                           ylab, log10_plot = FALSE, pseudo = 1e-6) {
  if (log10_plot) {
    df_plot <- df_plot %>%
      mutate(value = log10(value + pseudo)) %>%
      filter(is.finite(value))

    if (nrow(sig_df) > 0 && nrow(df_plot) > 0) {
      sig_df$y_position <- max(df_plot$value, na.rm = TRUE) +
        seq(0.25, by = 0.25, length.out = nrow(sig_df))
    }

    y_limit <- max(
      df_plot$value,
      sig_df$y_position,
      na.rm = TRUE
    ) + 0.25

    if (!is.finite(y_limit)) y_limit <- 1
  }

  ggplot(df_plot, aes(x = species, y = value)) +
    geom_violin(
      width = 0.42,
      scale = "width",
      trim = TRUE,
      fill = "#D9D9D9",
      color = "#6E6E6E",
      linewidth = 0.8
    ) +
    geom_boxplot(
      width = 0.055,
      coef = 0.35,
      fill = "white",
      color = "black",
      linewidth = 1,
      outlier.shape = NA
    ) +
    {
      if (nrow(sig_df) > 0) {
        geom_signif(
          data = sig_df,
          aes(
            xmin = group1,
            xmax = group2,
            annotations = label,
            y_position = y_position
          ),
          manual = TRUE,
          inherit.aes = FALSE,
          textsize = 3.6,
          tip_length = 0.01,
          linewidth = 0.7
        )
      }
    } +
    scale_x_discrete(
      limits = species_order,
      labels = c("P.edulis", "Z.mays", "A.tauschii")
    ) +
    scale_y_continuous(
      limits = c(NA, y_limit),
      expand = expansion(mult = c(0.02, 0.02))
    ) +
    labs(
      x = NULL,
      y = ylab,
      title = title_text
    ) +
    theme_mbe()
}

pan_map <- read_sg_pan(PAN_FILE)

message("[OK] Loaded strict SGs: ", nrow(pan_map))

all_tables <- list()
all_stats <- list()

for (thr in THRESHOLDS) {
  message("[INFO] Processing ", thr)

  df_thr <- build_one_threshold(thr, pan_map)
  split_list <- split_by_snp_class(df_thr)

  for (dt in DATA_TYPES) {
    df_dt <- split_list[[dt]]

    out_table <- file.path(
      TABLE_DIR,
      paste0("Strict_core_", thr, "_", dt,
             "_SNP_deleterious_metrics.tsv")
    )

    write_tsv_base(df_dt, out_table)

    all_tables[[paste(thr, dt, sep = "_")]] <- df_dt

    stats_dt <- bind_rows(
      run_stats_one_metric(df_dt, thr, dt, "SNP_density"),
      run_stats_one_metric(df_dt, thr, dt, "Deleterious_ratio")
    )

    out_stat <- file.path(
      STAT_DIR,
      paste0("Strict_core_", thr, "_", dt,
             "_paired_stats.tsv")
    )

    write_tsv_base(stats_dt, out_stat)

    all_stats[[paste(thr, dt, sep = "_")]] <- stats_dt

    message(
      "[OK] ", thr, " ", dt,
      ": n_SG = ", nrow(df_dt),
      " -> ", out_table
    )
  }
}

combined_table <- bind_rows(all_tables, .id = "threshold_data_type")
combined_stats <- bind_rows(all_stats)

write_tsv_base(
  combined_table,
  file.path(TABLE_DIR, "Strict_core_ALL_thresholds_ALL_data_types_metrics.tsv")
)

write_tsv_base(
  combined_stats,
  file.path(STAT_DIR, "Strict_core_ALL_thresholds_ALL_data_types_stats.tsv")
)

for (dt in DATA_TYPES) {
  message("[INFO] Plotting ", dt)

  df_snp <- all_tables[[paste("gt4", dt, sep = "_")]]

  long_snp <- make_long_df(
    df_snp,
    metric = "SNP_density"
  )

  stats_snp <- combined_stats %>%
    filter(
      threshold == "gt4",
      data_type == dt,
      metric == "SNP_density"
    )

  sig_snp <- make_sig_df(long_snp, stats_snp)

  pA <- plot_one_panel(
    df_plot = long_snp,
    sig_df = sig_snp$sig_df,
    y_limit = sig_snp$y_limit,
    title_text = paste0("A  SNP density (", dt, ")"),
    ylab = expression(log[10]("CDS SNP density" + 10^-6)),
    log10_plot = TRUE,
    pseudo = 1e-6
  )

  panel_titles <- c(
    gt2 = paste0("B  Deleterious ratio, GERP > 2 (", dt, ")"),
    gt4 = paste0("C  Deleterious ratio, GERP > 4 (", dt, ")"),
    gt6 = paste0("D  Deleterious ratio, GERP > 6 (", dt, ")")
  )

  p_list <- list()

  for (thr in THRESHOLDS) {
    df_thr <- all_tables[[paste(thr, dt, sep = "_")]]

    long_del <- make_long_df(
      df_thr,
      metric = "Deleterious_ratio"
    )

    stats_del <- combined_stats %>%
      filter(
        threshold == thr,
        data_type == dt,
        metric == "Deleterious_ratio"
      )

    sig_del <- make_sig_df(long_del, stats_del)

    p_list[[thr]] <- plot_one_panel(
      df_plot = long_del,
      sig_df = sig_del$sig_df,
      y_limit = max(1, sig_del$y_limit),
      title_text = panel_titles[[thr]],
      ylab = "CDS deleterious SNP ratio",
      log10_plot = FALSE
    )
  }

  fig <- (pA | p_list[["gt2"]]) /
    (p_list[["gt4"]] | p_list[["gt6"]]) +
    plot_layout(guides = "collect")

  out_pdf <- file.path(
    FIG_DIR,
    paste0("Fig_strict_core_", dt,
           "_SNPclass_SNP_density_deleterious_ratio.pdf")
  )

  out_png <- file.path(
    FIG_DIR,
    paste0("Fig_strict_core_", dt,
           "_SNPclass_SNP_density_deleterious_ratio.png")
  )

  ggsave(
    out_pdf,
    fig,
    width = 8.8,
    height = 7.2,
    units = "in"
  )

  ggsave(
    out_png,
    fig,
    width = 8.8,
    height = 7.2,
    units = "in",
    dpi = 600
  )

  message("[DONE] Figure: ", out_pdf)
  message("[DONE] Figure: ", out_png)
}

message("[DONE] All results written to: ", OUTDIR)