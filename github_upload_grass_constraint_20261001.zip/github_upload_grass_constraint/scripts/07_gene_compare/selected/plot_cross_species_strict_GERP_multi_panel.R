#!/usr/bin/env Rscript

## =========================================================
## Cross-species comparison of CDS constrained proportion
## Gene set: strict syntenic 1:1:1:1 matched SG orthogroups
##
## Species order:
##   P.edulis  -> Z.mays -> A.tauschii
##
## For P.edulis:
##   pedC and pedD are merged within each SG.
##   If cds_sites and cds_len exist:
##     P.edulis cds_pct = 100 * (pedC_cds_sites + pedD_cds_sites) /
##                         (pedC_cds_len   + pedD_cds_len)
##   Otherwise:
##     P.edulis cds_pct = mean(pedC_cds_pct, pedD_cds_pct)
##
## Statistics:
##   Overall paired multi-group test:
##     Friedman test, blocked by SG
##
##   Pairwise post-hoc tests:
##     paired Wilcoxon signed-rank tests
##     BH correction across pairwise comparisons within each threshold
##
## Output:
##   Fig_cross_species_strict_1to1_multi_gt2_gt4_gt6_gray_final.pdf
##   Fig_cross_species_strict_1to1_multi_gt2_gt4_gt6_gray_final.png
##   Supplementary_paired_Wilcoxon_strict_1to1_CDS.tsv
## =========================================================

suppressPackageStartupMessages({
  library(dplyr)
  library(ggplot2)
  library(ggsignif)
  library(patchwork)
  library(grid)
})

## =========================================================
## 1. Parameters
## =========================================================

PAN_FILE <- "../../../01.OG_gene/core_5sp_1to1.SG.pan"

panels_thresholds <- c("gt2", "gt4", "gt6")
supp_thresholds   <- c("gt0", "gt2", "gt4", "gt6")

show_ns_lines <- FALSE

out_fig_prefix <- "Fig_cross_species_strict_1to1_multi_gt2_gt4_gt6_gray_final"
out_supp_tsv   <- "Supplementary_paired_Wilcoxon_strict_1to1_CDS.tsv"

species_order <- c("P.edulis", "Z.mays", "A.tauschii")

## Uniform gray, do not use species-specific colors
violin_fill <- "#D9D9D9"
violin_line <- "#6A6A6A"

## =========================================================
## 2. Input file builder
## =========================================================

build_files <- function(threshold) {
  list(
    pedC = paste0("pedC_gerp_", threshold, "_CDS_per_gene.tsv"),
    pedD = paste0("pedD_gerp_", threshold, "_CDS_per_gene.tsv"),
    Zmay = paste0("Zmay_gerp_", threshold, "_CDS_per_gene.tsv"),
    Atau = paste0("Atau_gerp_", threshold, "_CDS_per_gene.tsv")
  )
}

## =========================================================
## 3. Base TSV read/write helpers
## =========================================================

read_tsv_base <- function(fp, header = TRUE) {
  read.delim(
    file = fp,
    header = header,
    sep = "\t",
    stringsAsFactors = FALSE,
    check.names = FALSE,
    quote = "",
    comment.char = ""
  )
}

write_tsv_base <- function(df, fp) {
  write.table(
    df,
    file = fp,
    sep = "\t",
    quote = FALSE,
    row.names = FALSE,
    col.names = TRUE
  )
}

strip_species_prefix <- function(x) {
  x <- as.character(x)
  x <- sub("^Atau_", "", x)
  x <- sub("^osat_", "", x)
  x <- sub("^pedC_", "", x)
  x <- sub("^pedD_", "", x)
  x <- sub("^Zmay_", "", x)
  x
}

p_to_star <- function(p) {
  if (is.na(p)) return("ns")
  if (p < 0.001) return("***")
  if (p < 0.01)  return("**")
  if (p < 0.05)  return("*")
  "ns"
}

## =========================================================
## 4. Read strict SG pan table
## =========================================================

read_sg_pan <- function(pan_file) {
  if (!file.exists(pan_file)) {
    stop("Missing SG pan file: ", pan_file, call. = FALSE)
  }

  pan <- read_tsv_base(pan_file, header = FALSE)

  if (ncol(pan) < 9) {
    stop(
      "SG pan file should have at least 9 columns: ",
      "SG, count columns, Atau, Osat, pedC, pedD, Zmay.",
      call. = FALSE
    )
  }

  pan <- pan[, 1:9]

  colnames(pan) <- c(
    "SG",
    "n_species",
    "n_genes",
    "flag",
    "Atau_gene",
    "Osat_gene",
    "pedC_gene",
    "pedD_gene",
    "Zmay_gene"
  )

  pan_map <- pan %>%
    transmute(
      SG   = as.character(SG),
      Atau = strip_species_prefix(Atau_gene),
      pedC = strip_species_prefix(pedC_gene),
      pedD = strip_species_prefix(pedD_gene),
      Zmay = strip_species_prefix(Zmay_gene)
    ) %>%
    filter(
      !is.na(SG),
      Atau != "-",
      pedC != "-",
      pedD != "-",
      Zmay != "-"
    ) %>%
    distinct(SG, .keep_all = TRUE)

  cat("[OK] Loaded SG pan table: ", nrow(pan_map), " strict SGs\n", sep = "")

  pan_map
}

## =========================================================
## 5. Read per-gene stats
## =========================================================

read_gene_stats <- function(fp, label) {
  if (!file.exists(fp)) {
    stop("Missing input file or broken symbolic link: ", fp, call. = FALSE)
  }

  df <- read_tsv_base(fp, header = TRUE)

  if (!"gene_id" %in% colnames(df)) {
    colnames(df)[1] <- "gene_id"
  }

  if (!"cds_pct" %in% colnames(df)) {
    stop("Missing required column 'cds_pct' in file: ", fp, call. = FALSE)
  }

  df$gene_id <- as.character(df$gene_id)
  df$gene_id_norm <- strip_species_prefix(df$gene_id)
  df$cds_pct <- suppressWarnings(as.numeric(df$cds_pct))

  if ("cds_sites" %in% colnames(df)) {
    df$cds_sites <- suppressWarnings(as.numeric(df$cds_sites))
  } else {
    df$cds_sites <- NA_real_
  }

  if ("cds_len" %in% colnames(df)) {
    df$cds_len <- suppressWarnings(as.numeric(df$cds_len))
  } else {
    df$cds_len <- NA_real_
  }

  out <- df %>%
    filter(
      !is.na(gene_id_norm),
      gene_id_norm != "",
      !is.na(cds_pct)
    ) %>%
    group_by(gene_id_norm) %>%
    summarise(
      cds_pct   = mean(cds_pct, na.rm = TRUE),
      cds_sites = mean(cds_sites, na.rm = TRUE),
      cds_len   = mean(cds_len, na.rm = TRUE),
      .groups = "drop"
    )

  out$cds_sites[is.nan(out$cds_sites)] <- NA_real_
  out$cds_len[is.nan(out$cds_len)] <- NA_real_

  colnames(out) <- c(
    "gene_id_norm",
    paste0(label, "_cds_pct"),
    paste0(label, "_cds_sites"),
    paste0(label, "_cds_len")
  )

  out
}

## =========================================================
## 6. Check input files
## =========================================================

check_input_files <- function(thresholds) {
  all_files <- unlist(lapply(thresholds, build_files), use.names = FALSE)
  all_files <- unique(all_files)

  missing_files <- all_files[!file.exists(all_files)]

  if (length(missing_files) > 0) {
    cat("\n[ERROR] Missing input files or broken symbolic links:\n")
    cat(paste0("  - ", missing_files, collapse = "\n"), "\n")
    stop("Please check symbolic links in current directory.", call. = FALSE)
  }

  cat("[OK] All per-gene input files exist.\n")
}

## =========================================================
## 7. Build SG-level paired table for one threshold
## =========================================================

read_one_threshold <- function(threshold, pan_map) {
  files <- build_files(threshold)

  pedC_df <- read_gene_stats(files$pedC, "pedC")
  pedD_df <- read_gene_stats(files$pedD, "pedD")
  Zmay_df <- read_gene_stats(files$Zmay, "Zmay")
  Atau_df <- read_gene_stats(files$Atau, "Atau")

  wide <- pan_map %>%
    left_join(pedC_df, by = c("pedC" = "gene_id_norm")) %>%
    left_join(pedD_df, by = c("pedD" = "gene_id_norm")) %>%
    left_join(Zmay_df, by = c("Zmay" = "gene_id_norm")) %>%
    left_join(Atau_df, by = c("Atau" = "gene_id_norm"))

  ped_weighted_possible <- with(
    wide,
    !is.na(pedC_cds_sites) &
      !is.na(pedD_cds_sites) &
      !is.na(pedC_cds_len) &
      !is.na(pedD_cds_len) &
      (pedC_cds_len + pedD_cds_len > 0)
  )

  ped_weighted_pct <- with(
    wide,
    100 * (pedC_cds_sites + pedD_cds_sites) /
      (pedC_cds_len + pedD_cds_len)
  )

  ped_mean_pct <- rowMeans(
    wide[, c("pedC_cds_pct", "pedD_cds_pct")],
    na.rm = FALSE
  )

  wide[["P.edulis"]] <- ifelse(
    ped_weighted_possible,
    ped_weighted_pct,
    ped_mean_pct
  )

  wide[["Z.mays"]] <- wide$Zmay_cds_pct
  wide[["A.tauschii"]] <- wide$Atau_cds_pct

  wide_complete <- wide %>%
    filter(complete.cases(wide[, species_order])) %>%
    select(SG, all_of(species_order))

  if (nrow(wide_complete) < 2) {
    stop(
      "Too few complete paired SGs for threshold ",
      threshold,
      ". Complete SG count = ",
      nrow(wide_complete),
      call. = FALSE
    )
  }

  long_df <- do.call(
    rbind,
    lapply(species_order, function(sp) {
      data.frame(
        SG = wide_complete$SG,
        species = sp,
        cds_pct = wide_complete[[sp]],
        threshold = threshold,
        stringsAsFactors = FALSE
      )
    })
  )

  long_df$species <- factor(long_df$species, levels = species_order)

  cat(
    "[INFO] ", threshold,
    ": complete paired SGs = ", nrow(wide_complete),
    "\n",
    sep = ""
  )

  list(
    wide = wide_complete,
    long = long_df
  )
}

## =========================================================
## 8. Paired statistics
## =========================================================

run_stats_one_threshold <- function(wide_df, threshold) {
  mat <- as.matrix(wide_df[, species_order])
  storage.mode(mat) <- "numeric"

  fried <- friedman.test(mat)

  pair_combs <- combn(species_order, 2, simplify = FALSE)

  pair_tbl <- lapply(pair_combs, function(cc) {
    g1 <- cc[1]
    g2 <- cc[2]

    x <- wide_df[[g1]]
    y <- wide_df[[g2]]

    ok <- complete.cases(x, y)
    x <- x[ok]
    y <- y[ok]

    wt <- wilcox.test(
      x,
      y,
      paired = TRUE,
      exact = FALSE
    )

    tibble(
      threshold = threshold,
      test = "paired Wilcoxon signed-rank (BH)",
      Comparison = paste0(g1, " - ", g2),
      group1 = g1,
      group2 = g2,
      n_pairs = length(x),
      median_group1 = median(x, na.rm = TRUE),
      median_group2 = median(y, na.rm = TRUE),
      median_diff_group1_minus_group2 = median(x - y, na.rm = TRUE),
      P.raw = wt$p.value
    )
  }) %>%
    bind_rows() %>%
    mutate(
      P.adj = p.adjust(P.raw, method = "BH"),
      label = vapply(P.adj, p_to_star, character(1)),
      Friedman_chisq = unname(fried$statistic),
      Friedman_df    = unname(fried$parameter),
      Friedman_p     = fried$p.value
    ) %>%
    select(
      threshold,
      test,
      Friedman_chisq,
      Friedman_df,
      Friedman_p,
      Comparison,
      group1,
      group2,
      n_pairs,
      median_group1,
      median_group2,
      median_diff_group1_minus_group2,
      P.raw,
      P.adj,
      label
    )

  list(
    friedman = fried,
    pairwise_tbl = pair_tbl
  )
}

## =========================================================
## 9. Significance annotation
##    More vertical headroom is reserved so stars stay inside panel.
## =========================================================

make_sig_df <- function(df_plot, pairwise_tbl) {
  sig_df <- pairwise_tbl %>%
    filter(!is.na(group1), !is.na(group2), !is.na(label))

  if (!show_ns_lines) {
    sig_df <- sig_df %>% filter(label != "ns")
  }

  y_data_max <- max(df_plot$cds_pct, na.rm = TRUE)

  if (nrow(sig_df) == 0) {
    return(list(
      sig_df = sig_df,
      y_panel_max = max(108, y_data_max + 8)
    ))
  }

  ## For percentage data, anchor brackets around 100.
  ## Keep all stars inside the panel.
  y_base <- max(100, y_data_max)

  sig_df <- sig_df %>%
    mutate(
      group1 = factor(group1, levels = species_order),
      group2 = factor(group2, levels = species_order)
    ) %>%
    arrange(group1, group2) %>%
    mutate(
      y_position = y_base + seq(
        from = 3.0,
        by = 3.4,
        length.out = n()
      )
    )

  y_panel_max <- max(sig_df$y_position, na.rm = TRUE) + 9.0

  list(
    sig_df = sig_df,
    y_panel_max = y_panel_max
  )
}

## =========================================================
## 10. MBE-like theme, consistent with ped figure style
## =========================================================

theme_mbe_gray <- function() {
  theme_classic(base_size = 16) +
    theme(
      plot.title = element_text(
        size = 15,
        face = "plain",
        hjust = 0.5,
        margin = margin(b = 8)
      ),

      axis.text.x = element_text(
        face = "italic",
        size = 15,
        color = "black",
        margin = margin(t = 5)
      ),
      axis.text.y = element_text(
        size = 13.5,
        color = "black"
      ),
      axis.title.y = element_text(
        size = 15,
        color = "black",
        margin = margin(r = 8)
      ),
      axis.title.x = element_blank(),

      axis.line = element_line(
        color = "black",
        linewidth = 0.55
      ),
      axis.ticks = element_line(
        color = "black",
        linewidth = 0.55
      ),
      axis.ticks.length = unit(2.2, "pt"),

      panel.grid.major.y = element_line(
        color = "#E9E9E9",
        linewidth = 0.35
      ),
      panel.grid.minor.y = element_blank(),
      panel.grid.major.x = element_blank(),
      panel.grid.minor.x = element_blank(),

      panel.border = element_rect(
        fill = NA,
        color = "black",
        linewidth = 0.75
      ),

      plot.margin = margin(16, 14, 10, 14)
    )
}

## =========================================================
## 11. Plot one panel
## =========================================================

plot_one_panel <- function(df_plot, sig_df, y_limit, panel_title) {
  ggplot(df_plot, aes(x = species, y = cds_pct)) +

    geom_violin(
      width = 0.62,
      scale = "width",
      trim = TRUE,
      fill = violin_fill,
      color = violin_line,
      linewidth = 0.55,
      alpha = 0.90
    ) +

    geom_boxplot(
      width = 0.105,
      coef = 0.35,
      fill = "white",
      color = "black",
      linewidth = 0.75,
      outlier.shape = NA
    ) +

    {
      if (nrow(sig_df) > 0) {
        geom_signif(
          data = sig_df,
          aes(
            xmin = group1,
            xmax = group2,
            annotations = label,
            y_position = y_position
          ),
          manual = TRUE,
          inherit.aes = FALSE,
          textsize = 3.7,
          tip_length = 0.010,
          linewidth = 0.65
        )
      }
    } +

    scale_x_discrete(
      limits = species_order,
      labels = c(
        "P.edulis",
        "Z.mays",
        "A.tauschii"
      )
    ) +

    scale_y_continuous(
      limits = c(0, y_limit),
      breaks = seq(0, 100, 25),
      expand = expansion(mult = c(0, 0))
    ) +

    labs(
      x = NULL,
      y = "CDS constrained sites (%)",
      title = panel_title
    ) +

    coord_cartesian(clip = "off") +
    theme_mbe_gray()
}

## =========================================================
## 12. Safe save
## =========================================================

safe_ggsave <- function(filename, plot, width, height, dpi = NULL) {
  if (grepl("\\.pdf$", filename, ignore.case = TRUE)) {
    ok <- FALSE

    try({
      ggsave(
        filename = filename,
        plot = plot,
        width = width,
        height = height,
        device = cairo_pdf
      )
      ok <- TRUE
    }, silent = TRUE)

    if (!ok) {
      ggsave(
        filename = filename,
        plot = plot,
        width = width,
        height = height
      )
    }

  } else {
    if (is.null(dpi)) {
      ggsave(
        filename = filename,
        plot = plot,
        width = width,
        height = height
      )
    } else {
      ggsave(
        filename = filename,
        plot = plot,
        width = width,
        height = height,
        dpi = dpi
      )
    }
  }
}

## =========================================================
## 13. Main workflow
## =========================================================

all_thresholds <- unique(c(panels_thresholds, supp_thresholds))

check_input_files(all_thresholds)

pan_map <- read_sg_pan(PAN_FILE)

## =========================================================
## 14. Supplementary table: gt0 / gt2 / gt4 / gt6
## =========================================================

supp_list <- lapply(supp_thresholds, function(th) {
  cat("[INFO] Running paired statistics for threshold: ", th, "\n", sep = "")

  dat <- read_one_threshold(th, pan_map)
  st <- run_stats_one_threshold(dat$wide, th)

  st$pairwise_tbl
})

supp_tbl <- bind_rows(supp_list)

write_tsv_base(supp_tbl, out_supp_tsv)

cat("[OK] Wrote paired statistics table: ",
    out_supp_tsv, "\n", sep = "")

## =========================================================
## 15. Multi-panel figure: gt2 / gt4 / gt6
## =========================================================

panel_objs <- lapply(panels_thresholds, function(th) {
  cat("[INFO] Building figure panel for threshold: ", th, "\n", sep = "")

  dat <- read_one_threshold(th, pan_map)
  st <- run_stats_one_threshold(dat$wide, th)
  sig_info <- make_sig_df(dat$long, st$pairwise_tbl)

  list(
    long = dat$long,
    wide = dat$wide,
    stats = st$pairwise_tbl,
    sig_df = sig_info$sig_df,
    y_panel_max = sig_info$y_panel_max
  )
})

global_y <- max(
  vapply(panel_objs, function(x) x$y_panel_max, numeric(1)),
  na.rm = TRUE
)

## Longer frame and enough top space for significance labels.
## Tick labels remain 0, 25, 50, 75, 100.
global_y <- max(global_y, 110)

titles <- c(
  gt2 = "GERP > 2",
  gt4 = "GERP > 4",
  gt6 = "GERP > 6"
)

plots <- lapply(seq_along(panels_thresholds), function(i) {
  th <- panels_thresholds[i]

  plot_one_panel(
    df_plot = panel_objs[[i]]$long,
    sig_df = panel_objs[[i]]$sig_df,
    y_limit = global_y,
    panel_title = titles[[th]]
  )
})

p_multi <- plots[[1]] + plots[[2]] + plots[[3]] +
  plot_layout(ncol = 3, guides = "collect") +
  plot_annotation(tag_levels = "A") &
  theme(
    plot.tag = element_text(
      size = 22,
      face = "plain",
      color = "black"
    ),
    plot.tag.position = c(0.01, 0.98)
  )

safe_ggsave(
  filename = paste0(out_fig_prefix, ".pdf"),
  plot = p_multi,
  width = 14.2,
  height = 5.15
)

safe_ggsave(
  filename = paste0(out_fig_prefix, ".png"),
  plot = p_multi,
  width = 14.2,
  height = 5.15,
  dpi = 300
)

cat("[OK] Saved multi-panel figure: ",
    out_fig_prefix, ".pdf / .png\n", sep = "")

cat("[DONE]\n")