#!/usr/bin/env bash
#BSUB -J zmay_2sets_combined_val[1-3]
#BSUB -q Q96C1T_X12
#BSUB -n 4
#BSUB -o logs/zmay_2sets_combined_val.%J.%I.out
#BSUB -e logs/zmay_2sets_combined_val.%J.%I.err

set -euo pipefail
module load bedtools 2>/dev/null || true

WORKDIR="${LS_SUBCWD:-$PWD}"
cd "${WORKDIR}"

OUT_ROOT="two_gene_sets_combined_stats_validated"
mkdir -p logs "${OUT_ROOT}"

BASE_GERP_DIR="$HOME/workspace/PHD/2.msa/Zmay/Zmay_v5_results/GERP_output/02.constrain_stat/gerp_conservation_results"

GENE_BED="genes.merged.bed"
CDS_BED="CDS_gene_merged/CDS.gene.merged.bed"
GENE_SNP_INTERSECT="genes_processed.intersect.bed"
CDS_SNP_INTERSECT="CDS_processed.intersect.bed"

SET1_NAME="other_syntenic"
SET1_LIST="other_syntenic.genes.txt"
SET2_NAME="candidate_nonsyntenic_private"
SET2_LIST="candidate_nonsyntenic_private.genes.txt"

CLASSES=("gt2" "gt4" "gt6")
IDX=$((LSB_JOBINDEX - 1))
if [[ ${IDX} -lt 0 || ${IDX} -ge ${#CLASSES[@]} ]]; then
  echo "[ERROR] Bad LSB_JOBINDEX=${LSB_JOBINDEX}" >&2
  exit 1
fi
CLASS="${CLASSES[$IDX]}"

THRESH_OUT="${OUT_ROOT}/gerp_${CLASS}"
TMP_DIR="${THRESH_OUT}/tmp"
mkdir -p "${THRESH_OUT}" "${TMP_DIR}"

GENE_GERP="${BASE_GERP_DIR}/${CLASS}/bed_files/genes_conserved_sites.bed"
CDS_GERP="${BASE_GERP_DIR}/${CLASS}/bed_files/CDS_conserved_sites.bed"
GENE_DEL_BED="merged_${CLASS}_genes_detailed.bed"
CDS_DEL_BED="merged_${CLASS}_CDS_detailed.bed"

for f in \
  "${SET1_LIST}" \
  "${SET2_LIST}" \
  "${GENE_BED}" \
  "${CDS_BED}" \
  "${GENE_SNP_INTERSECT}" \
  "${CDS_SNP_INTERSECT}" \
  "${GENE_GERP}" \
  "${CDS_GERP}" \
  "${GENE_DEL_BED}" \
  "${CDS_DEL_BED}"
do
  [[ -s "$f" ]] || { echo "[ERROR] Missing $f" >&2; exit 1; }
done

SHARED_DIR="${TMP_DIR}/_shared"
mkdir -p "${SHARED_DIR}"
GENE4="${SHARED_DIR}/genes.4col.bed"
CDS4="${SHARED_DIR}/CDS.4col.bed"

awk 'BEGIN{OFS="\t"} NF>=4{print $1,$2,$3,$4}' "${GENE_BED}" \
  | sort -k1,1 -k2,2n -k3,3n -k4,4 > "${GENE4}"

awk 'BEGIN{OFS="\t"} NF>=4{print $1,$2,$3,$4}' "${CDS_BED}" \
  | sort -k1,1 -k2,2n -k3,3n -k4,4 > "${CDS4}"

prepare_gene_list() {
  local in_list="$1"
  local out_list="$2"
  awk 'NF>0{g=$1; sub(/\r$/, "", g); if(g!="") print g}' "${in_list}" \
    | sed '/^[[:space:]]*$/d' | sort -u > "${out_list}"
}

calc_union_length_by_gene() {
  local in_bed="$1"
  local out_tsv="$2"
  if [[ ! -s "${in_bed}" ]]; then
    : > "${out_tsv}"
    return 0
  fi
  sort -k4,4 -k1,1 -k2,2n -k3,3n "${in_bed}" \
  | awk 'BEGIN{OFS="\t"}
    {
      g=$4; chr=$1; s=$2; e=$3
      if(NR==1){cg=g; cchr=chr; cs=s; ce=e; sum=0; next}
      if(g!=cg || chr!=cchr){
        sum += (ce-cs)
        print cg, sum
        cg=g; cchr=chr; cs=s; ce=e; sum=0
        next
      }
      if(s<=ce){ if(e>ce) ce=e }
      else { sum += (ce-cs); cs=s; ce=e }
    }
    END{ if(NR>0){ sum += (ce-cs); print cg, sum } }' \
  | sort -k1,1 > "${out_tsv}"
}

check_keys_are_gene_ids() {
  local tsv="$1"
  local label="$2"
  [[ -s "${tsv}" ]] || return 0
  if awk 'BEGIN{bad=0} $1 !~ /^Zm[0-9A-Za-z]+$/ {bad=1; print $1 > "/dev/stderr"; exit 1} END{exit bad}' "${tsv}"; then
    :
  else
    echo "[ERROR] ${label} contains non-gene keys. Stop." >&2
    exit 1
  fi
}

report_missing_targets() {
  local target_list="$1"
  local gene_len_tsv="$2"
  local out_missing="$3"
  awk 'NR==FNR{a[$1]=1; next} !($1 in a){print $1}' "${gene_len_tsv}" "${target_list}" > "${out_missing}"
}

calc_one_group() {
  local GROUP_NAME="$1"
  local GROUP_LIST="$2"
  local GDIR="${TMP_DIR}/${GROUP_NAME}"
  mkdir -p "${GDIR}"

  local TARGET_LIST="${GDIR}/target_gene.list"
  local TARGET_GENE_BED="${GDIR}/target_gene.bed"
  local TARGET_CDS_BED="${GDIR}/target_cds.bed"

  prepare_gene_list "${GROUP_LIST}" "${TARGET_LIST}"
  [[ -s "${TARGET_LIST}" ]] || { echo "[ERROR] Empty gene list: ${GROUP_NAME}" >&2; exit 1; }

  awk 'NR==FNR{a[$1]=1; next} ($4 in a)' "${TARGET_LIST}" "${GENE4}" > "${TARGET_GENE_BED}"
  awk 'NR==FNR{a[$1]=1; next} ($4 in a)' "${TARGET_LIST}" "${CDS4}"  > "${TARGET_CDS_BED}"

  calc_union_length_by_gene "${TARGET_GENE_BED}" "${GDIR}/gene_length.tsv"
  calc_union_length_by_gene "${TARGET_CDS_BED}"  "${GDIR}/cds_length.tsv"

  report_missing_targets "${TARGET_LIST}" "${GDIR}/gene_length.tsv" "${GDIR}/genes_not_found_in_annotation.txt"

  if [[ -s "${TARGET_GENE_BED}" ]]; then
    bedtools intersect -wo -a "${TARGET_GENE_BED}" -b "${GENE_GERP}" \
      | awk 'BEGIN{OFS="\t"}{sum[$4]+=$NF} END{for(g in sum) print g,sum[g]}' \
      | sort -k1,1 > "${GDIR}/gene_site_count.tsv"
  else
    : > "${GDIR}/gene_site_count.tsv"
  fi

  if [[ -s "${TARGET_CDS_BED}" ]]; then
    bedtools intersect -wo -a "${TARGET_CDS_BED}" -b "${CDS_GERP}" \
      | awk 'BEGIN{OFS="\t"}{sum[$4]+=$NF} END{for(g in sum) print g,sum[g]}' \
      | sort -k1,1 > "${GDIR}/cds_site_count.tsv"
  else
    : > "${GDIR}/cds_site_count.tsv"
  fi

  if [[ -s "${TARGET_GENE_BED}" ]]; then
    bedtools intersect -wa -wb -a "${TARGET_GENE_BED}" -b "${GENE_SNP_INTERSECT}" \
      | awk 'BEGIN{OFS="\t"}{gene=$4; key=$5":"$6"-"$7; if(!seen[gene FS key]++) c[gene]++} END{for(g in c) print g,c[g]}' \
      | sort -k1,1 > "${GDIR}/gene.snp.tsv"
  else
    : > "${GDIR}/gene.snp.tsv"
  fi

  if [[ -s "${TARGET_CDS_BED}" ]]; then
    bedtools intersect -wa -wb -a "${TARGET_CDS_BED}" -b "${CDS_SNP_INTERSECT}" \
      | awk 'BEGIN{OFS="\t"}{gene=$4; key=$5":"$6"-"$7; if(!seen[gene FS key]++) c[gene]++} END{for(g in c) print g,c[g]}' \
      | sort -k1,1 > "${GDIR}/cds.snp.tsv"
  else
    : > "${GDIR}/cds.snp.tsv"
  fi

  if [[ -s "${TARGET_GENE_BED}" ]]; then
    bedtools intersect -wa -wb -a "${TARGET_GENE_BED}" -b "${GENE_DEL_BED}" \
      | awk 'BEGIN{OFS="\t"}{gene=$4; key=$5":"$6"-"$7; if(!seen[gene FS key]++) c[gene]++} END{for(g in c) print g,c[g]}' \
      | sort -k1,1 > "${GDIR}/gene.del.tsv"
  else
    : > "${GDIR}/gene.del.tsv"
  fi

  if [[ -s "${TARGET_CDS_BED}" ]]; then
    bedtools intersect -wa -wb -a "${TARGET_CDS_BED}" -b "${CDS_DEL_BED}" \
      | awk 'BEGIN{OFS="\t"}{gene=$4; key=$5":"$6"-"$7; if(!seen[gene FS key]++) c[gene]++} END{for(g in c) print g,c[g]}' \
      | sort -k1,1 > "${GDIR}/cds.del.tsv"
  else
    : > "${GDIR}/cds.del.tsv"
  fi

  check_keys_are_gene_ids "${GDIR}/gene_length.tsv" "${GROUP_NAME} gene_length.tsv"
  check_keys_are_gene_ids "${GDIR}/cds_length.tsv" "${GROUP_NAME} cds_length.tsv"
  check_keys_are_gene_ids "${GDIR}/gene_site_count.tsv" "${GROUP_NAME} gene_site_count.tsv"
  check_keys_are_gene_ids "${GDIR}/cds_site_count.tsv" "${GROUP_NAME} cds_site_count.tsv"
  check_keys_are_gene_ids "${GDIR}/gene.snp.tsv" "${GROUP_NAME} gene.snp.tsv"
  check_keys_are_gene_ids "${GDIR}/cds.snp.tsv" "${GROUP_NAME} cds.snp.tsv"
  check_keys_are_gene_ids "${GDIR}/gene.del.tsv" "${GROUP_NAME} gene.del.tsv"
  check_keys_are_gene_ids "${GDIR}/cds.del.tsv" "${GROUP_NAME} cds.del.tsv"

  awk '
    BEGIN{
      OFS="\t";
      print "group","gene_id","gene_len","cds_len",
            "gene_conserved_sites","gene_conserved_pct",
            "cds_conserved_sites","cds_conserved_pct",
            "gene_snp_total","gene_snp_ratio",
            "gene_deleterious_snp","gene_deleterious_ratio",
            "cds_snp_total","cds_snp_ratio",
            "cds_deleterious_snp","cds_deleterious_ratio";
    }
    FNR==NR {order[++n]=$1; next}
    FILENAME ~ /gene_length.tsv$/      {gl[$1]=$2; next}
    FILENAME ~ /cds_length.tsv$/       {cl[$1]=$2; next}
    FILENAME ~ /gene_site_count.tsv$/  {gcs[$1]=$2; next}
    FILENAME ~ /cds_site_count.tsv$/   {ccs[$1]=$2; next}
    FILENAME ~ /gene\.snp\.tsv$/      {gs[$1]=$2; next}
    FILENAME ~ /cds\.snp\.tsv$/       {cs[$1]=$2; next}
    FILENAME ~ /gene\.del\.tsv$/      {gd[$1]=$2; next}
    FILENAME ~ /cds\.del\.tsv$/       {cd[$1]=$2; next}
    END{
      for(i=1;i<=n;i++){
        g = order[i]
        gene_len = gl[g] + 0
        cds_len  = cl[g] + 0
        gene_cons = gcs[g] + 0
        cds_cons  = ccs[g] + 0
        gene_snp  = gs[g] + 0
        cds_snp   = cs[g] + 0
        gene_del  = gd[g] + 0
        cds_del   = cd[g] + 0
        gene_cons_pct = (gene_len>0) ? 100*gene_cons/gene_len : 0
        cds_cons_pct  = (cds_len >0) ? 100*cds_cons /cds_len  : 0
        gene_snp_ratio = (gene_len>0) ? gene_snp/gene_len : 0
        cds_snp_ratio  = (cds_len >0) ? cds_snp /cds_len  : 0
        gene_del_ratio = (gene_snp>0) ? gene_del/gene_snp : 0
        cds_del_ratio  = (cds_snp >0) ? cds_del /cds_snp  : 0
        printf "%s\t%s\t%d\t%d\t%d\t%.6f\t%d\t%.6f\t%d\t%.6f\t%d\t%.6f\t%d\t%.6f\t%d\t%.6f\n",
          grp, g,
          gene_len, cds_len,
          gene_cons, gene_cons_pct,
          cds_cons, cds_cons_pct,
          gene_snp, gene_snp_ratio,
          gene_del, gene_del_ratio,
          cds_snp, cds_snp_ratio,
          cds_del, cds_del_ratio
      }
    }
  ' grp="${GROUP_NAME}" \
    "${TARGET_LIST}" \
    "${GDIR}/gene_length.tsv" \
    "${GDIR}/cds_length.tsv" \
    "${GDIR}/gene_site_count.tsv" \
    "${GDIR}/cds_site_count.tsv" \
    "${GDIR}/gene.snp.tsv" \
    "${GDIR}/cds.snp.tsv" \
    "${GDIR}/gene.del.tsv" \
    "${GDIR}/cds.del.tsv" \
    > "${GDIR}/per_gene_combined.tsv"

  awk 'BEGIN{FS=OFS="\t"}
    NR==1{next}
    {
      n++
      sum_gene_len += $3
      sum_cds_len  += $4
      sum_gene_cons += $5
      sum_cds_cons  += $7
      sum_gene_snp += $9
      sum_gene_del += $11
      sum_cds_snp  += $13
      sum_cds_del  += $15
      mean_gene_cons_pct += $6
      mean_cds_cons_pct  += $8
      mean_gene_snp_ratio += $10
      mean_gene_del_ratio += $12
      mean_cds_snp_ratio  += $14
      mean_cds_del_ratio  += $16
    }
    END{
      print "group","n_genes","sum_gene_len","sum_cds_len","sum_gene_conserved_sites","weighted_gene_conserved_pct","sum_cds_conserved_sites","weighted_cds_conserved_pct","sum_gene_snp_total","sum_gene_deleterious_snp","sum_cds_snp_total","sum_cds_deleterious_snp","mean_gene_conserved_pct","mean_cds_conserved_pct","mean_gene_snp_ratio","mean_gene_deleterious_ratio","mean_cds_snp_ratio","mean_cds_deleterious_ratio"
      if(n==0){
        printf "%s\t0\t0\t0\t0\t0.000000\t0\t0.000000\t0\t0\t0\t0\t0.000000\t0.000000\t0.000000\t0.000000\t0.000000\t0.000000\n", grp
      } else {
        weighted_gene_cons_pct = (sum_gene_len>0) ? 100*sum_gene_cons/sum_gene_len : 0
        weighted_cds_cons_pct  = (sum_cds_len >0) ? 100*sum_cds_cons /sum_cds_len  : 0
        printf "%s\t%d\t%d\t%d\t%d\t%.6f\t%d\t%.6f\t%d\t%d\t%d\t%d\t%.6f\t%.6f\t%.6f\t%.6f\t%.6f\t%.6f\n",
          grp, n, sum_gene_len, sum_cds_len,
          sum_gene_cons, weighted_gene_cons_pct,
          sum_cds_cons, weighted_cds_cons_pct,
          sum_gene_snp, sum_gene_del,
          sum_cds_snp, sum_cds_del,
          mean_gene_cons_pct/n, mean_cds_cons_pct/n,
          mean_gene_snp_ratio/n, mean_gene_del_ratio/n,
          mean_cds_snp_ratio/n, mean_cds_del_ratio/n
      }
    }' grp="${GROUP_NAME}" "${GDIR}/per_gene_combined.tsv" > "${GDIR}/group_summary.tsv"
}

calc_one_group "${SET1_NAME}" "${SET1_LIST}"
calc_one_group "${SET2_NAME}" "${SET2_LIST}"

{
  head -n 1 "${TMP_DIR}/${SET1_NAME}/per_gene_combined.tsv"
  tail -n +2 "${TMP_DIR}/${SET1_NAME}/per_gene_combined.tsv"
  tail -n +2 "${TMP_DIR}/${SET2_NAME}/per_gene_combined.tsv"
} > "${THRESH_OUT}/all_groups_combined.tsv"

{
  head -n 1 "${TMP_DIR}/${SET1_NAME}/group_summary.tsv"
  tail -n +2 "${TMP_DIR}/${SET1_NAME}/group_summary.tsv"
  tail -n +2 "${TMP_DIR}/${SET2_NAME}/group_summary.tsv"
} > "${THRESH_OUT}/group_summary.tsv"

echo "[INFO] Output: ${THRESH_OUT}/all_groups_combined.tsv"
echo "[INFO] Output: ${THRESH_OUT}/group_summary.tsv"
