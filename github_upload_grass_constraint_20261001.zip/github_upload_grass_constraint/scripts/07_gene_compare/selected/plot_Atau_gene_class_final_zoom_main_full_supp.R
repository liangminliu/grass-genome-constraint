#!/usr/bin/env Rscript

suppressPackageStartupMessages({
  library(dplyr)
  library(tidyr)
  library(ggplot2)
  library(ggsignif)
  library(patchwork)
  library(grid)
})

## =========================================================
## Atau gene-class SNP / deleterious metrics
##
## Main figure:
##   Density metrics use zoom y-axis to show the main distribution.
##   Long tails are clipped inside the panel.
##   No outer panel box is drawn.
##
## Supplementary figure:
##   Density metrics use full-scale y-axis, 0–100.
##
## SNP0:
##   Only output gene-count barplot.
## =========================================================

PAN_FILE <- "core_5sp_1to1.SG.pan"

THRESHOLDS <- c("gt2", "gt4", "gt6")
DATA_TYPES <- c("ALL", "SNPpos", "SNP0")
VIOLIN_DATA_TYPES <- c("ALL", "SNPpos")

OUTDIR    <- "Atau_gene_class_snp_deleterious_density_results"
TABLE_DIR <- file.path(OUTDIR, "tables")
STAT_DIR  <- file.path(OUTDIR, "stats")
FIG_DIR   <- file.path(OUTDIR, "figures")

dir.create(TABLE_DIR, recursive = TRUE, showWarnings = FALSE)
dir.create(STAT_DIR,  recursive = TRUE, showWarnings = FALSE)
dir.create(FIG_DIR,   recursive = TRUE, showWarnings = FALSE)

OTHER_FILE   <- "Atau_other_syntenic.genes.txt"
PRIVATE_FILE <- "Atau_candidate_nonsyntenic_private.genes.txt"

show_ns_lines <- FALSE

class_order <- c("Core", "Syntenic", "Nonsyntenic")

class_full_names <- c(
  "Core"        = "strict_perfect_copy_syntenic_core",
  "Syntenic"    = "broad_syntenic_excluding_strict_core",
  "Nonsyntenic" = "candidate_nonsyntenic_private"
)

class_fill <- c(
  "Core"        = "#9DBFD2",
  "Syntenic"    = "#B7B0CF",
  "Nonsyntenic" = "#D8A0A5"
)

LWD_AXIS   <- 0.55
LWD_GRID   <- 0.35
LWD_PANEL  <- 0.75
LWD_VIOLIN <- 0.55
LWD_BOX    <- 0.75
LWD_SIGNIF <- 0.65
LWD_BAR    <- 0.55

## =========================================================
## Basic helpers
## =========================================================

read_tsv_base <- function(fp, header = TRUE) {
  if (!file.exists(fp)) {
    stop("Missing input file: ", fp, call. = FALSE)
  }

  read.delim(
    fp,
    header = header,
    sep = "\t",
    stringsAsFactors = FALSE,
    check.names = FALSE,
    quote = "",
    comment.char = ""
  )
}

write_tsv_base <- function(df, fp) {
  write.table(
    df,
    file = fp,
    sep = "\t",
    quote = FALSE,
    row.names = FALSE,
    col.names = TRUE
  )
}

strip_Atau_prefix <- function(x) {
  x <- as.character(x)
  x <- sub("^Atau_", "", x)
  x <- sub("^Aegilops_tauschii_", "", x)
  x
}

p_to_star <- function(p) {
  if (is.na(p)) return("ns")
  if (p < 0.001) return("***")
  if (p < 0.01)  return("**")
  if (p < 0.05)  return("*")
  "ns"
}

build_core_file <- function(thr) {
  paste0("Atau_", thr, "_core_gene_deleterious.tsv")
}

build_combined_file <- function(thr) {
  paste0("Atau_gerp_", thr, "_combined.tsv")
}

safe_ggsave <- function(filename, plot, width, height, dpi = NULL) {
  if (grepl("\\.pdf$", filename, ignore.case = TRUE)) {
    ok <- FALSE

    try({
      ggsave(
        filename = filename,
        plot = plot,
        width = width,
        height = height,
        device = cairo_pdf
      )
      ok <- TRUE
    }, silent = TRUE)

    if (!ok) {
      ggsave(
        filename = filename,
        plot = plot,
        width = width,
        height = height
      )
    }
  } else {
    ggsave(
      filename = filename,
      plot = plot,
      width = width,
      height = height,
      dpi = dpi
    )
  }
}

## =========================================================
## Gene-class map
## =========================================================

read_gene_list <- function(fp) {
  if (!file.exists(fp)) {
    stop("Missing gene list file: ", fp, call. = FALSE)
  }

  x <- scan(fp, what = character(), quiet = TRUE)
  x <- strip_Atau_prefix(x)
  x <- x[!is.na(x) & x != "" & x != "-"]

  unique(x)
}

read_core_genes_from_pan <- function() {
  pan <- read_tsv_base(PAN_FILE, header = FALSE)

  if (ncol(pan) < 9) {
    stop("core_5sp_1to1.SG.pan should have at least 9 columns.", call. = FALSE)
  }

  core <- pan %>%
    transmute(
      SG = as.character(V1),
      Atau_gene = strip_Atau_prefix(V5)
    ) %>%
    filter(
      !is.na(SG),
      !is.na(Atau_gene),
      Atau_gene != "",
      Atau_gene != "-"
    ) %>%
    distinct(Atau_gene, .keep_all = TRUE)

  cat("[OK] Strict core Atau genes from SG pan: ", nrow(core), "\n", sep = "")

  core
}

build_gene_class_map <- function() {
  core_tbl <- read_core_genes_from_pan()
  core_genes <- core_tbl$Atau_gene

  other_genes   <- read_gene_list(OTHER_FILE)
  private_genes <- read_gene_list(PRIVATE_FILE)

  other_clean <- setdiff(other_genes, core_genes)
  private_clean <- setdiff(private_genes, unique(c(core_genes, other_clean)))

  gene_class <- bind_rows(
    data.frame(
      gene_id = core_genes,
      gene_class = "Core",
      stringsAsFactors = FALSE
    ),
    data.frame(
      gene_id = other_clean,
      gene_class = "Syntenic",
      stringsAsFactors = FALSE
    ),
    data.frame(
      gene_id = private_clean,
      gene_class = "Nonsyntenic",
      stringsAsFactors = FALSE
    )
  ) %>%
    distinct(gene_id, .keep_all = TRUE) %>%
    mutate(
      gene_class = factor(gene_class, levels = class_order)
    )

  cat("[OK] Gene class map:\n")
  print(table(gene_class$gene_class, useNA = "ifany"))

  gene_class
}

## =========================================================
## Read input tables
## =========================================================

read_core_stats <- function(thr, gene_class_map) {
  fp <- build_core_file(thr)

  df <- read_tsv_base(fp, header = TRUE)

  required_cols <- c(
    "gene_id",
    "cds_len",
    "cds_snp_total",
    "cds_deleterious_snp"
  )

  miss <- setdiff(required_cols, colnames(df))

  if (length(miss) > 0) {
    stop("Missing columns in ", fp, ": ", paste(miss, collapse = ", "), call. = FALSE)
  }

  core_genes <- gene_class_map %>%
    filter(gene_class == "Core") %>%
    pull(gene_id)

  df %>%
    transmute(
      threshold = thr,
      gene_class = "Core",
      gene_id = strip_Atau_prefix(gene_id),
      cds_len = suppressWarnings(as.numeric(cds_len)),
      cds_snp_total = suppressWarnings(as.numeric(cds_snp_total)),
      cds_deleterious_snp = suppressWarnings(as.numeric(cds_deleterious_snp)),
      source = fp
    ) %>%
    filter(
      gene_id %in% core_genes,
      !is.na(cds_len),
      cds_len > 0,
      !is.na(cds_snp_total),
      !is.na(cds_deleterious_snp)
    )
}

read_noncore_stats <- function(thr, gene_class_map) {
  fp <- build_combined_file(thr)

  df <- read_tsv_base(fp, header = TRUE)

  required_cols <- c(
    "group",
    "gene_id",
    "cds_len",
    "cds_snp_total",
    "cds_deleterious_snp"
  )

  miss <- setdiff(required_cols, colnames(df))

  if (length(miss) > 0) {
    stop("Missing columns in ", fp, ": ", paste(miss, collapse = ", "), call. = FALSE)
  }

  noncore_map <- gene_class_map %>%
    filter(gene_class %in% c("Syntenic", "Nonsyntenic"))

  df %>%
    mutate(
      gene_id = strip_Atau_prefix(gene_id),
      group_class = case_when(
        group == "other_syntenic" ~ "Syntenic",
        group == "candidate_nonsyntenic_private" ~ "Nonsyntenic",
        TRUE ~ NA_character_
      )
    ) %>%
    filter(!is.na(group_class)) %>%
    inner_join(noncore_map, by = "gene_id") %>%
    filter(as.character(gene_class) == group_class) %>%
    transmute(
      threshold = thr,
      gene_class = as.character(gene_class),
      gene_id = gene_id,
      cds_len = suppressWarnings(as.numeric(cds_len)),
      cds_snp_total = suppressWarnings(as.numeric(cds_snp_total)),
      cds_deleterious_snp = suppressWarnings(as.numeric(cds_deleterious_snp)),
      source = paste0(fp, ":", group)
    ) %>%
    filter(
      !is.na(cds_len),
      cds_len > 0,
      !is.na(cds_snp_total),
      !is.na(cds_deleterious_snp)
    )
}

build_one_threshold <- function(thr, gene_class_map) {
  core_df <- read_core_stats(thr, gene_class_map)
  noncore_df <- read_noncore_stats(thr, gene_class_map)

  df <- bind_rows(core_df, noncore_df) %>%
    mutate(
      gene_class = factor(gene_class, levels = class_order),

      cds_snp_density = cds_snp_total / cds_len,

      cds_deleterious_ratio = ifelse(
        cds_snp_total > 0,
        cds_deleterious_snp / cds_snp_total,
        0
      ),

      cds_deleterious_density = cds_deleterious_snp / cds_len
    ) %>%
    filter(
      !is.na(gene_class),
      is.finite(cds_snp_density),
      is.finite(cds_deleterious_ratio),
      is.finite(cds_deleterious_density)
    ) %>%
    select(
      threshold,
      gene_class,
      gene_id,
      cds_len,
      cds_snp_total,
      cds_snp_density,
      cds_deleterious_snp,
      cds_deleterious_ratio,
      cds_deleterious_density,
      source
    )

  cat("[INFO] ", thr, " final genes by class:\n", sep = "")
  print(table(df$gene_class, useNA = "ifany"))

  df
}

split_by_snp_class <- function(df) {
  list(
    ALL = df,
    SNPpos = df %>% filter(cds_snp_total > 0),
    SNP0 = df %>% filter(cds_snp_total == 0)
  )
}

## =========================================================
## Statistics
## =========================================================

run_stats_one_metric <- function(df_plot, thr, data_type, metric) {
  df_plot <- df_plot %>%
    filter(!is.na(gene_class), is.finite(.data[[metric]])) %>%
    droplevels()

  observed_levels <- levels(droplevels(df_plot$gene_class))

  if (length(observed_levels) < 2 || nrow(df_plot) < 3) {
    return(tibble(
      threshold = thr,
      data_type = data_type,
      metric = metric,
      test = NA_character_,
      KW_chisq = NA_real_,
      KW_df = NA_real_,
      KW_p = NA_real_,
      Comparison = NA_character_,
      group1 = NA_character_,
      group2 = NA_character_,
      n_group1 = NA_integer_,
      n_group2 = NA_integer_,
      median_group1 = NA_real_,
      median_group2 = NA_real_,
      median_diff_group1_minus_group2 = NA_real_,
      P.raw = NA_real_,
      P.adj = NA_real_,
      label = NA_character_
    ))
  }

  kw <- kruskal.test(df_plot[[metric]] ~ df_plot$gene_class)
  pair_combs <- combn(observed_levels, 2, simplify = FALSE)

  pair_tbl <- lapply(pair_combs, function(cc) {
    g1 <- cc[1]
    g2 <- cc[2]

    x <- df_plot[[metric]][df_plot$gene_class == g1]
    y <- df_plot[[metric]][df_plot$gene_class == g2]

    wt <- tryCatch(
      wilcox.test(x, y, paired = FALSE, exact = FALSE),
      error = function(e) NULL
    )

    tibble(
      threshold = thr,
      data_type = data_type,
      metric = metric,
      test = "Wilcoxon rank-sum test; BH correction",
      KW_chisq = unname(kw$statistic),
      KW_df = unname(kw$parameter),
      KW_p = kw$p.value,
      Comparison = paste0(class_full_names[[g1]], " - ", class_full_names[[g2]]),
      group1 = class_full_names[[g1]],
      group2 = class_full_names[[g2]],
      n_group1 = length(x),
      n_group2 = length(y),
      median_group1 = median(x, na.rm = TRUE),
      median_group2 = median(y, na.rm = TRUE),
      median_diff_group1_minus_group2 =
        median(x, na.rm = TRUE) - median(y, na.rm = TRUE),
      P.raw = ifelse(is.null(wt), NA_real_, wt$p.value)
    )
  }) %>%
    bind_rows() %>%
    mutate(
      P.adj = p.adjust(P.raw, method = "BH"),
      label = vapply(P.adj, p_to_star, character(1))
    )

  pair_tbl
}

summarise_one_table <- function(df, thr, data_type) {
  df %>%
    group_by(threshold, gene_class) %>%
    summarise(
      data_type = data_type,
      n_genes = n(),
      n_snp_pos = sum(cds_snp_total > 0, na.rm = TRUE),
      n_snp0 = sum(cds_snp_total == 0, na.rm = TRUE),

      median_cds_len = median(cds_len, na.rm = TRUE),
      mean_cds_len = mean(cds_len, na.rm = TRUE),

      median_cds_snp_total = median(cds_snp_total, na.rm = TRUE),
      mean_cds_snp_total = mean(cds_snp_total, na.rm = TRUE),

      median_cds_snp_density = median(cds_snp_density, na.rm = TRUE),
      mean_cds_snp_density = mean(cds_snp_density, na.rm = TRUE),

      median_cds_deleterious_snp = median(cds_deleterious_snp, na.rm = TRUE),
      mean_cds_deleterious_snp = mean(cds_deleterious_snp, na.rm = TRUE),

      median_cds_deleterious_ratio = median(cds_deleterious_ratio, na.rm = TRUE),
      mean_cds_deleterious_ratio = mean(cds_deleterious_ratio, na.rm = TRUE),

      median_cds_deleterious_density = median(cds_deleterious_density, na.rm = TRUE),
      mean_cds_deleterious_density = mean(cds_deleterious_density, na.rm = TRUE),
      .groups = "drop"
    ) %>%
    mutate(
      data_type = data_type,
      gene_class_full = class_full_names[as.character(gene_class)]
    ) %>%
    select(
      threshold,
      data_type,
      gene_class,
      gene_class_full,
      everything()
    )
}

## =========================================================
## Plot helpers
## =========================================================

choose_exp10_from_positive_median <- function(x) {
  x <- x[is.finite(x) & x > 0]

  if (length(x) == 0) return(0)

  ref <- median(x, na.rm = TRUE)

  if (!is.finite(ref) || ref <= 0) return(0)

  floor(log10(ref))
}

make_scaled_ylab <- function(label_text, exp10) {
  if (is.null(exp10) || exp10 == 0) {
    return(label_text)
  }

  bquote(.(label_text) ~ "(" %*% 10^.(exp10) * ")")
}

density_breaks_100 <- function() {
  c(0, 25, 50, 75, 100)
}

ratio_breaks_1 <- function() {
  c(0, 0.25, 0.5, 0.75, 1)
}

count_breaks_4segment <- function(y_upper) {
  if (!is.finite(y_upper) || y_upper <= 0) {
    return(c(0, 1, 2, 3, 4))
  }

  step <- ceiling(y_upper / 4)
  step <- max(step, 1)

  seq(0, step * 4, by = step)
}

get_zoom_upper <- function(x, prob = 0.95, min_upper = 1) {
  x <- x[is.finite(x) & x >= 0]

  if (length(x) == 0) return(min_upper)

  q <- as.numeric(quantile(x, probs = prob, na.rm = TRUE))

  if (!is.finite(q) || q <= 0) {
    q <- max(x, na.rm = TRUE)
  }

  max(q, min_upper, na.rm = TRUE)
}

make_zoom_integer_breaks <- function(y_upper) {
  if (!is.finite(y_upper) || y_upper <= 0) {
    return(c(0, 1, 2, 3, 4))
  }

  step <- ceiling(y_upper / 4)

  if (step >= 10) {
    step <- ceiling(step / 5) * 5
  }

  step <- max(step, 1)

  seq(0, step * 4, by = step)
}

format_density_number <- function(x) {
  format(round(x), trim = TRUE, scientific = FALSE, big.mark = ",")
}

format_ratio_number <- function(x) {
  out <- sprintf("%.2f", x)
  out <- sub("0+$", "", out)
  out <- sub("\\.$", "", out)
  out
}

format_count_number <- function(x) {
  format(round(x), trim = TRUE, scientific = FALSE, big.mark = ",")
}

zoom_prob_by_threshold <- function(thr) {
  if (thr == "gt6") {
    0.97
  } else {
    0.95
  }
}

make_sig_df_groups <- function(stat_tbl) {
  sig_df <- stat_tbl %>%
    filter(!is.na(group1), !is.na(group2), !is.na(label))

  inv_map <- setNames(names(class_full_names), class_full_names)

  sig_df <- sig_df %>%
    mutate(
      group1_plot = inv_map[group1],
      group2_plot = inv_map[group2]
    ) %>%
    filter(
      !is.na(group1_plot),
      !is.na(group2_plot)
    )

  if (!show_ns_lines) {
    sig_df <- sig_df %>% filter(label != "ns")
  }

  sig_df %>%
    mutate(
      group1_plot = factor(group1_plot, levels = class_order),
      group2_plot = factor(group2_plot, levels = class_order)
    ) %>%
    arrange(group1_plot, group2_plot)
}

theme_mbe <- function() {
  theme_classic(base_size = 16) +
    theme(
      plot.title = element_text(
        size = 13.2,
        face = "plain",
        hjust = 0.5,
        margin = margin(b = 5)
      ),

      axis.text.x = element_text(
        size = 13.2,
        color = "black",
        margin = margin(t = 4)
      ),
      axis.text.y = element_text(
        size = 12.2,
        color = "black"
      ),
      axis.title.y = element_text(
        size = 14.2,
        color = "black",
        margin = margin(r = 7)
      ),
      axis.title.x = element_blank(),

      ## Only left and bottom axes are kept.
      ## The outer panel box is removed.
      axis.line = element_line(color = "black", linewidth = LWD_AXIS),
      axis.ticks = element_line(color = "black", linewidth = LWD_AXIS),
      axis.ticks.length = unit(2.0, "pt"),

      panel.grid.major.y = element_line(
        color = "#E9E9E9",
        linewidth = LWD_GRID
      ),
      panel.grid.minor.y = element_blank(),
      panel.grid.major.x = element_blank(),
      panel.grid.minor.x = element_blank(),

      panel.border = element_blank(),

      plot.margin = margin(6, 9, 6, 9)
    )
}

plot_one_panel_continuous <- function(df_plot,
                                      stat_tbl,
                                      value_col,
                                      panel_title,
                                      ylab_base,
                                      scale_exp10 = NULL,
                                      y_mode = c(
                                        "density_zoom",
                                        "density_full100",
                                        "ratio_fixed1"
                                      ),
                                      zoom_prob = 0.95) {

  y_mode <- match.arg(y_mode)

  plot_df <- df_plot %>%
    filter(is.finite(.data[[value_col]])) %>%
    mutate(raw_value = .data[[value_col]])

  if (!is.null(scale_exp10)) {
    scale_factor <- 10^scale_exp10
    plot_df <- plot_df %>%
      mutate(plot_value = raw_value / scale_factor)
    ylab_use <- make_scaled_ylab(ylab_base, scale_exp10)
  } else {
    plot_df <- plot_df %>%
      mutate(plot_value = raw_value)
    ylab_use <- ylab_base
  }

  sig_plot <- make_sig_df_groups(stat_tbl)

  if (y_mode == "density_zoom") {
    y_body <- get_zoom_upper(
      plot_df$plot_value,
      prob = zoom_prob,
      min_upper = 1
    )

    breaks_use <- make_zoom_integer_breaks(y_body * 1.18)
    y_upper_plot <- max(breaks_use)
    labels_use <- format_density_number

    if (nrow(sig_plot) > 0) {
      sig_plot <- sig_plot %>%
        mutate(
          y_position = seq(
            from = 0.78 * y_upper_plot,
            to   = 0.90 * y_upper_plot,
            length.out = n()
          )
        )
    }

  } else if (y_mode == "density_full100") {
    breaks_use <- density_breaks_100()
    labels_use <- format_density_number
    y_upper_plot <- 106

    if (nrow(sig_plot) > 0) {
      sig_plot <- sig_plot %>%
        mutate(
          y_position = seq(
            from = 90,
            to   = 102,
            length.out = n()
          )
        )
    }

  } else if (y_mode == "ratio_fixed1") {
    breaks_use <- ratio_breaks_1()
    labels_use <- format_ratio_number
    y_upper_plot <- 1.10

    if (nrow(sig_plot) > 0) {
      sig_plot <- sig_plot %>%
        mutate(
          y_position = seq(
            from = 1.02,
            to   = 1.08,
            length.out = n()
          )
        )
    }
  }

  lower_pad <- 0.018 * y_upper_plot
  y_lower <- -lower_pad

  ggplot(
    plot_df,
    aes(
      x = gene_class,
      y = plot_value,
      fill = gene_class
    )
  ) +
    geom_violin(
      width = 0.62,
      scale = "width",
      trim = TRUE,
      color = "#5F5F5F",
      linewidth = LWD_VIOLIN,
      alpha = 0.85
    ) +
    geom_boxplot(
      width = 0.105,
      coef = 0.35,
      fill = "white",
      color = "black",
      linewidth = LWD_BOX,
      outlier.shape = NA
    ) +
    {
      if (nrow(sig_plot) > 0) {
        geom_signif(
          data = sig_plot,
          aes(
            xmin = group1_plot,
            xmax = group2_plot,
            annotations = label,
            y_position = y_position
          ),
          manual = TRUE,
          inherit.aes = FALSE,
          textsize = 3.25,
          tip_length = 0.008,
          linewidth = LWD_SIGNIF
        )
      }
    } +
    scale_fill_manual(
      values = class_fill,
      guide = "none"
    ) +
    scale_x_discrete(
      limits = class_order,
      labels = class_order
    ) +
    scale_y_continuous(
      breaks = breaks_use,
      labels = labels_use,
      expand = expansion(mult = c(0, 0))
    ) +
    coord_cartesian(
      ylim = c(y_lower, y_upper_plot),
      clip = "on"
    ) +
    labs(
      x = NULL,
      y = ylab_use,
      title = panel_title
    ) +
    theme_mbe()
}

## =========================================================
## SNP0 count table and plot
## =========================================================

build_snp0_count_table <- function(all_tables) {
  count_tbl <- lapply(THRESHOLDS, function(thr) {
    df_all  <- all_tables[[paste(thr, "ALL", sep = "_")]]
    df_snp0 <- all_tables[[paste(thr, "SNP0", sep = "_")]]

    total_tbl <- df_all %>%
      group_by(gene_class) %>%
      summarise(
        n_total_genes = n(),
        .groups = "drop"
      )

    snp0_tbl <- df_snp0 %>%
      group_by(gene_class) %>%
      summarise(
        n_snp0_genes = n(),
        .groups = "drop"
      )

    full_join(total_tbl, snp0_tbl, by = "gene_class") %>%
      mutate(
        threshold = thr,
        gene_class = factor(gene_class, levels = class_order),
        n_total_genes = ifelse(is.na(n_total_genes), 0L, n_total_genes),
        n_snp0_genes = ifelse(is.na(n_snp0_genes), 0L, n_snp0_genes),
        prop_snp0 = ifelse(n_total_genes > 0, n_snp0_genes / n_total_genes, NA_real_)
      )
  }) %>%
    bind_rows() %>%
    complete(
      threshold = THRESHOLDS,
      gene_class = factor(class_order, levels = class_order),
      fill = list(
        n_total_genes = 0L,
        n_snp0_genes = 0L,
        prop_snp0 = NA_real_
      )
    ) %>%
    arrange(factor(threshold, levels = THRESHOLDS), gene_class) %>%
    mutate(
      gene_class_full = class_full_names[as.character(gene_class)]
    ) %>%
    select(
      threshold,
      gene_class,
      gene_class_full,
      n_snp0_genes,
      n_total_genes,
      prop_snp0
    )

  count_tbl
}

plot_snp0_count_panel <- function(df_count,
                                  panel_title,
                                  y_upper) {

  if (!is.finite(y_upper) || y_upper <= 0) {
    y_upper <- 1
  }

  breaks_use <- count_breaks_4segment(y_upper)
  y_upper_plot <- max(breaks_use)

  plot_df <- df_count %>%
    mutate(
      gene_class = factor(gene_class, levels = class_order),
      label_text = format(n_snp0_genes, big.mark = ",", scientific = FALSE)
    )

  ggplot(
    plot_df,
    aes(
      x = gene_class,
      y = n_snp0_genes,
      fill = gene_class
    )
  ) +
    geom_col(
      width = 0.62,
      color = "#5F5F5F",
      linewidth = LWD_BAR,
      alpha = 0.90
    ) +
    geom_text(
      aes(label = label_text),
      vjust = -0.25,
      size = 3.4,
      color = "black"
    ) +
    scale_fill_manual(
      values = class_fill,
      guide = "none"
    ) +
    scale_x_discrete(
      limits = class_order,
      labels = class_order
    ) +
    scale_y_continuous(
      breaks = breaks_use,
      labels = format_count_number,
      expand = expansion(mult = c(0, 0))
    ) +
    coord_cartesian(
      ylim = c(0, y_upper_plot),
      clip = "on"
    ) +
    labs(
      x = NULL,
      y = "Number of genes with CDS SNP = 0",
      title = panel_title
    ) +
    theme_mbe()
}

## =========================================================
## Main workflow
## =========================================================

gene_class_map <- build_gene_class_map()

all_tables <- list()
all_stats <- list()
all_summary <- list()

for (thr in THRESHOLDS) {
  cat("[INFO] Processing threshold: ", thr, "\n", sep = "")

  df_thr <- build_one_threshold(thr, gene_class_map)
  split_list <- split_by_snp_class(df_thr)

  for (dt in DATA_TYPES) {
    df_dt <- split_list[[dt]]

    out_table <- file.path(
      TABLE_DIR,
      paste0(
        "Atau_gene_class_",
        thr,
        "_",
        dt,
        "_SNP_deleterious_density_metrics.tsv"
      )
    )

    write_tsv_base(df_dt, out_table)

    stat_dt <- bind_rows(
      run_stats_one_metric(df_dt, thr, dt, "cds_snp_density"),
      run_stats_one_metric(df_dt, thr, dt, "cds_deleterious_ratio"),
      run_stats_one_metric(df_dt, thr, dt, "cds_deleterious_density")
    )

    out_stat <- file.path(
      STAT_DIR,
      paste0(
        "Atau_gene_class_",
        thr,
        "_",
        dt,
        "_SNP_deleterious_density_stats.tsv"
      )
    )

    write_tsv_base(stat_dt, out_stat)

    summary_dt <- summarise_one_table(df_dt, thr, dt)

    out_summary <- file.path(
      TABLE_DIR,
      paste0(
        "Atau_gene_class_",
        thr,
        "_",
        dt,
        "_summary.tsv"
      )
    )

    write_tsv_base(summary_dt, out_summary)

    all_tables[[paste(thr, dt, sep = "_")]] <- df_dt
    all_stats[[paste(thr, dt, sep = "_")]] <- stat_dt
    all_summary[[paste(thr, dt, sep = "_")]] <- summary_dt

    cat("[OK] ", thr, " ", dt, ": n_genes = ", nrow(df_dt), "\n", sep = "")
    print(table(df_dt$gene_class, useNA = "ifany"))
  }
}

combined_metrics <- bind_rows(all_tables, .id = "threshold_data_type")
combined_stats   <- bind_rows(all_stats)
combined_summary <- bind_rows(all_summary)

write_tsv_base(
  combined_metrics,
  file.path(TABLE_DIR, "Atau_gene_class_ALL_thresholds_ALL_data_types_metrics.tsv")
)

write_tsv_base(
  combined_stats,
  file.path(STAT_DIR, "Atau_gene_class_ALL_thresholds_ALL_data_types_stats.tsv")
)

write_tsv_base(
  combined_summary,
  file.path(TABLE_DIR, "Atau_gene_class_ALL_thresholds_ALL_data_types_summary.tsv")
)

## =========================================================
## SNP0 count figure
## =========================================================

snp0_count_tbl <- build_snp0_count_table(all_tables)

write_tsv_base(
  snp0_count_tbl,
  file.path(TABLE_DIR, "Atau_gene_class_SNP0_gene_counts_by_threshold.tsv")
)

snp0_y_upper <- max(snp0_count_tbl$n_snp0_genes, na.rm = TRUE)

if (!is.finite(snp0_y_upper) || snp0_y_upper <= 0) {
  snp0_y_upper <- 1
} else {
  snp0_y_upper <- snp0_y_upper * 1.06
}

snp0_title_map <- c(
  gt2 = "A  Genes with CDS SNP = 0, GERP > 2",
  gt4 = "B  Genes with CDS SNP = 0, GERP > 4",
  gt6 = "C  Genes with CDS SNP = 0, GERP > 6"
)

snp0_plots <- lapply(THRESHOLDS, function(thr) {
  df_count <- snp0_count_tbl %>%
    filter(threshold == thr)

  plot_snp0_count_panel(
    df_count = df_count,
    panel_title = snp0_title_map[[thr]],
    y_upper = snp0_y_upper
  )
})

fig_snp0_count <- snp0_plots[[1]] + snp0_plots[[2]] + snp0_plots[[3]] +
  plot_layout(ncol = 3, guides = "collect")

safe_ggsave(
  file.path(FIG_DIR, "Fig_Atau_gene_class_SNP0_gene_counts_final.pdf"),
  fig_snp0_count,
  width = 12.4,
  height = 3.35
)

safe_ggsave(
  file.path(FIG_DIR, "Fig_Atau_gene_class_SNP0_gene_counts_final.png"),
  fig_snp0_count,
  width = 12.4,
  height = 3.35,
  dpi = 300
)

## =========================================================
## Figure 1:
## SNP density + deleterious ratio
## Main: zoom density
## Supplement: full-scale density
## Output names are unchanged, so old figures are overwritten.
## =========================================================

for (dt in VIOLIN_DATA_TYPES) {
  cat("[INFO] Plotting SNP density + deleterious ratio, data type: ", dt, "\n", sep = "")

  for (fig_mode in c("mainZoom", "suppFull")) {

    df_snp <- all_tables[[paste("gt4", dt, sep = "_")]]

    stat_snp <- combined_stats %>%
      filter(
        threshold == "gt4",
        data_type == dt,
        metric == "cds_snp_density"
      )

    snp_exp10 <- choose_exp10_from_positive_median(df_snp$cds_snp_density)

    snp_y_mode <- ifelse(fig_mode == "mainZoom", "density_zoom", "density_full100")

    pA <- plot_one_panel_continuous(
      df_plot = df_snp,
      stat_tbl = stat_snp,
      value_col = "cds_snp_density",
      panel_title = paste0("A  SNP density (", dt, ")"),
      ylab_base = "CDS SNP density",
      scale_exp10 = snp_exp10,
      y_mode = snp_y_mode,
      zoom_prob = 0.95
    )

    p_list <- list()

    title_map <- c(
      gt2 = paste0("B  Deleterious ratio, GERP > 2 (", dt, ")"),
      gt4 = paste0("C  Deleterious ratio, GERP > 4 (", dt, ")"),
      gt6 = paste0("D  Deleterious ratio, GERP > 6 (", dt, ")")
    )

    for (thr in THRESHOLDS) {
      df_del <- all_tables[[paste(thr, dt, sep = "_")]]

      stat_del <- combined_stats %>%
        filter(
          threshold == thr,
          data_type == dt,
          metric == "cds_deleterious_ratio"
        )

      p_list[[thr]] <- plot_one_panel_continuous(
        df_plot = df_del,
        stat_tbl = stat_del,
        value_col = "cds_deleterious_ratio",
        panel_title = title_map[[thr]],
        ylab_base = "CDS deleterious SNP ratio",
        scale_exp10 = NULL,
        y_mode = "ratio_fixed1"
      )
    }

    fig <- (pA | p_list[["gt2"]]) /
      (p_list[["gt4"]] | p_list[["gt6"]]) +
      plot_layout(guides = "collect")

    mode_suffix <- ifelse(fig_mode == "mainZoom", "mainZoom", "suppFullScale")

    out_pdf <- file.path(
      FIG_DIR,
      paste0(
        "Fig_Atau_gene_class_",
        dt,
        "_SNP_density_deleterious_ratio_",
        mode_suffix,
        ".pdf"
      )
    )

    out_png <- file.path(
      FIG_DIR,
      paste0(
        "Fig_Atau_gene_class_",
        dt,
        "_SNP_density_deleterious_ratio_",
        mode_suffix,
        ".png"
      )
    )

    safe_ggsave(out_pdf, fig, width = 8.7, height = 5.25)
    safe_ggsave(out_png, fig, width = 8.7, height = 5.25, dpi = 300)
  }
}

## =========================================================
## Figure 2:
## Deleterious density
## Main: zoom y-axis with clipped tails
## Supplement: full-scale 0–100
## Output names are unchanged, so old figures are overwritten.
## =========================================================

for (dt in VIOLIN_DATA_TYPES) {
  cat("[INFO] Plotting deleterious density, data type: ", dt, "\n", sep = "")

  for (fig_mode in c("mainZoom", "suppFull")) {

    p_list <- list()

    title_map <- c(
      gt2 = paste0("A  Deleterious density, GERP > 2 (", dt, ")"),
      gt4 = paste0("B  Deleterious density, GERP > 4 (", dt, ")"),
      gt6 = paste0("C  Deleterious density, GERP > 6 (", dt, ")")
    )

    den_values_dt <- unlist(
      lapply(THRESHOLDS, function(thr) {
        all_tables[[paste(thr, dt, sep = "_")]]$cds_deleterious_density
      }),
      use.names = FALSE
    )

    den_exp10 <- choose_exp10_from_positive_median(den_values_dt)

    for (thr in THRESHOLDS) {
      df_den <- all_tables[[paste(thr, dt, sep = "_")]]

      stat_den <- combined_stats %>%
        filter(
          threshold == thr,
          data_type == dt,
          metric == "cds_deleterious_density"
        )

      y_mode_use <- ifelse(fig_mode == "mainZoom", "density_zoom", "density_full100")

      p_list[[thr]] <- plot_one_panel_continuous(
        df_plot = df_den,
        stat_tbl = stat_den,
        value_col = "cds_deleterious_density",
        panel_title = title_map[[thr]],
        ylab_base = "CDS deleterious density",
        scale_exp10 = den_exp10,
        y_mode = y_mode_use,
        zoom_prob = zoom_prob_by_threshold(thr)
      )
    }

    fig_den <- p_list[["gt2"]] + p_list[["gt4"]] + p_list[["gt6"]] +
      plot_layout(ncol = 3, guides = "collect")

    mode_suffix <- ifelse(fig_mode == "mainZoom", "mainZoom", "suppFullScale")

    out_pdf <- file.path(
      FIG_DIR,
      paste0(
        "Fig_Atau_gene_class_",
        dt,
        "_deleterious_density_",
        mode_suffix,
        ".pdf"
      )
    )

    out_png <- file.path(
      FIG_DIR,
      paste0(
        "Fig_Atau_gene_class_",
        dt,
        "_deleterious_density_",
        mode_suffix,
        ".png"
      )
    )

    safe_ggsave(out_pdf, fig_den, width = 12.4, height = 3.35)
    safe_ggsave(out_png, fig_den, width = 12.4, height = 3.35, dpi = 300)
  }
}

cat("[DONE] All results written to: ", OUTDIR, "\n", sep = "")