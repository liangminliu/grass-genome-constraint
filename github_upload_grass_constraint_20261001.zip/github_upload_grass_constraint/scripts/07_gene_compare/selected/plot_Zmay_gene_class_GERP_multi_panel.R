#!/usr/bin/env Rscript

## =========================================================
## Zea mays within-species comparison of CDS GERP conservation
##
## Gene classes:
##   1) strict perfect-copy syntenic core
##   2) broad syntenic genes excluding strict core
##   3) candidate nonsyntenic/private genes
##
## Plot labels:
##   Core
##   Syntenic
##   Nonsyntenic
##
## Statistics:
##   Kruskal-Wallis test
##   pairwise Wilcoxon rank-sum test with BH correction
##
## Input:
##   ../../../01.OG_gene/core_5sp_1to1.SG.pan
##   Zmay_other_syntenic.genes.txt
##   Zmay_candidate_nonsyntenic_private.genes.txt
##   Zmay_gerp_gt2_combined.tsv
##   Zmay_gerp_gt4_combined.tsv
##   Zmay_gerp_gt6_combined.tsv
##
## Optional fallback input for strict core genes:
##   Zmay_gerp_gt2_CDS_per_gene.tsv
##   Zmay_gerp_gt4_CDS_per_gene.tsv
##   Zmay_gerp_gt6_CDS_per_gene.tsv
##
## Output:
##   Fig_Zmay_gene_class_GERP_gt2_gt4_gt6.pdf
##   Fig_Zmay_gene_class_GERP_gt2_gt4_gt6.png
##   Supplementary_Zmay_gene_class_Wilcoxon_GERP.tsv
##   Zmay_gene_class_counts_by_threshold.tsv
## =========================================================

suppressPackageStartupMessages({
  library(dplyr)
  library(ggplot2)
  library(ggsignif)
  library(patchwork)
})

## =========================================================
## 1. Parameters
## =========================================================
PAN_FILE     <- "../../../01.OG_gene/core_5sp_1to1.SG.pan"
OTHER_FILE   <- "Zmay_other_syntenic.genes.txt"
PRIVATE_FILE <- "Zmay_candidate_nonsyntenic_private.genes.txt"

panels_thresholds <- c("gt2", "gt4", "gt6")
supp_thresholds   <- c("gt2", "gt4", "gt6")

show_ns_lines <- FALSE

out_fig_prefix <- "Fig_Zmay_gene_class_GERP_gt2_gt4_gt6"
out_supp_tsv   <- "Supplementary_Zmay_gene_class_Wilcoxon_GERP.tsv"
out_count_tsv  <- "Zmay_gene_class_counts_by_threshold.tsv"

## Short labels for plotting
class_order <- c("Core", "Syntenic", "Nonsyntenic")

## Full names for output table
class_full_names <- c(
  "Core"        = "strict_perfect_copy_syntenic_core",
  "Syntenic"    = "broad_syntenic_excluding_strict_core",
  "Nonsyntenic" = "candidate_nonsyntenic_private"
)

## MBE-like low-saturation palette
class_fill <- c(
  "Core"        = "#9DBFD2",
  "Syntenic"    = "#B7B0CF",
  "Nonsyntenic" = "#D8A0A5"
)

## =========================================================
## 2. File builders
## =========================================================
build_combined_file <- function(threshold) {
  paste0("Zmay_gerp_", threshold, "_combined.tsv")
}

build_core_per_gene_file <- function(threshold) {
  paste0("Zmay_gerp_", threshold, "_CDS_per_gene.tsv")
}

## =========================================================
## 3. Base TSV read/write helpers
## =========================================================
read_tsv_base <- function(fp, header = TRUE) {
  read.delim(
    file = fp,
    header = header,
    sep = "\t",
    stringsAsFactors = FALSE,
    check.names = FALSE,
    quote = "",
    comment.char = ""
  )
}

write_tsv_base <- function(df, fp) {
  write.table(
    df,
    file = fp,
    sep = "\t",
    quote = FALSE,
    row.names = FALSE,
    col.names = TRUE
  )
}

strip_species_prefix <- function(x) {
  x <- as.character(x)
  x <- sub("^Zmay_", "", x)
  x <- sub("^Zea_mays_", "", x)
  x
}

p_to_star <- function(p) {
  if (is.na(p)) return("ns")
  if (p < 0.001) return("***")
  if (p < 0.01)  return("**")
  if (p < 0.05)  return("*")
  "ns"
}

## =========================================================
## 4. Read gene lists
## =========================================================
read_gene_list <- function(fp) {
  if (!file.exists(fp)) {
    stop("Missing gene list file: ", fp, call. = FALSE)
  }

  x <- scan(
    fp,
    what = character(),
    quiet = TRUE
  )

  x <- strip_species_prefix(x)
  x <- x[!is.na(x) & x != "" & x != "-"]

  unique(x)
}

read_strict_core_genes_from_pan <- function(pan_file) {
  if (!file.exists(pan_file)) {
    stop("Missing SG pan file: ", pan_file, call. = FALSE)
  }

  pan <- read_tsv_base(pan_file, header = FALSE)

  if (ncol(pan) < 9) {
    stop(
      "SG pan file should have at least 9 columns. ",
      "Expected Zmay gene in column 9.",
      call. = FALSE
    )
  }

  ## core_5sp_1to1.SG.pan columns:
  ## 1 SG
  ## 2 n_species
  ## 3 n_genes
  ## 4 flag
  ## 5 Atau
  ## 6 Osat
  ## 7 pedC
  ## 8 pedD
  ## 9 Zmay
  Zmay <- strip_species_prefix(pan[[9]])

  genes <- unique(Zmay)
  genes <- genes[!is.na(genes) & genes != "" & genes != "-"]

  cat("[OK] Strict core genes from SG pan: ", length(genes), "\n", sep = "")

  genes
}

build_gene_class_map <- function() {
  strict_genes  <- read_strict_core_genes_from_pan(PAN_FILE)
  other_genes   <- read_gene_list(OTHER_FILE)
  private_genes <- read_gene_list(PRIVATE_FILE)

  ## Ensure mutually exclusive classes
  other_excluding_strict <- setdiff(other_genes, strict_genes)

  private_clean <- setdiff(
    private_genes,
    unique(c(strict_genes, other_excluding_strict))
  )

  gene_class <- bind_rows(
    data.frame(
      gene_id_norm = strict_genes,
      gene_class = "Core",
      stringsAsFactors = FALSE
    ),
    data.frame(
      gene_id_norm = other_excluding_strict,
      gene_class = "Syntenic",
      stringsAsFactors = FALSE
    ),
    data.frame(
      gene_id_norm = private_clean,
      gene_class = "Nonsyntenic",
      stringsAsFactors = FALSE
    )
  ) %>%
    distinct(gene_id_norm, .keep_all = TRUE) %>%
    mutate(
      gene_class = factor(gene_class, levels = class_order)
    )

  cat("[OK] Gene class map:\n")
  print(table(gene_class$gene_class, useNA = "ifany"))

  gene_class
}

## =========================================================
## 5. Extract CDS constrained percentage from stats table
## =========================================================
get_cds_pct_column <- function(df, fp) {
  if ("cds_conserved_pct" %in% colnames(df)) {
    return(suppressWarnings(as.numeric(df$cds_conserved_pct)))
  }

  if ("cds_pct" %in% colnames(df)) {
    return(suppressWarnings(as.numeric(df$cds_pct)))
  }

  if (all(c("cds_conserved_sites", "cds_len") %in% colnames(df))) {
    cds_sites <- suppressWarnings(as.numeric(df$cds_conserved_sites))
    cds_len   <- suppressWarnings(as.numeric(df$cds_len))
    return(100 * cds_sites / cds_len)
  }

  if (all(c("cds_sites", "cds_len") %in% colnames(df))) {
    cds_sites <- suppressWarnings(as.numeric(df$cds_sites))
    cds_len   <- suppressWarnings(as.numeric(df$cds_len))
    return(100 * cds_sites / cds_len)
  }

  stop(
    "Cannot find CDS constrained percentage columns in file: ",
    fp,
    "\nNeed one of: cds_conserved_pct, cds_pct, ",
    "or cds_conserved_sites/cds_len, or cds_sites/cds_len.",
    call. = FALSE
  )
}

get_cds_len_column <- function(df) {
  if ("cds_len" %in% colnames(df)) {
    return(suppressWarnings(as.numeric(df$cds_len)))
  }

  return(rep(NA_real_, nrow(df)))
}

read_combined_stats <- function(threshold) {
  fp <- build_combined_file(threshold)

  if (!file.exists(fp)) {
    warning("Combined file not found: ", fp)
    return(NULL)
  }

  df <- read_tsv_base(fp, header = TRUE)

  if (!"gene_id" %in% colnames(df)) {
    stop("Missing gene_id column in combined file: ", fp, call. = FALSE)
  }

  out <- data.frame(
    gene_id_norm = strip_species_prefix(df$gene_id),
    cds_len = get_cds_len_column(df),
    cds_conserved_pct = get_cds_pct_column(df, fp),
    source = "combined",
    source_rank = 1,
    stringsAsFactors = FALSE
  ) %>%
    filter(
      !is.na(gene_id_norm),
      gene_id_norm != "",
      !is.na(cds_conserved_pct)
    )

  ## Remove invalid CDS entries when cds_len is available.
  ## This prevents cds_len = 0 and cds_conserved_pct = 0 from being treated as real values.
  if (any(!is.na(out$cds_len))) {
    out <- out %>%
      filter(!is.na(cds_len), cds_len > 0)
  }

  out
}

read_core_per_gene_stats <- function(threshold) {
  fp <- build_core_per_gene_file(threshold)

  if (!file.exists(fp)) {
    return(NULL)
  }

  df <- read_tsv_base(fp, header = TRUE)

  if (!"gene_id" %in% colnames(df)) {
    colnames(df)[1] <- "gene_id"
  }

  out <- data.frame(
    gene_id_norm = strip_species_prefix(df$gene_id),
    cds_len = get_cds_len_column(df),
    cds_conserved_pct = get_cds_pct_column(df, fp),
    source = paste0("core_per_gene_", threshold),
    source_rank = 2,
    stringsAsFactors = FALSE
  ) %>%
    filter(
      !is.na(gene_id_norm),
      gene_id_norm != "",
      !is.na(cds_conserved_pct)
    )

  if (any(!is.na(out$cds_len))) {
    out <- out %>%
      filter(!is.na(cds_len), cds_len > 0)
  }

  out
}

read_Zmay_stats_for_threshold <- function(threshold) {
  combined <- read_combined_stats(threshold)
  core_pg  <- read_core_per_gene_stats(threshold)

  all_stats <- bind_rows(combined, core_pg)

  if (nrow(all_stats) == 0) {
    stop(
      "No usable stats found for threshold: ",
      threshold,
      call. = FALSE
    )
  }

  ## Prefer combined values when duplicated.
  ## If strict core genes are absent from combined, per-gene core file fills them.
  all_stats <- all_stats %>%
    arrange(gene_id_norm, source_rank) %>%
    group_by(gene_id_norm) %>%
    summarise(
      cds_len = first(cds_len),
      cds_conserved_pct = first(cds_conserved_pct),
      source = first(source),
      .groups = "drop"
    )

  all_stats
}

## =========================================================
## 6. Build plotting table for one threshold
## =========================================================
read_one_threshold <- function(threshold, gene_class_map) {
  stats <- read_Zmay_stats_for_threshold(threshold)

  df <- stats %>%
    inner_join(gene_class_map, by = "gene_id_norm") %>%
    mutate(
      threshold = threshold,
      gene_class = factor(gene_class, levels = class_order)
    ) %>%
    filter(!is.na(gene_class), !is.na(cds_conserved_pct))

  if (nrow(df) == 0) {
    stop(
      "No genes matched gene-class map for threshold: ",
      threshold,
      call. = FALSE
    )
  }

  cat("[INFO] ", threshold, " matched genes by class:\n", sep = "")
  print(table(df$gene_class, useNA = "ifany"))

  df
}

## =========================================================
## 7. Statistics: independent gene classes
## =========================================================
run_stats_one_threshold <- function(df_plot, threshold) {
  df_plot <- df_plot %>%
    filter(!is.na(gene_class), !is.na(cds_conserved_pct)) %>%
    droplevels()

  observed_levels <- levels(droplevels(df_plot$gene_class))

  if (length(observed_levels) < 2) {
    stop(
      "Need at least two gene classes for statistical test at threshold: ",
      threshold,
      call. = FALSE
    )
  }

  kw <- kruskal.test(cds_conserved_pct ~ gene_class, data = df_plot)

  pair_combs <- combn(observed_levels, 2, simplify = FALSE)

  pair_tbl <- lapply(pair_combs, function(cc) {
    g1 <- cc[1]
    g2 <- cc[2]

    sub_df <- df_plot %>%
      filter(gene_class %in% c(g1, g2)) %>%
      droplevels()

    x <- sub_df$cds_conserved_pct[sub_df$gene_class == g1]
    y <- sub_df$cds_conserved_pct[sub_df$gene_class == g2]

    wt <- wilcox.test(
      x,
      y,
      paired = FALSE,
      exact = FALSE
    )

    tibble(
      threshold = threshold,
      test = "Wilcoxon rank-sum (BH)",
      Comparison = paste0(
        class_full_names[[g1]],
        " - ",
        class_full_names[[g2]]
      ),
      group1 = class_full_names[[g1]],
      group2 = class_full_names[[g2]],
      n_group1 = length(x),
      n_group2 = length(y),
      median_group1 = median(x, na.rm = TRUE),
      median_group2 = median(y, na.rm = TRUE),
      median_diff_group1_minus_group2 =
        median(x, na.rm = TRUE) - median(y, na.rm = TRUE),
      P.raw = wt$p.value
    )
  }) %>%
    bind_rows() %>%
    mutate(
      P.adj = p.adjust(P.raw, method = "BH"),
      label = vapply(P.adj, p_to_star, character(1)),
      KW_chisq = unname(kw$statistic),
      KW_df    = unname(kw$parameter),
      KW_p     = kw$p.value
    ) %>%
    select(
      threshold,
      test,
      KW_chisq,
      KW_df,
      KW_p,
      Comparison,
      group1,
      group2,
      n_group1,
      n_group2,
      median_group1,
      median_group2,
      median_diff_group1_minus_group2,
      P.raw,
      P.adj,
      label
    )

  list(
    kw = kw,
    pairwise_tbl = pair_tbl
  )
}

## =========================================================
## 8. Significance annotation
## =========================================================
make_sig_df <- function(df_plot, pairwise_tbl) {
  sig_df <- pairwise_tbl %>%
    filter(!is.na(group1), !is.na(group2), !is.na(label))

  ## Convert full names back to plotting labels
  inv_map <- setNames(names(class_full_names), class_full_names)

  sig_df <- sig_df %>%
    mutate(
      group1_plot = inv_map[group1],
      group2_plot = inv_map[group2]
    )

  if (!show_ns_lines) {
    sig_df <- sig_df %>% filter(label != "ns")
  }

  y_data_max <- max(df_plot$cds_conserved_pct, na.rm = TRUE)

  if (nrow(sig_df) == 0) {
    return(list(
      sig_df = sig_df,
      y_panel_max = y_data_max
    ))
  }

  sig_df <- sig_df %>%
    mutate(
      group1_plot = factor(group1_plot, levels = class_order),
      group2_plot = factor(group2_plot, levels = class_order)
    ) %>%
    arrange(group1_plot, group2_plot) %>%
    mutate(
      y_position = y_data_max + seq(from = 3, by = 3, length.out = n())
    )

  y_panel_max <- max(sig_df$y_position, na.rm = TRUE) + 3

  list(
    sig_df = sig_df,
    y_panel_max = y_panel_max
  )
}

## =========================================================
## 9. Plot one panel
## =========================================================
plot_one_panel <- function(df_plot, sig_df, y_limit, panel_title) {
  ggplot(df_plot, aes(x = gene_class, y = cds_conserved_pct, fill = gene_class)) +

    geom_violin(
      width = 0.62,
      scale = "width",
      trim = TRUE,
      color = "#5F5F5F",
      linewidth = 0.55,
      alpha = 0.85
    ) +

    geom_boxplot(
      width = 0.105,
      coef = 0.35,
      fill = "white",
      color = "black",
      linewidth = 0.75,
      outlier.shape = NA
    ) +

    {
      if (nrow(sig_df) > 0) {
        geom_signif(
          data = sig_df,
          aes(
            xmin = group1_plot,
            xmax = group2_plot,
            annotations = label,
            y_position = y_position
          ),
          manual = TRUE,
          inherit.aes = FALSE,
          textsize = 3.7,
          tip_length = 0.012,
          linewidth = 0.65
        )
      }
    } +

    scale_fill_manual(
      values = class_fill,
      guide = "none"
    ) +

    scale_x_discrete(
      limits = class_order,
      labels = class_order
    ) +

    scale_y_continuous(
      limits = c(0, y_limit),
      breaks = seq(0, 100, 25),
      expand = c(0, 0)
    ) +

    labs(
      x = NULL,
      y = "CDS constrained sites (%)",
      title = panel_title
    ) +

    theme_classic(base_size = 16) +
    theme(
      plot.title = element_text(
        size = 15,
        face = "plain",
        hjust = 0.5,
        margin = margin(b = 8)
      ),

      axis.text.x = element_text(
        size = 14,
        color = "black",
        margin = margin(t = 5)
      ),
      axis.text.y = element_text(
        size = 13.5,
        color = "black"
      ),
      axis.title.y = element_text(
        size = 15,
        color = "black",
        margin = margin(r = 8)
      ),

      axis.line = element_line(
        color = "black",
        linewidth = 0.55
      ),
      axis.ticks = element_line(
        color = "black",
        linewidth = 0.55
      ),
      axis.ticks.length = unit(2.2, "pt"),

      ## MBE-style light horizontal grid only
      panel.grid.major.y = element_line(
        color = "#E9E9E9",
        linewidth = 0.35
      ),
      panel.grid.minor.y = element_blank(),
      panel.grid.major.x = element_blank(),
      panel.grid.minor.x = element_blank(),

      panel.border = element_rect(
        fill = NA,
        color = "black",
        linewidth = 0.75
      ),

      plot.margin = margin(12, 13, 10, 13)
    )
}

safe_ggsave <- function(filename, plot, width, height, dpi = NULL) {
  if (grepl("\\.pdf$", filename, ignore.case = TRUE)) {
    ok <- FALSE

    try({
      ggsave(
        filename = filename,
        plot = plot,
        width = width,
        height = height,
        device = cairo_pdf
      )
      ok <- TRUE
    }, silent = TRUE)

    if (!ok) {
      ggsave(
        filename = filename,
        plot = plot,
        width = width,
        height = height
      )
    }

  } else {
    if (is.null(dpi)) {
      ggsave(
        filename = filename,
        plot = plot,
        width = width,
        height = height
      )
    } else {
      ggsave(
        filename = filename,
        plot = plot,
        width = width,
        height = height,
        dpi = dpi
      )
    }
  }
}

## =========================================================
## 10. Main workflow
## =========================================================
all_thresholds <- unique(c(panels_thresholds, supp_thresholds))

gene_class_map <- build_gene_class_map()

## Build supplementary statistics
supp_list <- lapply(supp_thresholds, function(th) {
  cat("[INFO] Running statistics for threshold: ", th, "\n", sep = "")

  df_th <- read_one_threshold(th, gene_class_map)
  st <- run_stats_one_threshold(df_th, th)

  st$pairwise_tbl
})

supp_tbl <- bind_rows(supp_list)

write_tsv_base(supp_tbl, out_supp_tsv)

cat("[OK] Wrote statistics table: ",
    out_supp_tsv, "\n", sep = "")

## Count table
count_tbl <- lapply(all_thresholds, function(th) {
  df_th <- read_one_threshold(th, gene_class_map)

  df_th %>%
    group_by(threshold, gene_class) %>%
    summarise(
      n_genes = n(),
      median_cds_conserved_pct = median(cds_conserved_pct, na.rm = TRUE),
      mean_cds_conserved_pct = mean(cds_conserved_pct, na.rm = TRUE),
      .groups = "drop"
    )
}) %>%
  bind_rows() %>%
  mutate(
    gene_class_full = class_full_names[as.character(gene_class)]
  ) %>%
  select(
    threshold,
    gene_class,
    gene_class_full,
    n_genes,
    median_cds_conserved_pct,
    mean_cds_conserved_pct
  )

write_tsv_base(count_tbl, out_count_tsv)

cat("[OK] Wrote count/summary table: ",
    out_count_tsv, "\n", sep = "")

## Build figure panels
panel_objs <- lapply(panels_thresholds, function(th) {
  cat("[INFO] Building figure panel for threshold: ", th, "\n", sep = "")

  df_th <- read_one_threshold(th, gene_class_map)
  st <- run_stats_one_threshold(df_th, th)
  sig_info <- make_sig_df(df_th, st$pairwise_tbl)

  list(
    df = df_th,
    stats = st$pairwise_tbl,
    sig_df = sig_info$sig_df,
    y_panel_max = sig_info$y_panel_max
  )
})

global_y <- max(
  vapply(panel_objs, function(x) x$y_panel_max, numeric(1)),
  na.rm = TRUE
)

global_y <- max(global_y, 108)

titles <- c(
  gt2 = "GERP > 2",
  gt4 = "GERP > 4",
  gt6 = "GERP > 6"
)

plots <- lapply(seq_along(panels_thresholds), function(i) {
  th <- panels_thresholds[i]

  plot_one_panel(
    df_plot = panel_objs[[i]]$df,
    sig_df = panel_objs[[i]]$sig_df,
    y_limit = global_y,
    panel_title = titles[[th]]
  )
})

p_multi <- plots[[1]] + plots[[2]] + plots[[3]] +
  plot_layout(ncol = 3, guides = "collect") +
  plot_annotation(tag_levels = "A") &
  theme(
    plot.tag = element_text(
      size = 22,
      face = "plain",
      color = "black"
    )
  )

safe_ggsave(
  filename = paste0(out_fig_prefix, ".pdf"),
  plot = p_multi,
  width = 13.2,
  height = 4.85
)

safe_ggsave(
  filename = paste0(out_fig_prefix, ".png"),
  plot = p_multi,
  width = 13.2,
  height = 4.85,
  dpi = 300
)

cat("[OK] Saved figure: ",
    out_fig_prefix, ".pdf / .png\n", sep = "")

cat("[DONE]\n")