#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import os
import csv
import argparse
from collections import defaultdict

def split_genes(cell):
    cell = cell.strip()
    if not cell:
        return []
    return [x.strip() for x in cell.split(",") if x.strip()]

def gene_count(cell):
    return len(split_genes(cell))

def only_this_species_present(row, focal):
    species_cols = ["Atau", "Osat", "pedC", "pedD", "Zmay"]
    for sp in species_cols:
        n = gene_count(row[sp])
        if sp == focal:
            if n == 0:
                return False
        else:
            if n != 0:
                return False
    return True

def only_pedC_present(row):
    return (
        gene_count(row["pedC"]) == 1 and
        gene_count(row["pedD"]) == 0 and
        gene_count(row["Atau"]) == 0 and
        gene_count(row["Osat"]) == 0 and
        gene_count(row["Zmay"]) == 0
    )

def only_pedD_present(row):
    return (
        gene_count(row["pedD"]) == 1 and
        gene_count(row["pedC"]) == 0 and
        gene_count(row["Atau"]) == 0 and
        gene_count(row["Osat"]) == 0 and
        gene_count(row["Zmay"]) == 0
    )

def is_strict_core(row):
    if row["SharedGenomes"] != 5:
        return False
    if row["TotalGenes"] != 5:
        return False
    if row["Flag"] != "-":
        return False
    for sp in ["Atau", "Osat", "pedC", "pedD", "Zmay"]:
        if gene_count(row[sp]) != 1:
            return False
    return True

def has_external_support(row):
    return (
        gene_count(row["Atau"]) > 0 or
        gene_count(row["Osat"]) > 0 or
        gene_count(row["Zmay"]) > 0
    )

def classify_species_level(row):
    classes = {}

    # Atau
    if gene_count(row["Atau"]) > 0:
        if is_strict_core(row):
            classes["Atau"] = "strict_core_syntenic"
        elif (
            row["SharedGenomes"] == 1 and
            row["TotalGenes"] == 1 and
            row["Flag"] == "-" and
            only_this_species_present(row, "Atau")
        ):
            classes["Atau"] = "candidate_nonsyntenic_private"
        elif row["SharedGenomes"] >= 2:
            classes["Atau"] = "other_syntenic"

    # Zmay
    if gene_count(row["Zmay"]) > 0:
        if is_strict_core(row):
            classes["Zmay"] = "strict_core_syntenic"
        elif (
            row["SharedGenomes"] == 1 and
            row["TotalGenes"] == 1 and
            row["Flag"] == "-" and
            only_this_species_present(row, "Zmay")
        ):
            classes["Zmay"] = "candidate_nonsyntenic_private"
        elif row["SharedGenomes"] >= 2:
            classes["Zmay"] = "other_syntenic"

    # Ped (combine pedC + pedD as one focal species)
    if gene_count(row["pedC"]) > 0 or gene_count(row["pedD"]) > 0:
        if is_strict_core(row):
            classes["Ped"] = "strict_core_syntenic"
        elif (
            row["SharedGenomes"] == 1 and
            row["TotalGenes"] == 1 and
            row["Flag"] == "-" and
            (only_pedC_present(row) or only_pedD_present(row))
        ):
            classes["Ped"] = "candidate_nonsyntenic_private"
        elif row["SharedGenomes"] >= 2:
            classes["Ped"] = "other_syntenic"

    return classes

def classify_bamboo_subgenome(row):
    gC = gene_count(row["pedC"])
    gD = gene_count(row["pedD"])
    ext = has_external_support(row)

    labels = []

    if gC > 0 and gD > 0 and ext:
        labels.append("pedCD_retained_syntenic")
    elif gC > 0 and gD == 0 and ext:
        labels.append("pedC_retained_pedD_lost_syntenic")
    elif gD > 0 and gC == 0 and ext:
        labels.append("pedD_retained_pedC_lost_syntenic")

    if gC > 0 and gD > 0 and not ext:
        labels.append("pedCD_lineage_specific_syntenic")

    if row["SharedGenomes"] == 1 and row["TotalGenes"] == 1 and row["Flag"] == "-":
        if only_pedC_present(row):
            labels.append("pedC_private_candidate_nonsyntenic")
        if only_pedD_present(row):
            labels.append("pedD_private_candidate_nonsyntenic")

    return labels

def get_species_genes(row, species):
    if species == "Ped":
        return split_genes(row["pedC"]) + split_genes(row["pedD"])
    return split_genes(row[species])

def get_bamboo_genes(row, label):
    if label in ("pedCD_retained_syntenic", "pedCD_lineage_specific_syntenic"):
        return split_genes(row["pedC"]) + split_genes(row["pedD"])
    elif label == "pedC_retained_pedD_lost_syntenic":
        return split_genes(row["pedC"])
    elif label == "pedD_retained_pedC_lost_syntenic":
        return split_genes(row["pedD"])
    elif label == "pedC_private_candidate_nonsyntenic":
        return split_genes(row["pedC"])
    elif label == "pedD_private_candidate_nonsyntenic":
        return split_genes(row["pedD"])
    return []

def ensure_dir(path):
    os.makedirs(path, exist_ok=True)

def write_rows_tsv(path, rows):
    header = ["SG", "SharedGenomes", "TotalGenes", "Flag", "Atau", "Osat", "pedC", "pedD", "Zmay"]
    with open(path, "w", newline="") as f:
        w = csv.writer(f, delimiter="\t")
        w.writerow(header)
        for r in rows:
            w.writerow([r[h] for h in header])

def write_gene_list(path, genes):
    with open(path, "w") as f:
        for g in genes:
            f.write(g + "\n")

def main():
    parser = argparse.ArgumentParser(description="Classify SynPan SG.pan results into species-level and bamboo subgenome-level classes.")
    parser.add_argument("-i", "--input", required=True, help="Input SG.pan file")
    parser.add_argument("-o", "--outdir", required=True, help="Output directory")
    args = parser.parse_args()

    outdir = args.outdir
    ensure_dir(outdir)

    species_level = {
        "Atau": defaultdict(list),
        "Zmay": defaultdict(list),
        "Ped": defaultdict(list),
    }
    bamboo_level = defaultdict(list)
    species_genes = {
        "Atau": defaultdict(list),
        "Zmay": defaultdict(list),
        "Ped": defaultdict(list),
    }
    bamboo_genes = defaultdict(list)

    with open(args.input) as f:
        for line in f:
            line = line.rstrip("\n")
            if not line.strip():
                continue

            fields = line.split("\t")
            if len(fields) < 9:
                fields += [""] * (9 - len(fields))
            elif len(fields) > 9:
                fields = fields[:9]

            row = {
                "SG": fields[0],
                "SharedGenomes": int(fields[1]),
                "TotalGenes": int(fields[2]),
                "Flag": fields[3].strip(),
                "Atau": fields[4].strip(),
                "Osat": fields[5].strip(),
                "pedC": fields[6].strip(),
                "pedD": fields[7].strip(),
                "Zmay": fields[8].strip(),
            }

            # species-level
            sp_classes = classify_species_level(row)
            for sp, label in sp_classes.items():
                species_level[sp][label].append(row)
                species_genes[sp][label].extend(get_species_genes(row, sp))

            # bamboo subgenome-level
            bg_classes = classify_bamboo_subgenome(row)
            for label in bg_classes:
                bamboo_level[label].append(row)
                bamboo_genes[label].extend(get_bamboo_genes(row, label))

    # write species-level results
    species_base = os.path.join(outdir, "01_species_level")
    for sp in ["Atau", "Zmay", "Ped"]:
        sp_dir = os.path.join(species_base, sp)
        ensure_dir(sp_dir)
        for label in ["strict_core_syntenic", "other_syntenic", "candidate_nonsyntenic_private"]:
            rows = species_level[sp].get(label, [])
            genes = species_genes[sp].get(label, [])
            write_rows_tsv(os.path.join(sp_dir, f"{label}.tsv"), rows)
            write_gene_list(os.path.join(sp_dir, f"{label}.genes.txt"), sorted(set(genes)))

    # write bamboo subgenome-level results
    bamboo_base = os.path.join(outdir, "02_bamboo_subgenome")
    ensure_dir(bamboo_base)
    bamboo_labels = [
        "pedCD_retained_syntenic",
        "pedC_retained_pedD_lost_syntenic",
        "pedD_retained_pedC_lost_syntenic",
        "pedCD_lineage_specific_syntenic",
        "pedC_private_candidate_nonsyntenic",
        "pedD_private_candidate_nonsyntenic",
    ]
    for label in bamboo_labels:
        rows = bamboo_level.get(label, [])
        genes = bamboo_genes.get(label, [])
        write_rows_tsv(os.path.join(bamboo_base, f"{label}.tsv"), rows)
        write_gene_list(os.path.join(bamboo_base, f"{label}.genes.txt"), sorted(set(genes)))

    # summary
    summary_dir = os.path.join(outdir, "03_summary")
    ensure_dir(summary_dir)
    summary_file = os.path.join(summary_dir, "class_counts.tsv")
    with open(summary_file, "w", newline="") as f:
        w = csv.writer(f, delimiter="\t")
        w.writerow(["Level", "Group", "Class", "n_SG", "n_unique_genes"])
        for sp in ["Atau", "Zmay", "Ped"]:
            for label in ["strict_core_syntenic", "other_syntenic", "candidate_nonsyntenic_private"]:
                rows = species_level[sp].get(label, [])
                genes = set(species_genes[sp].get(label, []))
                w.writerow(["species_level", sp, label, len(rows), len(genes)])
        for label in bamboo_labels:
            rows = bamboo_level.get(label, [])
            genes = set(bamboo_genes.get(label, []))
            w.writerow(["bamboo_subgenome", "Ped", label, len(rows), len(genes)])

    print(f"[INFO] Done. Results written to: {outdir}")

if __name__ == "__main__":
    main()