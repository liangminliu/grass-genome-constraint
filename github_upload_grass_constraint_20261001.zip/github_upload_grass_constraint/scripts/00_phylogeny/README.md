# Grass phylogeny

Methods: 97 genomes (94 grasses and three outgroups), ROADIES accurate mode, followed by treePL dating and rate-tree extraction. Results: Fig. 1, provisional U1 and Table S1D–F.

| Order | Selected script | Role |
|---|---|---|
| 1 | `config/config_97sp_accurate.yaml` and `selected/run_roadies_97sp_accurate_v2.sh` | author-identified final ROADIES configuration and 88-core LSF job |
| 2 | `selected/01_prime.lsf` | treePL PRIME optimization |
| 3 | `selected/04_standard_cv.lsf` | smoothing cross-validation |
| 4 | `selected/03_final.lsf` and `selected/run_treePL.sh` | final dating job and runner |
| 5 | `selected/00_verify_mrca.py` | calibration-node check |

The author supplied the final ROADIES config and 88-core job. The pasted job ended before its closing `fi`; the selected file is the matching complete recovered copy. Historical candidate filenames had reversed core-count labels: `source_candidates/run_roadies_97sp_accurate_v2_LSF8.sh` actually requests 88 cores, whereas `source_candidates/run_roadies_97sp_accurate_v2_local88.sh` requests 8. Both remain unchanged for provenance. The tracked master Methods now reports continuity 85 and support threshold 0.95. The production log and tree hashes remain needed; an archived 250-gene execution config documents a test.

`GENE_COUNT: 16000` means initial sampled 500-bp genomic segments, not final retained gene trees. The manuscript reports 6,485 gene trees after five iterations; that count still needs run-level verification. **The selected job deletes both configured output directories with `rm -rf` before execution.** Preserve existing results before submitting it.

See `SCRIPT_INDEX.tsv` for every recovered file and its source.
