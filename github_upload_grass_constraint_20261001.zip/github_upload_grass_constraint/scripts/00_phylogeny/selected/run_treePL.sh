#!/usr/bin/env bash
set -euo pipefail
CFG="${1:?usage: scripts/run_treePL.sh config.cfg}"
if command -v treePL >/dev/null 2>&1; then
    exec treePL "$CFG"
fi
if [[ -x /ds3200_1/proc/treePL-master/src/treePL ]]; then
    exec /ds3200_1/proc/treePL-master/src/treePL "$CFG"
fi
echo "[ERROR] treePL executable not found" >&2
exit 1
