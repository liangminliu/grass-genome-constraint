#!/usr/bin/env python3
from Bio import Phylo
tree=Phylo.read("01_ROADIES97_rooted_substitutions_per_site.nwk","newick")
pairs=[
("ROOTMAX_POALES","Acom","Atau"),
("POACEAE","Spic","Atau"),
("POOIDEAE","Nspl","Atau"),
("CHLORIDOIDEAE","Cson","Etef"),
("LEERSIA","Leper","Oruf"),
("ORYZA_ZEA","Oniv","Zmay"),
]
for label,a,b in pairs:
    c=tree.common_ancestor(a,b)
    tips=sorted(t.name for t in c.get_terminals())
    print(f"{label}\t{a}\t{b}\tN={len(tips)}\t" + ",".join(tips))
