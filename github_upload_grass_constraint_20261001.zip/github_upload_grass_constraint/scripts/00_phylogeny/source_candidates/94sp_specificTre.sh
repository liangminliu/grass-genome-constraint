#!/bin/bash
#SBATCH --job-name=tree_pipeline
#SBATCH --output=tree_logs/tree_pipeline_%j.out
#SBATCH --error=tree_logs/tree_pipeline_%j.err
#SBATCH --cpus-per-task=10
#SBATCH -p parallel
#SBATCH --nodes=1


# 1. 创建目录
mkdir -p tree_logs 

# 2. 激活conda环境
source ~/miniforge3/bin/activate workflow_envs

#3  step: raxml - 固定拓扑 + bootstrap
echo "Running raxml bootstrap with fixed topology..."
cd 94sp_ped_results/tree/
mkdir -p specific_raxml/

# 设置文件名
FIXED_TREE="fixed_topology_tree.tre"  # 
ALIGNMENT="roast_mincol_maxlen.fa"
PREFIX="roast_mincol_maxlen_fixed"
THREADS=20
BOOTSTRAP_REPLICATES=100

# (a) Bootstrap推演（固定树拓扑）
raxmlHPC-PTHREADS -T ${THREADS} -f e -m GTRGAMMA -s ${ALIGNMENT} \
    -t ${FIXED_TREE} -p 12345 -x 23456 -# ${BOOTSTRAP_REPLICATES} \
    -n ${PREFIX}_bs &> ../tree_logs/raxml_fixed_bs_log.txt

# (b) 映射bootstrap支持率到固定树
raxmlHPC-PTHREADS -T ${THREADS} -f b -m GTRGAMMA -t ${FIXED_TREE} \
    -z specific_raxml/RAxML_bootstrap.${PREFIX}_bs -n ${PREFIX}_final &> ../../tree_logs/raxml_fixed_map_log.txt
mv RAxML_* specific_raxml/
cd ../..



