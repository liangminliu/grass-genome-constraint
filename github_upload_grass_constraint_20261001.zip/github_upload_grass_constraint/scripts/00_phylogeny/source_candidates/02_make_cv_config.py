#!/usr/bin/env python3
import argparse, re
from pathlib import Path

ap=argparse.ArgumentParser()
ap.add_argument("--prime-log", required=True)
ap.add_argument("--template", required=True)
ap.add_argument("--out", required=True)
args=ap.parse_args()

txt=Path(args.prime_log).read_text(errors="replace")

# treePL prime ends with lines like:
# PLACE THE LINES BELOW IN THE CONFIGURATION FILE
# opt = 4
# optad = 4
# optcvad = 4
patterns={
    "__OPT__": r"(?m)^\s*opt\s*=\s*(\d+)\s*$",
    "__OPTAD__": r"(?m)^\s*optad\s*=\s*(\d+)\s*$",
    "__OPTCVAD__": r"(?m)^\s*optcvad\s*=\s*(\d+)\s*$",
}
vals={}
for key,pat in patterns.items():
    hits=re.findall(pat,txt)
    if not hits:
        raise SystemExit(f"Could not find {key} value in {args.prime_log}")
    vals[key]=hits[-1]

tmpl=Path(args.template).read_text()
for key,val in vals.items():
    tmpl=tmpl.replace(key,val)
Path(args.out).write_text(tmpl)

print("Created", args.out)
print("opt =", vals["__OPT__"])
print("optad =", vals["__OPTAD__"])
print("optcvad =", vals["__OPTCVAD__"])
