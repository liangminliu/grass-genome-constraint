#!/usr/bin/env bash
set -euo pipefail

echo "===== scheduler ====="
command -v bsub || true
bqueues 2>/dev/null | head -20 || true

echo
echo "===== native treePL ====="
command -v treePL || true

echo
echo "===== container runtime ====="
command -v apptainer || true
command -v singularity || true

echo
echo "===== project files ====="
for f in \
  01_ROADIES97_rooted_substitutions_per_site.nwk \
  config/01_97_main_prime.cfg \
  config/02_97_main_cv.template.cfg \
  config/03_97_main_final.template.cfg
do
    [[ -s "$f" ]] && echo "[OK] $f" || echo "[MISSING] $f"
done

echo
echo "Use native treePL if 'command -v treePL' succeeds."
echo "Otherwise use Apptainer/Singularity via scripts/01_pull_treePL_container.sh."
