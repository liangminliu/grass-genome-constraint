#!/usr/bin/env bash
set -euo pipefail

CFG="${1:?Usage: scripts/run_treePL.sh config.cfg}"

if [[ ! -s "$CFG" ]]; then
    echo "[ERROR] missing config: $CFG" >&2
    exit 1
fi

if command -v treePL >/dev/null 2>&1; then
    echo "[INFO] Using native treePL: $(command -v treePL)"
    exec treePL "$CFG"
fi

if [[ -s software/treepl.sif ]]; then
    if command -v apptainer >/dev/null 2>&1; then
        RUNTIME=apptainer
    elif command -v singularity >/dev/null 2>&1; then
        RUNTIME=singularity
    else
        echo "[ERROR] software/treepl.sif exists but no apptainer/singularity runtime found." >&2
        exit 1
    fi

    # Bind the project root to /work and execute from /work.
    # Config paths are project-root-relative.
    echo "[INFO] Using $RUNTIME container: software/treepl.sif"
    exec "$RUNTIME" exec \
      --bind "$PWD":/work \
      --pwd /work \
      software/treepl.sif \
      /usr/local/src/treePL/src/treePL \
      "$CFG"
fi

echo "[ERROR] No native treePL and no software/treepl.sif." >&2
echo "Run: bash scripts/01_pull_treePL_container.sh" >&2
exit 1
