#!/usr/bin/env bash
set -euo pipefail

mkdir -p software

if command -v apptainer >/dev/null 2>&1; then
    RUNTIME=apptainer
elif command -v singularity >/dev/null 2>&1; then
    RUNTIME=singularity
else
    echo "[ERROR] Neither apptainer nor singularity is available."
    echo "Use a native treePL binary or ask the cluster administrator to provide Apptainer/treePL."
    exit 1
fi

echo "[INFO] pulling naturalis/docker-treepl ..."
"$RUNTIME" pull --force software/treepl.sif docker://naturalis/docker-treepl

echo "[INFO] testing binary ..."
"$RUNTIME" exec software/treepl.sif /usr/local/src/treePL/src/treePL 2>&1 | head -20 || true

echo "[DONE] software/treepl.sif"
