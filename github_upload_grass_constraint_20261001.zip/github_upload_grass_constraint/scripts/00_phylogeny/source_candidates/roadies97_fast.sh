#!/bin/bash
#BSUB -J roadies97_fast
#BSUB -q Q96C1T_X12
#BSUB -n 16
#BSUB -o /ds3200_1/users_root/liuliangmin/workspace/PHD/run97/logs/roadies97_fast.%J.out
#BSUB -e /ds3200_1/users_root/liuliangmin/workspace/PHD/run97/logs/roadies97_fast.%J.err

set -euo pipefail

WORKDIR="/ds3200_1/users_root/liuliangmin/workspace/PHD/run97"
CFG="${WORKDIR}/config_97sp_fast.yaml"

mkdir -p "${WORKDIR}/logs"
mkdir -p "${WORKDIR}/fast_output_97sp"
mkdir -p "${WORKDIR}/fast_converge_files"

source "$HOME/miniforge3/etc/profile.d/conda.sh"
conda activate roadies_env

cd "$CONDA_PREFIX/ROADIES"

echo "[INFO] start : $(date)"
echo "[INFO] host  : $(hostname)"
echo "[INFO] env   : $CONDA_PREFIX"
echo "[INFO] repo  : $(pwd)"
echo "[INFO] cfg   : ${CFG}"

test -f "${CFG}" || { echo "[ERROR] missing config: ${CFG}"; exit 1; }

GENOME_DIR=$(awk -F': *' '/^GENOMES:/{print $2}' "${CFG}")
test -d "${GENOME_DIR}" || { echo "[ERROR] missing genome dir: ${GENOME_DIR}"; exit 1; }

N_GENOMES=$(find "${GENOME_DIR}" -maxdepth 1 \( -name "*.fa" -o -name "*.fa.gz" \) | wc -l)
echo "[INFO] genome files found: ${N_GENOMES}"
[[ "${N_GENOMES}" -eq 97 ]] || { echo "[ERROR] expected 97 genome files"; exit 1; }

chmod +x workflow/scripts/get_run_noconverge.sh

python run_roadies.py \
  --cores 16 \
  --mode fast \
  --noconverge \
  --config "${CFG}"

echo "[INFO] done: $(date)"

ls -lh "${WORKDIR}/fast_output_97sp/roadies.nwk"
ls -lh "${WORKDIR}/fast_output_97sp/roadies_stats.nwk" || true