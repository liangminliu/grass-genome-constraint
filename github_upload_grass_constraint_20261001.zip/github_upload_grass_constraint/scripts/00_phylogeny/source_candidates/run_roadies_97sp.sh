#!/bin/bash
#BSUB -J roadies_97sp
#BSUB -q Q96C1T_X12
#BSUB -n 32
#BSUB -R "span[hosts=1]"
#BSUB -o /ds3200_1/users_root/liuliangmin/workspace/PHD/run97/logs/roadies_97sp.%J.out
#BSUB -e /ds3200_1/users_root/liuliangmin/workspace/PHD/run97/logs/roadies_97sp.%J.err


########################################
# 1. Paths
########################################
RUN_DIR="/ds3200_1/users_root/liuliangmin/workspace/PHD/run97"
ROADIES_DIR="${RUN_DIR}/ROADIES"

CONFIG="${RUN_DIR}/config_97sp.yaml"
INPUT_DIR="${RUN_DIR}/input97"

########################################
# 2. Parameters
########################################
CORES=32
MODE="fast"          # fast / balanced / accurate
DEEP="True"          # True / False
NOCONVERGE="yes"     # yes = 单轮测试；no = 正式迭代

########################################
# 3. Prepare dirs
########################################
mkdir -p "${RUN_DIR}/logs" "${RUN_DIR}/output_files" "${RUN_DIR}/converge_files"

echo "[INFO] Job started at: $(date)"
echo "[INFO] Host: $(hostname)"
echo "[INFO] Submit dir: $(pwd)"
echo "[INFO] RUN_DIR=${RUN_DIR}"
echo "[INFO] ROADIES_DIR=${ROADIES_DIR}"
echo "[INFO] CONFIG=${CONFIG}"
echo "[INFO] INPUT_DIR=${INPUT_DIR}"
echo "[INFO] CORES=${CORES}"
echo "[INFO] MODE=${MODE}"
echo "[INFO] DEEP=${DEEP}"
echo "[INFO] NOCONVERGE=${NOCONVERGE}"

########################################
# 4. Sanity checks
########################################
[[ -d "${RUN_DIR}" ]] || { echo "[ERROR] RUN_DIR not found: ${RUN_DIR}"; exit 1; }
[[ -L "${ROADIES_DIR}" || -d "${ROADIES_DIR}" ]] || { echo "[ERROR] ROADIES link/dir not found: ${ROADIES_DIR}"; exit 1; }

[[ -f "${ROADIES_DIR}/roadies_env.sh" ]] || { echo "[ERROR] roadies_env.sh not found: ${ROADIES_DIR}/roadies_env.sh"; exit 1; }
[[ -f "${ROADIES_DIR}/run_roadies.py" ]] || { echo "[ERROR] run_roadies.py not found: ${ROADIES_DIR}/run_roadies.py"; exit 1; }
[[ -f "${ROADIES_DIR}/workflow/scripts/noconverge.py" ]] || { echo "[ERROR] noconverge.py not found under ROADIES/workflow/scripts"; exit 1; }

[[ -d "${INPUT_DIR}" ]] || { echo "[ERROR] INPUT_DIR not found: ${INPUT_DIR}"; exit 1; }
[[ -f "${CONFIG}" ]] || { echo "[ERROR] CONFIG not found: ${CONFIG}"; exit 1; }

N_GENOMES=$(find "${INPUT_DIR}" -maxdepth 1 \( -type l -o -type f \) | wc -l)
echo "[INFO] Number of genome files in input dir: ${N_GENOMES}"

########################################
# 5. Enter ROADIES and load env
########################################
cd "${ROADIES_DIR}"
echo "[INFO] Current working directory after cd: $(pwd)"

source roadies_env.sh

echo "[INFO] CONDA_DEFAULT_ENV=${CONDA_DEFAULT_ENV:-NA}"
echo "[INFO] Python: $(which python)"
echo "[INFO] Snakemake: $(which snakemake || true)"
echo "[INFO] IQ-TREE: $(which iqtree || true)"
echo "[INFO] LASTZ: $(which lastz || true)"

########################################
# 6. Run ROADIES
########################################
CMD=(
    python run_roadies.py
    --cores "${CORES}"
    --mode "${MODE}"
    --deep "${DEEP}"
    --config "${CONFIG}"
)

if [[ "${NOCONVERGE}" == "yes" ]]; then
    CMD+=(--noconverge)
fi

echo "[INFO] Running command:"
printf ' %q' "${CMD[@]}"
echo

"${CMD[@]}"

########################################
# 7. Done
########################################
echo "[INFO] Job finished at: $(date)"
echo "[INFO] output_files:"
ls -lh "${RUN_DIR}/output_files" 2>/dev/null || true
echo "[INFO] converge_files:"
ls -lh "${RUN_DIR}/converge_files" 2>/dev/null || true