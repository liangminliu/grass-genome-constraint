# Genome-wide synteny

Methods: GeneTribe v1.2.1, each of three focal references compared with 93 other grass genomes; retained reference genes divided by all annotated reference genes. JCVI/MCscan supplies representative chromosome views. Results: Fig. 1B–C and Table S1.

| Order | Selected script | Role |
|---|---|---|
| 1 | `selected/step1_prepare_genetribe_ref_layout.sh` | prepare reference layout |
| 2 | `selected/calc_all_block_lengths.py` | summarize collinear blocks |
| 3 | `selected/summarize_genetribe_main_table.py` | construct reference-query summary |

The user confirmed 93 query genomes per reference. `source_candidates/` includes `batch.genetribe.sh` (an 81-species partial/earlier list) and `genetribe_3ref.sh` (one hard-coded query). Neither establishes the final 3 × 93 run. `drafts/build_pair_manifest.py` creates the 279-pair list from a validated 94-genome panel, and `drafts/run_genetribe_manifest.sh` prints commands by default or runs them with `EXECUTE=1`. These are methods-derived drafts, not recovered final jobs. The final pair manifest, assembly/annotation versions and job logs remain required.

See `SCRIPT_INDEX.tsv` for every recovered file and its source.
