#!/usr/bin/env python3
"""METHODS-DERIVED DRAFT: enumerate three focal references against 93 queries.

Input is a one-column UTF-8 species ID file without a header. IDs must match
the genome and GeneTribe identifiers. This creates a manifest only; it does
not claim to reproduce the historical GeneTribe jobs or their parameters.
"""
import argparse
import csv
from pathlib import Path


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--species", required=True, type=Path)
    parser.add_argument("--references", required=True, nargs=3)
    parser.add_argument("--output", required=True, type=Path)
    args = parser.parse_args()
    species = [line.strip() for line in args.species.read_text(encoding="utf-8").splitlines()
               if line.strip() and not line.startswith("#")]
    if len(species) != 94 or len(set(species)) != 94:
        parser.error("expected exactly 94 unique grass genome identifiers")
    if len(set(args.references)) != 3 or any(ref not in species for ref in args.references):
        parser.error("three distinct focal references must occur in the 94-genome list")
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with args.output.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.writer(handle, delimiter="\t")
        writer.writerow(["reference", "query"])
        for ref in args.references:
            for query in species:
                if query != ref:
                    writer.writerow([ref, query])


if __name__ == "__main__":
    main()
