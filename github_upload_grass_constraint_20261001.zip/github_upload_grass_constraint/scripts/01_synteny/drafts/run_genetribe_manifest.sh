#!/usr/bin/env bash
# METHODS-DERIVED DRAFT. Expects the 279-pair TSV created by
# build_pair_manifest.py. DRY RUN by default; set EXECUTE=1 only after final
# assembly identifiers, versions and GeneTribe options are checked.
set -euo pipefail

if [[ $# -ne 1 ]]; then
  echo "Usage: $0 pair_manifest.tsv" >&2
  exit 2
fi
manifest=$1
[[ -s "$manifest" ]] || { echo "Missing manifest: $manifest" >&2; exit 1; }
lines=$(($(wc -l < "$manifest") - 1))
[[ "$lines" -eq 279 ]] || { echo "Expected 279 pairs (3 x 93), found $lines" >&2; exit 1; }
if [[ "${EXECUTE:-0}" == "1" ]]; then
  command -v genetribe >/dev/null || { echo "GeneTribe not found" >&2; exit 1; }
fi

while IFS=$'\t' read -r ref query; do
  [[ "$ref" == "reference" && "$query" == "query" ]] && continue
  [[ -n "$ref" && -n "$query" && "$ref" != "$query" ]] || exit 1
  if [[ "${EXECUTE:-0}" == "1" ]]; then
    genetribe core -l "$ref" -f "$query"
  else
    printf 'genetribe core -l %q -f %q\n' "$ref" "$query"
  fi
done < "$manifest"
