#!/usr/bin/env bash
#BSUB -J install_jcvi_deps
#BSUB -q Q96C1T_X12
#BSUB -n 4
#BSUB -o logs/install_jcvi_deps.%J.out
#BSUB -e logs/install_jcvi_deps.%J.err

set -euo pipefail

mkdir -p logs

echo "[INFO] job started at: $(date)"
echo "[INFO] host: $(hostname)"
echo "[INFO] workdir: $(pwd)"

# 1. 初始化 conda/mamba
source ~/miniforge3/etc/profile.d/conda.sh

# 2. 激活目标环境
conda activate genetribe

echo "[INFO] active env: $CONDA_DEFAULT_ENV"
echo "[INFO] python: $(which python)"
python -c "import sys; print(sys.executable)"

# 3. 安装 jcvi 缺失依赖

pip install jcvi
conda install -c bioconda blast bedtools -y

# 4. 简单验证
python - <<'PY'
mods = [
    "Bio",
    "rich",
    "networkx",
    "jinja2",
    "gffutils",
    "goatools",
    "boto3",
    "pyefd",
    "pypdf",
    "skimage",
    "webcolors"
]
for m in mods:
    __import__(m)
print("Python deps import OK")
PY

python -m jcvi.compara.catalog --help >/dev/null

echo "[INFO] jcvi.compara.catalog OK"
echo "[INFO] job finished at: $(date)"