#!/bin/bash
#SBATCH -p parallel
#SBATCH --job-name=catalog
#SBATCH --output=catalog.out
#SBATCH --error=catalog.err
#SBATCH --ntasks=60

  python3 -m jcvi.compara.catalog ortholog \
  bamboo Phyllostachys_edulis --full  \
  > bamboo.Hic.Phyllostachys_edulis.full.tsv