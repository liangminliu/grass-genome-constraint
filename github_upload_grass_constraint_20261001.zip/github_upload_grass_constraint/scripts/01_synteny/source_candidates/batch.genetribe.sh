#!/bin/bash

# 读取81sp.list文件，逐行处理
cat 81sp.list | while read sp; do
    # 创建每个物种的目录
  
   
    # 创建单独的任务脚本
    TASK_SCRIPT="${sp}/${sp}_genetribe.sh"
    cat <<EOT > $TASK_SCRIPT
#!/usr/bin/env bash
#SBATCH -p parallel
#SBATCH --job-name=${sp}
#SBATCH --output=${sp}_log.out
#SBATCH --error=${sp}.err
#SBATCH --ntasks=8



# 运行 genetribe 核心工作流
genetribe core -l Phyllostachys_edulis -f ${sp} 
EOT

    # 赋予任务脚本可执行权限
    chmod +x $TASK_SCRIPT

    echo "Generated job for ${sp} with script: $TASK_SCRIPT"
done
