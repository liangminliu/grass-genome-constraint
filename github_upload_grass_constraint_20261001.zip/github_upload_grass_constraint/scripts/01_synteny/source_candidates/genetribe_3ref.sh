#!/bin/bash
#BSUB -J gt_parallel_3refs
#BSUB -q Q96C1T_X12
#BSUB -n 24
#BSUB -o gt_parallel_3refs.%J.out
#BSUB -e gt_parallel_3refs.%J.err


TOTAL_THREADS="${LSB_DJOB_NUMPROC:-24}"

SUBMIT_DIR="${LS_SUBCWD:-$PWD}"
JOBID="${LSB_JOBID:-manual}"
RUN_TAG="$(date +%Y%m%d_%H%M%S)"
TMPROOT="${SUBMIT_DIR}/parallel_runs_${JOBID}_${RUN_TAG}"
STATUS_DIR="${TMPROOT}/status"

mkdir -p "${TMPROOT}" "${STATUS_DIR}"

source ~/miniforge3/etc/profile.d/conda.sh
conda activate genetribe

QUERY="Echinochloa_crusgalli"

REFS=(
  "Aegilops_tauschii ref_Aegilops_tauschii_output"
  "Phyllostachys_edulis ref_Phyllostachys_edulis_output"
  "Zea_mays ref_Zea_mays_output"
)

N_REFS="${#REFS[@]}"
MAX_PARALLEL="${N_REFS}"
if (( MAX_PARALLEL > TOTAL_THREADS )); then
    MAX_PARALLEL="${TOTAL_THREADS}"
fi
if (( MAX_PARALLEL < 1 )); then
    MAX_PARALLEL=1
fi

THREADS_PER_RUN=$(( TOTAL_THREADS / MAX_PARALLEL ))
if (( THREADS_PER_RUN < 1 )); then
    THREADS_PER_RUN=1
fi

log() {
    echo "[INFO] $(date '+%F %T') $*"
}

die() {
    echo "[ERROR] $(date '+%F %T') $*" >&2
    exit 1
}

check_input() {
    local prefix="$1"
    for ext in fa bed chrlist; do
        [[ -e "${SUBMIT_DIR}/${prefix}.${ext}" ]] || die "missing input: ${SUBMIT_DIR}/${prefix}.${ext}"
    done
}

check_fasta_header() {
    local fa="$1"

    [[ -s "${fa}" ]] || die "empty FASTA file: ${fa}"
    grep -q '^>' "${fa}" || die "not a FASTA file or no FASTA header found: ${fa}"

    if ! grep -m 1 '^>' "${fa}" | grep -q 'gene:'; then
        log "WARNING: FASTA header has no 'gene:' field -> ${fa}"
        log "WARNING: continue anyway"
    fi
}

prepare_query_fa() {
    local infa="$1"
    local outfa="$2"

    awk '
    /^>/{
        raw=$1
        sub(/^>/, "", raw)

        gene=""
        transcript=""
        chr=""

        for(i=2;i<=NF;i++){
            if($i ~ /^gene:/){
                gene=$i
                sub(/^gene:/, "", gene)
            } else if($i ~ /^transcript:/){
                transcript=$i
            } else if($i ~ /^chr:/){
                chr=$i
            }
        }

        if(gene==""){
            print "[ERROR] gene: field missing in header -> " $0 > "/dev/stderr"
            exit 1
        }

        prot=raw

        if(index(raw, gene ".")==1){
            prot=substr(raw, length(gene)+2)
        }
        else if(raw ~ /\|/){
            n=split(raw, a, /\|/)
            prot=a[n]
        }

        printf(">%s.%s gene:%s", gene, prot, gene)
        if(transcript!="") printf(" %s", transcript)
        if(chr!="") printf(" %s", chr)
        printf("\n")
        next
    }
    {print}
    ' "${infa}" > "${outfa}"
}

preview_inputs() {
    local prefix="$1"
    local fa_path="$2"
    local bed_path="$3"
    local chrlist_path="$4"

    {
        echo "===== FASTA preview: ${prefix} ====="
        grep '^>' "${fa_path}" | head -n 2 || true
        echo
        echo "===== BED preview: ${prefix} ====="
        head -n 2 "${bed_path}" || true
        echo
        echo "===== chrlist: ${prefix} ====="
        cat "${chrlist_path}" || true
        echo
    }
}

copy_primary_results() {
    local workdir="$1"
    local outdir="$2"
    local ref="$3"
    local dest="${SUBMIT_DIR}/${outdir}"

    mkdir -p "${dest}"

    shopt -s nullglob
    local files=(
        "${workdir}/${QUERY}_${ref}."*
        "${workdir}/${ref}_${QUERY}."*
    )
    shopt -u nullglob

    [[ "${#files[@]}" -gt 0 ]] || die "no result files found in ${workdir} for ${QUERY} vs ${ref}"

    cp -af "${files[@]}" "${dest}/"
}

copy_full_run() {
    local workdir="$1"
    local outdir="$2"
    local ref="$3"
    local dest="${SUBMIT_DIR}/${outdir}/full_run_${QUERY}_vs_${ref}"

    mkdir -p "${dest}"

    rsync -a --delete \
      --exclude="${QUERY}.fa" \
      --exclude="${QUERY}.bed" \
      --exclude="${QUERY}.chrlist" \
      --exclude="${ref}.fa" \
      --exclude="${ref}.bed" \
      --exclude="${ref}.chrlist" \
      "${workdir}/" "${dest}/"
}

run_one_ref() {
    local ref="$1"
    local outdir="$2"

    set -euo pipefail

    local workdir="${TMPROOT}/run_${QUERY}_vs_${ref}"
    local runlog="${workdir}/RUN_LOG.${QUERY}_vs_${ref}.log"

    rm -rf "${workdir}"
    mkdir -p "${workdir}"
    mkdir -p "${SUBMIT_DIR}/${outdir}"

    cd "${workdir}"

    ln -sfn "${SUBMIT_DIR}/${QUERY}.bed"     "./${QUERY}.bed"
    ln -sfn "${SUBMIT_DIR}/${QUERY}.chrlist" "./${QUERY}.chrlist"

    # query fasta做规范化，避免只取header第一个token时与bed不匹配
    prepare_query_fa "${SUBMIT_DIR}/${QUERY}.fa" "./${QUERY}.fa"

    ln -sfn "${SUBMIT_DIR}/${ref}.fa"      "./${ref}.fa"
    ln -sfn "${SUBMIT_DIR}/${ref}.bed"     "./${ref}.bed"
    ln -sfn "${SUBMIT_DIR}/${ref}.chrlist" "./${ref}.chrlist"

    {
        preview_inputs "${QUERY}" "./${QUERY}.fa" "./${QUERY}.bed" "./${QUERY}.chrlist"
        preview_inputs "${ref}"   "./${ref}.fa"   "./${ref}.bed"   "./${ref}.chrlist"

        echo "[INFO] Running genetribe core: QUERY=${QUERY}, REF=${ref}, THREADS=${THREADS_PER_RUN}"
        genetribe core \
          -l "${ref}" \
          -f "${QUERY}" \
          -r \
          -n "${THREADS_PER_RUN}"

        echo "[INFO] genetribe core finished: QUERY=${QUERY}, REF=${ref}"
    } > "${runlog}" 2>&1

    copy_primary_results "${workdir}" "${outdir}" "${ref}"
    copy_full_run "${workdir}" "${outdir}" "${ref}"
    cp -af "${runlog}" "${SUBMIT_DIR}/${outdir}/"
}

wait_for_slot() {
    while true; do
        local n_running
        n_running=$(jobs -rp | wc -l)
        if (( n_running < MAX_PARALLEL )); then
            break
        fi
        sleep 2
    done
}

main() {
    log "TOTAL_THREADS=${TOTAL_THREADS}"
    log "N_REFS=${N_REFS}"
    log "MAX_PARALLEL=${MAX_PARALLEL}"
    log "THREADS_PER_RUN=${THREADS_PER_RUN}"
    log "QUERY=${QUERY}"
    log "TMPROOT=${TMPROOT}"

    check_input "${QUERY}"
    check_fasta_header "${SUBMIT_DIR}/${QUERY}.fa"

    local pids=()
    local names=()

    local item ref outdir
    for item in "${REFS[@]}"; do
        read -r ref outdir <<< "${item}"

        check_input "${ref}"
        check_fasta_header "${SUBMIT_DIR}/${ref}.fa"

        wait_for_slot

        log "Launching: ${QUERY} vs ${ref} -> ${outdir}"
        (
            run_one_ref "${ref}" "${outdir}"
        ) &
        pids+=("$!")
        names+=("${ref}")
    done

    local fail=0
    local i
    for i in "${!pids[@]}"; do
        if wait "${pids[$i]}"; then
            log "Finished successfully: ${names[$i]}"
        else
            log "FAILED: ${names[$i]}"
            fail=1
        fi
    done

    (( fail == 0 )) || die "One or more parallel runs failed."
    log "All parallel runs completed successfully."
}

main