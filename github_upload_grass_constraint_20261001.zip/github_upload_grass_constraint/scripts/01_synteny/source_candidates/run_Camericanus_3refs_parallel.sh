#!/bin/bash
#BSUB -J 3refs_Camericanus_parallel
#BSUB -q Q96C1T_X12
#BSUB -n 24
#BSUB -o gt_Camericanus_3refs_parallel.%J.out
#BSUB -e gt_Camericanus_3refs_parallel.%J.err

set -euo pipefail

TOTAL_THREADS="${LSB_DJOB_NUMPROC:-24}"
MAX_PARALLEL=3
THREADS_PER_RUN=$(( TOTAL_THREADS / MAX_PARALLEL ))
if [[ "${THREADS_PER_RUN}" -lt 1 ]]; then
    THREADS_PER_RUN=1
fi

SUBMIT_DIR="${LS_SUBCWD:-$PWD}"
JOBID="${LSB_JOBID:-manual}"
RUN_TAG="$(date +%Y%m%d_%H%M%S)"
TMPROOT="${SUBMIT_DIR}/parallel_runs_${JOBID}_${RUN_TAG}"

mkdir -p "${TMPROOT}"

source ~/miniforge3/etc/profile.d/conda.sh
conda activate genetribe

QUERY="Cenchrus_americanus"

REFS=(
  "Zea_mays ref_Zea_mays_output"
  "Aegilops_tauschii ref_Aegilops_tauschii_output"
  "Phyllostachys_edulis ref_Phyllostachys_edulis_output"
)

log() {
    echo "[INFO] $(date '+%F %T') $*"
}

preview_inputs() {
    local prefix="$1"
    {
        echo "===== FASTA preview: ${prefix} ====="
        grep '^>' "${SUBMIT_DIR}/${prefix}.fa" | head -n 2 || true
        echo
        echo "===== BED preview: ${prefix} ====="
        head -n 2 "${SUBMIT_DIR}/${prefix}.bed" || true
        echo
        echo "===== chrlist: ${prefix} ====="
        cat "${SUBMIT_DIR}/${prefix}.chrlist" || true
        echo
    }
}

copy_primary_results() {
    local workdir="$1"
    local outdir="$2"
    local ref="$3"
    local dest="${SUBMIT_DIR}/${outdir}"

    mkdir -p "${dest}"

    shopt -s nullglob
    local files=(
        "${workdir}/${QUERY}_${ref}."*
        "${workdir}/${ref}_${QUERY}."*
    )
    shopt -u nullglob

    if [[ "${#files[@]}" -gt 0 ]]; then
        cp -af "${files[@]}" "${dest}/"
    fi
}

copy_full_run() {
    local workdir="$1"
    local outdir="$2"
    local ref="$3"
    local dest="${SUBMIT_DIR}/${outdir}/full_run_${QUERY}_vs_${ref}"

    mkdir -p "${dest}"

    rsync -a --delete \
      --exclude="${QUERY}.fa" \
      --exclude="${QUERY}.bed" \
      --exclude="${QUERY}.chrlist" \
      --exclude="${ref}.fa" \
      --exclude="${ref}.bed" \
      --exclude="${ref}.chrlist" \
      "${workdir}/" "${dest}/"
}

run_one_ref() {
    local ref="$1"
    local outdir="$2"

    (
        set -euo pipefail

        local workdir="${TMPROOT}/run_${QUERY}_vs_${ref}"
        local runlog="${workdir}/RUN_LOG.${QUERY}_vs_${ref}.log"

        rm -rf "${workdir}"
        mkdir -p "${workdir}"
        mkdir -p "${SUBMIT_DIR}/${outdir}"
        cd "${workdir}"

        ln -sfn "${SUBMIT_DIR}/${QUERY}.fa"      "./${QUERY}.fa"
        ln -sfn "${SUBMIT_DIR}/${QUERY}.bed"     "./${QUERY}.bed"
        ln -sfn "${SUBMIT_DIR}/${QUERY}.chrlist" "./${QUERY}.chrlist"

        ln -sfn "${SUBMIT_DIR}/${ref}.fa"      "./${ref}.fa"
        ln -sfn "${SUBMIT_DIR}/${ref}.bed"     "./${ref}.bed"
        ln -sfn "${SUBMIT_DIR}/${ref}.chrlist" "./${ref}.chrlist"

        preview_inputs "${QUERY}" > "${runlog}" 2>&1
        preview_inputs "${ref}"  >> "${runlog}" 2>&1

        genetribe core \
          -l "${QUERY}" \
          -f "${ref}" \
          -n "${THREADS_PER_RUN}" >> "${runlog}" 2>&1

        copy_primary_results "${workdir}" "${outdir}" "${ref}"
        copy_full_run "${workdir}" "${outdir}" "${ref}"
        cp -af "${runlog}" "${SUBMIT_DIR}/${outdir}/"
    ) &
}

main() {
    for item in "${REFS[@]}"; do
        ref="$(echo "${item}" | awk '{print $1}')"
        outdir="$(echo "${item}" | awk '{print $2}')"
        run_one_ref "${ref}" "${outdir}"
    done

    wait
    log "All parallel runs completed."
}

main
