#!/bin/bash

# 读取81sp.list文件，逐行处理
cat 81sp.list | while read sp; do
    # 创建每个物种的输出目录
    OUTPUT_DIR="./${sp}_output"  # 每个物种的输出文件夹
    mkdir -p $OUTPUT_DIR  # 确保输出目录存在

    # 创建单独的任务脚本
    TASK_SCRIPT="${sp}_genetribe.sh"
    cat <<EOT > $TASK_SCRIPT
#!/usr/bin/env bash
#SBATCH -p parallel
#SBATCH --job-name=${sp}
#SBATCH --output=${OUTPUT_DIR}/${sp}_log
#SBATCH --error=${OUTPUT_DIR}/${sp}.err
#SBATCH --ntasks=8

# 创建输出目录
mkdir -p ${OUTPUT_DIR}

# 运行 genetribe 核心工作流
genetribe core -l Phyllostachys_edulis -f ${sp} 
# 移动结果文件
mv ./Phyllostachys_edulis_${sp}* ${OUTPUT_DIR}/
mv ./${sp}_Phyllostachys_edulis* ${OUTPUT_DIR}/

# 确认文件已移动
echo "Moved output files for ${sp} to ${OUTPUT_DIR}"
EOT

  
    echo "generated job for ${sp} with script: $TASK_SCRIPT"
done
