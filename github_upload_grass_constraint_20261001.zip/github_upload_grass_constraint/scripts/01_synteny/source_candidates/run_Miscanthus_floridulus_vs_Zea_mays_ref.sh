#!/usr/bin/env bash
#BSUB -J Miscanthus_ref_Zea_mays
#BSUB -q Q96C1T_X12
#BSUB -n 4
#BSUB -o /ds3200_1/users_root/liuliangmin/workspace/PHD/3.genetribe/Miscanthus_floridulus/Miscanthus_ref_Zea_mays.%J.out
#BSUB -e /ds3200_1/users_root/liuliangmin/workspace/PHD/3.genetribe/Miscanthus_floridulus/Miscanthus_ref_Zea_mays.%J.err

set -euo pipefail

QUERY="Miscanthus_floridulus"
REF="Zea_mays"
WORKDIR="/ds3200_1/users_root/liuliangmin/workspace/PHD/3.genetribe/Miscanthus_floridulus"
OUTDIR="${WORKDIR}/ref_${REF}_output"

# source ~/.bashrc
# conda activate genetribe

suffixes=(
    block_pos
    collinearity_info
    one2many
    one2one
    SBH
    RBH
    singleton
)

ts=$(date +%Y%m%d_%H%M%S)
RUNDIR="${WORKDIR}/run_${QUERY}_vs_${REF}_${ts}"

echo "[INFO] start time: $(date)"
echo "[INFO] QUERY=${QUERY}"
echo "[INFO] REF=${REF}"
echo "[INFO] WORKDIR=${WORKDIR}"

cd "${WORKDIR}"
mkdir -p "${OUTDIR}" "${RUNDIR}"

cleanup() {
    local ec=$?
    if [[ -d "${RUNDIR}" ]]; then
        mv "${RUNDIR}" "${OUTDIR}/run_files_${ts}" 2>/dev/null || true
    fi
    exit $ec
}
trap cleanup EXIT

############################################
# 1. check inputs
############################################
for f in \
    "${QUERY}.fa" "${QUERY}.bed" "${QUERY}.chrlist" \
    "${REF}.fa"   "${REF}.bed"   "${REF}.chrlist"
do
    if [[ ! -e "${f}" ]]; then
        echo "[ERROR] missing input: ${WORKDIR}/${f}" >&2
        exit 1
    fi
done

############################################
# 2. copy QUERY unchanged
############################################
cp -f "${QUERY}.fa"      "${RUNDIR}/${QUERY}.fa"
cp -f "${QUERY}.bed"     "${RUNDIR}/${QUERY}.bed"
cp -f "${QUERY}.chrlist" "${RUNDIR}/${QUERY}.chrlist"

############################################
# 3. process REF(Zea_mays)
#    keep bed unchanged
#    remove transcript suffix like .001 in fasta header
############################################
cp -f "${REF}.bed"     "${RUNDIR}/${REF}.bed"
cp -f "${REF}.chrlist" "${RUNDIR}/${REF}.chrlist"

awk '
BEGIN{FS=OFS=""}
{
    if ($0 ~ /^>/) {
        line = substr($0, 2)
        n = split(line, a, /[ \t]/)
        id = a[1]
        sub(/\.[0-9]+$/, "", id)
        printf(">%s", id)
        if (length(line) > length(a[1])) {
            printf("%s", substr(line, length(a[1]) + 1))
        }
        printf("\n")
    } else {
        print
    }
}
' "${REF}.fa" > "${RUNDIR}/${REF}.fa"

############################################
# 4. sanity check
############################################
echo "[INFO] processed files in ${RUNDIR}"
echo "[INFO] head ${REF}.bed"
head -n 3 "${RUNDIR}/${REF}.bed" || true
echo "[INFO] head ${REF}.fa"
head -n 3 "${RUNDIR}/${REF}.fa" || true

############################################
# 5. run genetribe
#    query still needs -s "@"
############################################
cd "${RUNDIR}"

if [[ -d genetribe_output ]]; then
    echo "[ERROR] unexpected existing ${RUNDIR}/genetribe_output" >&2
    exit 1
fi

echo "[INFO] running genetribe core ..."
genetribe core -l "${REF}" -f "${QUERY}" -s "@" 2>&1 | tee "${OUTDIR}/${QUERY}_ref_${REF}.runtime.log"

############################################
# 6. collect outputs
############################################
for s in "${suffixes[@]}"; do
    [[ -e "${QUERY}_${REF}.${s}" ]] && mv -f "${QUERY}_${REF}.${s}" "${OUTDIR}/"
    [[ -e "${REF}_${QUERY}.${s}" ]] && mv -f "${REF}_${QUERY}.${s}" "${OUTDIR}/"
done

for f in \
    "${QUERY}.${REF}.last" \
    "${QUERY}.${REF}.last.filtered" \
    "${QUERY}.${REF}.anchors" \
    "${QUERY}.${REF}.lifted.anchors" \
    "${QUERY}.${REF}.pdf" \
    "${REF}.${QUERY}.last" \
    "${REF}.${QUERY}.last.filtered" \
    "${REF}.${QUERY}.anchors" \
    "${REF}.${QUERY}.lifted.anchors" \
    "${REF}.${QUERY}.pdf"
do
    [[ -e "${f}" ]] && mv -f "${f}" "${OUTDIR}/"
done

if [[ -d genetribe_output ]]; then
    if [[ -e "${OUTDIR}/genetribe_output" ]]; then
        mv genetribe_output "${OUTDIR}/genetribe_output.${ts}"
    else
        mv genetribe_output "${OUTDIR}/genetribe_output"
    fi
fi

echo "[INFO] finished successfully"
echo "[INFO] output dir: ${OUTDIR}"
echo "[INFO] end time: $(date)"