import os
import csv

def calc_block_lengths(filepath):
    ae_umb_sum = 0
    ped_sum = 0
    if not os.path.exists(filepath):
        return (None, None)
    with open(filepath) as f:
        for line in f:
            if line.strip() == "" or line.startswith("#"):
                continue
            arr = line.strip().split()
            if len(arr) < 6:
                continue
            try:
                ae_umb_len = abs(int(arr[2]) - int(arr[1]))
                ped_len = abs(int(arr[5]) - int(arr[4]))
            except ValueError:
                continue
            ae_umb_sum += ae_umb_len
            ped_sum += ped_len
    return (ae_umb_sum, ped_sum)

# 写入csv文件
with open("all_block_length_stats.csv", "w", newline="") as csvfile:
    writer = csv.writer(csvfile)
    # 写表头
    writer.writerow([
        "Species",
        "FileType",
        "Total length of syntenic blocks in the query genome (bp)",
        "Total length of syntenic blocks in the reference genome (bp)"
    ])
    with open("81sp.list") as spfile:
        for species in spfile:
            sp = species.strip()
            if not sp:
                continue

            # 两个文件名，注意后缀
            file1 = os.path.join(sp, f"{sp}_Phyllostachys_edulis.block_pos")
            file2 = os.path.join(sp, f"Phyllostachys_edulis_{sp}.block_pos")  # 注意是 .block_pos

            # 处理 file1
            r1 = calc_block_lengths(file1)
            if r1[0] is not None:
                writer.writerow([
                    sp,
                    "sp_Phyllostachys_edulis.block_pos",
                    r1[0],
                    r1[1]
                ])
            else:
                writer.writerow([
                    sp,
                    "sp_Phyllostachys_edulis.block_pos",
                    "FILE_NOT_FOUND",
                    "FILE_NOT_FOUND"
                ])

            # 处理 file2
            r2 = calc_block_lengths(file2)
            if r2[0] is not None:
                writer.writerow([
                    sp,
                    "Phyllostachys_edulis_sp.block_pos",
                    r2[0],
                    r2[1]
                ])
            else:
                writer.writerow([
                    sp,
                    "Phyllostachys_edulis_sp.block_pos",
                    "FILE_NOT_FOUND",
                    "FILE_NOT_FOUND"
                ])