#!/usr/bin/env bash
set -euo pipefail

BASE_DIR="${PWD}"                  # .../PHD/3.genetribe
DATA_DIR="$(realpath -m "${BASE_DIR}/../data")"
SAMPLE_LIST="${BASE_DIR}/sample.list"

OLD_REF="Phyllostachys_edulis"
REF1="Aegilops_tauschii"
REF2="Zea_mays"

QUEUE="Q96C1T_X12"
NCORE=2

if [[ ! -f "${SAMPLE_LIST}" ]]; then
    echo "[ERROR] sample.list not found: ${SAMPLE_LIST}" >&2
    exit 1
fi

if [[ ! -d "${DATA_DIR}" ]]; then
    echo "[ERROR] data directory not found: ${DATA_DIR}" >&2
    exit 1
fi

########################################################
# 为每个 ref 定义固定来源
# 输出3列：fa_target bed_target chr_target
# 这些 target 是“写入软链接时使用的相对路径”
########################################################
build_ref_targets() {
    local ref="$1"

    case "${ref}" in
        Phyllostachys_edulis)
            echo "../../data/Phyllostachys_edulis.fa ../../data/Phyllostachys_edulis.bed ../../data/Phyllostachys_edulis.chrlist"
            ;;
        Aegilops_tauschii)
            echo "../Aegilops_tauschii/Aegilops_tauschii.fa ../../data/Aegilops_tauschii.bed ../../data/Aegilops_tauschii.chrlist"
            ;;
        Zea_mays)
            echo "../Zea_mays/Zea_mays.fa ../../data/Zea_mays.bed ../../data/Zea_mays.chrlist"
            ;;
        *)
            echo "[ERROR] unsupported ref: ${ref}" >&2
            exit 1
            ;;
    esac
}

########################################################
# 检查每个 ref 的真实源文件是否存在
########################################################
check_ref_sources() {
    local ref="$1"
    local fa_check bed_check chr_check

    case "${ref}" in
        Phyllostachys_edulis)
            fa_check="${DATA_DIR}/Phyllostachys_edulis.fa"
            bed_check="${DATA_DIR}/Phyllostachys_edulis.bed"
            chr_check="${DATA_DIR}/Phyllostachys_edulis.chrlist"
            ;;
        Aegilops_tauschii)
            fa_check="${BASE_DIR}/Aegilops_tauschii/Aegilops_tauschii.fa"
            bed_check="${DATA_DIR}/Aegilops_tauschii.bed"
            chr_check="${DATA_DIR}/Aegilops_tauschii.chrlist"
            ;;
        Zea_mays)
            fa_check="${BASE_DIR}/Zea_mays/Zea_mays.fa"
            bed_check="${DATA_DIR}/Zea_mays.bed"
            chr_check="${DATA_DIR}/Zea_mays.chrlist"
            ;;
        *)
            echo "[ERROR] unsupported ref: ${ref}" >&2
            exit 1
            ;;
    esac

    [[ -e "${fa_check}"  ]] || { echo "[ERROR] missing ${fa_check}" >&2;  exit 1; }
    [[ -e "${bed_check}" ]] || { echo "[ERROR] missing ${bed_check}" >&2; exit 1; }
    [[ -e "${chr_check}" ]] || { echo "[ERROR] missing ${chr_check}" >&2; exit 1; }
}

########################################################
# 构建 ref 输入软链接
# 这就是“对应 ref 的软连接代码”
########################################################
link_ref_inputs() {
    local qdir="$1"
    local query="$2"
    local ref="$3"
    local fa_target bed_target chr_target

    [[ "${query}" == "${ref}" ]] && return 0

    check_ref_sources "${ref}"
    read -r fa_target bed_target chr_target < <(build_ref_targets "${ref}")

    rm -f "${qdir}/${ref}.fa" "${qdir}/${ref}.bed" "${qdir}/${ref}.chrlist"

    ln -s "${fa_target}"  "${qdir}/${ref}.fa"
    ln -s "${bed_target}" "${qdir}/${ref}.bed"
    ln -s "${chr_target}" "${qdir}/${ref}.chrlist"
}

########################################################
# 归档旧 ped(ref=Phyllostachys_edulis) 结果
########################################################
archive_old_ped_outputs() {
    local qdir="$1"
    local query="$2"
    local ref="$3"
    local outdir="${qdir}/ref_${ref}_output"
    local s ts

    mkdir -p "${outdir}"

    local suffixes=(
        block_pos
        collinearity_info
        one2many
        one2one
        SBH
        RBH
        singleton
    )

    for s in "${suffixes[@]}"; do
        [[ -e "${qdir}/${query}_${ref}.${s}" ]] && mv -n "${qdir}/${query}_${ref}.${s}" "${outdir}/"
        [[ -e "${qdir}/${ref}_${query}.${s}" ]] && mv -n "${qdir}/${ref}_${query}.${s}" "${outdir}/"
    done

    [[ -e "${qdir}/${query}_log.out" ]] && mv -n "${qdir}/${query}_log.out" "${outdir}/"
    [[ -e "${qdir}/${query}.err"     ]] && mv -n "${qdir}/${query}.err"     "${outdir}/"

    if [[ -d "${qdir}/genetribe_output" ]]; then
        if [[ -e "${outdir}/genetribe_output" ]]; then
            ts="$(date +%Y%m%d_%H%M%S)"
            mv "${qdir}/genetribe_output" "${outdir}/genetribe_output.${ts}"
        else
            mv "${qdir}/genetribe_output" "${outdir}/genetribe_output"
        fi
    fi
}

########################################################
# 生成每个 query 的串联 bsub 脚本
# 先跑 Aegilops_tauschii，再跑 Zea_mays
########################################################
write_chain_script() {
    local qdir="$1"
    local query="$2"
    local script="${qdir}/${query}_ref_chain.bsub.sh"

    cat > "${script}" <<EOF
#!/usr/bin/env bash
#BSUB -J ${query}_ref_chain
#BSUB -q ${QUEUE}
#BSUB -n ${NCORE}
#BSUB -o ${qdir}/${query}_ref_chain.%J.out
#BSUB -e ${qdir}/${query}_ref_chain.%J.err

set -euo pipefail

QUERY="${query}"
REF1="${REF1}"
REF2="${REF2}"

cd "${qdir}"

# 如需环境，取消注释
# source ~/.bashrc
# conda activate genetribe

suffixes=(
    block_pos
    collinearity_info
    one2many
    one2one
    SBH
    RBH
    singleton
)

run_one_ref() {
    local REF="\$1"
    local OUTDIR="ref_\${REF}_output"
    local ts backup_dir s f

    ts=\$(date +%Y%m%d_%H%M%S)

    if [[ "\${QUERY}" == "\${REF}" ]]; then
        echo "[INFO] skip self-self: QUERY=\${QUERY}, REF=\${REF}"
        return 0
    fi

    mkdir -p "\${OUTDIR}"

    for f in \\
        "\${QUERY}.fa" "\${QUERY}.bed" "\${QUERY}.chrlist" \\
        "\${REF}.fa"   "\${REF}.bed"   "\${REF}.chrlist"
    do
        if [[ ! -e "\${f}" ]]; then
            echo "[ERROR] missing input: \${f}" >&2
            exit 1
        fi
    done

    if [[ -d genetribe_output ]]; then
        echo "[ERROR] existing ./genetribe_output found before REF=\${REF}" >&2
        exit 1
    fi

    backup_dir=""
    for s in "\${suffixes[@]}"; do
        for f in "\${QUERY}_\${REF}.\${s}" "\${REF}_\${QUERY}.\${s}"; do
            if [[ -e "\${f}" ]]; then
                if [[ -z "\${backup_dir}" ]]; then
                    backup_dir="\${OUTDIR}/preexisting_\${ts}"
                    mkdir -p "\${backup_dir}"
                fi
                mv "\${f}" "\${backup_dir}/"
            fi
        done
    done

    echo "[INFO] start genetribe: QUERY=\${QUERY}, REF=\${REF}"
    genetribe core -l "\${REF}" -f "\${QUERY}" 2>&1 | tee "\${OUTDIR}/\${QUERY}_ref_\${REF}.runtime.log"

    for s in "\${suffixes[@]}"; do
        [[ -e "\${QUERY}_\${REF}.\${s}" ]] && mv -f "\${QUERY}_\${REF}.\${s}" "\${OUTDIR}/"
        [[ -e "\${REF}_\${QUERY}.\${s}" ]] && mv -f "\${REF}_\${QUERY}.\${s}" "\${OUTDIR}/"
    done

    if [[ -d genetribe_output ]]; then
        if [[ -e "\${OUTDIR}/genetribe_output" ]]; then
            mv genetribe_output "\${OUTDIR}/genetribe_output.\${ts}"
        else
            mv genetribe_output "\${OUTDIR}/genetribe_output"
        fi
    fi

    echo "[INFO] finished: QUERY=\${QUERY}, REF=\${REF}"
}

run_one_ref "\${REF1}"
run_one_ref "\${REF2}"

echo "[INFO] all finished for QUERY=\${QUERY}"
EOF

    chmod +x "${script}"
}

########################################################
# 主循环
########################################################
while IFS= read -r query || [[ -n "${query}" ]]; do
    [[ -z "${query}" ]] && continue

    qdir="${BASE_DIR}/${query}"
    if [[ ! -d "${qdir}" ]]; then
        echo "[WARN] skip missing directory: ${qdir}"
        continue
    fi

    # query 自己输入必须存在
    for f in "${qdir}/${query}.fa" "${qdir}/${query}.bed" "${qdir}/${query}.chrlist"; do
        if [[ ! -e "${f}" ]]; then
            echo "[WARN] skip ${query}: missing ${f}"
            continue 2
        fi
    done

    echo "[INFO] processing ${query}"

    # 固定规则重建 ref 软链接
    link_ref_inputs "${qdir}" "${query}" "${OLD_REF}"
    link_ref_inputs "${qdir}" "${query}" "${REF1}"
    link_ref_inputs "${qdir}" "${query}" "${REF2}"

    # 归档旧 ped 结果
    archive_old_ped_outputs "${qdir}" "${query}" "${OLD_REF}"

    # 生成串联任务脚本
    write_chain_script "${qdir}" "${query}"
done < "${SAMPLE_LIST}"

echo "[INFO] done"