#!/bin/bash
#BSUB -J ped_structure_v2
#BSUB -q Q64C1T_X4
#BSUB -n 4
#BSUB -o logs/ped_structure_v2.%J.out
#BSUB -e logs/ped_structure_v2.%J.err

set -euo pipefail

mkdir -p logs results

PY_SCRIPT="genome_structure_final_v2_ped.py"

GENE="genes.bed"
EXON="exons_sorted.bed"
CDS="CDS_jcvi.bed"
PROMOTER="promoters.bed"
TE="TE.bed"
UTR5="five_prime_UTR.bed"
UTR3="three_prime_UTR.bed"
UPDOWN5K="updown5k.bed"
CHROM_SIZES="ped_data/chrom_list_chrom_sizes.txt"

OUT_PREFIX="results/ped_structure_v2"

echo "[INFO] Job started at: $(date)"
echo "[INFO] Host: $(hostname)"
echo "[INFO] Workdir: $(pwd)"
echo "[INFO] Python: $(command -v python3 || true)"

for f in \
    "${PY_SCRIPT}" \
    "${GENE}" \
    "${EXON}" \
    "${CDS}" \
    "${PROMOTER}" \
    "${TE}" \
    "${UTR5}" \
    "${UTR3}" \
    "${UPDOWN5K}" \
    "${CHROM_SIZES}"
do
    if [[ ! -s "${f}" ]]; then
        echo "[ERROR] Missing or empty file: ${f}" >&2
        exit 1
    fi
done

python3 "${PY_SCRIPT}" \
    --gene "${GENE}" \
    --exon "${EXON}" \
    --cds "${CDS}" \
    --promoter "${PROMOTER}" \
    --te "${TE}" \
    --utr5 "${UTR5}" \
    --utr3 "${UTR3}" \
    --updown5k "${UPDOWN5K}" \
    --chrom-sizes "${CHROM_SIZES}" \
    --out "${OUT_PREFIX}" \
    --scope all

for suffix in ped pedC pedD; do
    for ext in all_metrics.tsv te_subclass.tsv qc.tsv; do
        f="${OUT_PREFIX}.${suffix}.${ext}"
        if [[ ! -s "${f}" ]]; then
            echo "[ERROR] Output not generated: ${f}" >&2
            exit 1
        fi
    done
done

echo "[INFO] Output summary:"
ls -lh \
    "${OUT_PREFIX}.ped.all_metrics.tsv" \
    "${OUT_PREFIX}.ped.te_subclass.tsv" \
    "${OUT_PREFIX}.ped.qc.tsv" \
    "${OUT_PREFIX}.pedC.all_metrics.tsv" \
    "${OUT_PREFIX}.pedC.te_subclass.tsv" \
    "${OUT_PREFIX}.pedC.qc.tsv" \
    "${OUT_PREFIX}.pedD.all_metrics.tsv" \
    "${OUT_PREFIX}.pedD.te_subclass.tsv" \
    "${OUT_PREFIX}.pedD.qc.tsv"

echo "[INFO] Job finished at: $(date)"
