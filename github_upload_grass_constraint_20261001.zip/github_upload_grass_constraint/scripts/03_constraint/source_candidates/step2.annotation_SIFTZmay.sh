#!/bin/bash
#BSUB -J step2.annotation_SIFTZmay
#BSUB -q Q96C1T_X12
#BSUB -n 10
#BSUB -o logs/step2.annotation_SIFTZmay.%J.out
#BSUB -e logs/step2.annotation_SIFTZmay.%J.err

set -euo pipefail

mkdir -p logs
mkdir -p SIFT_del

########################################
# Input / output
########################################
VCF_IN="SIFT_del/Zmay.sift_lt_all.vcf.gz"
VCF_OUT="SIFT_del/Zmay.sift_lt_all.ann.vcf"
CSV_OUT="SIFT_del/Zmay.sift_lt_all.csv"
HTML_OUT="SIFT_del/Zmay.sift_lt_all.html"

########################################
# snpEff settings
########################################
SIF="$HOME/workspace/4.reseq-chr/software/Reseq_genek.sif"
CONFIG="./snpEff.config"
GENOME_DB="Zmay"   # 若 snpEff.config 中名称不是 Zmay，请改成实际 genome ID

########################################
# Check input
########################################
[[ -f "${VCF_IN}" ]] || { echo "[ERROR] Input not found: ${VCF_IN}"; exit 1; }
[[ -f "${CONFIG}" ]] || { echo "[ERROR] Config not found: ${CONFIG}"; exit 1; }
[[ -f "${SIF}" ]] || { echo "[ERROR] Singularity image not found: ${SIF}"; exit 1; }

echo "[INFO] Start: $(date)"
echo "[INFO] Input : ${VCF_IN}"
echo "[INFO] Output: ${VCF_OUT}"
echo "[INFO] DB    : ${GENOME_DB}"

singularity exec "${SIF}" \
  java -Xmx200g -jar /opt/snpEff/snpEff.jar \
  -c "${CONFIG}" \
  -ud 5000 \
  -csvStats "${CSV_OUT}" \
  -htmlStats "${HTML_OUT}" \
  -o vcf \
  "${GENOME_DB}" \
  "${VCF_IN}" \
  > "${VCF_OUT}"

echo "[INFO] snpEff finished: $(date)"

bgzip -f "${VCF_OUT}"
tabix -f -p vcf "${VCF_OUT}.gz"

echo "[INFO] Done: $(date)"