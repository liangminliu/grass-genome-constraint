#!/bin/bash
#BSUB -J step8
#BSUB -q Q96C1T_X12
#BSUB -n 16
#BSUB -o step8.%J.out
#BSUB -e step8.%J.err


bash CNS_GERP_analysis/08_gene_RS_positive.sh

python3 CNS_GERP_analysis/08_summarize_gene_RS.py


python3 CNS_GERP_analysis/08_compile_gene_table_chr.py