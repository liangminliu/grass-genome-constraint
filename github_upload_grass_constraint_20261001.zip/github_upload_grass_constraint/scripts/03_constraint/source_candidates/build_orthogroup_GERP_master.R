#!/usr/bin/env Rscript

suppressPackageStartupMessages({
  library(dplyr)
  library(readr)
  library(tidyr)
  library(purrr)
  library(stringr)
})

############################################################
# 1. 参数设置
############################################################
thresholds <- c("gt0", "gt2", "gt4", "gt6")

species_files <- function(threshold) {
  tibble(
    species = c("pedC", "pedD", "Zmay", "Atau"),
    file = c(
      paste0("2.1.ped/ped_target_gene_CDS_GERP_stats/gerp_", threshold,
             "/pedC/per_gene_stats.tsv"),
      paste0("2.1.ped/ped_target_gene_CDS_GERP_stats/gerp_", threshold,
             "/pedD/per_gene_stats.tsv"),
      paste0("2.2.Zmay/Zmay_target_gene_CDS_GERP_stats/",
             threshold, "/per_gene_stats.tsv"),
      paste0("2.3.Atau/target_gene_CDS_GERP_stats/",
             threshold, "/per_gene_stats.tsv")
    )
  )
}

PAN_FILE <- "core_5sp_1to1.SG.pan"

############################################################
# 2. 读取 PAN，构建 orthogroup → gene 映射
############################################################
# PAN 列顺序（你现在的数据）：
# 1: orthogroup
# 5: Atau
# 7: pedC
# 8: pedD
# 9: Zmay

pan_long <- read_tsv(
  PAN_FILE,
  col_names = FALSE,
  show_col_types = FALSE
) %>%
  transmute(
    orthogroup = X1,
    Atau = str_remove(X5, "^Atau_"),
    pedC = str_remove(X7, "^pedC_"),
    pedD = str_remove(X8, "^pedD_"),
    Zmay = str_remove(X9, "^Zmay_")
  ) %>%
  pivot_longer(
    cols = c(Atau, pedC, pedD, Zmay),
    names_to = "species",
    values_to = "gene_id"
  ) %>%
  filter(!is.na(gene_id), gene_id != "-")

############################################################
# 3. 读取 per_gene_stats，并加 threshold / species
############################################################
read_one_threshold <- function(threshold) {
  species_files(threshold) %>%
    mutate(
      data = map(file, ~ {
        if (!file.exists(.x)) {
          stop("Missing file: ", .x)
        }
        read_tsv(.x, show_col_types = FALSE)
      })
    ) %>%
    unnest(data) %>%
    mutate(threshold = threshold)
}

stats_all <- map_dfr(thresholds, read_one_threshold)

############################################################
# 4. 与 PAN 进行 join，构建 master 表
############################################################
master_table <- pan_long %>%
  left_join(
    stats_all,
    by = c("species", "gene_id")
  ) %>%
  relocate(orthogroup, species, threshold, gene_id)

############################################################
# 5. 基本 sanity check（强烈建议保留）
############################################################
# 1) 每个 orthogroup × species × threshold 只有 1 个 gene
dup_check <- master_table %>%
  count(orthogroup, species, threshold) %>%
  filter(n > 1)

if (nrow(dup_check) > 0) {
  warning("Duplicated orthogroup-species-threshold entries detected!")
}

# 2) cds_pct 不应 > 100
bad_cds <- master_table %>%
  filter(!is.na(cds_pct) & cds_pct > 100)

if (nrow(bad_cds) > 0) {
  warning("Found cds_pct > 100, please double-check input data.")
}

############################################################
# 6. 输出结果
############################################################
write_tsv(master_table, "orthogroup_GERP_master.tsv")

cat("[INFO] Master table written to orthogroup_GERP_master.tsv\n")
cat("[INFO] Rows:", nrow(master_table), "\n")
