#!/bin/bash
#SBATCH --job-name=functional_intersect
#SBATCH --output=logs/functional_intersect_%A_%a.log
#SBATCH --error=logs/functional_intersect_%A_%a.err
#SBATCH --cpus-per-task=10
#SBATCH --array=1-4%4

set -euo pipefail

mkdir -p logs

# ============================================================
# Singularity tmp dir
# ============================================================

WORK_TMP_DIR="$(pwd)/singularity_tmp_${SLURM_JOB_ID}_${SLURM_ARRAY_TASK_ID}"
export SINGULARITY_TMPDIR="$WORK_TMP_DIR"
export TMPDIR="$WORK_TMP_DIR"
mkdir -p "$WORK_TMP_DIR"

cleanup() {
    rm -rf "$WORK_TMP_DIR"
}
trap cleanup EXIT

# ============================================================
# Input definition
# ============================================================

BASE_INPUT_DIR="../03.deletrious/02.stat_deleterious"

GERP_CLASSES=("gt0" "gt2" "gt4" "gt6")

GERP_BED_BASE="/gpfs/hpc/home/kib_unit/lidezhu/liuliangmin/2.msa/Zmay/Zmay_v5_results/GERP_final_output"

IDX=$((SLURM_ARRAY_TASK_ID - 1))
GERP_CLASS="${GERP_CLASSES[$IDX]}"

GERP_BED_RAW="${GERP_BED_BASE}/merged_${GERP_CLASS}.bed"

INPUT_VCF="${BASE_INPUT_DIR}/merged_${GERP_CLASS}/merged_${GERP_CLASS}_snps.vcf.gz"

if [[ ! -f "$GERP_BED_RAW" || ! -f "$INPUT_VCF" ]]; then
    echo "ERROR: missing input"
    exit 1
fi

# ============================================================
# Output dir
# ============================================================

OUTPUT_DIR="$(pwd)/functional_analysis/merged_${GERP_CLASS}"
mkdir -p "$OUTPUT_DIR"

# ============================================================
# Functional BEDs
# ============================================================

FUNCTIONAL_BEDS=($(find . -maxdepth 1 -name "*.bed" | sort))

if [ ${#FUNCTIONAL_BEDS[@]} -eq 0 ]; then
    echo "ERROR: no functional BED found"
    exit 1
fi

# ============================================================
# Prepare GERP BED (remove header)
# ============================================================

GERP_BED="${WORK_TMP_DIR}/gerp_${GERP_CLASS}.bed"

awk 'NR>1 {print $1,$2,$3}' OFS="\t" "$GERP_BED_RAW" > "$GERP_BED"

# ============================================================
# Main loop
# ============================================================

for FUNC_BED in "${FUNCTIONAL_BEDS[@]}"; do
    FUNC_NAME=$(basename "$FUNC_BED" .bed)

    echo "==> ${GERP_CLASS} × ${FUNC_NAME}"

    OUT_VCF="${OUTPUT_DIR}/merged_${GERP_CLASS}_${FUNC_NAME}_overlap.vcf"
    OUT_SNP_BED="${OUTPUT_DIR}/merged_${GERP_CLASS}_${FUNC_NAME}_overlap.bed"
    OUT_FUNC_BED="${OUTPUT_DIR}/merged_${GERP_CLASS}_${FUNC_NAME}_func_regions.bed"

    # --------------------------------------------------------
    # 1. VCF ∩ GERP ∩ Functional
    # --------------------------------------------------------

    singularity exec ~/liuliangmin/4.may/software/Reseq_genek.sif \
      bcftools view -Ou "$INPUT_VCF" | \
      bedtools intersect -a stdin -b "$GERP_BED" | \
      bedtools intersect -a stdin -b "$FUNC_BED" -header \
      > "$OUT_VCF"

    if [ -s "$OUT_VCF" ]; then
        grep -vc '^#' "$OUT_VCF"
    else
        rm -f "$OUT_VCF"
    fi

    # --------------------------------------------------------
    # 2. SNP BED
    # --------------------------------------------------------

    singularity exec ~/liuliangmin/4.may/software/Reseq_genek.sif \
      bcftools view "$OUT_VCF" | \
      awk 'BEGIN{OFS="\t"} !/^#/ {print $1,$2-1,$2,$3}' \
      > "$OUT_SNP_BED"

    [ ! -s "$OUT_SNP_BED" ] && rm -f "$OUT_SNP_BED"

    # --------------------------------------------------------
    # 3. Functional regions hit by SNPs
    # --------------------------------------------------------

    bedtools intersect \
      -a "$FUNC_BED" \
      -b "$OUT_SNP_BED" \
      -wa > "$OUT_FUNC_BED"

    [ ! -s "$OUT_FUNC_BED" ] && rm -f "$OUT_FUNC_BED"

done

echo "ALL DONE: ${GERP_CLASS}"
