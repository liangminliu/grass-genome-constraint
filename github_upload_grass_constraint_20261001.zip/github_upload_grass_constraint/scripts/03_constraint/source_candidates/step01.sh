#!/bin/bash
#BSUB -J step01
#BSUB -q Q96C1T_X12
#BSUB -n 20
#BSUB -o logs/step01.%J.out
#BSUB -e logs/step01.%J.err

python3 scripts/01_summarize_SIFT.py \
  --input Ped=/ds3200_1/users_root/liuliangmin/workspace/PHD/5.deleterious/06_SIFT/SIFI_annotator/SIFT4G_results/ALL_annot/63sp.filtered.mainChr_SIFTannotations.xls \
  --input Zmay=/ds3200_1/users_root/liuliangmin/workspace/PHD/2.msa/Zmay/Zmay_v5_results/GERP_output/03.deletrious/04.SIFT/SIFT4G_results/all.filtered.bi-allelic.miss0.5.snp_SIFTannotations.xls \
  --input Atau=/ds3200_1/users_root/liuliangmin/workspace/PHD/2.msa/Atau_msa/pop/04_SIFT/SIFI_annotator/SIFT4G_results/141sp.filtered.bi-allelic.snp_SIFTannotations.xls \
  --outdir 01.variant_QC \
  > logs/01_recalculate_SIFT_complete.stdout.log \
  2> logs/01_recalculate_SIFT_complete.stderr.log




