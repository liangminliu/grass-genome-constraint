#!/bin/bash
#BSUB -J step7
#BSUB -q Q96C1T_X12
#BSUB -n 16
#BSUB -o step7.%J.out
#BSUB -e step7.%J.err

bedtools map \
    -sorted \
    -a CNS_GERP_analysis/01_CNS/CNS_all.sorted.bed \
    -b CNS_GERP_analysis/02_GERP/GERP_gt0.unique.bed \
    -c 5 \
    -o count,mean,median,min,max \
    -null NA \
    > CNS_GERP_analysis/03_overlap/CNS_RS_positive.map.tsv

    python3 CNS_GERP_analysis/04_compile_CNS_table_chr.py