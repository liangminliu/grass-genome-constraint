#!/bin/bash
#SBATCH --job-name=LD_calcu
#SBATCH --output=LD_calcu.%A_%a.out
#SBATCH --error=LD_calcu.%A_%a.err
#SBATCH --cpus-per-task=20
#SBATCH --partition=parallel

echo "Starting LD calculation with optimized memory usage..."

# 1. 分割Ped09X染色体并直接压缩
echo "Step 1: Splitting Ped09X chromosome..."

# 提取Ped09X的D亚基因组部分 (1-58257725)
singularity exec ~/liuliangmin/4.may/software/Reseq_genek.sif bcftools view -Oz -r Ped09X:1-58257725 71sp.filtered.bi-allelic.snp.rename.vcf.gz -o Ped09X_D_part.vcf.gz
singularity exec ~/liuliangmin/4.may/software/Reseq_genek.sif bcftools index Ped09X_D_part.vcf.gz

# 提取Ped09X的C亚基因组部分 (58257726-end)
singularity exec ~/liuliangmin/4.may/software/Reseq_genek.sif bcftools view -Oz -r Ped09X:58257726- 71sp.filtered.bi-allelic.snp.rename.vcf.gz -o Ped09X_C_part.vcf.gz  
singularity exec ~/liuliangmin/4.may/software/Reseq_genek.sif bcftools index Ped09X_C_part.vcf.gz

# 2. 创建包含完整D亚基因组的VCF文件
echo "Step 2: Creating complete D subgenome VCF..."

# 提取D亚基因组主要染色体
singularity exec ~/liuliangmin/4.may/software/Reseq_genek.sif bcftools view -Oz -r Ped01D,Ped02D,Ped03D,Ped04D,Ped05D,Ped06D,Ped07D,Ped08D,Ped10D,Ped11D,Ped12D 71sp.filtered.bi-allelic.snp.rename.vcf.gz -o D_subgenome_main.vcf.gz
singularity exec ~/liuliangmin/4.may/software/Reseq_genek.sif bcftools index D_subgenome_main.vcf.gz

# 合并D亚基因组文件
singularity exec ~/liuliangmin/4.may/software/Reseq_genek.sif bcftools concat -Oz D_subgenome_main.vcf.gz Ped09X_D_part.vcf.gz -o D_subgenome_complete.vcf.gz
singularity exec ~/liuliangmin/4.may/software/Reseq_genek.sif bcftools index D_subgenome_complete.vcf.gz

# 3. 创建包含完整C亚基因组的VCF文件
echo "Step 3: Creating complete C subgenome VCF..."

# 提取C亚基因组主要染色体
singularity exec ~/liuliangmin/4.may/software/Reseq_genek.sif bcftools view -Oz -r Ped01C,Ped02C,Ped03C,Ped04C,Ped05C,Ped06C,Ped07C,Ped08C,Ped09C,Ped10C,Ped11C,Ped12C 71sp.filtered.bi-allelic.snp.rename.vcf.gz -o C_subgenome_main.vcf.gz
singularity exec ~/liuliangmin/4.may/software/Reseq_genek.sif bcftools index C_subgenome_main.vcf.gz

# 合并C亚基因组文件
singularity exec ~/liuliangmin/4.may/software/Reseq_genek.sif bcftools concat -Oz C_subgenome_main.vcf.gz Ped09X_C_part.vcf.gz -o C_subgenome_complete.vcf.gz
singularity exec ~/liuliangmin/4.may/software/Reseq_genek.sif bcftools index C_subgenome_complete.vcf.gz

# 4. 清理中间文件以节省空间
echo "Step 4: Cleaning intermediate files..."
rm D_subgenome_main.vcf.gz* C_subgenome_main.vcf.gz* Ped09X_D_part.vcf.gz* Ped09X_C_part.vcf.gz*

# 5. 计算LD值
echo "Step 5: Calculating LD decay..."

# 完整C亚基因组 - ped群体
echo "  - C subgenome for ped population..."
singularity exec ~/liuliangmin/4.may/software/Reseq_genek.sif PopLDdecay \
    -InVCF C_subgenome_complete.vcf.gz \
    -SubPop ../data/pop.ped.table \
    -MaxDist 500 \
    -OutStat pop.ped.C_subgenome_complete.stat

# 完整D亚基因组 - ped群体  
echo "  - D subgenome for ped population..."
singularity exec ~/liuliangmin/4.may/software/Reseq_genek.sif PopLDdecay \
    -InVCF D_subgenome_complete.vcf.gz \
    -SubPop ../data/pop.ped.table \
    -MaxDist 500 \
    -OutStat pop.ped.D_subgenome_complete.stat

# 完整C亚基因组 - other群体
echo "  - C subgenome for other population..."
singularity exec ~/liuliangmin/4.may/software/Reseq_genek.sif PopLDdecay \
    -InVCF C_subgenome_complete.vcf.gz \
    -SubPop ../data/pop.other.table \
    -MaxDist 500 \
    -OutStat pop.other.C_subgenome_complete.stat

# 完整D亚基因组 - other群体
echo "  - D subgenome for other population..."
singularity exec ~/liuliangmin/4.may/software/Reseq_genek.sif PopLDdecay \
    -InVCF D_subgenome_complete.vcf.gz \
    -SubPop ../data/pop.other.table \
    -MaxDist 500 \
    -OutStat pop.other.D_subgenome_complete.stat

echo "LD calculation completed successfully!"

# 输出文件信息
echo "Generated files:"
ls -lh *.stat
ls -lh *subgenome_complete.vcf.gz*