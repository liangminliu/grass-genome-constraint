#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import argparse
import csv
import gzip
import math
import os
import re
import shlex
import statistics
import subprocess
from pathlib import Path

import pysam


VALID_BASES = {"A", "C", "G", "T"}


def open_text(path):
    path = str(path)
    if path.endswith(".gz"):
        return gzip.open(path, "rt")
    return open(path, "r")


def run_cmd(cmd):
    subprocess.run(cmd, shell=True, check=True, executable="/bin/bash")


def percentile(vals, p):
    if not vals:
        return "NA"
    vals = sorted(vals)
    if len(vals) == 1:
        return vals[0]
    k = (len(vals) - 1) * p
    f = math.floor(k)
    c = math.ceil(k)
    if f == c:
        return vals[int(k)]
    return vals[f] + (vals[c] - vals[f]) * (k - f)


def summarize_numeric(vals, prefix):
    vals = [x for x in vals if x is not None]
    if not vals:
        return {
            f"{prefix}_mean": "NA",
            f"{prefix}_median": "NA",
            f"{prefix}_p25": "NA",
            f"{prefix}_p75": "NA",
            f"{prefix}_min": "NA",
            f"{prefix}_max": "NA",
        }
    return {
        f"{prefix}_mean": statistics.mean(vals),
        f"{prefix}_median": statistics.median(vals),
        f"{prefix}_p25": percentile(vals, 0.25),
        f"{prefix}_p75": percentile(vals, 0.75),
        f"{prefix}_min": min(vals),
        f"{prefix}_max": max(vals),
    }


def write_single_row_tsv(path, row_dict):
    with open(path, "w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=list(row_dict.keys()), delimiter="\t")
        writer.writeheader()
        writer.writerow(row_dict)


def normalize_sample_id(sample_id, mode):
    if mode == "strip_last_cd":
        return re.sub(r"[CD]$", "", sample_id)
    return sample_id


def sort_bgzip_tabix(temp_plain, out_bgz):
    out_bgz = str(out_bgz)
    temp_plain = str(temp_plain)
    cmd = (
        f"LC_ALL=C sort -k1,1 -k2,2n {shlex.quote(temp_plain)} "
        f"| bgzip -c > {shlex.quote(out_bgz)} && "
        f"tabix -f -p bed {shlex.quote(out_bgz)}"
    )
    run_cmd(cmd)


def prepare_ancestral_bed(input_bed, out_bgz, aa_col=4):
    tmp = Path(str(out_bgz) + ".tmp")
    with open_text(input_bed) as fin, open(tmp, "w") as fout:
        for line in fin:
            if not line.strip() or line.startswith("#"):
                continue
            parts = line.rstrip("\n").split("\t")
            if len(parts) < aa_col:
                continue
            chrom, start, end = parts[0], parts[1], parts[2]
            aa = parts[aa_col - 1].upper()
            if aa not in VALID_BASES:
                continue
            fout.write(f"{chrom}\t{start}\t{end}\t{aa}\n")
    sort_bgzip_tabix(tmp, out_bgz)
    tmp.unlink(missing_ok=True)


def prepare_gerp_rs_bed(input_bed, out_bgz, rs_col=5):
    tmp = Path(str(out_bgz) + ".tmp")
    with open_text(input_bed) as fin, open(tmp, "w") as fout:
        for line in fin:
            if not line.strip() or line.startswith("#"):
                continue
            parts = line.rstrip("\n").split("\t")
            if len(parts) < rs_col:
                continue
            chrom, start, end = parts[0], parts[1], parts[2]
            try:
                rs = float(parts[rs_col - 1])
            except ValueError:
                continue
            fout.write(f"{chrom}\t{start}\t{end}\t{rs}\n")
    sort_bgzip_tabix(tmp, out_bgz)
    tmp.unlink(missing_ok=True)


def fetch_exact_aa(tabix_obj, chrom, pos0, pos1):
    aa_set = set()
    try:
        for line in tabix_obj.fetch(chrom, pos0, pos1):
            parts = line.rstrip("\n").split("\t")
            if len(parts) < 4:
                continue
            s = int(parts[1])
            e = int(parts[2])
            if s == pos0 and e == pos1:
                aa = parts[3].upper()
                if aa in VALID_BASES:
                    aa_set.add(aa)
    except ValueError:
        return None, "chrom_missing"

    if len(aa_set) == 1:
        return next(iter(aa_set)), "ok"
    if len(aa_set) == 0:
        return None, "no_aa"
    return None, "conflict"


def fetch_exact_rs(tabix_obj, chrom, pos0, pos1):
    rs_set = set()
    try:
        for line in tabix_obj.fetch(chrom, pos0, pos1):
            parts = line.rstrip("\n").split("\t")
            if len(parts) < 4:
                continue
            s = int(parts[1])
            e = int(parts[2])
            if s == pos0 and e == pos1:
                try:
                    rs = float(parts[3])
                    rs_set.add(rs)
                except ValueError:
                    continue
    except ValueError:
        return None, "chrom_missing"

    if len(rs_set) == 1:
        return next(iter(rs_set)), "ok"
    if len(rs_set) == 0:
        return None, "no_rs"
    return None, "conflict"


def is_biallelic_snp(rec):
    if rec.alts is None or len(rec.alts) != 1:
        return False
    ref = rec.ref.upper()
    alt = rec.alts[0].upper()
    if ref not in VALID_BASES or alt not in VALID_BASES:
        return False
    return len(ref) == 1 and len(alt) == 1


def init_sample_stats(sample_id):
    return {
        "sample_id": sample_id,
        "n_called_sites": 0,
        "called_alleles": 0,
        "derived_del_allele_count": 0,
        "full_derived_count": 0,
        "partial_derived_count": 0,
        "hom_del_count": 0,
        "het_del_count": 0,
        "additive_count_burden": 0.0,
        "derived_rs_dosage_sum": 0.0,
        "full_rs_burden": 0.0,
        "partial_rs_burden": 0.0,
        "hom_rs_burden": 0.0,
        "het_rs_burden": 0.0,
        "additive_rs_burden": 0.0,
    }


def finalize_sample_stats(d):
    if d["called_alleles"] > 0:
        d["derived_per_allele"] = d["derived_del_allele_count"] / d["called_alleles"]
    else:
        d["derived_per_allele"] = "NA"

    if d["n_called_sites"] > 0:
        d["additive_count_burden_per_site"] = d["additive_count_burden"] / d["n_called_sites"]
        d["additive_rs_burden_per_site"] = d["additive_rs_burden"] / d["n_called_sites"]
        d["full_rs_burden_per_site"] = d["full_rs_burden"] / d["n_called_sites"]
        d["partial_rs_burden_per_site"] = d["partial_rs_burden"] / d["n_called_sites"]
    else:
        d["additive_count_burden_per_site"] = "NA"
        d["additive_rs_burden_per_site"] = "NA"
        d["full_rs_burden_per_site"] = "NA"
        d["partial_rs_burden_per_site"] = "NA"

    denom = d["hom_del_count"] + d["het_del_count"]
    d["hom_ratio"] = (d["hom_del_count"] / denom) if denom > 0 else "NA"
    return d


def process_one_subgenome(label, vcf_path, ancestral_bgz, gerp_bgz, outdir):
    outdir = Path(outdir)

    site_out = outdir / f"{label}.site_load.tsv"
    ind_out = outdir / f"{label}.individual_load.tsv"
    sum_out = outdir / f"{label}.summary.tsv"

    vcf = pysam.VariantFile(vcf_path)
    anc = pysam.TabixFile(str(ancestral_bgz))
    gerp = pysam.TabixFile(str(gerp_bgz))

    samples = list(vcf.header.samples)
    sample_stats = {s: init_sample_stats(s) for s in samples}

    n_total_records = 0
    n_biallelic_snp = 0
    n_missing_aa_sites = 0
    n_unpolarized_sites = 0
    n_missing_rs_sites = 0
    n_final_scored_sites = 0

    L_add_count = 0.0
    L_add_rs = 0.0
    L_full_count = 0.0
    L_full_rs = 0.0
    L_q2_count = 0.0
    L_q2_rs = 0.0

    with open(site_out, "w", newline="") as fout_site:
        site_writer = csv.writer(fout_site, delimiter="\t")
        site_writer.writerow([
            "subgenome", "chrom", "pos", "ref", "alt", "aa", "gerp_rs",
            "n_called_samples", "total_called_alleles", "sum_derived_dosage",
            "q_derived",
            "n_full_derived", "f_full_derived",
            "site_additive_count_load", "site_additive_rs_load",
            "site_full_count_load", "site_full_rs_load",
            "site_q2_count_load", "site_q2_rs_load"
        ])

        for rec in vcf:
            n_total_records += 1

            if not is_biallelic_snp(rec):
                continue
            n_biallelic_snp += 1

            chrom = rec.chrom
            pos1 = rec.pos
            pos0 = pos1 - 1
            ref = rec.ref.upper()
            alt = rec.alts[0].upper()

            aa, aa_status = fetch_exact_aa(anc, chrom, pos0, pos1)
            if aa is None:
                n_missing_aa_sites += 1
                continue

            if aa not in {ref, alt}:
                n_unpolarized_sites += 1
                continue

            rs, rs_status = fetch_exact_rs(gerp, chrom, pos0, pos1)
            if rs is None:
                n_missing_rs_sites += 1
                continue

            site_called_samples = 0
            site_total_called_alleles = 0
            site_sum_dosage = 0
            site_n_full = 0

            for s in samples:
                gt = rec.samples[s].get("GT", None)
                if gt is None:
                    continue
                alleles = [a for a in gt if a is not None and a >= 0]
                if len(alleles) == 0:
                    continue

                ploidy = len(alleles)
                alt_count = sum(1 for a in alleles if a == 1)

                if aa == ref:
                    dosage = alt_count
                else:
                    dosage = ploidy - alt_count

                d = sample_stats[s]
                d["n_called_sites"] += 1
                d["called_alleles"] += ploidy
                d["derived_del_allele_count"] += dosage
                d["additive_count_burden"] += (dosage / ploidy)
                d["derived_rs_dosage_sum"] += (dosage * rs)
                d["additive_rs_burden"] += ((dosage / ploidy) * rs)

                if dosage == ploidy:
                    d["full_derived_count"] += 1
                    d["full_rs_burden"] += rs
                    site_n_full += 1
                    if ploidy == 2:
                        d["hom_del_count"] += 1
                        d["hom_rs_burden"] += rs

                elif 0 < dosage < ploidy:
                    d["partial_derived_count"] += 1
                    d["partial_rs_burden"] += rs
                    if ploidy == 2 and dosage == 1:
                        d["het_del_count"] += 1
                        d["het_rs_burden"] += rs

                site_called_samples += 1
                site_total_called_alleles += ploidy
                site_sum_dosage += dosage

            if site_called_samples == 0:
                continue

            n_final_scored_sites += 1

            q = site_sum_dosage / site_total_called_alleles
            f_full = site_n_full / site_called_samples
            q2 = q * q

            site_add_count = q
            site_add_rs = q * rs
            site_full_count = f_full
            site_full_rs = f_full * rs
            site_q2_count = q2
            site_q2_rs = q2 * rs

            L_add_count += site_add_count
            L_add_rs += site_add_rs
            L_full_count += site_full_count
            L_full_rs += site_full_rs
            L_q2_count += site_q2_count
            L_q2_rs += site_q2_rs

            site_writer.writerow([
                label, chrom, pos1, ref, alt, aa, rs,
                site_called_samples, site_total_called_alleles, site_sum_dosage,
                q, site_n_full, f_full,
                site_add_count, site_add_rs,
                site_full_count, site_full_rs,
                site_q2_count, site_q2_rs
            ])

    sample_rows = []
    for s in samples:
        row = finalize_sample_stats(sample_stats[s])
        row["subgenome"] = label
        sample_rows.append(row)

    ind_fields = [
        "sample_id", "subgenome",
        "n_called_sites", "called_alleles",
        "derived_del_allele_count",
        "full_derived_count", "partial_derived_count",
        "hom_del_count", "het_del_count",
        "additive_count_burden",
        "derived_rs_dosage_sum",
        "full_rs_burden", "partial_rs_burden",
        "hom_rs_burden", "het_rs_burden",
        "additive_rs_burden",
        "derived_per_allele",
        "additive_count_burden_per_site",
        "additive_rs_burden_per_site",
        "full_rs_burden_per_site",
        "partial_rs_burden_per_site",
        "hom_ratio",
    ]

    with open(ind_out, "w", newline="") as fout_ind:
        writer = csv.DictWriter(fout_ind, fieldnames=ind_fields, delimiter="\t")
        writer.writeheader()
        for row in sample_rows:
            writer.writerow({k: row.get(k, "NA") for k in ind_fields})

    summary = {
        "subgenome": label,
        "n_total_records": n_total_records,
        "n_biallelic_snp": n_biallelic_snp,
        "n_missing_aa_sites": n_missing_aa_sites,
        "n_unpolarized_sites": n_unpolarized_sites,
        "n_missing_rs_sites": n_missing_rs_sites,
        "n_final_scored_sites": n_final_scored_sites,
        "L_add_count": L_add_count,
        "L_add_rs": L_add_rs,
        "L_full_count": L_full_count,
        "L_full_rs": L_full_rs,
        "L_q2_count": L_q2_count,
        "L_q2_rs": L_q2_rs,
        "L_add_count_norm": (L_add_count / n_final_scored_sites) if n_final_scored_sites > 0 else "NA",
        "L_add_rs_norm": (L_add_rs / n_final_scored_sites) if n_final_scored_sites > 0 else "NA",
        "L_full_count_norm": (L_full_count / n_final_scored_sites) if n_final_scored_sites > 0 else "NA",
        "L_full_rs_norm": (L_full_rs / n_final_scored_sites) if n_final_scored_sites > 0 else "NA",
        "L_q2_rs_norm": (L_q2_rs / n_final_scored_sites) if n_final_scored_sites > 0 else "NA",
    }

    summary.update(summarize_numeric([x["additive_rs_burden"] for x in sample_rows], "ind_additive_rs_burden"))
    summary.update(summarize_numeric([x["full_rs_burden"] for x in sample_rows], "ind_full_rs_burden"))
    summary.update(summarize_numeric([x["partial_rs_burden"] for x in sample_rows], "ind_partial_rs_burden"))
    summary.update(summarize_numeric([x["hom_del_count"] for x in sample_rows], "ind_hom_del_count"))
    summary.update(summarize_numeric([x["het_del_count"] for x in sample_rows], "ind_het_del_count"))
    summary.update(summarize_numeric([x["derived_del_allele_count"] for x in sample_rows], "ind_derived_del_allele_count"))

    write_single_row_tsv(sum_out, summary)

    return {
        "summary": summary,
        "samples": sample_rows,
        "site_out": str(site_out),
        "ind_out": str(ind_out),
        "sum_out": str(sum_out),
    }


def merge_whole_ped(res_c, res_d, outdir, merge_mode="exact"):
    outdir = Path(outdir)
    merged_ind_out = outdir / "ped.merged_individual_load.tsv"
    total_sum_out = outdir / "ped.total_summary.tsv"

    fields_to_sum = [
        "n_called_sites", "called_alleles",
        "derived_del_allele_count",
        "full_derived_count", "partial_derived_count",
        "hom_del_count", "het_del_count",
        "additive_count_burden",
        "derived_rs_dosage_sum",
        "full_rs_burden", "partial_rs_burden",
        "hom_rs_burden", "het_rs_burden",
        "additive_rs_burden",
    ]

    c_map = {normalize_sample_id(x["sample_id"], merge_mode): x for x in res_c["samples"]}
    d_map = {normalize_sample_id(x["sample_id"], merge_mode): x for x in res_d["samples"]}

    all_keys = sorted(set(c_map.keys()) | set(d_map.keys()))
    merged_rows = []

    for key in all_keys:
        c = c_map.get(key)
        d = d_map.get(key)

        row = {
            "merged_sample_id": key,
            "sample_id_C": c["sample_id"] if c else "NA",
            "sample_id_D": d["sample_id"] if d else "NA",
        }

        for f in fields_to_sum:
            c_val = c[f] if c else 0
            d_val = d[f] if d else 0
            row[f"{f}_C"] = c_val
            row[f"{f}_D"] = d_val
            row[f"{f}_total"] = c_val + d_val

        if row["called_alleles_total"] > 0:
            row["derived_per_allele_total"] = row["derived_del_allele_count_total"] / row["called_alleles_total"]
        else:
            row["derived_per_allele_total"] = "NA"

        if row["n_called_sites_total"] > 0:
            row["additive_count_burden_per_site_total"] = row["additive_count_burden_total"] / row["n_called_sites_total"]
            row["additive_rs_burden_per_site_total"] = row["additive_rs_burden_total"] / row["n_called_sites_total"]
            row["full_rs_burden_per_site_total"] = row["full_rs_burden_total"] / row["n_called_sites_total"]
            row["partial_rs_burden_per_site_total"] = row["partial_rs_burden_total"] / row["n_called_sites_total"]
        else:
            row["additive_count_burden_per_site_total"] = "NA"
            row["additive_rs_burden_per_site_total"] = "NA"
            row["full_rs_burden_per_site_total"] = "NA"
            row["partial_rs_burden_per_site_total"] = "NA"

        denom = row["hom_del_count_total"] + row["het_del_count_total"]
        row["hom_ratio_total"] = (row["hom_del_count_total"] / denom) if denom > 0 else "NA"

        merged_rows.append(row)

    merged_fields = [
        "merged_sample_id", "sample_id_C", "sample_id_D"
    ]
    for f in fields_to_sum:
        merged_fields.extend([f"{f}_C", f"{f}_D", f"{f}_total"])
    merged_fields.extend([
        "derived_per_allele_total",
        "additive_count_burden_per_site_total",
        "additive_rs_burden_per_site_total",
        "full_rs_burden_per_site_total",
        "partial_rs_burden_per_site_total",
        "hom_ratio_total",
    ])

    with open(merged_ind_out, "w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=merged_fields, delimiter="\t")
        writer.writeheader()
        for row in merged_rows:
            writer.writerow(row)

    csum = res_c["summary"]
    dsum = res_d["summary"]

    total_sites = csum["n_final_scored_sites"] + dsum["n_final_scored_sites"]
    total_summary = {
        "species": "ped",
        "merge_mode": merge_mode,
        "n_final_scored_sites_total": total_sites,
        "L_add_count_total": csum["L_add_count"] + dsum["L_add_count"],
        "L_add_rs_total": csum["L_add_rs"] + dsum["L_add_rs"],
        "L_full_count_total": csum["L_full_count"] + dsum["L_full_count"],
        "L_full_rs_total": csum["L_full_rs"] + dsum["L_full_rs"],
        "L_q2_count_total": csum["L_q2_count"] + dsum["L_q2_count"],
        "L_q2_rs_total": csum["L_q2_rs"] + dsum["L_q2_rs"],
    }

    if total_sites > 0:
        total_summary["L_add_count_norm"] = total_summary["L_add_count_total"] / total_sites
        total_summary["L_add_rs_norm"] = total_summary["L_add_rs_total"] / total_sites
        total_summary["L_full_count_norm"] = total_summary["L_full_count_total"] / total_sites
        total_summary["L_full_rs_norm"] = total_summary["L_full_rs_total"] / total_sites
        total_summary["L_q2_rs_norm"] = total_summary["L_q2_rs_total"] / total_sites
    else:
        total_summary["L_add_count_norm"] = "NA"
        total_summary["L_add_rs_norm"] = "NA"
        total_summary["L_full_count_norm"] = "NA"
        total_summary["L_full_rs_norm"] = "NA"
        total_summary["L_q2_rs_norm"] = "NA"

    total_summary.update(
        summarize_numeric([x["additive_rs_burden_total"] for x in merged_rows], "merged_additive_rs_burden")
    )
    total_summary.update(
        summarize_numeric([x["full_rs_burden_total"] for x in merged_rows], "merged_full_rs_burden")
    )
    total_summary.update(
        summarize_numeric([x["partial_rs_burden_total"] for x in merged_rows], "merged_partial_rs_burden")
    )
    total_summary.update(
        summarize_numeric([x["hom_del_count_total"] for x in merged_rows], "merged_hom_del_count")
    )
    total_summary.update(
        summarize_numeric([x["het_del_count_total"] for x in merged_rows], "merged_het_del_count")
    )
    total_summary.update(
        summarize_numeric([x["derived_del_allele_count_total"] for x in merged_rows], "merged_derived_del_allele_count")
    )

    write_single_row_tsv(total_sum_out, total_summary)
    return str(merged_ind_out), str(total_sum_out)


def main():
    ap = argparse.ArgumentParser(
        description="Integrated pipeline for ped GERP>4 burden calculation"
    )
    ap.add_argument("--ancestral", required=True, help="all.ancestral.bed or .bed.gz (AA in column 4 by default)")
    ap.add_argument("--pedc-vcf", required=True, help="pedC_gt4_snps.vcf.gz")
    ap.add_argument("--pedc-gerp", required=True, help="pedC_gt4_gerp_regions.bed")
    ap.add_argument("--pedd-vcf", required=True, help="pedD_gt4_snps.vcf.gz")
    ap.add_argument("--pedd-gerp", required=True, help="pedD_gt4_gerp_regions.bed")
    ap.add_argument("--outdir", required=True, help="output directory")
    ap.add_argument("--ancestral-aa-col", type=int, default=4, help="AA column in ancestral bed (1-based), default=4")
    ap.add_argument("--gerp-rs-col", type=int, default=5, help="GERP RS column in ped*_gt4_gerp_regions.bed (1-based), default=5")
    ap.add_argument(
        "--merge-samples-mode",
        choices=["exact", "strip_last_cd"],
        default="exact",
        help="how to merge pedC/pedD sample IDs into whole-ped individuals"
    )
    args = ap.parse_args()

    outdir = Path(args.outdir)
    prepdir = outdir / "prep"
    outdir.mkdir(parents=True, exist_ok=True)
    prepdir.mkdir(parents=True, exist_ok=True)

    ancestral_bgz = prepdir / "all.ancestral.AA.bed.gz"
    pedc_gerp_bgz = prepdir / "pedC.gerpRS.bed.gz"
    pedd_gerp_bgz = prepdir / "pedD.gerpRS.bed.gz"

    print("[INFO] preparing ancestral AA bed ...")
    prepare_ancestral_bed(args.ancestral, ancestral_bgz, aa_col=args.ancestral_aa_col)

    print("[INFO] preparing pedC GERP RS bed ...")
    prepare_gerp_rs_bed(args.pedc_gerp, pedc_gerp_bgz, rs_col=args.gerp_rs_col)

    print("[INFO] preparing pedD GERP RS bed ...")
    prepare_gerp_rs_bed(args.pedd_gerp, pedd_gerp_bgz, rs_col=args.gerp_rs_col)

    print("[INFO] processing pedC ...")
    res_c = process_one_subgenome("pedC", args.pedc_vcf, ancestral_bgz, pedc_gerp_bgz, outdir)

    print("[INFO] processing pedD ...")
    res_d = process_one_subgenome("pedD", args.pedd_vcf, ancestral_bgz, pedd_gerp_bgz, outdir)

    print("[INFO] merging whole-ped results ...")
    merged_ind, total_sum = merge_whole_ped(
        res_c, res_d, outdir, merge_mode=args.merge_samples_mode
    )

    print("[INFO] done")
    print(f"[INFO] pedC individual : {res_c['ind_out']}")
    print(f"[INFO] pedD individual : {res_d['ind_out']}")
    print(f"[INFO] whole ped individual : {merged_ind}")
    print(f"[INFO] whole ped summary : {total_sum}")


if __name__ == "__main__":
    main()