#!/usr/bin/env bash
#BSUB -J step12
#BSUB -q Q96C1T_X12
#BSUB -n 16
#BSUB -o step17.%J.out
#BSUB -e step17.%J.err
set -euo pipefail

# ============================================================
# INPUT
# ============================================================

WUSBED="08_WUS/WUS1_WUS2.genes.bed"

CNS_TSV="04_tables/CNS_level_GERP_summary_chr.tsv"

BGDIR="07_final_stats/background"

GENOME="${BGDIR}/Zmay_v5.genome"

CHRORDER="${BGDIR}/Zmay_v5.chr.order"

OUTDIR="08_WUS/tracks"

mkdir -p "${OUTDIR}"

# ============================================================
# QC
# ============================================================

for f in \
    "${WUSBED}" \
    "${CNS_TSV}" \
    "${GENOME}" \
    "${CHRORDER}" \
    "${BGDIR}/GERPgt0.sorted.merged.bed" \
    "${BGDIR}/GERPgt2.sorted.merged.bed" \
    "${BGDIR}/GERPgt4.sorted.merged.bed" \
    "${BGDIR}/GERPgt6.sorted.merged.bed"
do
    if [[ ! -s "${f}" ]]; then
        echo "[ERROR] Missing or empty file: ${f}" >&2
        exit 1
    fi
done

# WUS BED should contain exactly two genes
NWUS=$(wc -l < "${WUSBED}")

if [[ "${NWUS}" -ne 2 ]]; then
    echo "[ERROR] Expected 2 WUS genes, observed ${NWUS}" >&2
    cat "${WUSBED}" >&2
    exit 1
fi

# ============================================================
# 1. Generate ±100-kb windows
# ============================================================

bedtools slop \
    -i "${WUSBED}" \
    -g "${GENOME}" \
    -b 100000 \
> "${OUTDIR}/WUS1_WUS2.plusminus100kb.bed"

echo
echo "===== WUS ±100kb ====="

cat "${OUTDIR}/WUS1_WUS2.plusminus100kb.bed"

# ============================================================
# 2. Split WUS1 and WUS2 windows
# ============================================================

awk 'BEGIN{FS=OFS="\t"}
     $4 ~ /^ZmWUS1\|/ {
         print
     }' \
"${OUTDIR}/WUS1_WUS2.plusminus100kb.bed" \
> "${OUTDIR}/ZmWUS1.plusminus100kb.bed"

awk 'BEGIN{FS=OFS="\t"}
     $4 ~ /^ZmWUS2\|/ {
         print
     }' \
"${OUTDIR}/WUS1_WUS2.plusminus100kb.bed" \
> "${OUTDIR}/ZmWUS2.plusminus100kb.bed"

# QC
for W in ZmWUS1 ZmWUS2
do
    if [[ ! -s "${OUTDIR}/${W}.plusminus100kb.bed" ]]; then
        echo "[ERROR] Failed to create ${W} window" >&2
        exit 1
    fi
done

# ============================================================
# 3. Convert CNS table to STRICT BED4
#
# CNS input columns:
#
# 1  chr
# 2  start0
# 3  end
# 4  cns_id
# 5  CNS_name
#
# Only these are needed for bedtools locus operations.
# ============================================================

awk 'BEGIN{FS=OFS="\t"}

     # read chromosome whitelist/order first
     NR==FNR {
         keep[$1]=1
         next
     }

     # skip CNS header
     FNR==1 {
         next
     }

     # retain canonical chromosomes and valid coordinates
     ($1 in keep) &&
     $2 ~ /^[0-9]+$/ &&
     $3 ~ /^[0-9]+$/ &&
     $3 > $2 {

         name=$5

         if(name=="" || name=="NA")
             name=$4

         # BED name field should contain no whitespace
         gsub(/[[:space:]]+/,"_",name)

         print $1,$2,$3,name
     }' \
"${CHRORDER}" \
"${CNS_TSV}" \
> "${OUTDIR}/all_CNS.raw.bed"

# ============================================================
# 4. BED4 QC
# ============================================================

echo
echo "===== CNS BED QC ====="

echo -n "Number CNS: "
wc -l < "${OUTDIR}/all_CNS.raw.bed"

BAD=$(
    awk -F'\t' '
        NF!=4 {
            n++
        }
        END {
            print n+0
        }' \
    "${OUTDIR}/all_CNS.raw.bed"
)

echo "Malformed BED lines: ${BAD}"

if [[ "${BAD}" -ne 0 ]]; then

    echo "[ERROR] BED field-count problem remains:" >&2

    awk -F'\t' '
        NF!=4 {
            print NR,NF,$0
        }' \
    "${OUTDIR}/all_CNS.raw.bed" \
    | head -20 >&2

    exit 1
fi

# ============================================================
# 5. Sort CNS according to maize chromosome order
#
# bedtools v2.25 uses -faidx rather than -g for sort
# ============================================================

bedtools sort \
    -faidx "${CHRORDER}" \
    -i "${OUTDIR}/all_CNS.raw.bed" \
> "${OUTDIR}/all_CNS.sorted.bed"

echo "[OK] CNS BED sorted."

# ============================================================
# 6. Extract all physical CNS in ±100 kb
# ============================================================

for W in ZmWUS1 ZmWUS2
do

    REGION="${OUTDIR}/${W}.plusminus100kb.bed"

    bedtools intersect \
        -a "${OUTDIR}/all_CNS.sorted.bed" \
        -b "${REGION}" \
        -wa \
    | sort -u \
    > "${OUTDIR}/${W}.plusminus100kb.all_CNS.bed"

    echo -n "[INFO] ${W} nearby CNS = "
    wc -l < "${OUTDIR}/${W}.plusminus100kb.all_CNS.bed"

done

# ============================================================
# 7. Normalize Conservatory-associated CNS to BED4
#
# These are the biologically relevant CNSs for formal WUS
# analysis. ±100 kb CNSs are only physical locus context.
# ============================================================

for W in ZmWUS1 ZmWUS2
do

    SRC="08_WUS/${W}.associated_CNS.bed"
    DST="${OUTDIR}/${W}.associated_CNS.bed"

    if [[ -s "${SRC}" ]]; then

        awk 'BEGIN{FS=OFS="\t"}
             NF>=4 {
                 print $1,$2,$3,$4
             }' \
        "${SRC}" \
        > "${DST}"

        echo -n "[INFO] ${W} associated CNS = "
        wc -l < "${DST}"

    else

        echo "[WARNING] Missing ${SRC}" >&2
        : > "${DST}"

    fi

done

# ============================================================
# 8. Extract GERP tracks within each ±100-kb region
#
# Use default bedtools intersect so GERP intervals are clipped
# to the WUS window.
# ============================================================

for W in ZmWUS1 ZmWUS2
do

    REGION="${OUTDIR}/${W}.plusminus100kb.bed"

    for t in 0 2 4 6
    do

        G="${BGDIR}/GERPgt${t}.sorted.merged.bed"

        bedtools intersect \
            -a "${G}" \
            -b "${REGION}" \
        > "${OUTDIR}/${W}.plusminus100kb.GERPgt${t}.bed"

    done

done

# ============================================================
# 9. Calculate number and bp of GERP intervals in locus
# ============================================================

echo
echo "===== GERP locus coverage ====="

printf \
"WUS\tthreshold\twindow_bp\tGERP_bp\tGERP_fraction\n"

for W in ZmWUS1 ZmWUS2
do

    REGION="${OUTDIR}/${W}.plusminus100kb.bed"

    WINDOW_BP=$(
        awk '{
            s += $3-$2
        }
        END {
            print s+0
        }' \
        "${REGION}"
    )

    for t in 0 2 4 6
    do

        F="${OUTDIR}/${W}.plusminus100kb.GERPgt${t}.bed"

        GERP_BP=$(
            awk '{
                s += $3-$2
            }
            END {
                print s+0
            }' \
            "${F}"
        )

        FRAC=$(
            awk \
            -v G="${GERP_BP}" \
            -v L="${WINDOW_BP}" \
            'BEGIN {
                if(L>0)
                    printf "%.6f",G/L
                else
                    print "NA"
            }'
        )

        printf \
        "%s\tGERP>%s\t%s\t%s\t%s\n" \
        "${W}" \
        "${t}" \
        "${WINDOW_BP}" \
        "${GERP_BP}" \
        "${FRAC}"

    done

done

# ============================================================
# 10. Generate WUS gene BED4 for plotting
# ============================================================

awk 'BEGIN{FS=OFS="\t"}
     {
         print $1,$2,$3,$4
     }' \
"${WUSBED}" \
> "${OUTDIR}/WUS1_WUS2.genes.bed"

# ============================================================
# 11. Final list
# ============================================================

echo
echo "============================================================"
echo "WUS locus-track files"
echo "============================================================"

find "${OUTDIR}" \
    -maxdepth 1 \
    -type f \
    | sort

echo
echo "[DONE] WUS locus tracks generated successfully."

