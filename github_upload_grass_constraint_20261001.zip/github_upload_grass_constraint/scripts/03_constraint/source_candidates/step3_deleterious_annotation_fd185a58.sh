#!/bin/bash
#SBATCH --job-name=functional_intersect
#SBATCH --output=logs/functional_intersect_%A_%a.log
#SBATCH --error=logs/functional_intersect_%A_%a.err
#SBATCH --cpus-per-task=8
#SBATCH --array=1-8%8

set -euo pipefail

############################################################
# 0. 基本准备
############################################################
mkdir -p logs

WORK_TMP_DIR="$(pwd)/singularity_tmp_$$"
export SINGULARITY_TMPDIR="$WORK_TMP_DIR"
export TMPDIR="$WORK_TMP_DIR"
mkdir -p "$SINGULARITY_TMPDIR"

cleanup() {
    rm -rf "$SINGULARITY_TMPDIR"
}
trap cleanup EXIT

df -h "$(pwd)"

############################################################
# 1. GERP × Subgenome 组合
############################################################
GERP_DIRS=("gerp_gt0" "gerp_gt2" "gerp_gt4" "gerp_gt6")
SUBGENOMES=("pedC" "pedD")

TOTAL_GERP=${#GERP_DIRS[@]}
TOTAL_SUB=${#SUBGENOMES[@]}

GERP_INDEX=$(( (SLURM_ARRAY_TASK_ID - 1) / TOTAL_SUB ))
SUB_INDEX=$(( (SLURM_ARRAY_TASK_ID - 1) % TOTAL_SUB ))

CURRENT_GERP_DIR=${GERP_DIRS[$GERP_INDEX]}
CURRENT_SUBGENOME=${SUBGENOMES[$SUB_INDEX]}

# ✅ 关键修复：去掉 gerp_ 前缀
GERP_TAG=${CURRENT_GERP_DIR#gerp_}

echo "GERP dir  : $CURRENT_GERP_DIR"
echo "GERP tag  : $GERP_TAG"
echo "Subgenome : $CURRENT_SUBGENOME"

############################################################
# 2. 输入 VCF（已完全对齐真实文件名）
############################################################
INPUT_VCF="${CURRENT_GERP_DIR}/${CURRENT_SUBGENOME}_${GERP_TAG}_snps.vcf.gz"

if [ ! -s "$INPUT_VCF" ]; then
    echo "ERROR: input VCF not found: $INPUT_VCF"
    echo "Available files in $CURRENT_GERP_DIR:"
    ls "$CURRENT_GERP_DIR" | head -20
    exit 1
fi

############################################################
# 3. 功能区域 BED
############################################################
FUNCTIONAL_DIR_LINK="./2.1.constrained_category"
FUNCTIONAL_DIR=$(readlink -f "$FUNCTIONAL_DIR_LINK")

if [ ! -d "$FUNCTIONAL_DIR" ]; then
    echo "ERROR: functional dir missing"
    exit 1
fi

FUNCTIONAL_BEDS=($(find "$FUNCTIONAL_DIR" -name "*.bed" | sort))
[ ${#FUNCTIONAL_BEDS[@]} -gt 0 ] || { echo "No functional BEDs"; exit 1; }

############################################################
# 4. 输出目录
############################################################
OUTPUT_DIR="${CURRENT_GERP_DIR}/functional_analysis"
mkdir -p "$OUTPUT_DIR"

############################################################
# 5. 主循环（完全保持原逻辑）
############################################################
for FUNC_BED in "${FUNCTIONAL_BEDS[@]}"; do
    FUNC_NAME=$(basename "$FUNC_BED" .bed)

    OUTPUT_VCF="${OUTPUT_DIR}/${CURRENT_SUBGENOME}_${GERP_TAG}_${FUNC_NAME}_overlap.vcf"
    OUTPUT_BED="${OUTPUT_DIR}/${CURRENT_SUBGENOME}_${GERP_TAG}_${FUNC_NAME}_overlap.bed"
    OUTPUT_FUNC="${OUTPUT_DIR}/${CURRENT_SUBGENOME}_${GERP_TAG}_${FUNC_NAME}_func_regions.bed"

    # 1. SNP ∩ 功能区（VCF）
    singularity exec ~/liuliangmin/4.may/software/Reseq_genek.sif \
    bcftools view "$INPUT_VCF" | \
    bedtools intersect -a stdin -b "$FUNC_BED" -header > "$OUTPUT_VCF" || true
    [ -s "$OUTPUT_VCF" ] || rm -f "$OUTPUT_VCF"

    # 2. SNP ∩ 功能区（BED）
    singularity exec ~/liuliangmin/4.may/software/Reseq_genek.sif \
    bcftools view "$INPUT_VCF" | \
    bedtools intersect -a stdin -b "$FUNC_BED" | \
    awk 'BEGIN{OFS="\t"} !/^#/ {print $1,$2-1,$2,$3}' > "$OUTPUT_BED" || true
    [ -s "$OUTPUT_BED" ] || rm -f "$OUTPUT_BED"

    # 3. 功能区 ∩ SNP（保留功能区）
    bedtools intersect \
      -a "$FUNC_BED" \
      -b <(
          singularity exec ~/liuliangmin/4.may/software/Reseq_genek.sif \
          bcftools view "$INPUT_VCF" | \
          awk 'BEGIN{OFS="\t"} !/^#/ {print $1,$2-1,$2}'
      ) \
      -wa > "$OUTPUT_FUNC" || true
    [ -s "$OUTPUT_FUNC" ] || rm -f "$OUTPUT_FUNC"
done

############################################################
# 6. 汇总（保持原样）
############################################################
SUMMARY_FILE="${OUTPUT_DIR}/${CURRENT_SUBGENOME}_${GERP_TAG}_summary.txt"
echo "GERP dir  : $CURRENT_GERP_DIR" > "$SUMMARY_FILE"
echo "GERP tag  : $GERP_TAG" >> "$SUMMARY_FILE"
echo "Subgenome : $CURRENT_SUBGENOME" >> "$SUMMARY_FILE"
echo "Input VCF : $INPUT_VCF" >> "$SUMMARY_FILE"
echo "Time      : $(date)" >> "$SUMMARY_FILE"
