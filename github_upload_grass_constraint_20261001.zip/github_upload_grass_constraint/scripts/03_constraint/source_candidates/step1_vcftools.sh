#!/bin/bash
#SBATCH --job-name=KING_DIRECT_VCF
#SBATCH --output=king_direct.%j.out
#SBATCH --error=king_direct.%j.err
#SBATCH --cpus-per-task=40
#SBATCH -p parallel

SOURCE_VCF="./all_chr.filter.vcf.gz"
CONTAINER=~/liuliangmin/4.may/software/Reseq_genek.sif

echo "===== 使用vcftools处理VCF文件 ====="
echo "开始时间: $(date)"

# ===== 1. 使用vcftools提取样品（忽略header问题）=====
echo "===== 正在使用vcftools提取样品 ====="
singularity exec $CONTAINER vcftools --gzvcf $SOURCE_VCF \
    --keep keep_maize_429.list \
    --recode --recode-INFO-all \
    --stdout | bgzip > extracted_429sp_maize.vcf.gz

# 检查文件是否生成
if [ ! -f "extracted_429sp_maize.vcf.gz" ] || [ ! -s "extracted_429sp_maize.vcf.gz" ]; then
    echo "错误: vcftools提取失败"
    exit 1
fi

# 索引文件
echo "===== 索引VCF文件 ====="
singularity exec $CONTAINER bcftools index extracted_429sp_maize.vcf.gz

# ===== 2. 转换为PLINK格式 =====
echo "===== 转换为PLINK格式 ====="
singularity exec $CONTAINER plink --vcf extracted_429sp_maize.vcf.gz \
    --allow-extra-chr \
    --chr-set 10 \
    --double-id \
    --make-bed \
    --out king_direct \
    --threads 20

echo "===== 运行KING分析 ====="
./king -b king_direct.bed --unrelated --degree 1 --prefix maize_unrelatedD1 --cpus 10 --sexchr 11 &
./king -b king_direct.bed -prefix maize_king_directD1 --build --degree 1 --rplot --sexchr 11 &
   # plink --bfile king_direct --keep unrelatedD1unrelated.txt --make-bed --out king_direct_unrelated --allow-extra-chr



#./king -b king_direct.bed  --fam fixed.fam --prefix king_directD1 --build --degree 1 --rplot --sexchr 25  ##报错
#./king -b king_direct.bed  --fam fixed.fam --duplicate --rplot --sexchr 25

./king -b king_direct.bed --unrelated --degree 2 --prefix maize_unrelatedD2 --cpus 10 --sexchr 11  &
./king -b king_direct.bed --related --degree 2 --prefix maize_relatedD2 --cpus 10 --sexchr 11  &
wait
echo "===== 处理完成 ====="