#!/bin/bash
#BSUB -J step9-11
#BSUB -q Q96C1T_X12
#BSUB -n 16
#BSUB -o step9-11.%J.out
#BSUB -e step9-11.%J.err

set -euo pipefail

echo "============================================================"
echo " CNS × GERP analysis: Step 9–11"
echo " TB1 extraction + P1-P12 + genome-wide concordance"
echo "============================================================"

BASE="CNS_GERP_analysis"

CNS_TABLE="${BASE}/04_tables/CNS_level_GERP_summary_chr.tsv"
GENE_TABLE="${BASE}/04_tables/gene_level_CNS_GERP_summary_chr.tsv"

TB1DIR="${BASE}/05_TB1"
QCDIR="${BASE}/06_QC"
TABLEDIR="${BASE}/04_tables"

mkdir -p "${TB1DIR}" "${QCDIR}" "${TABLEDIR}"

# ------------------------------------------------------------
# Input checks
# ------------------------------------------------------------

for f in "${CNS_TABLE}" "${GENE_TABLE}"
do
    if [[ ! -s "${f}" ]]
    then
        echo "[ERROR] Missing input: ${f}" >&2
        exit 1
    fi
done

echo "[INFO] Inputs found:"
echo "       ${CNS_TABLE}"
echo "       ${GENE_TABLE}"

# ------------------------------------------------------------
# Main Python analysis
# ------------------------------------------------------------

python3 - <<'PY'
import os
import sys
import math
import pandas as pd

try:
    from scipy.stats import spearmanr
except ImportError:
    sys.exit(
        "[ERROR] scipy is required for Spearman correlation.\n"
        "Please load/install scipy before running Step 9–11."
    )

BASE = "CNS_GERP_analysis"

CNS_FILE = f"{BASE}/04_tables/CNS_level_GERP_summary_chr.tsv"
GENE_FILE = f"{BASE}/04_tables/gene_level_CNS_GERP_summary_chr.tsv"

TB1DIR = f"{BASE}/05_TB1"
QCDIR = f"{BASE}/06_QC"
TABLEDIR = f"{BASE}/04_tables"

os.makedirs(TB1DIR, exist_ok=True)
os.makedirs(QCDIR, exist_ok=True)
os.makedirs(TABLEDIR, exist_ok=True)

TB1 = "Zm00001eb054440"

# ============================================================
# STEP 9.0
# Read final Step-8 tables
# ============================================================

cns = pd.read_csv(CNS_FILE, sep="\t")
gene = pd.read_csv(GENE_FILE, sep="\t")

print("\n[STEP 9] Input summary")
print("CNS rows :", len(cns))
print("Gene rows:", len(gene))

required_cns = [
    "chr",
    "start0",
    "end",
    "cns_id",
    "CNS_name",
    "species_count",
    "node",
    "level",
    "associated_loci",
    "length_bp",
    "GERPgt0_bp",
    "GERPgt0_fraction",
    "GERPgt2_bp",
    "GERPgt2_fraction",
    "GERPgt4_bp",
    "GERPgt4_fraction",
    "GERPgt6_bp",
    "GERPgt6_fraction",
]

missing = [x for x in required_cns if x not in cns.columns]

if missing:
    raise RuntimeError(
        "Missing required CNS columns: " + ", ".join(missing)
    )

if "gene_id" not in gene.columns:
    raise RuntimeError(
        "gene_level_CNS_GERP_summary_chr.tsv lacks gene_id column"
    )

# ============================================================
# STEP 9.1
# TB1 gene-level summary
# ============================================================

tb1_gene = gene[
    gene["gene_id"].astype(str) == TB1
].copy()

if len(tb1_gene) != 1:
    print(
        f"[WARNING] Expected exactly one TB1 gene row, found {len(tb1_gene)}"
    )

tb1_gene.to_csv(
    f"{TB1DIR}/TB1_gene_CNS_GERP_summary.tsv",
    sep="\t",
    index=False
)

print("\n[STEP 9.1] TB1 gene summary")
if len(tb1_gene):
    print(tb1_gene.to_string(index=False))

# ============================================================
# Helper:
# associated_loci may contain multiple genes separated by |
# ============================================================

def gene_is_associated(value, target):
    if pd.isna(value):
        return False

    genes = [
        x.strip()
        for x in str(value).split("|")
        if x.strip()
    ]

    return target in genes

# ============================================================
# STEP 9.2
# Extract all TB1-associated CNSs
# ============================================================

mask_tb1 = cns["associated_loci"].apply(
    lambda x: gene_is_associated(x, TB1)
)

tb1 = cns[mask_tb1].copy()

tb1 = tb1.sort_values(
    ["chr", "start0", "end", "CNS_name"]
).reset_index(drop=True)

tb1.to_csv(
    f"{TB1DIR}/TB1_all_CNS_GERP.tsv",
    sep="\t",
    index=False
)

print("\n[STEP 9.2] TB1-associated CNS")
print("N =", len(tb1))

# ============================================================
# STEP 9.3
# Define published P1-P12
# Based on Conservatory IDs from Table S8
# ============================================================

P_LABELS = {
    "Poaceae_328925": "P1",
    "Poaceae_177392": "P2",
    "Poaceae_103351": "P3",
    "Poaceae_314218": "P4",
    "Poaceae_54698":  "P5",
    "Poaceae_105458": "P6",
    "Poaceae_160109": "P7",
    "Poaceae_283562": "P8",
    "Poaceae_105936": "P9",
    "Poaceae_211702": "P10",
    "Poaceae_351091": "P11",
    "Poaceae_285155": "P12",
}

p12 = tb1[
    tb1["CNS_name"].isin(P_LABELS)
].copy()

p12["P_element"] = p12["CNS_name"].map(P_LABELS)

p12["_P_order"] = (
    p12["P_element"]
    .str.replace("P", "", regex=False)
    .astype(int)
)

p12["TB1_cluster"] = p12["_P_order"].apply(
    lambda x:
    "P1-P6_distal"
    if x <= 6
    else "P7-P12_proximal"
)

p12 = p12.sort_values("_P_order").drop(
    columns="_P_order"
)

# Put P label near front
front = [
    "P_element",
    "TB1_cluster",
    "CNS_name",
    "chr",
    "start0",
    "end",
    "length_bp",
    "species_count",
    "node",
    "level",
    "associated_loci"
]

others = [
    x for x in p12.columns
    if x not in front
]

p12 = p12[front + others]

p12.to_csv(
    f"{TB1DIR}/TB1_P1_P12_GERP.tsv",
    sep="\t",
    index=False
)

print("\n[STEP 9.3] Published TB1 P1-P12")
print("N =", len(p12))

if len(p12) != 12:
    print(
        "[WARNING] Expected 12 P-elements but found",
        len(p12)
    )

found = set(p12["CNS_name"])
missing_p = [
    f"{p}:{cid}"
    for cid, p in P_LABELS.items()
    if cid not in found
]

if missing_p:
    print("[WARNING] Missing P elements:")
    for x in missing_p:
        print(" ", x)

# ============================================================
# STEP 9.4
# Other TB1-associated CNSs
# ============================================================

other_tb1 = tb1[
    ~tb1["CNS_name"].isin(P_LABELS)
].copy()

other_tb1.to_csv(
    f"{TB1DIR}/TB1_other_CNS_GERP.tsv",
    sep="\t",
    index=False
)

print("\n[STEP 9.4] Other TB1 CNS")
print("N =", len(other_tb1))

# ============================================================
# STEP 9.5
# Add relative position to TB1 TSS
#
# TB1 GFF:
# chr1 272330564 ... +
#
# BED TSS0 = 272330563
# ============================================================

TSS0 = 272330563

p12["relative_start_bp"] = (
    p12["start0"] - TSS0
)

p12["relative_end_bp"] = (
    p12["end"] - TSS0
)

p12["relative_mid_kb"] = (
    (
        (p12["start0"] + p12["end"]) / 2
        - TSS0
    ) / 1000
)

p12.to_csv(
    f"{TB1DIR}/TB1_P1_P12_GERP.tsv",
    sep="\t",
    index=False
)

# ============================================================
# STEP 10.1
# Weighted summary:
# P1-P6 versus P7-P12
#
# IMPORTANT:
# fractions are calculated using:
#
# sum(GERP bp) / sum(CNS bp)
#
# rather than arithmetic mean of CNS fractions.
# ============================================================

rows = []

for group, x in p12.groupby(
    "TB1_cluster",
    sort=False
):

    total_bp = x["length_bp"].sum()

    row = {
        "TB1_cluster": group,
        "N_CNS": len(x),
        "total_CNS_bp": total_bp,
        "median_CNS_length_bp":
            x["length_bp"].median(),
        "median_species_count":
            x["species_count"].median(),
        "mean_species_count":
            x["species_count"].mean(),
    }

    # node composition
    row["nodes"] = ",".join(
        sorted(
            x["node"]
            .dropna()
            .astype(str)
            .unique()
        )
    )

    for T in [0, 2, 4, 6]:

        bp_col = f"GERPgt{T}_bp"

        bp = pd.to_numeric(
            x[bp_col],
            errors="coerce"
        ).fillna(0).sum()

        row[bp_col] = int(bp)

        row[f"GERPgt{T}_fraction_weighted"] = (
            bp / total_bp
            if total_bp > 0
            else float("nan")
        )

    # positive RS summary if Step 8 supplied it
    if "RS_positive_median" in x.columns:

        vals = pd.to_numeric(
            x["RS_positive_median"],
            errors="coerce"
        ).dropna()

        if len(vals):
            row["median_of_CNS_RS_positive_median"] = \
                vals.median()
        else:
            row["median_of_CNS_RS_positive_median"] = \
                float("nan")

    rows.append(row)

cluster = pd.DataFrame(rows)

# desired biological order
cluster_order = {
    "P1-P6_distal": 1,
    "P7-P12_proximal": 2
}

cluster["_order"] = (
    cluster["TB1_cluster"]
    .map(cluster_order)
)

cluster = cluster.sort_values("_order").drop(
    columns="_order"
)

cluster.to_csv(
    f"{TB1DIR}/TB1_P1P6_vs_P7P12_GERP_summary.tsv",
    sep="\t",
    index=False
)

print("\n[STEP 10.1] P1-P6 vs P7-P12")
print(cluster.to_string(index=False))

# ============================================================
# STEP 10.2
# Generate compact publication-oriented P1-P12 table
# ============================================================

pub_cols = [
    "P_element",
    "TB1_cluster",
    "CNS_name",
    "chr",
    "start0",
    "end",
    "length_bp",
    "relative_mid_kb",
    "species_count",
    "node",
    "level",
    "GERPgt0_bp",
    "GERPgt0_fraction",
    "GERPgt2_bp",
    "GERPgt2_fraction",
    "GERPgt4_bp",
    "GERPgt4_fraction",
    "GERPgt6_bp",
    "GERPgt6_fraction",
]

for x in [
    "RS_positive_n",
    "RS_positive_mean",
    "RS_positive_median",
    "RS_positive_Q1",
    "RS_positive_Q3",
    "RS_positive_min",
    "RS_positive_max",
]:
    if x in p12.columns:
        pub_cols.append(x)

p12_pub = p12[
    [x for x in pub_cols if x in p12.columns]
].copy()

p12_pub.to_csv(
    f"{TB1DIR}/TB1_P1_P12_GERP_publication_table.tsv",
    sep="\t",
    index=False
)

# ============================================================
# STEP 10.3
# TB1 P1-P12 versus other TB1-associated CNS
#
# This is useful as a supplementary comparison.
# ============================================================

def summarize_cns_group(name, x):

    total_bp = x["length_bp"].sum()

    r = {
        "group": name,
        "N_CNS": len(x),
        "total_CNS_bp": total_bp,
        "median_species_count":
            pd.to_numeric(
                x["species_count"],
                errors="coerce"
            ).median()
    }

    for T in [0,2,4,6]:

        bp = pd.to_numeric(
            x[f"GERPgt{T}_bp"],
            errors="coerce"
        ).fillna(0).sum()

        r[f"GERPgt{T}_bp"] = int(bp)

        r[f"GERPgt{T}_fraction_weighted"] = (
            bp / total_bp
            if total_bp > 0
            else float("nan")
        )

    if "RS_positive_median" in x.columns:

        r["median_of_CNS_RS_positive_median"] = (
            pd.to_numeric(
                x["RS_positive_median"],
                errors="coerce"
            ).median()
        )

    return r

tb1_compare = pd.DataFrame([
    summarize_cns_group(
        "published_P1-P12",
        p12
    ),
    summarize_cns_group(
        "other_TB1_CNS",
        other_tb1
    )
])

tb1_compare.to_csv(
    f"{TB1DIR}/TB1_P1P12_vs_other_CNS_summary.tsv",
    sep="\t",
    index=False
)

# ============================================================
# STEP 11.1
# Genome-wide:
# Conservatory conservation breadth vs GERP constraint
# ============================================================

metrics = [
    "GERPgt0_fraction",
    "GERPgt2_fraction",
    "GERPgt4_fraction",
    "GERPgt6_fraction",
]

if "RS_positive_mean" in cns.columns:
    metrics.append("RS_positive_mean")

if "RS_positive_median" in cns.columns:
    metrics.append("RS_positive_median")

corr_rows = []

for metric in metrics:

    x = cns[
        [
            "species_count",
            metric
        ]
    ].copy()

    x["species_count"] = pd.to_numeric(
        x["species_count"],
        errors="coerce"
    )

    x[metric] = pd.to_numeric(
        x[metric],
        errors="coerce"
    )

    x = x.dropna()

    # Conservatory missing values were previously represented
    # as negative numbers in some parsing workflows.
    x = x[
        x["species_count"] >= 0
    ]

    if len(x) < 3:

        rho = float("nan")
        p = float("nan")

    else:

        rho, p = spearmanr(
            x["species_count"],
            x[metric]
        )

    corr_rows.append({
        "predictor":
            "Conservatory_species_count",
        "response":
            metric,
        "N_CNS":
            len(x),
        "Spearman_rho":
            rho,
        "P_value":
            p
    })

corr = pd.DataFrame(corr_rows)

corr.to_csv(
    f"{TABLEDIR}/"
    "CNS_speciesbreadth_vs_GERP_spearman.tsv",
    sep="\t",
    index=False
)

print("\n[STEP 11.1] Genome-wide Spearman")
print(corr.to_string(index=False))

# ============================================================
# STEP 11.2
# Bin CNSs by species_count
#
# This table is useful for plotting:
# conservation breadth -> GERP constraint
# ============================================================

tmp = cns.copy()

tmp["species_count"] = pd.to_numeric(
    tmp["species_count"],
    errors="coerce"
)

tmp = tmp[
    tmp["species_count"].notna()
    &
    (tmp["species_count"] >= 0)
].copy()

def breadth_bin(n):

    if n <= 5:
        return "01_1-5"

    if n <= 10:
        return "02_6-10"

    if n <= 15:
        return "03_11-15"

    if n <= 20:
        return "04_16-20"

    return "05_>20"

tmp["species_breadth_bin"] = (
    tmp["species_count"]
    .apply(breadth_bin)
)

agg = {
    "CNS_name": "count",
    "species_count": ["median", "mean"],
    "GERPgt0_fraction": ["median", "mean"],
    "GERPgt2_fraction": ["median", "mean"],
    "GERPgt4_fraction": ["median", "mean"],
    "GERPgt6_fraction": ["median", "mean"],
}

if "RS_positive_median" in tmp.columns:
    agg["RS_positive_median"] = [
        "median",
        "mean"
    ]

breadth = (
    tmp.groupby(
        "species_breadth_bin",
        observed=True
    )
    .agg(agg)
)

breadth.columns = [
    "_".join(map(str, x))
    for x in breadth.columns
]

breadth = breadth.reset_index()

breadth = breadth.rename(
    columns={
        "CNS_name_count": "N_CNS"
    }
)

breadth.to_csv(
    f"{TABLEDIR}/"
    "CNS_speciesbreadth_bins_GERP_summary.tsv",
    sep="\t",
    index=False
)

# ============================================================
# STEP 11.3
# Node-level summary
#
# Do not interpret node as age until nodes are mapped to
# phylogenetic depths/ages.
# ============================================================

node_tmp = cns.copy()

node_tmp = node_tmp[
    node_tmp["node"].notna()
].copy()

node_summary = (
    node_tmp.groupby("node")
    .agg(
        N_CNS=("CNS_name", "count"),
        median_species_count=(
            "species_count",
            "median"
        ),
        median_GERPgt0_fraction=(
            "GERPgt0_fraction",
            "median"
        ),
        median_GERPgt2_fraction=(
            "GERPgt2_fraction",
            "median"
        ),
        median_GERPgt4_fraction=(
            "GERPgt4_fraction",
            "median"
        ),
        median_GERPgt6_fraction=(
            "GERPgt6_fraction",
            "median"
        )
    )
    .reset_index()
)

if "RS_positive_median" in node_tmp.columns:

    rs_node = (
        node_tmp.groupby("node")[
            "RS_positive_median"
        ]
        .median()
        .reset_index()
        .rename(
            columns={
                "RS_positive_median":
                "median_RS_positive"
            }
        )
    )

    node_summary = node_summary.merge(
        rs_node,
        on="node",
        how="left"
    )

node_summary.to_csv(
    f"{TABLEDIR}/"
    "CNS_node_level_GERP_summary.tsv",
    sep="\t",
    index=False
)

# ============================================================
# STEP 11.4
# QC summary
# ============================================================

qc = []

qc.append(
    ("canonical_CNS_total", len(cns))
)

qc.append(
    ("canonical_gene_total", len(gene))
)

qc.append(
    ("TB1_associated_CNS", len(tb1))
)

qc.append(
    ("TB1_P1_P12_found", len(p12))
)

qc.append(
    ("TB1_other_CNS", len(other_tb1))
)

qc.append(
    (
        "P1_P6_count",
        int(
            (
                p12["TB1_cluster"]
                ==
                "P1-P6_distal"
            ).sum()
        )
    )
)

qc.append(
    (
        "P7_P12_count",
        int(
            (
                p12["TB1_cluster"]
                ==
                "P7-P12_proximal"
            ).sum()
        )
    )
)

# nested GERP thresholds in CNS-level table
bad_nested = cns[
    (cns["GERPgt6_bp"] > cns["GERPgt4_bp"])
    |
    (cns["GERPgt4_bp"] > cns["GERPgt2_bp"])
    |
    (cns["GERPgt2_bp"] > cns["GERPgt0_bp"])
]

qc.append(
    (
        "CNS_non_nested_GERP_threshold_rows",
        len(bad_nested)
    )
)

pd.DataFrame(
    qc,
    columns=["metric", "value"]
).to_csv(
    f"{QCDIR}/Step9_11_QC_summary.tsv",
    sep="\t",
    index=False
)

if len(bad_nested):

    bad_nested.to_csv(
        f"{QCDIR}/"
        "CNS_non_nested_GERP_threshold_rows.tsv",
        sep="\t",
        index=False
    )

# ============================================================
# Final output manifest
# ============================================================

outputs = [
    (
        "TB1 gene-level summary",
        f"{TB1DIR}/TB1_gene_CNS_GERP_summary.tsv"
    ),
    (
        "All TB1-associated CNS",
        f"{TB1DIR}/TB1_all_CNS_GERP.tsv"
    ),
    (
        "Published P1-P12 full table",
        f"{TB1DIR}/TB1_P1_P12_GERP.tsv"
    ),
    (
        "Published P1-P12 compact table",
        f"{TB1DIR}/TB1_P1_P12_GERP_publication_table.tsv"
    ),
    (
        "Other TB1 CNS",
        f"{TB1DIR}/TB1_other_CNS_GERP.tsv"
    ),
    (
        "P1-P6 vs P7-P12",
        f"{TB1DIR}/TB1_P1P6_vs_P7P12_GERP_summary.tsv"
    ),
    (
        "P1-P12 vs other TB1 CNS",
        f"{TB1DIR}/TB1_P1P12_vs_other_CNS_summary.tsv"
    ),
    (
        "Genome-wide Spearman",
        f"{TABLEDIR}/CNS_speciesbreadth_vs_GERP_spearman.tsv"
    ),
    (
        "Breadth-bin summary",
        f"{TABLEDIR}/CNS_speciesbreadth_bins_GERP_summary.tsv"
    ),
    (
        "Node-level summary",
        f"{TABLEDIR}/CNS_node_level_GERP_summary.tsv"
    ),
    (
        "QC",
        f"{QCDIR}/Step9_11_QC_summary.tsv"
    ),
]

with open(
    f"{BASE}/Step9_11_output_manifest.tsv",
    "w"
) as out:

    out.write(
        "description\tfile\n"
    )

    for desc, fn in outputs:

        out.write(
            f"{desc}\t{fn}\n"
        )

print("\n============================================================")
print("Step 9–11 completed")
print("============================================================")

for desc, fn in outputs:
    print(f"{desc}:")
    print(f"  {fn}")

PY

echo
echo "============================================================"
echo " Quick QC"
echo "============================================================"

column -t \
"${QCDIR}/Step9_11_QC_summary.tsv"

echo
echo "============================================================"
echo " TB1 P1-P6 vs P7-P12"
echo "============================================================"

column -t \
"${TB1DIR}/TB1_P1P6_vs_P7P12_GERP_summary.tsv"

echo
echo "============================================================"
echo " Genome-wide conservation breadth vs GERP"
echo "============================================================"

column -t \
"${TABLEDIR}/CNS_speciesbreadth_vs_GERP_spearman.tsv"

echo
echo "[DONE] Step 9–11"
