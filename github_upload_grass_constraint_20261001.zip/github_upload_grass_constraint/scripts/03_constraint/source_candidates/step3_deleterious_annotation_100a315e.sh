#!/bin/bash
#SBATCH --job-name=functional_intersect
#SBATCH --output=logs/functional_intersect_%A_%a.log
#SBATCH --error=logs/functional_intersect_%A_%a.err
#SBATCH --cpus-per-task=8
#SBATCH --array=1-10%10

# 创建日志目录
mkdir -p logs
# 设置Singularity临时目录 - 使用当前工作目录下的临时目录
WORK_TMP_DIR="$(pwd)/singularity_tmp_$$"
export SINGULARITY_TMPDIR="$WORK_TMP_DIR"
export TMPDIR="$WORK_TMP_DIR"
mkdir -p "$SINGULARITY_TMPDIR"

# 设置清理函数
cleanup() {
    echo "清理临时目录: $SINGULARITY_TMPDIR"
    rm -rf "$SINGULARITY_TMPDIR"
}
trap cleanup EXIT

echo "临时目录: $SINGULARITY_TMPDIR"
echo "可用磁盘空间:"
df -h "$(pwd)"

# GERP分数目录和亚基因组的组合
GERP_DIRS=("gerp_ge0" "gerp_ge2" "gerp_ge2.75" "gerp_ge3.5" "gerp_ge4.0")
SUBGENOMES=("pedC" "pedD")
GERP_LABELS=("weakly" "mild" "moderate" "strongly" "strongly")

# 功能区域目录 - 解析软链接
FUNCTIONAL_DIR_LINK="./2.1.constrained_category"
FUNCTIONAL_DIR=$(readlink -f "$FUNCTIONAL_DIR_LINK")

# 调试信息：打印当前工作目录
echo "当前工作目录: $(pwd)"
echo "功能区域目录链接: $FUNCTIONAL_DIR_LINK"
echo "功能区域实际目录: $FUNCTIONAL_DIR"

# 检查软链接是否存在
if [ ! -L "$FUNCTIONAL_DIR_LINK" ]; then
    echo "错误: 功能区域目录链接不存在: $FUNCTIONAL_DIR_LINK"
    exit 1
fi

# 检查实际目录是否存在
if [ ! -d "$FUNCTIONAL_DIR" ]; then
    echo "错误: 功能区域实际目录不存在: $FUNCTIONAL_DIR"
    echo "软链接指向: $(readlink $FUNCTIONAL_DIR_LINK)"
    exit 1
fi

# 列出实际目录内容
echo "实际目录内容:"
ls -la "$FUNCTIONAL_DIR"

# 根据数组任务ID确定当前处理的组合
TOTAL_GERP=${#GERP_DIRS[@]}
TOTAL_SUBGENOMES=${#SUBGENOMES[@]}

# 计算当前任务对应的GERP目录和亚基因组
GERP_INDEX=$(( (SLURM_ARRAY_TASK_ID - 1) / TOTAL_SUBGENOMES ))
SUBGENOME_INDEX=$(( (SLURM_ARRAY_TASK_ID - 1) % TOTAL_SUBGENOMES ))

CURRENT_GERP_DIR=${GERP_DIRS[$GERP_INDEX]}
CURRENT_SUBGENOME=${SUBGENOMES[$SUBGENOME_INDEX]}
CURRENT_LABEL=${GERP_LABELS[$GERP_INDEX]}

echo "处理组合: GERP_INDEX=$GERP_INDEX, SUBGENOME_INDEX=$SUBGENOME_INDEX"
echo "当前GERP目录: $CURRENT_GERP_DIR"
echo "当前亚基因组: $CURRENT_SUBGENOME"
echo "当前标签: $CURRENT_LABEL"

# 输入VCF文件
INPUT_VCF="${CURRENT_GERP_DIR}/${CURRENT_SUBGENOME}_${CURRENT_LABEL}.clean_snps.vcf"

# 检查输入文件是否存在
if [ ! -f "$INPUT_VCF" ]; then
    echo "错误: 输入文件不存在: $INPUT_VCF"
    echo "查找可能的VCF文件..."
    find $CURRENT_GERP_DIR -name "*.vcf" 2>/dev/null | head -5
    exit 1
fi

# 创建输出目录
OUTPUT_DIR="${CURRENT_GERP_DIR}/functional_analysis"
mkdir -p "$OUTPUT_DIR"

echo "$(date): 开始处理 $CURRENT_GERP_DIR/$CURRENT_SUBGENOME"
echo "输入文件: $INPUT_VCF"

# 获取所有功能区域BED文件 - 使用实际目录路径
echo "查找功能区域BED文件..."
FUNCTIONAL_BEDS=($(find "$FUNCTIONAL_DIR" -name "*.bed" -type f | sort))

echo "找到的功能区域文件数量: ${#FUNCTIONAL_BEDS[@]}"
if [ ${#FUNCTIONAL_BEDS[@]} -eq 0 ]; then
    echo "错误: 没有找到功能区域BED文件"
    echo "尝试其他查找方式:"
    find "$FUNCTIONAL_DIR" -type f | head -10
    exit 1
fi

echo "功能区域文件列表:"
for bed in "${FUNCTIONAL_BEDS[@]}"; do
    echo "  - $bed"
done

# 处理每个功能区域
for FUNC_BED in "${FUNCTIONAL_BEDS[@]}"; do
    FUNC_NAME=$(basename "$FUNC_BED" .bed)
    
    echo "=================================================="
    echo "正在处理功能区域: $FUNC_NAME"
    echo "功能区域文件: $FUNC_BED"
    
    # 检查功能区域文件是否存在且非空
    if [ ! -f "$FUNC_BED" ]; then
        echo "  错误: 功能区域文件不存在: $FUNC_BED"
        continue
    fi
    
    if [ ! -s "$FUNC_BED" ]; then
        echo "  警告: 功能区域文件为空: $FUNC_BED"
        continue
    fi
    
    # 显示功能区域文件的前几行
    echo "功能区域文件内容预览:"
    head -3 "$FUNC_BED"
    echo "功能区域总数: $(wc -l < "$FUNC_BED")"
    
    # 输出文件名
    OUTPUT_VCF="${OUTPUT_DIR}/${CURRENT_SUBGENOME}_${CURRENT_LABEL}_${FUNC_NAME}_overlap.vcf"
    OUTPUT_BED="${OUTPUT_DIR}/${CURRENT_SUBGENOME}_${CURRENT_LABEL}_${FUNC_NAME}_overlap.bed"
    OUTPUT_FUNC_BED="${OUTPUT_DIR}/${CURRENT_SUBGENOME}_${CURRENT_LABEL}_${FUNC_NAME}_func_regions.bed"
    
    echo "输出文件:"
    echo "  VCF: $OUTPUT_VCF"
    echo "  BED: $OUTPUT_BED"
    echo "  功能区域: $OUTPUT_FUNC_BED"
    
    # 1. 提取重叠的SNP (VCF格式)
    echo "步骤1: 提取重叠SNP (VCF格式)"
    singularity exec ~/liuliangmin/4.may/software/Reseq_genek.sif bcftools view "$INPUT_VCF" | \
    bedtools intersect -a stdin -b "$FUNC_BED" -header > "$OUTPUT_VCF"
    
    # 检查VCF输出
    if [ -s "$OUTPUT_VCF" ]; then
        VCF_SNP_COUNT=$(grep -v '^#' "$OUTPUT_VCF" | wc -l)
        echo "  VCF输出: $VCF_SNP_COUNT 个SNP"
    else
        echo "  VCF输出: 无重叠SNP"
        rm -f "$OUTPUT_VCF"
    fi
    
    # 2. 提取重叠的SNP位点 (BED格式)
    echo "步骤2: 提取重叠SNP位点 (BED格式)"
    singularity exec ~/liuliangmin/4.may/software/Reseq_genek.sif bcftools view "$INPUT_VCF" | \
    bedtools intersect -a stdin -b "$FUNC_BED" | \
    awk 'BEGIN{OFS="\t"} !/^#/ {print $1, $2-1, $2, $3}' > "$OUTPUT_BED"
    
    # 检查BED输出
    if [ -s "$OUTPUT_BED" ]; then
        BED_SNP_COUNT=$(wc -l < "$OUTPUT_BED")
        echo "  BED输出: $BED_SNP_COUNT 个SNP位点"
        echo "  BED文件预览:"
        head -3 "$OUTPUT_BED"
    else
        echo "  BED输出: 无重叠SNP位点"
        rm -f "$OUTPUT_BED"
    fi
    
    # 3. 提取对应的功能区域信息 (保留功能区域注释)
    echo "步骤3: 提取对应的功能区域信息"
     bedtools intersect \
    -a "$FUNC_BED" \
    -b <(singularity exec ~/liuliangmin/4.may/software/Reseq_genek.sif bcftools view "$INPUT_VCF" | awk 'BEGIN{OFS="\t"} !/^#/ {print $1, $2-1, $2}') \
    -wa > "$OUTPUT_FUNC_BED"
    
    # 检查功能区域输出
    if [ -s "$OUTPUT_FUNC_BED" ]; then
        FUNC_REGION_COUNT=$(wc -l < "$OUTPUT_FUNC_BED")
        echo "  功能区域输出: $FUNC_REGION_COUNT 个区域"
        echo "  功能区域文件预览:"
        head -3 "$OUTPUT_FUNC_BED"
    else
        echo "  功能区域输出: 无重叠区域"
        rm -f "$OUTPUT_FUNC_BED"
    fi
    
    # 4. 生成详细的重叠信息 (包含SNP位点和功能区域注释)
    if [ -f "$OUTPUT_BED" ] && [ -s "$OUTPUT_BED" ]; then
        echo "步骤4: 生成详细重叠信息"
        DETAILED_OUTPUT="${OUTPUT_DIR}/${CURRENT_SUBGENOME}_${CURRENT_LABEL}_${FUNC_NAME}_detailed.bed"
        
        # 使用bedtools intersect -wa -wb 获取详细信息
        singularity exec ~/liuliangmin/4.may/software/Reseq_genek.sif bcftools view "$INPUT_VCF" | \
        awk 'BEGIN{OFS="\t"} !/^#/ {print $1, $2-1, $2, $3}' | \
        bedtools intersect -a stdin -b "$FUNC_BED" -wa -wb > "$DETAILED_OUTPUT"
        
        if [ -s "$DETAILED_OUTPUT" ]; then
            DETAILED_COUNT=$(wc -l < "$DETAILED_OUTPUT")
            echo "  详细信息输出: $DETAILED_COUNT 个重叠记录"
            echo "  详细信息文件预览:"
            head -3 "$DETAILED_OUTPUT"
        fi
    fi
    
    echo "功能区域 $FUNC_NAME 处理完成"
    echo ""
done

echo "$(date): 完成处理 $CURRENT_GERP_DIR/$CURRENT_SUBGENOME"
echo "结果保存在: $OUTPUT_DIR"

# 生成汇总报告
SUMMARY_FILE="${OUTPUT_DIR}/${CURRENT_SUBGENOME}_${CURRENT_LABEL}_summary.txt"
echo "功能区域与SNP重叠分析汇总报告" > "$SUMMARY_FILE"
echo "GERP分数类别: $CURRENT_GERP_DIR" >> "$SUMMARY_FILE"
echo "亚基因组: $CURRENT_SUBGENOME" >> "$SUMMARY_FILE"
echo "输入VCF: $INPUT_VCF" >> "$SUMMARY_FILE"
echo "总SNP数: $(grep -v '^#' "$INPUT_VCF" | wc -l)" >> "$SUMMARY_FILE"
echo "分析时间: $(date)" >> "$SUMMARY_FILE"
echo "" >> "$SUMMARY_FILE"
echo "各功能区域重叠统计:" >> "$SUMMARY_FILE"

for FUNC_BED in "${FUNCTIONAL_BEDS[@]}"; do
    FUNC_NAME=$(basename "$FUNC_BED" .bed)
    OUTPUT_BED="${OUTPUT_DIR}/${CURRENT_SUBGENOME}_${CURRENT_LABEL}_${FUNC_NAME}_overlap.bed"
    OUTPUT_VCF="${OUTPUT_DIR}/${CURRENT_SUBGENOME}_${CURRENT_LABEL}_${FUNC_NAME}_overlap.vcf"
    
    if [ -f "$OUTPUT_BED" ] && [ -s "$OUTPUT_BED" ]; then
        BED_COUNT=$(wc -l < "$OUTPUT_BED")
        VCF_COUNT=0
        if [ -f "$OUTPUT_VCF" ] && [ -s "$OUTPUT_VCF" ]; then
            VCF_COUNT=$(grep -v '^#' "$OUTPUT_VCF" | wc -l)
        fi
        echo "$FUNC_NAME: BED=$BED_COUNT, VCF=$VCF_COUNT" >> "$SUMMARY_FILE"
    else
        echo "$FUNC_NAME: 0" >> "$SUMMARY_FILE"
    fi
done

echo "汇总报告已保存: $SUMMARY_FILE"

# 输出最终统计
echo ""
echo "=== 最终统计 ==="
echo "处理的功能区域数量: ${#FUNCTIONAL_BEDS[@]}"
echo "生成的结果文件:"
find "$OUTPUT_DIR" -name "*${CURRENT_SUBGENOME}_${CURRENT_LABEL}*" -type f | sort
echo ""
echo "文件大小统计:"
find "$OUTPUT_DIR" -name "*${CURRENT_SUBGENOME}_${CURRENT_LABEL}*" -type f -exec ls -lh {} \;
