#!/bin/bash
#SBATCH --job-name=gerp_snp_intersect
#SBATCH --output=logs/gerp_snp_intersect_%A_%a.log
#SBATCH --error=logs/gerp_snp_intersect_%A_%a.err
#SBATCH --cpus-per-task=10
#SBATCH --array=1-4%4

# ============================================================
# Purpose:
#   Intersect SNPs (VCF) with GERP constrained sites
#   GERP BED files contain header -> skipped on-the-fly
#   SNP VCF output is bgzip-compressed (.vcf.gz)
# ============================================================

set -euo pipefail

mkdir -p logs

# ============================================================
# Input files
# ============================================================

VCF="141sp.filtered.bi-allelic.snp.vcf.gz"

GERP_BASE="/gpfs/hpc/home/kib_unit/lidezhu/liuliangmin/2.msa/Atau_msa/results/GERP_final_output"

GERP_BEDS=(
  "merged_gt0.bed"
  "merged_gt2.bed"
  "merged_gt4.bed"
  "merged_gt6.bed"
)

TOTAL=${#GERP_BEDS[@]}

if [ "$SLURM_ARRAY_TASK_ID" -gt "$TOTAL" ]; then
    echo "ERROR: SLURM_ARRAY_TASK_ID exceeds GERP list"
    exit 1
fi

GERP_BED=${GERP_BEDS[$SLURM_ARRAY_TASK_ID-1]}
GERP_PATH="${GERP_BASE}/${GERP_BED}"
PREFIX=${GERP_BED%.bed}

# ============================================================
# Output structure
# ============================================================

OUTDIR="./${PREFIX}"
mkdir -p "${OUTDIR}"

OUT_VCF="${OUTDIR}/${PREFIX}_snps.vcf.gz"
OUT_SNP_BED="${OUTDIR}/${PREFIX}_snps.bed"
OUT_GERP_BED="${OUTDIR}/${PREFIX}_gerp_regions.bed"

echo "$(date)  Processing ${GERP_PATH}"

# ============================================================
# 1. SNP ∩ GERP  (VCF.gz output)
#    - skip BED header using tail -n +2
# ============================================================

singularity exec ~/liuliangmin/4.may/software/Reseq_genek.sif \
bcftools view "$VCF" | \
bedtools intersect -a stdin -b <(tail -n +2 "$GERP_PATH") -header | \
bgzip -c > "$OUT_VCF"

# ============================================================
# 2. SNP ∩ GERP  (BED output, SNP coordinates)
# ============================================================

singularity exec ~/liuliangmin/4.may/software/Reseq_genek.sif \
bcftools view "$VCF" | \
bedtools intersect -a stdin -b <(tail -n +2 "$GERP_PATH") | \
awk 'BEGIN{OFS="\t"} !/^#/ {print $1, $2-1, $2, $3}' \
> "$OUT_SNP_BED"

# ============================================================
# 3. GERP sites overlapped by SNPs (retain GERP scores)
# ============================================================

singularity exec ~/liuliangmin/4.may/software/Reseq_genek.sif \
bcftools view "$VCF" | \
awk 'BEGIN{OFS="\t"} !/^#/ {print $1, $2-1, $2}' | \
bedtools intersect -a <(tail -n +2 "$GERP_PATH") -b stdin -wa \
> "$OUT_GERP_BED"

# ============================================================
# 4. Summary
# ============================================================

if [ -s "$OUT_VCF" ]; then
    SNP_N=$(zgrep -vc '^#' "$OUT_VCF")
    echo "DONE: ${PREFIX}"
    echo "  SNP count      : ${SNP_N}"
    echo "  VCF output     : ${OUT_VCF}"
    echo "  SNP BED        : ${OUT_SNP_BED}"
    echo "  GERP BED       : ${OUT_GERP_BED}"
else
    echo "ERROR: empty result for ${PREFIX}"
    exit 2
fi
