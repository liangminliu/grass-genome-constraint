#!/bin/bash

# Batch submission script for polarisation analysis across all chromosomes
# This script submits individual SBATCH jobs for each chromosome

# Define chromosomes array
chromosomes=("Ped01C" "Ped01D" "Ped02C" "Ped02D" "Ped03C" "Ped03D" "Ped04C" "Ped04D" 
             "Ped05C" "Ped05D" "Ped06C" "Ped06D" "Ped07C" "Ped07D" "Ped08C" "Ped08D"
             "Ped09C" "Ped09X" "Ped10C" "Ped10D" "Ped11C" "Ped11D" "Ped12C" "Ped12D")

# Set parameters
focfreq="table.acgt.format.tsv"
config="config_kimura.txt"
outgr_bed="ped_hca_alu.bed"
base_outd="est_sfs_results"

# Check if required files exist
echo "Checking required input files..."
for file in "$focfreq" "$config" "$outgr_bed" "seedfile.txt"; do
    if [ ! -f "$file" ]; then
        echo "Error: Required file $file not found!"
        exit 1
    fi
done

# Check if the polarisation script exists
polarisation_script="polarise_sfs.sh"
if [ ! -f "$polarisation_script" ]; then
    echo "Error: Polarisation script $polarisation_script not found!"
    echo "Please make sure the SBATCH polarisation script is in the current directory."
    exit 1
fi

# Create main output directory
mkdir -p "$base_outd"

# Array to store job IDs
job_ids=()

echo "Starting batch submission for ${#chromosomes[@]} chromosomes..."
echo "=================================="

# Submit jobs for each chromosome
for chr in "${chromosomes[@]}"; do
    echo "Submitting job for chromosome: $chr"
    
    # Create chromosome-specific output directory
    chr_outd="${base_outd}/${chr}"
    mkdir -p "$chr_outd"
    
    # Submit the job and capture job ID
    job_id=$(sbatch \
        --export=chr="$chr",focfreq="$focfreq",config="$config",outgr="$outgr_bed",outd="$chr_outd" \
        --job-name="polarise_${chr}" \
        --output="${chr_outd}/polarise_${chr}_%j.out" \
        --error="${chr_outd}/polarise_${chr}_%j.err" \
        "$polarisation_script" | awk '{print $4}')
    
    if [ $? -eq 0 ]; then
        job_ids+=("$job_id")
        echo "  Job ID: $job_id"
    else
        echo "  Failed to submit job for $chr"
    fi
    
    # Small delay to avoid overwhelming the scheduler
    sleep 1
done

echo "=================================="
echo "Batch submission completed!"
echo "Total jobs submitted: ${#job_ids[@]}"
echo "Job IDs: ${job_ids[*]}"

# Create a summary script to check job status
cat > check_jobs.sh << EOF
#!/bin/bash
# Auto-generated script to check job status

job_ids=(${job_ids[*]})

echo "Checking status of polarisation jobs..."
echo "======================================"

for job_id in "\${job_ids[@]}"; do
    status=\$(squeue -j \$job_id -h -o "%T" 2>/dev/null)
    if [ -z "\$status" ]; then
        status="COMPLETED/NOT_FOUND"
    fi
    echo "Job \$job_id: \$status"
done

echo ""
echo "Summary by chromosome:"
echo "====================="
EOF

for chr in "${chromosomes[@]}"; do
    cat >> check_jobs.sh << EOF
if [ -f "${base_outd}/${chr}/${chr}.sfs.output.txt" ]; then
    echo "$chr: COMPLETED"
else
    echo "$chr: RUNNING/PENDING/FAILED"
fi
EOF
done

chmod +x check_jobs.sh

echo ""
echo "Created check_jobs.sh script to monitor job progress."
echo "Run './check_jobs.sh' to check the status of all jobs."

# Create a summary collection script
cat > collect_results.sh << EOF
#!/bin/bash
# Auto-generated script to collect and summarize results

echo "Collecting results from all chromosomes..."
echo "========================================"

total_sites=0
total_missing=0
completed_chrs=0

for chr in ${chromosomes[*]}; do
    chr_dir="${base_outd}/\${chr}"
    if [ -f "\${chr_dir}/\${chr}.sfs.output.txt" ]; then
        echo "Processing \$chr..."
        ((completed_chrs++))
        
        # Count sites if available
        if [ -f "\${chr_dir}/\${chr}.est_sfs.input" ]; then
            sites=\$(wc -l < "\${chr_dir}/\${chr}.est_sfs.input")
            missing=\$(grep -c "0,0,0,0 0,0,0,0" "\${chr_dir}/\${chr}.est_sfs.input" 2>/dev/null || echo 0)
            total_sites=\$((total_sites + sites))
            total_missing=\$((total_missing + missing))
            echo "  Sites: \$sites, Missing: \$missing"
        fi
    else
        echo "\$chr: NOT COMPLETED"
    fi
done

echo ""
echo "Summary:"
echo "========"
echo "Completed chromosomes: \$completed_chrs/${#chromosomes[@]}"
echo "Total sites analyzed: \$total_sites"
echo "Total missing sites: \$total_missing"

if [ \$total_sites -gt 0 ]; then
    missing_pct=\$(echo "scale=2; \$total_missing * 100 / \$total_sites" | bc -l 2>/dev/null || echo "N/A")
    echo "Missing percentage: \$missing_pct%"
fi

# Create combined SFS output
echo ""
echo "Creating combined SFS output..."
combined_sfs="${base_outd}/combined_sfs_output.txt"
> "\$combined_sfs"

for chr in ${chromosomes[*]}; do
    chr_dir="${base_outd}/\${chr}"
    if [ -f "\${chr_dir}/\${chr}.sfs.output.txt" ]; then
        echo "# \$chr" >> "\$combined_sfs"
        cat "\${chr_dir}/\${chr}.sfs.output.txt" >> "\$combined_sfs"
        echo "" >> "\$combined_sfs"
    fi
done

echo "Combined SFS output saved to: \$combined_sfs"
EOF

chmod +x collect_results.sh

echo "Created collect_results.sh script to collect and summarize all results."
echo "Run './collect_results.sh' after all jobs complete."

# Create a cleanup script
cat > cleanup_intermediate.sh << EOF
#!/bin/bash
# Auto-generated script to clean up intermediate files

echo "Cleaning up intermediate files..."
echo "================================"

for chr in ${chromosomes[*]}; do
    chr_dir="${base_outd}/\${chr}"
    if [ -d "\$chr_dir" ]; then
        echo "Cleaning \$chr..."
        # Remove intermediate files but keep important outputs
        rm -f "\${chr_dir}/\${chr}.intersected"
        rm -f "\${chr_dir}/"*.noindel.bed
        rm -f "\${chr_dir}/"*.fixed.bed
        rm -f "\${chr_dir}/"*.log
    fi
done

echo "Cleanup completed!"
EOF

chmod +x cleanup_intermediate.sh

echo "Created cleanup_intermediate.sh script to clean up intermediate files after analysis."

echo ""
echo "All scripts created successfully!"
echo "================================"
echo "1. Run this script to submit all jobs"
echo "2. Use './check_jobs.sh' to monitor progress"
echo "3. Use './collect_results.sh' to summarize results"
echo "4. Use './cleanup_intermediate.sh' to clean up intermediate files"
echo ""
echo "Jobs will be submitted to directories under: $base_outd/"