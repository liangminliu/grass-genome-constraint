#!/bin/bash
#SBATCH --job-name=functional_intersect
#SBATCH --output=logs/functional_intersect_%A_%a.log
#SBATCH --error=logs/functional_intersect_%A_%a.err
#SBATCH --cpus-per-task=8
#SBATCH --array=1-10%10

# 创建日志目录
mkdir -p logs

# 设置 Singularity 临时目录
WORK_TMP_DIR="$(pwd)/singularity_tmp_$$"
export SINGULARITY_TMPDIR="$WORK_TMP_DIR"
export TMPDIR="$WORK_TMP_DIR"
mkdir -p "$SINGULARITY_TMPDIR"

cleanup() {
    echo "清理临时目录: $SINGULARITY_TMPDIR"
    rm -rf "$SINGULARITY_TMPDIR"
}
trap cleanup EXIT

echo "临时目录: $SINGULARITY_TMPDIR"
echo "可用磁盘空间:"
df -h "$(pwd)"

# —— 输入 VCF 的基目录和样本前缀 —— #
BASE_INPUT_DIR="/gpfs/hpc/home/kib_unit/lidezhu/liuliangmin/5.deleterious/01.snp_calling/01.filtering/01.3.filter_all_individual/71sp"
SAMPLE_PREFIX="71sp"

# GERP 分数目录、亚基因组与标签
GERP_DIRS=("gerp_ge0" "gerp_ge2" "gerp_ge2.75" "gerp_ge3.5" "gerp_ge4.0")
SUBGENOMES=("pedC")
GERP_LABELS=("weakly" "mild" "moderate" "strongly" "strongly")

# 功能区域 BED 文件目录（当前工作目录）
FUNCTIONAL_DIR_LINK="."
FUNCTIONAL_DIR=$(readlink -f "$FUNCTIONAL_DIR_LINK")

echo "当前工作目录: $(pwd)"
echo "功能区域目录: $FUNCTIONAL_DIR"

if [ ! -d "$FUNCTIONAL_DIR" ]; then
    echo "错误: 功能区域目录不存在: $FUNCTIONAL_DIR"
    exit 1
fi

ls -la "$FUNCTIONAL_DIR"

# 计算任务对应的组合
TOTAL_GERP=${#GERP_DIRS[@]}
TOTAL_SUBGENOMES=${#SUBGENOMES[@]}
GERP_INDEX=$(( (SLURM_ARRAY_TASK_ID - 1) / TOTAL_SUBGENOMES ))
SUBGENOME_INDEX=$(( (SLURM_ARRAY_TASK_ID - 1) % TOTAL_SUBGENOMES ))
CURRENT_GERP_DIR=${GERP_DIRS[$GERP_INDEX]}
CURRENT_SUBGENOME=${SUBGENOMES[$SUBGENOME_INDEX]}
CURRENT_LABEL=${GERP_LABELS[$GERP_INDEX]}

echo "处理组合: GERP=$CURRENT_GERP_DIR, 亚基因组=$CURRENT_SUBGENOME, 标签=$CURRENT_LABEL"

# 构建输入 VCF 路径
INPUT_VCF="${BASE_INPUT_DIR}/${CURRENT_GERP_DIR}/${SAMPLE_PREFIX}_${CURRENT_SUBGENOME}_${CURRENT_LABEL}.clean_snps.vcf"
if [ ! -f "$INPUT_VCF" ]; then
    echo "错误: 输入 VCF 不存在: $INPUT_VCF"
    echo "可选文件预览:"
    ls "${BASE_INPUT_DIR}/${CURRENT_GERP_DIR}" | head -5
    exit 1
fi

# 输出目录设为当前工作目录下的 functional_analysis
OUTPUT_DIR="$(pwd)/${CURRENT_GERP_DIR}"
mkdir -p "$OUTPUT_DIR"

echo "开始处理: $INPUT_VCF"
echo "输出目录: $OUTPUT_DIR"

# 查找功能区域 BED 文件
FUNCTIONAL_BEDS=($(find "$FUNCTIONAL_DIR" -maxdepth 1 -name "*.bed" -type f | sort))
echo "找到功能区域 BED 文件共 ${#FUNCTIONAL_BEDS[@]} 个:"
if [ ${#FUNCTIONAL_BEDS[@]} -eq 0 ]; then
    echo "错误: 没有找到任何 BED 文件"
    exit 1
fi
for f in "${FUNCTIONAL_BEDS[@]}"; do
    echo "  - $f"
done

# 对每个功能区域进行交集分析
for FUNC_BED in "${FUNCTIONAL_BEDS[@]}"; do
    FUNC_NAME=$(basename "$FUNC_BED" .bed)
    echo "=================================================="
    echo "功能区域: $FUNC_NAME"

    OUTPUT_VCF="${OUTPUT_DIR}/${SAMPLE_PREFIX}_${CURRENT_SUBGENOME}_${CURRENT_LABEL}_${FUNC_NAME}_overlap.vcf"
    OUTPUT_BED="${OUTPUT_DIR}/${SAMPLE_PREFIX}_${CURRENT_SUBGENOME}_${CURRENT_LABEL}_${FUNC_NAME}_overlap.bed"
    OUTPUT_FUNC_BED="${OUTPUT_DIR}/${SAMPLE_PREFIX}_${CURRENT_SUBGENOME}_${CURRENT_LABEL}_${FUNC_NAME}_func_regions.bed"

    # 步骤1：提取重叠 SNP（VCF）
    echo "步骤1: 提取重叠 SNP (VCF)"
    singularity exec ~/liuliangmin/4.may/software/Reseq_genek.sif \
      bcftools view "$INPUT_VCF" | \
      bedtools intersect -a stdin -b "$FUNC_BED" -header > "$OUTPUT_VCF"
    if [ -s "$OUTPUT_VCF" ]; then
        VCF_COUNT=$(grep -v '^#' "$OUTPUT_VCF" | wc -l)
        echo "  VCF 输出: $VCF_COUNT 个 SNP"
    else
        echo "  VCF 输出: 0"
        rm -f "$OUTPUT_VCF"
    fi

    # 步骤2：提取重叠 SNP 位点（BED）
    echo "步骤2: 提取重叠 SNP 位点 (BED)"
    singularity exec ~/liuliangmin/4.may/software/Reseq_genek.sif \
      bcftools view "$INPUT_VCF" | \
      bedtools intersect -a stdin -b "$FUNC_BED" | \
      awk 'BEGIN{OFS="\t"} !/^#/ {print $1, $2-1, $2, $3}' > "$OUTPUT_BED"
    if [ -s "$OUTPUT_BED" ]; then
        BED_COUNT=$(wc -l < "$OUTPUT_BED")
        echo "  BED 输出: $BED_COUNT 个 SNP 位点"
        echo "  预览:"
        head -3 "$OUTPUT_BED"
    else
        echo "  BED 输出: 0"
        rm -f "$OUTPUT_BED"
    fi

    # 步骤3：提取功能区域信息（带注释）
    echo "步骤3: 提取功能区域信息"
    bedtools intersect \
      -a "$FUNC_BED" \
      -b <(singularity exec ~/liuliangmin/4.may/software/Reseq_genek.sif \
           bcftools view "$INPUT_VCF" | awk 'BEGIN{OFS="\t"} !/^#/ {print $1, $2-1, $2}') \
      -wa > "$OUTPUT_FUNC_BED"
    if [ -s "$OUTPUT_FUNC_BED" ]; then
        FREGION_COUNT=$(wc -l < "$OUTPUT_FUNC_BED")
        echo "  功能区域输出: $FREGION_COUNT 个区域"
        echo "  预览:"
        head -3 "$OUTPUT_FUNC_BED"
    else
        echo "  功能区域输出: 0"
        rm -f "$OUTPUT_FUNC_BED"
    fi

    # 步骤4：详细重叠信息（可选）
    if [ -s "$OUTPUT_BED" ]; then
        DETAILED="${OUTPUT_DIR}/${SAMPLE_PREFIX}_${CURRENT_SUBGENOME}_${CURRENT_LABEL}_${FUNC_NAME}_detailed.bed"
        echo "步骤4: 生成详细重叠信息"
        singularity exec ~/liuliangmin/4.may/software/Reseq_genek.sif \
          bcftools view "$INPUT_VCF" | \
          awk 'BEGIN{OFS="\t"} !/^#/ {print $1, $2-1, $2, $3}' | \
          bedtools intersect -a stdin -b "$FUNC_BED" -wa -wb > "$DETAILED"
        if [ -s "$DETAILED" ]; then
            DCOUNT=$(wc -l < "$DETAILED")
            echo "  详细信息输出: $DCOUNT 条记录"
            echo "  预览:"
            head -3 "$DETAILED"
        fi
    fi

    echo "功能区域 $FUNC_NAME 处理完成"
    echo ""
done

echo "所有功能区域处理结束，结果保存在: $OUTPUT_DIR"