#!/bin/bash
#BSUB -J ped_gt4_load
#BSUB -q Q96C1T_X12
#BSUB -n 4
#BSUB -o logs/ped_gt4_load.%J.out
#BSUB -e logs/ped_gt4_load.%J.err

set -euo pipefail
mkdir -p logs

python3 ped_gerp_burden_pipeline.py \
  --ancestral all.ancestral.bed \
  --pedc-vcf pedC_gt4_snps.vcf.gz \
  --pedc-gerp /ds3200_1/users_root/liuliangmin/workspace/PHD/5.deleterious/01.snp_calling/01.filtering/01.3.filter_all_individual/63sp/gerp_gt4/pedC_gt4_gerp_regions.bed \
  --pedd-vcf pedD_gt4_snps.vcf.gz \
  --pedd-gerp /ds3200_1/users_root/liuliangmin/workspace/PHD/5.deleterious/01.snp_calling/01.filtering/01.3.filter_all_individual/63sp/gerp_gt4/pedD_gt4_gerp_regions.bed \
  --outdir ped_gt4_load \
  --gerp-rs-col 5 \
  --ancestral-aa-col 4 \
  --merge-samples-mode exact