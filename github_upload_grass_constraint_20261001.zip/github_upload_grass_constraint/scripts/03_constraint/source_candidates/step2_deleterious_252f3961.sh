#!/bin/bash
#SBATCH --job-name=gerp_snp_intersect_Zmay
#SBATCH --output=logs/gerp_snp_intersect_Zmay_%A_%a.log
#SBATCH --error=logs/gerp_snp_intersect_Zmay_%A_%a.err
#SBATCH --cpus-per-task=8
#SBATCH --array=1-4%4

# ============================================================
# Purpose:
#   Intersect SNPs with GERP constrained sites (Zea mays)
#   Input GERP = merged_gt*.bed (WITH header)
#   Header skipped on-the-fly using tail -n +2
#   Output SNP VCF = bgzip-compressed
# ============================================================

set -euo pipefail

mkdir -p logs

############################################################
# 0. Singularity 临时目录
############################################################
WORK_TMP_DIR="$(pwd)/singularity_tmp_${SLURM_JOB_ID}_${SLURM_ARRAY_TASK_ID}"
export SINGULARITY_TMPDIR="$WORK_TMP_DIR"
export TMPDIR="$WORK_TMP_DIR"
mkdir -p "$WORK_TMP_DIR"

cleanup() {
    rm -rf "$WORK_TMP_DIR"
}
trap cleanup EXIT

echo "[$(date)] TMPDIR: $WORK_TMP_DIR"
df -h "$(pwd)"

############################################################
# 1. Input VCF (Zea mays)
############################################################
VCF="./2.1_vcf.filter/all.filtered.bi-allelic.miss0.5.snp.vcf.gz"

############################################################
# 2. GERP merged BEDs (Zmay v5)
############################################################
GERP_BASE="/gpfs/hpc/home/kib_unit/lidezhu/liuliangmin/2.msa/Zmay/Zmay_v5_results/GERP_final_output"

GERP_CLASSES=("gt0" "gt2" "gt4" "gt6")
TOTAL=${#GERP_CLASSES[@]}

if [ "$SLURM_ARRAY_TASK_ID" -gt "$TOTAL" ]; then
    echo "ERROR: SLURM_ARRAY_TASK_ID exceeds number of GERP classes"
    exit 1
fi

IDX=$((SLURM_ARRAY_TASK_ID - 1))
GERP_CLASS="${GERP_CLASSES[$IDX]}"
GERP_BED="${GERP_BASE}/merged_${GERP_CLASS}.bed"

if [ ! -f "$GERP_BED" ]; then
    echo "ERROR: GERP BED not found: $GERP_BED"
    exit 1
fi

echo "[$(date)] Processing GERP class: ${GERP_CLASS}"
echo "GERP BED: ${GERP_BED}"

############################################################
# 3. Output directory
############################################################
OUTDIR="./merged_${GERP_CLASS}"
mkdir -p "$OUTDIR"

OUT_VCF="${OUTDIR}/merged_${GERP_CLASS}_snps.vcf.gz"
OUT_SNP_BED="${OUTDIR}/merged_${GERP_CLASS}_snps.bed"
OUT_GERP_BED="${OUTDIR}/merged_${GERP_CLASS}_gerp_regions.bed"

############################################################
# 4. SNP ∩ GERP  (VCF.gz)
############################################################
singularity exec ~/liuliangmin/4.may/software/Reseq_genek.sif \
bcftools view "$VCF" | \
bedtools intersect -a stdin -b <(tail -n +2 "$GERP_BED") -header | \
bgzip -c > "$OUT_VCF"

############################################################
# 5. SNP ∩ GERP  (BED, SNP positions)
############################################################
singularity exec ~/liuliangmin/4.may/software/Reseq_genek.sif \
bcftools view "$VCF" | \
bedtools intersect -a stdin -b <(tail -n +2 "$GERP_BED") | \
awk 'BEGIN{OFS="\t"} !/^#/ {print $1, $2-1, $2, $3}' \
> "$OUT_SNP_BED"

############################################################
# 6. GERP regions overlapped by SNPs (retain GERP scores)
############################################################
singularity exec ~/liuliangmin/4.may/software/Reseq_genek.sif \
bcftools view "$VCF" | \
awk 'BEGIN{OFS="\t"} !/^#/ {print $1, $2-1, $2}' | \
bedtools intersect -a <(tail -n +2 "$GERP_BED") -b stdin -wa \
> "$OUT_GERP_BED"

############################################################
# 7. Summary
############################################################
if [ -s "$OUT_VCF" ]; then
    SNP_N=$(zgrep -vc '^#' "$OUT_VCF")
    echo "DONE: merged_${GERP_CLASS}"
    echo "  SNP count      : $SNP_N"
    echo "  VCF output     : $OUT_VCF"
    echo "  SNP BED        : $OUT_SNP_BED"
    echo "  GERP BED       : $OUT_GERP_BED"
else
    echo "ERROR: empty result for merged_${GERP_CLASS}"
    exit 2
fi
