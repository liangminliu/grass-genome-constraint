#!/bin/bash
#SBATCH --job-name=gerp_snp_intersect
#SBATCH --output=logs/gerp_snp_intersect_%A_%a.log
#SBATCH --error=logs/gerp_snp_intersect_%A_%a.err
#SBATCH --cpus-per-task=10
#SBATCH --mem=60G
#SBATCH --array=1

set -euo pipefail
mkdir -p logs

############################################################
# 0. Singularity TMPDIR（非常重要）
############################################################
WORK_TMP_DIR="$(pwd)/singularity_tmp_${SLURM_JOB_ID}_$$"
export SINGULARITY_TMPDIR="$WORK_TMP_DIR"
export TMPDIR="$WORK_TMP_DIR"
mkdir -p "$WORK_TMP_DIR"
trap 'rm -rf "$WORK_TMP_DIR"' EXIT

SIF=~/liuliangmin/4.may/software/Reseq_genek.sif

############################################################
# 1. Input
############################################################
VCF="141sp.filtered.bi-allelic.snp.vcf.gz"

GERP_BASE="/gpfs/hpc/home/kib_unit/lidezhu/liuliangmin/2.msa/Atau_msa/results/GERP_final_output"
GERP_BED="merged_gt0.bed"
GERP_PATH="${GERP_BASE}/${GERP_BED}"
PREFIX=${GERP_BED%.bed}

OUTDIR="./${PREFIX}"
mkdir -p "$OUTDIR"

OUT_VCF="${OUTDIR}/${PREFIX}_snps.vcf.gz"
OUT_SNP_BED="${OUTDIR}/${PREFIX}_snps.bed"
OUT_GERP_BED="${OUTDIR}/${PREFIX}_gerp_regions.bed"

############################################################
# 2. Step 1: VCF → SNP BED（这是关键修复）
############################################################
echo "[1/3] Converting VCF to SNP BED"

singularity exec "$SIF" \
bcftools view -H "$VCF" | \
awk 'BEGIN{OFS="\t"} {print $1,$2-1,$2,$3}' \
> "$WORK_TMP_DIR/snps.bed"

############################################################
# 3. Step 2: SNP BED ∩ GERP BED
############################################################
echo "[2/3] SNP BED intersect GERP"

bedtools intersect \
  -a "$WORK_TMP_DIR/snps.bed" \
  -b <(awk 'NR>1 {print $1,$2,$3,$5}' OFS="\t" "$GERP_PATH") \
> "$OUT_SNP_BED"

############################################################
# 4. Step 3: 生成 GERP 区域子集（保留 score）
############################################################
bedtools intersect \
  -a <(awk 'NR>1 {print $1,$2,$3,$5}' OFS="\t" "$GERP_PATH") \
  -b "$WORK_TMP_DIR/snps.bed" \
  -wa \
> "$OUT_GERP_BED"

############################################################
# 5. Step 4: BED → VCF（可选，但你原来就要）
############################################################
echo "[3/3] Extracting VCF records"

singularity exec "$SIF" \
bcftools view \
  -R "$OUT_SNP_BED" \
  -Oz \
  -o "$OUT_VCF" \
  "$VCF"

tabix -f -p vcf "$OUT_VCF"

############################################################
# 6. Summary
############################################################
echo "DONE: $PREFIX"
echo "  SNP BED : $(wc -l < "$OUT_SNP_BED")"
echo "  GERP    : $(wc -l < "$OUT_GERP_BED")"
echo "  VCF     : $(zgrep -vc '^#' "$OUT_VCF")"
