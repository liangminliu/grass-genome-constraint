#!/usr/bin/env bash
#BSUB -J step12
#BSUB -q Q96C1T_X12
#BSUB -n 16
#BSUB -o step12.%J.out
#BSUB -e step12.%J.err


set -euo pipefail

# ============================================================
# INPUT
# ============================================================

CNS_TSV="04_tables/CNS_level_GERP_summary_chr.tsv"

BGDIR="07_final_stats/background"

GENOME="${BGDIR}/Zmay_v5.genome"
CHRORDER="${BGDIR}/Zmay_v5.chr.order"
NONCDS="${BGDIR}/Zmay_v5.nonCDS.bed"

# ------------------------------------------------------------
# 修改成你 02_GERP 中真实文件名
# 如果下面文件本身存在，就无需改
# ------------------------------------------------------------

GERP0="02_GERP/GERP_gt0.unique.bed"
GERP2="02_GERP/GERP_gt2.unique.bed"
GERP4="02_GERP/GERP_gt4.unique.bed"
GERP6="02_GERP/GERP_gt6.unique.bed"

# ============================================================
# CHECK
# ============================================================

for f in \
    "$CNS_TSV" \
    "$GENOME" \
    "$CHRORDER" \
    "$NONCDS" \
    "$GERP0" \
    "$GERP2" \
    "$GERP4" \
    "$GERP6"
do
    if [[ ! -s "$f" ]]; then
        echo "[ERROR] Missing file: $f" >&2
        exit 1
    fi
done

# ============================================================
# FUNCTIONS
# ============================================================

bp_sum () {
    awk '{
        s += $3-$2
    }
    END{
        print s+0
    }' "$1"
}

sort_merge_bed () {

    local input="$1"
    local output="$2"

    # 仅保留 genome file 中 chr1-chr10
    awk '
        NR==FNR {
            keep[$1]=1
            next
        }
        ($1 in keep) {
            print
        }
    ' "$CHRORDER" "$input" \
    | bedtools sort \
        -faidx "$CHRORDER" \
        -i - \
    | bedtools merge -i - \
    > "$output"
}

intersection_bp () {

    local A="$1"
    local B="$2"

    bedtools intersect \
        -a "$A" \
        -b "$B" \
        -wo \
    | awk '{
        s += $NF
    }
    END{
        print s+0
    }'
}

# ============================================================
# 1. CNS union
# ============================================================

awk 'BEGIN{FS=OFS="\t"}
     NR>1 {
         print $1,$2,$3
     }' "$CNS_TSV" \
> "${BGDIR}/CNS.raw.bed"

sort_merge_bed \
    "${BGDIR}/CNS.raw.bed" \
    "${BGDIR}/CNS.union.bed"

# ============================================================
# 2. CNS restricted to non-CDS
# ============================================================

bedtools intersect \
    -a "${BGDIR}/CNS.union.bed" \
    -b "$NONCDS" \
> "${BGDIR}/CNS.nonCDS.raw.bed"

sort_merge_bed \
    "${BGDIR}/CNS.nonCDS.raw.bed" \
    "${BGDIR}/CNS.nonCDS.union.bed"

# ============================================================
# 3. non-CNS non-CDS background
# ============================================================

bedtools subtract \
    -a "$NONCDS" \
    -b "${BGDIR}/CNS.nonCDS.union.bed" \
> "${BGDIR}/nonCNS.nonCDS.raw.bed"

sort_merge_bed \
    "${BGDIR}/nonCNS.nonCDS.raw.bed" \
    "${BGDIR}/nonCNS.nonCDS.bed"

# ============================================================
# 4. standardize four GERP catalogs
# ============================================================

sort_merge_bed \
    "$GERP0" \
    "${BGDIR}/GERPgt0.sorted.merged.bed"

sort_merge_bed \
    "$GERP2" \
    "${BGDIR}/GERPgt2.sorted.merged.bed"

sort_merge_bed \
    "$GERP4" \
    "${BGDIR}/GERPgt4.sorted.merged.bed"

sort_merge_bed \
    "$GERP6" \
    "${BGDIR}/GERPgt6.sorted.merged.bed"

# ============================================================
# 5. region sizes
# ============================================================

CNS_BP=$(bp_sum "${BGDIR}/CNS.nonCDS.union.bed")
NONCDS_BP=$(bp_sum "$NONCDS")
NONCNS_BP=$(bp_sum "${BGDIR}/nonCNS.nonCDS.bed")

echo "[INFO] CNS nonCDS bp     = $CNS_BP"
echo "[INFO] total nonCDS bp   = $NONCDS_BP"
echo "[INFO] nonCNS nonCDS bp  = $NONCNS_BP"

# ============================================================
# 6. enrichment
# ============================================================

OUT="${BGDIR}/CNS_vs_noncoding_GERP_enrichment.tsv"

echo -e \
"threshold\tCNS_bp\tnonCDS_bp\tnonCNS_nonCDS_bp\tCNS_GERP_bp\tnonCDS_GERP_bp\tnonCNS_GERP_bp\tCNS_GERP_fraction\tnonCDS_GERP_fraction\tnonCNS_GERP_fraction\tfold_enrichment_vs_nonCDS\tfold_enrichment_vs_nonCNS\tpercent_all_nonCDS_GERP_bp_in_CNS" \
> "$OUT"

for t in 0 2 4 6
do

    G="${BGDIR}/GERPgt${t}.sorted.merged.bed"

    CNS_GERP_BP=$(
        intersection_bp \
        "${BGDIR}/CNS.nonCDS.union.bed" \
        "$G"
    )

    NONCDS_GERP_BP=$(
        intersection_bp \
        "$NONCDS" \
        "$G"
    )

    NONCNS_GERP_BP=$(
        intersection_bp \
        "${BGDIR}/nonCNS.nonCDS.bed" \
        "$G"
    )

    awk \
      -v T="$t" \
      -v CB="$CNS_BP" \
      -v NB="$NONCDS_BP" \
      -v XB="$NONCNS_BP" \
      -v CG="$CNS_GERP_BP" \
      -v NG="$NONCDS_GERP_BP" \
      -v XG="$NONCNS_GERP_BP" \
      'BEGIN{

          OFS="\t"

          fc = (CB>0 ? CG/CB : 0)
          fn = (NB>0 ? NG/NB : 0)
          fx = (XB>0 ? XG/XB : 0)

          enrich_all = (fn>0 ? fc/fn : "NA")
          enrich_non = (fx>0 ? fc/fx : "NA")

          capture = (NG>0 ? 100*CG/NG : "NA")

          print \
              "GERP>"T,
              CB,
              NB,
              XB,
              CG,
              NG,
              XG,
              fc,
              fn,
              fx,
              enrich_all,
              enrich_non,
              capture
      }' \
      >> "$OUT"

done

echo
echo "===== RESULT ====="

column -t -s $'\t' "$OUT"

echo "[DONE]"