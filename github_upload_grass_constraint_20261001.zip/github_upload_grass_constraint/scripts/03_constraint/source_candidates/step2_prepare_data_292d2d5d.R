library(data.table)

# 1. 设置工作目录
target_dir <- "/gpfs/hpc/home/kib_unit/lidezhu/liuliangmin/2.msa/2.3.Atau_result_stat/01.Fig_all_vs_CDS"
setwd(target_dir)
cat("当前工作目录:", getwd(), "\n")

# 2. 定义输入文件路径
cds_dir <- file.path(target_dir, "processed_data")
all_dir <- "/gpfs/hpc/home/kib_unit/lidezhu/liuliangmin/2.msa/Atau_msa/results/gerp/"

# 3. 检查输入目录是否存在
if(!dir.exists(cds_dir)) stop(paste("CDS目录不存在:", cds_dir))
if(!dir.exists(all_dir)) stop(paste("GERP目录不存在:", all_dir))

# 4. 获取输入文件列表
cds_files <- list.files(cds_dir, pattern = "_cds_gerp.bed$", full.names = TRUE)
all_files <- list.files(all_dir, pattern = ".gerp.final.bed$", full.names = TRUE)

# 5. 检查是否找到输入文件
if(length(cds_files) == 0) stop("在processed_data目录中没有找到任何_cds_gerp.bed文件")
if(length(all_files) == 0) stop("在GERP目录中没有找到任何.gerp.final.bed文件")

cat("找到", length(cds_files), "个CDS文件和", length(all_files), "个ALL文件\n")

# 6. 定义输出文件路径
all_output <- file.path(target_dir, "ALL_gerp.tsv")
cds_output <- file.path(target_dir, "CDS_gerp.tsv")

# 7. 清空或创建输出文件（如果已存在则覆盖）
if(file.exists(all_output)) file.remove(all_output)
if(file.exists(cds_output)) file.remove(cds_output)

# 8. 流式处理函数（直接逐文件处理并追加写入结果）
process_and_save <- function(file_list, output_file, is_cds = FALSE) {
  for(file in file_list) {
    cat("正在处理文件:", file, "\n")
    
    # 根据文件类型选择读取方式
    if(is_cds) {
      df <- fread(file, header = FALSE, 
                  col.names = c("chr", "start", "end", "GERP_ExpSubst", "GERP_RejSubstScore", "TaxaAligned"))
    } else {
      df <- fread(file, header = TRUE)
      colnames(df)[1:3] <- c("chr", "start", "end")
    }
    
    # 提取GERP分数并过滤NA值
    df$GERP <- as.numeric(df$GERP_RejSubstScore)
    df <- df[!is.na(GERP), .(GERP)]
    
    # 追加写入结果文件
    fwrite(df, output_file, sep = "\t", append = TRUE)
    
    # 释放内存
    rm(df)
    gc()
  }
}

# 9. 处理ALL数据
cat("\n开始处理ALL数据...\n")
process_and_save(all_files, all_output, is_cds = FALSE)

# 10. 处理CDS数据
cat("\n开始处理CDS数据...\n")
process_and_save(cds_files, cds_output, is_cds = TRUE)

# 11. 验证输出文件
cat("\n处理完成！验证输出文件:\n")
if(file.exists(all_output)) {
  cat("- ALL_gerp.tsv 行数:", nrow(fread(all_output, select = 1L)), "\n")
} else {
  warning("ALL_gerp.tsv 未生成！")
}

if(file.exists(cds_output)) {
  cat("- CDS_gerp.tsv 行数:", nrow(fread(cds_output, select = 1L)), "\n")
} else {
  warning("CDS_gerp.tsv 未生成！")
}

# 12. 可选：生成统计信息（抽样部分数据避免内存问题）
cat("\n生成统计信息（基于抽样）:\n")
sample_stats <- function(file, sample_size = 1e6) {
  if(!file.exists(file)) return(NULL)
  total_lines <- nrow(fread(file, select = 1L))
  if(total_lines <= sample_size) {
    df <- fread(file)
  } else {
    df <- fread(file, nrows = sample_size)
  }
  cat(basename(file), "统计（基于", nrow(df), "/", total_lines, "行）:\n")
  print(summary(df$GERP))
  cat("----------------------------------------\n")
}

#sample_stats(all_output)
#sample_stats(cds_output)

cat("\n脚本执行完毕！输出文件已保存到:\n", all_output, "\n", cds_output, "\n")