#!/bin/bash
#SBATCH --job-name=maf_parallel
#SBATCH --output=maf_parallel.out
#SBATCH --error=maf_parallel.err
#SBATCH --cpus-per-task=40
#SBATCH --partition=parallel

set -euo pipefail

############################################
# 0. 环境初始化（SLURM / HPC 标准写法）
############################################
source /gpfs/hpc/home/kib_unit/lidezhu/miniforge3/etc/profile.d/conda.sh
conda activate /gpfs/hpc/home/kib_unit/lidezhu/miniforge3/envs/cactus

SIF=/gpfs/hpc/home/kib_unit/lidezhu/liuliangmin/4.may/software/Reseq_genek.sif
THREADS=${SLURM_CPUS_PER_TASK}

############################################
# 1. 输入文件（已压缩 VCF）
############################################
vcfC="pedC_gt2_snps.vcf.gz"
vcfD="pedD_gt2_snps.vcf.gz"

############################################
# 2. 检查并补建 tabix 索引
############################################
echo "Checking tabix index for input VCFs ..."

for vcf in ${vcfC} ${vcfD}; do
  if [ ! -f "${vcf}.tbi" ]; then
    echo "Indexing ${vcf} ..."
    tabix -p vcf "${vcf}"
  else
    echo "${vcf}.tbi exists, skip."
  fi
done

############################################
# 3. 合并 pedC + pedD（关键修复点）
#    允许同名染色体（Ped09X）出现
############################################
merged="pedC_pedD_gt2_snps.vcf.gz"
rm -f ${merged} ${merged}.tbi

echo "Merging pedC and pedD VCFs (allowing non-contiguous chromosomes)..."

singularity exec ${SIF} \
  bcftools concat -a \
    -O z \
    -o ${merged} \
    ${vcfC} ${vcfD}

echo "Indexing merged VCF ..."
tabix -p vcf ${merged}

############################################
# 4. 并行计算 Minor Allele Frequency
#    注意：3 个 plink 同时跑，会共享 CPU
############################################
echo "Computing Minor Allele Frequencies (MAF) ..."

singularity exec ${SIF} \
  plink \
    --vcf ${merged} \
    --freq \
    --out pedC_pedD_gt2_maf \
    --allow-extra-chr \
    --snps-only \
    --threads ${THREADS} &

singularity exec ${SIF} \
  plink \
    --vcf ${vcfC} \
    --freq \
    --out pedC_gt2_maf \
    --allow-extra-chr \
    --snps-only \
    --threads ${THREADS} &

singularity exec ${SIF} \
  plink \
    --vcf ${vcfD} \
    --freq \
    --out pedD_gt2_maf \
    --allow-extra-chr \
    --snps-only \
    --threads ${THREADS} &

wait

############################################
# 5. 完成提示
############################################
echo "All MAF calculations finished successfully."
echo "Generated files:"
echo "  pedC_gt2_maf.frq"
echo "  pedD_gt2_maf.frq"
echo "  pedC_pedD_gt2_maf.frq"
