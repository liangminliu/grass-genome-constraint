library(data.table)

# 路径设置
cds_files <- list.files("processed_data", pattern = "_cds_gerp.bed$", full.names = TRUE)
all_files <- list.files("/gpfs/hpc/home/kib_unit/lidezhu/liuliangmin/2.msa/84sp_ped/94sp_ped_results/gerp", 
                        pattern = ".gerp.final.bed$", full.names = TRUE)

# ALL 数据
all_data <- rbindlist(lapply(all_files, function(file) {
  df <- fread(file, header = TRUE)
  colnames(df)[1:3] <- c("chr", "start", "end")
  df$GERP <- as.numeric(df$GERP_RejSubstScore)
  df <- df[!is.na(GERP), .(GERP)]
  return(df)
}))
fwrite(all_data, "ALL_gerp.tsv", sep = "\t")

# CDS 分为 C 和 D 区
cds_data_C <- cds_data_D <- list()

for (file in cds_files) {
  sample_name <- gsub("processed_data/|_cds_gerp.bed", "", file)
  # 修改这里：指定6列的名称
  chr_data <- fread(file, header = FALSE, 
                   col.names = c("chr", "start", "end", "GERP_ExpSubst", "GERP_RejSubstScore", "TaxaAligned"))

  if (sample_name == "Ped09X") {
    c_range <- 58257726
    cds_data_C[[sample_name]] <- chr_data[start >= c_range]
    cds_data_D[[sample_name]] <- chr_data[start < c_range]
  } else if (grepl("C$", sample_name)) {
    cds_data_C[[sample_name]] <- chr_data
  } else if (grepl("D$", sample_name)) {
    cds_data_D[[sample_name]] <- chr_data
  }
}

# 保存 C 和 D CDS
c_cds <- rbindlist(cds_data_C)[, .(GERP_RejSubstScore)]
d_cds <- rbindlist(cds_data_D)[, .(GERP_RejSubstScore)]
# 修改列名保持一致
setnames(c_cds, "GERP_RejSubstScore", "GERP")
setnames(d_cds, "GERP_RejSubstScore", "GERP")
fwrite(c_cds, "C_CDS_gerp.tsv", sep = "\t")
fwrite(d_cds, "D_CDS_gerp.tsv", sep = "\t")