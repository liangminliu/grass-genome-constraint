#!/bin/bash
#SBATCH --job-name=bedtools_intersect
#SBATCH --output=logs/bedtools_intersect_%A_%a.log
#SBATCH --error=logs/bedtools_intersect_%A_%a.err
#SBATCH --cpus-per-task=4
#SBATCH --array=1-10%10

# 创建日志目录
mkdir -p logs

# VCF文件
VCF="71sp.filtered.bi-allelic.snp.vcf.gz"
RENAMED_VCF="71sp.filtered.bi-allelic.snp.rename.vcf.gz"

# 基础目录
BASE_DIR="/gpfs/hpc/home/kib_unit/lidezhu/liuliangmin/2.msa/84sp_ped/94sp_ped_results/GERPnew_output"

# 获取所有BED文件列表
BED_FILES=($(find $BASE_DIR -name "ped*.clean.bed" | sort))
TOTAL_FILES=${#BED_FILES[@]}

# 下标检查
if [ "$SLURM_ARRAY_TASK_ID" -gt "$TOTAL_FILES" ]; then
    echo "SLURM_ARRAY_TASK_ID ($SLURM_ARRAY_TASK_ID) exceeds number of BED files ($TOTAL_FILES)"
    exit 1
fi

# 当前任务的BED文件
BED_FILE=${BED_FILES[$SLURM_ARRAY_TASK_ID-1]}

# 结果目录结构
RELATIVE_PATH=$(realpath --relative-to=$BASE_DIR $(dirname $BED_FILE))
OUTPUT_DIR="./${RELATIVE_PATH}"
mkdir -p "$OUTPUT_DIR"

# 输出文件名
BED_BASENAME=$(basename "$BED_FILE" .bed)
OUTPUT_VCF="${OUTPUT_DIR}/${BED_BASENAME}_snps.vcf"
OUTPUT_BED="${OUTPUT_DIR}/${BED_BASENAME}_snps.bed"
OUTPUT_GERP_BED="${OUTPUT_DIR}/${BED_BASENAME}_gerp_regions.bed"

echo "$(date): 正在处理: $BED_FILE"

# 1. 提取重叠的SNP (VCF格式)
singularity exec ~/liuliangmin/4.may/software/Reseq_genek.sif bcftools view "$RENAMED_VCF" | \
bedtools intersect -a stdin -b "$BED_FILE" -header > "$OUTPUT_VCF"

# 2. 提取重叠的SNP位点 (BED格式)
singularity exec ~/liuliangmin/4.may/software/Reseq_genek.sif bcftools view "$RENAMED_VCF" | \
bedtools intersect -a stdin -b "$BED_FILE" | \
awk 'BEGIN{OFS="\t"} !/^#/ {print $1, $2-1, $2, $3}' > "$OUTPUT_BED"

# 3. 提取对应的GERP区间信息 (保留GERP分数)
bedtools intersect -a "$BED_FILE" -b <(singularity exec ~/liuliangmin/4.may/software/Reseq_genek.sif bcftools view "$RENAMED_VCF" | awk 'BEGIN{OFS="\t"} !/^#/ {print $1, $2-1, $2}') -wa > "$OUTPUT_GERP_BED"

# 检查输出文件
if [ -s "$OUTPUT_VCF" ]; then
    echo "成功处理: $BED_FILE"
    echo "VCF结果: $OUTPUT_VCF ($(grep -v '^#' "$OUTPUT_VCF" | wc -l) SNPs)"
    echo "BED结果: $OUTPUT_BED"
    echo "GERP区间: $OUTPUT_GERP_BED"
else
    echo "处理失败: $BED_FILE"
    exit 2
fi