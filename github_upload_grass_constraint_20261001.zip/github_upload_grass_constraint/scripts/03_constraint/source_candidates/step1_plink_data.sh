#!/bin/bash
#SBATCH --job-name=KING_DIRECT_VCF
#SBATCH --output=king_direct.%j.out
#SBATCH --error=king_direct.%j.err
#SBATCH --cpus-per-task=10
#SBATCH -p FAT2

# ===== 关键配置 =====
CONTAINER="../../../4.may/software/Reseq_genek.sif"
SOURCE_VCF="./all.filtered.snp.vcf.gz"

# ===== 1. 创建染色体映射文件 =====
cat > chrom_map.txt <<EOF
Ped04D 1
Ped01D 2
Ped03D 3
Ped01C 4
Ped09X 5
Ped02D 6
Ped03C 7
Ped11D 8
Ped06C 9
Ped06D 10
Ped07D 11
Ped08D 12
Ped09C 13
Ped05D 14
Ped07C 15
Ped02C 16
Ped04C 17
Ped10C 18
Ped08C 19
Ped12C 20
Ped05C 21
Ped12D 22
Ped11C 23
Ped10D 24
EOF

# ===== 2. 直接重命名并输出VCF =====
echo "===== 正在重命名染色体并输出VCF ====="
singularity exec ../../../4.may/software/Reseq_genek.sif   bcftools annotate --rename-chrs chrom_map.txt $SOURCE_VCF -Ou | singularity exec ../../../4.may/software/Reseq_genek.sif bcftools view -O z -o filtered_chrom.vcf.gz

# 索引新VCF文件
singularity exec $CONTAINER bcftools index filtered_chrom.vcf.gz

# ===== 3. 转换为PLINK格式 =====
echo "===== 转换为PLINK格式 ====="
singularity exec $CONTAINER plink --vcf filtered_chrom.vcf.gz \
    --geno 0.05 \
    --maf 0.0001 \
    --allow-extra-chr \
    --chr-set 24 \
    --make-bed \
    --out king_direct



# ===== 4. 结果报告 =====
echo "===== 分析结果 ====="
echo "样本数: $(wc -l < king_direct.fam)"
echo "SNP总数: $(wc -l < king_direct.bim)"
