#!/bin/bash
#SBATCH --job-name=KING_DIRECT_VCF
#SBATCH --output=king.%j.out
#SBATCH --error=king.%j.err
#SBATCH --cpus-per-task=30
#SBATCH -p parallel

CONTAINER=~/liuliangmin/4.may/software/Reseq_genek.sif

# ===== 2. 转换为PLINK格式 =====
echo "===== 转换为PLINK格式 ====="
singularity exec $CONTAINER plink --vcf extracted_429sp_maize.vcf.gz \
    --allow-extra-chr \
    --chr-set 10 \
    --double-id \
    --make-bed \
    --out king_direct \
    --threads 20

echo "===== 运行KING分析 ====="
./king -b king_direct.bed --unrelated --degree 1 --prefix maize_unrelatedD1 --cpus 10 --sexchr 11 &
./king -b king_direct.bed -prefix maize_king_directD1 --build --degree 1 --rplot --sexchr 11 &


./king -b king_direct.bed --unrelated --degree 2 --prefix maize_unrelatedD2 --cpus 10 --sexchr 11  &
./king -b king_direct.bed --related --degree 2 --prefix maize_relatedD2 --cpus 10 --sexchr 11  &
wait
echo "===== 处理完成 ====="

