#!/bin/bash
# 查找所有sbatch脚本并提交
find . -maxdepth 1 -name "haplotype_scripts/HC5_*.sbatch" | while read script; do
    echo "正在提交：${script}"
    sbatch ${script}
done
echo "监控命令："
echo "watch -n 30 'squeue -u \$(whoami) -o \"%.18i %.9P %.30j %.8u %.8T %.10M %.9l %.6D %R %S\"'"
