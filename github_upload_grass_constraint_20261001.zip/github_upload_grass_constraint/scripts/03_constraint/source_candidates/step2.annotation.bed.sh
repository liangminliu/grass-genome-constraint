#!/bin/bash
#SBATCH --job-name=functional_intersect
#SBATCH --output=logs/functional_intersect_%A_%a.log
#SBATCH --error=logs/functional_intersect_%A_%a.err
#SBATCH --cpus-per-task=4
#SBATCH --array=1-4%4

set -euo pipefail
mkdir -p logs

# ============================================================
# Parameters
# ============================================================

BASE_DIR="../03.deletrious/02.stat_deleterious"

GERP_CLASSES=("gt0" "gt2" "gt4" "gt6")

FUNCTIONAL_BEDS=(
  missense.bed
  synonymous.bed
  stop_gained.bed
  stop_lost.bed
  start_lost.bed
)

IDX=$((SLURM_ARRAY_TASK_ID - 1))
GERP_CLASS="${GERP_CLASSES[$IDX]}"

GERP_RAW="${BASE_DIR}/merged_${GERP_CLASS}/merged_${GERP_CLASS}_gerp_regions.bed"

OUT_DIR="functional_analysis/merged_${GERP_CLASS}"
mkdir -p "$OUT_DIR"

# ============================================================
# Checks
# ============================================================

[[ -f "$GERP_RAW" ]] || { echo "ERROR: $GERP_RAW not found"; exit 1; }

for b in "${FUNCTIONAL_BEDS[@]}"; do
    [[ -f "$b" ]] || { echo "ERROR: missing $b"; exit 1; }
done

# ============================================================
# Prepare GERP BED (chr start end only)
# ============================================================

GERP_BED="${OUT_DIR}/merged_${GERP_CLASS}_gerp_sites.bed"
awk 'BEGIN{OFS="\t"} {print $1,$2,$3}' "$GERP_RAW" > "$GERP_BED"

# ============================================================
# Intersections
# ============================================================

for FUNC in "${FUNCTIONAL_BEDS[@]}"; do
    NAME=$(basename "$FUNC" .bed)

    echo "==> ${GERP_CLASS} × ${NAME}"

    # 位点级：GERP 位点 ∩ functional 区域
    OUT_SITE="${OUT_DIR}/merged_${GERP_CLASS}_${NAME}_sites.bed"

    bedtools intersect \
      -a "$GERP_BED" \
      -b "$FUNC" \
      -wa > "$OUT_SITE"

    [[ -s "$OUT_SITE" ]] || rm -f "$OUT_SITE"

    # 区域级：被命中的 functional 区域
    OUT_REGION="${OUT_DIR}/merged_${GERP_CLASS}_${NAME}_func_regions.bed"

    bedtools intersect \
      -a "$FUNC" \
      -b "$GERP_BED" \
      -wa > "$OUT_REGION"

    [[ -s "$OUT_REGION" ]] || rm -f "$OUT_REGION"

done

echo "ALL DONE: ${GERP_CLASS}"
