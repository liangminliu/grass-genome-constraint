#!/usr/bin/env bash
#BSUB -q Q96C1T_X12
#BSUB -n 8
#BSUB -J Hopscotch_GERP
#BSUB -o Hopscotch_GERP_%J.out
#BSUB -e Hopscotch_GERP_%J.err

set -euo pipefail

# ============================================================
# INPUT
# ============================================================

HOP="05_TB1/Hopscotch_v5.bed"

BGDIR="07_final_stats/background"

# Detailed P1-P12 publication table
PUBTAB="05_TB1/TB1_P1_P12_GERP_publication_table.tsv"

# P1-P6 versus P7-P12 summary table
CLUSTAB="05_TB1/TB1_P1P6_vs_P7P12_GERP_summary.tsv"

TMPDIR="tmp/Hopscotch_update"
mkdir -p "${TMPDIR}"

# ============================================================
# QC
# ============================================================

for f in \
    "${HOP}" \
    "${BGDIR}/GERPgt0.sorted.merged.bed" \
    "${BGDIR}/GERPgt2.sorted.merged.bed" \
    "${BGDIR}/GERPgt4.sorted.merged.bed" \
    "${BGDIR}/GERPgt6.sorted.merged.bed" \
    "${PUBTAB}" \
    "${CLUSTAB}"
do
    if [[ ! -s "${f}" ]]; then
        echo "[ERROR] Missing or empty file: ${f}" >&2
        exit 1
    fi
done

N=$(wc -l < "${HOP}")

if [[ "${N}" -ne 1 ]]; then
    echo "[ERROR] ${HOP} must contain exactly one Hopscotch interval." >&2
    echo "[ERROR] Current number of lines: ${N}" >&2
    exit 1
fi

# ============================================================
# Hopscotch coordinates
# ============================================================

CHR=$(awk 'NR==1{print $1}' "${HOP}")
START=$(awk 'NR==1{print $2}' "${HOP}")
END=$(awk 'NR==1{print $3}' "${HOP}")
STRAND=$(awk 'NR==1{print $6}' "${HOP}")

LEN=$((END - START))

echo "[INFO] Hopscotch:"
echo "       ${CHR}:${START}-${END}"
echo "       length = ${LEN} bp"

if [[ "${LEN}" -ne 4884 ]]; then
    echo "[WARNING] Hopscotch length is ${LEN}, expected 4884 bp."
fi

# ============================================================
# Function: overlap bp
# ============================================================

overlap_bp () {

    local GERP="$1"

    bedtools intersect \
        -a "${HOP}" \
        -b "${GERP}" \
        -wo \
    | awk '
        {
            s += $NF
        }
        END {
            print s+0
        }
    '
}

# ============================================================
# GERP overlap
# ============================================================

G0=$(overlap_bp "${BGDIR}/GERPgt0.sorted.merged.bed")
G2=$(overlap_bp "${BGDIR}/GERPgt2.sorted.merged.bed")
G4=$(overlap_bp "${BGDIR}/GERPgt4.sorted.merged.bed")
G6=$(overlap_bp "${BGDIR}/GERPgt6.sorted.merged.bed")

F0=$(awk -v x="${G0}" -v L="${LEN}" 'BEGIN{print x/L}')
F2=$(awk -v x="${G2}" -v L="${LEN}" 'BEGIN{print x/L}')
F4=$(awk -v x="${G4}" -v L="${LEN}" 'BEGIN{print x/L}')
F6=$(awk -v x="${G6}" -v L="${LEN}" 'BEGIN{print x/L}')

G60_0=$(awk -v x="${F0}" 'BEGIN{print (x>=0.60 ? "YES":"NO")}')
G60_2=$(awk -v x="${F2}" 'BEGIN{print (x>=0.60 ? "YES":"NO")}')
G60_4=$(awk -v x="${F4}" 'BEGIN{print (x>=0.60 ? "YES":"NO")}')
G60_6=$(awk -v x="${F6}" 'BEGIN{print (x>=0.60 ? "YES":"NO")}')

echo
echo "============================================================"
echo "Hopscotch GERP result"
echo "============================================================"

printf "%-10s %-10s %-12s %-10s\n" \
    "Threshold" "GERP_bp" "Fraction" ">=60%"

printf "%-10s %-10s %-12s %-10s\n" \
    "GERP>0" "${G0}" "${F0}" "${G60_0}"

printf "%-10s %-10s %-12s %-10s\n" \
    "GERP>2" "${G2}" "${F2}" "${G60_2}"

printf "%-10s %-10s %-12s %-10s\n" \
    "GERP>4" "${G4}" "${F4}" "${G60_4}"

printf "%-10s %-10s %-12s %-10s\n" \
    "GERP>6" "${G6}" "${F6}" "${G60_6}"

# ============================================================
# PART 1
# Add Hopscotch to detailed TB1 publication table
#
# Existing columns:
#
# P_element
# TB1_cluster
# CNS_name
# chr
# start0
# end
# length_bp
# relative_mid_kb
# species_count
# node
# level
# GERPgt0_bp
# GERPgt0_fraction
# GERPgt2_bp
# GERPgt2_fraction
# GERPgt4_bp
# GERPgt4_fraction
# GERPgt6_bp
# GERPgt6_fraction
# RS_positive_n
# RS_positive_mean
# RS_positive_median
# RS_positive_min
# RS_positive_max
#
# Hopscotch is not a Conservatory CNS, therefore:
# species_count = NA
# node          = NA
# RS values     = NA
#
# ============================================================

# TB1 start coordinate inferred from your P-element relative coordinates.
# From P6:
# midpoint ~272266941.5
# relative_mid = -63.6215 kb
# TB1 reference point = 272330563
TB1_REF=272330563

MID=$(awk -v S="${START}" -v E="${END}" 'BEGIN{print (S+E)/2}')

REL_MID_KB=$(awk \
    -v M="${MID}" \
    -v T="${TB1_REF}" \
    'BEGIN{
        printf "%.6f",(M-T)/1000
    }'
)

# Remove any previous Hopscotch row so rerunning script is safe
awk 'BEGIN{FS=OFS="\t"}
     NR==1 || $1!="Hopscotch"' \
    "${PUBTAB}" \
> "${TMPDIR}/publication.noHopscotch.tsv"

# Append Hopscotch
awk \
    -v chr="${CHR}" \
    -v s="${START}" \
    -v e="${END}" \
    -v L="${LEN}" \
    -v rel="${REL_MID_KB}" \
    -v g0="${G0}" \
    -v f0="${F0}" \
    -v g2="${G2}" \
    -v f2="${F2}" \
    -v g4="${G4}" \
    -v f4="${F4}" \
    -v g6="${G6}" \
    -v f6="${F6}" \
    'BEGIN{
        OFS="\t"

        print \
            "Hopscotch", \
            "intercluster_TE", \
            "hopscotch_AC209396_10229", \
            chr, \
            s, \
            e, \
            L, \
            rel, \
            "NA", \
            "NA", \
            "LTR/Copia", \
            g0, \
            f0, \
            g2, \
            f2, \
            g4, \
            f4, \
            g6, \
            f6, \
            "NA", \
            "NA", \
            "NA", \
            "NA", \
            "NA"
    }' \
>> "${TMPDIR}/publication.noHopscotch.tsv"

mv \
    "${TMPDIR}/publication.noHopscotch.tsv" \
    "${PUBTAB}"

# ============================================================
# PART 2
# Add Hopscotch to existing P1-P6 / P7-P12 summary table
#
# Columns:
#
# TB1_cluster
# N_CNS
# total_CNS_bp
# median_CNS_length_bp
# median_species_count
# mean_species_count
# nodes
# GERPgt0_bp
# GERPgt0_fraction_weighted
# GERPgt2_bp
# GERPgt2_fraction_weighted
# GERPgt4_bp
# GERPgt4_fraction_weighted
# GERPgt6_bp
# GERPgt6_fraction_weighted
# median_of_CNS_RS_positive_median
#
# Hopscotch is not a CNS. We retain the existing schema but
# use N_CNS=0 to make this explicit.
# ============================================================

awk 'BEGIN{FS=OFS="\t"}
     NR==1 || $1!="Hopscotch_TE"' \
    "${CLUSTAB}" \
> "${TMPDIR}/cluster.noHopscotch.tsv"

awk \
    -v L="${LEN}" \
    -v g0="${G0}" \
    -v f0="${F0}" \
    -v g2="${G2}" \
    -v f2="${F2}" \
    -v g4="${G4}" \
    -v f4="${F4}" \
    -v g6="${G6}" \
    -v f6="${F6}" \
    'BEGIN{
        OFS="\t"

        print \
            "Hopscotch_TE", \
            0, \
            L, \
            L, \
            "NA", \
            "NA", \
            "NA", \
            g0, \
            f0, \
            g2, \
            f2, \
            g4, \
            f4, \
            g6, \
            f6, \
            "NA"
    }' \
>> "${TMPDIR}/cluster.noHopscotch.tsv"

mv \
    "${TMPDIR}/cluster.noHopscotch.tsv" \
    "${CLUSTAB}"

# ============================================================
# PART 3
# QC: verify column numbers
# ============================================================

PUB_NCOL=$(awk -F'\t' 'NR==1{print NF}' "${PUBTAB}")

awk \
    -F'\t' \
    -v n="${PUB_NCOL}" \
    'NF!=n{
        print "[ERROR] publication table bad column count at line",NR, \
              "expected",n,"observed",NF > "/dev/stderr"
        bad=1
    }
    END{
        if(bad) exit 1
    }' \
    "${PUBTAB}"

CLU_NCOL=$(awk -F'\t' 'NR==1{print NF}' "${CLUSTAB}")

awk \
    -F'\t' \
    -v n="${CLU_NCOL}" \
    'NF!=n{
        print "[ERROR] cluster table bad column count at line",NR, \
              "expected",n,"observed",NF > "/dev/stderr"
        bad=1
    }
    END{
        if(bad) exit 1
    }' \
    "${CLUSTAB}"

# ============================================================
# FINAL DISPLAY
# ============================================================

echo
echo "============================================================"
echo "Updated detailed publication table"
echo "============================================================"

{
    head -1 "${PUBTAB}"
    grep '^Hopscotch' "${PUBTAB}"
} | column -t -s $'\t'

echo
echo "============================================================"
echo "Updated TB1 cluster summary"
echo "============================================================"

column -t -s $'\t' "${CLUSTAB}"

echo
echo "[DONE]"
echo "[UPDATED] ${PUBTAB}"
echo "[UPDATED] ${CLUSTAB}"

rm -rf "${TMPDIR}"

