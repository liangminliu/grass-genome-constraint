############################################################
## GERP>2 pie plots – multi-species (single PDF, one legend)
## Input : all_gt2_CDS.tsv
## Output: GERP_gt2_species_pies.pdf
############################################################

library(ggplot2)
library(dplyr)
library(readr)
library(patchwork)
library(tidyr)

## =========================================================
## 1. Region colors & fixed order (publication-safe gray scale)
## =========================================================
region_levels <- c(
  "CDS",
  "Intron",
  "UTR",
  "UpDown5K",
  "Inter-genic"
)

region_colors <- c(
  "CDS"         = "#2F2F2F",
  "Intron"      = "#7A7A7A",
  "UTR"         = "#A6A6A6",
  "UpDown5K"    = "#C8C8C8",
  "Inter-genic" = "#F0F0F0"
)

## =========================================================
## 2. Read & clean input data
## =========================================================
df <- read_tsv(
  "all_gt2_CDS.tsv",
  col_names = c("species", "region", "count"),
  col_types = "ccc"
)

## 去掉千分位逗号并转数值
df <- df %>%
  mutate(
    count  = as.numeric(gsub(",", "", count)),
    region = factor(region, levels = region_levels)
  )

## =========================================================
## 3. Percentage calculation per species
## =========================================================
df_base <- df %>%
  group_by(species) %>%
  mutate(
    total   = sum(count),
    frac    = count / total,
    percent = frac * 100
  ) %>%
  ungroup()

## =========================================================
## 4. Single pie plot function
## =========================================================
plot_one_species <- function(sp) {

  d <- df_base %>%
    filter(species == sp) %>%
    complete(
      region = factor(region_levels, levels = region_levels),
      fill   = list(count = 0, frac = 0, percent = 0)
    ) %>%
    arrange(region) %>%
    mutate(
      ymax = cumsum(frac),
      ymin = lag(ymax, default = 0),
      mid  = (ymin + ymax) / 2
    )

  ggplot(d, aes(ymax = ymax, ymin = ymin, xmax = 1, xmin = 0, fill = region)) +
    geom_rect(color = "black", linewidth = 0.4) +
    coord_polar(theta = "y") +
    geom_segment(
      aes(x = 1, xend = 1.06, y = mid, yend = mid),
      linewidth = 0.35
    ) +
    geom_text(
      aes(x = 1.12, y = mid, label = paste0(round(percent), "%")),
      size = 3
    ) +
    scale_fill_manual(values = region_colors, drop = FALSE) +
    labs(title = sp) +
    theme_void() +
    theme(
      plot.title      = element_text(size = 13, hjust = 0.5, face = "bold"),
      legend.position = "none"
    )
}

## =========================================================
## 5. Build multi-species layout
## =========================================================
species_order <- c("P.edulis", "Z.may", "A.tauschii")

plots <- lapply(species_order, plot_one_species)

final_plot <- wrap_plots(plots, ncol = 3) +
  plot_layout(guides = "collect") &
  theme(
    legend.position = "right",
    legend.title    = element_blank()
  )

## =========================================================
## 6. Save figure
## =========================================================
ggsave(
  "GERP_gt2_species_pies.pdf",
  final_plot,
  width  = 12,
  height = 4
)

final_plot
