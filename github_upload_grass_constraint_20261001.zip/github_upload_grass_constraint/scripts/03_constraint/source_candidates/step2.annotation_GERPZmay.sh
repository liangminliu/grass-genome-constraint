#!/bin/bash
#BSUB -J step2.annotation_GERPZmay
#BSUB -q Q96C1T_X12
#BSUB -n 20
#BSUB -o logs/step2.annotation_GERPZmay.%J.out
#BSUB -e logs/step2.annotation_GERPZmay.%J.err

set -euo pipefail

mkdir -p logs
mkdir -p GERP_del

########################################
# Input / output
########################################
VCF_IN="GERP_del/merged_gt4_snps.vcf.gz"
VCF_OUT="GERP_del/merged_gt4.snp.ann.vcf"
CSV_OUT="GERP_del/Zmay_gt4.csv"
HTML_OUT="GERP_del/Zmay_gt4.html"

########################################
# snpEff settings
########################################
SIF="$HOME/workspace/4.reseq-chr/software/Reseq_genek.sif"
CONFIG="./snpEff.config"
GENOME_DB="Zmay"   # 如果你在 snpEff.config 里定义的名字不是 Zmay，这里改成实际 genome ID

########################################
# Check input
########################################
[[ -f "${VCF_IN}" ]] || { echo "[ERROR] Input not found: ${VCF_IN}"; exit 1; }

echo "[INFO] Start: $(date)"
echo "[INFO] Input : ${VCF_IN}"
echo "[INFO] Output: ${VCF_OUT}"
echo "[INFO] DB    : ${GENOME_DB}"

singularity exec "${SIF}" \
  java -Xmx200g -jar /opt/snpEff/snpEff.jar \
  -c "${CONFIG}" \
  -ud 5000 \
  -csvStats "${CSV_OUT}" \
  -htmlStats "${HTML_OUT}" \
  -o vcf \
  "${GENOME_DB}" \
  "${VCF_IN}" \
  > "${VCF_OUT}" 

echo "[INFO] Done: $(date)"


bgzip -f all.filtered.bi-allelic.miss0.5.snp.ann.vcf 
tabix -f -p vcf all.filtered.bi-allelic.miss0.5.snp.ann.vcf.gz

bgzip -f  $VCF_OUT
tabix -f -p vcf $VCF_OUT

