# Moso bamboo conserved-site phylogenetic support — direct 97-MAF workflow

## 1. Purpose

This workflow replaces the previous step that physically generated a 94-species MAF.
It reads the original 97-species `roast.maf` directly and excludes the three Poales
outgroups (`Ssto`, `Acom`, `Jeff`) **in memory** when each MAF block is analyzed.

No `94.maf` file is created.

The retained analysis universe is therefore:

- 97 taxa in the original ROADIES tree / original MAF
- minus `Ssto`, `Acom`, `Jeff`
- = 94 grass taxa
- reference taxon = `ped`
- primary species breadth = aligned non-reference grass taxa = 0..93
- `n_all_grass` = aligned grass taxa including `ped` = 1..94 for normal mapped sites

## 2. Project paths

Working directory:

```bash
/ds3200_1/users_root/liuliangmin/workspace/PHD/2.msa/2.2.ped_result_stat/2.2.constrain_stat
```

Existing feature inputs:

```text
intersect_results/gerp_gt0/
intersect_results/gerp_gt2/
intersect_results/gerp_gt4/
intersect_results/gerp_gt6/
```

Each threshold contains `pedC` and `pedD` files for:

```text
CDS_jcvi
five_prime_UTR
genes
intergenic_final
introns
ped_chr_0-fold_sites
ped_chr_4-fold_sites
promoters
TE
three_prime_UTR
updown5k
```

Input BED column 6 is retained as `source_n_species` for QC only. The final grass
support count is recomputed from the MAF.

Original MAF:

```bash
/ds3200_1/users_root/liuliangmin/workspace/PHD/2.msa/84sp_ped/97sp_ped.results/roast/roast.maf
```

ROADIES tree:

```bash
/ds3200_1/users_root/liuliangmin/workspace/PHD/run97/treePL/ROADIES_treePL_LSF/01_ROADIES97_rooted_substitutions_per_site.nwk
```

If either absolute path differs on the cluster, edit only `config.sh`.

## 3. Definitions

For every target reference site:

1. Read the corresponding alignment column from the original 97-species MAF.
2. Ignore `Ssto`, `Acom`, and `Jeff` completely for the final grass statistics.
3. A retained taxon is represented only when its MAF character is A/C/G/T.
   Gap and ambiguous bases are missing.
4. `n_nonref_grass` = number of represented grass taxa excluding `ped`.
   This is the primary `species breadth`, with a theoretical maximum of 93.
5. `n_all_grass` = represented retained grass taxa including `ped`.
6. `deepest node` = deepest node on the `ped`-to-root path required to contain
   the reference and all represented non-reference grass taxa.
7. `node occupancy` = `n_all_grass / n_descendant_grasses(deepest node)`.

The original BED-column-6 count is compared with the new `n_nonref_grass` value.
If the original count was produced from all 97 MAF taxa, `source_n - n_nonref_grass`
will commonly be 0..3 depending on whether the three excluded outgroups had A/C/G/T.
Therefore a non-zero mismatch is not automatically an error in this new workflow.

## 4. Why no 94-MAF is needed

The parser does not alter or rewrite the MAF. For each MAF block it:

- identifies the `ped` reference row;
- maps the requested genomic positions to MAF columns;
- uses only the 94 retained grass taxa when building the presence matrix;
- calculates support statistics for target sites only.

A small reference-path table is derived from the 97-tip tree after ignoring the
three excluded outgroups. This is tree metadata, not a new MAF.

## 5. Install

Place this directory at:

```bash
cd /ds3200_1/users_root/liuliangmin/workspace/PHD/2.msa/2.2.ped_result_stat/2.2.constrain_stat
mkdir -p Ped94_from97MAF_pipeline
# copy the package files into Ped94_from97MAF_pipeline/
cd Ped94_from97MAF_pipeline
```

Check `config.sh`, especially `MAF`, `TREE`, and `SCRIPT_DIR`.

Python requirement:

```bash
python3 -c 'import numpy; print(numpy.__version__)'
```

## 6. Run

### Recommended: submit all jobs with dependencies

```bash
cd /ds3200_1/users_root/liuliangmin/workspace/PHD/2.msa/2.2.ped_result_stat/2.2.constrain_stat/Ped94_from97MAF_pipeline
bash submit_pipeline.sh "$PWD/config.sh"
```

### Or run each stage manually

```bash
bsub -env "all,CONFIG=$PWD/config.sh" < 00_prepare_targets.bsub
```

After it finishes:

```bash
bsub -env "all,CONFIG=$PWD/config.sh" < 01_parse_97maf.bsub
```

After it finishes:

```bash
bsub -env "all,CONFIG=$PWD/config.sh" < 02_summarize_support.bsub
```

## 7. Stage 1 — prepare target sites

`00_prepare_targets.sh` does two things:

1. Deduplicates coordinates within every threshold/subgenome/feature BED while
   retaining the first column-6 source count.
2. Builds the union of all `GERP >0` feature coordinates. Because >2, >4 and >6
   are nested subsets of >0, only this union needs to be looked up in the MAF.

Outputs:

```text
Ped94_phylogenetic_support_from97MAF/
├── dedup/gt0..gt6/
├── targets/gt0_all_features.unique.bed
├── targets/by_chr/*.positions.npy
└── qc/dedup_input_qc.tsv
```

The script aborts if a feature BED moves backwards within a chromosome or a
chromosome reappears later in the same file.

## 8. Stage 2 — parse original 97-MAF

`01_parse_97maf.py` scans the original MAF once and calculates support only at
requested target coordinates.

Main outputs:

```text
support_npz/<chrom>.support.npz
tree/ped.reference_path.tsv
tree/retained_grass_taxa.txt
tree/excluded_outgroups.txt
qc/ROADIES97_vs_MAF.validation.tsv
qc/support_by_chrom.tsv
analysis_definition.json
```

### Required validation

```bash
cat Ped94_phylogenetic_support_from97MAF/qc/ROADIES97_vs_MAF.validation.tsv
```

Expected core values:

```text
tree_tips                     97
retained_grass_tree_tips      94
observed_maf_taxa             97
observed_retained_grass_taxa  94
observed_excluded_taxa        Acom,Jeff,Ssto   # sorted order
reference_taxon               ped
```

Because this workflow reads the original 97-MAF, `tree_not_maf` should normally
be empty. This differs from the old 97-tree-vs-94-MAF validation.

Then inspect:

```bash
cat Ped94_phylogenetic_support_from97MAF/qc/support_by_chrom.tsv
```

`max_n_nonref` must never exceed 93; `max_n_all` must never exceed 94.

## 9. Stage 3 — summarize all features and thresholds

`02_summarize_support.py` joins each deduplicated feature set back to the MAF-derived
support arrays and generates separate results for:

- `whole`
- `pedC`
- `pedD`

### Species-breadth histograms

Example:

```text
species_support/whole/raw_hist/gt0.4-fold_sites.hist.tsv
```

Columns:

```text
threshold  feature  n_species  n_sites
```

Here `n_species` means `n_nonref_grass`; therefore the maximum possible value is 93.
This is the table to compare directly with the goatgrass `...hist.tsv` results.

### Deepest-node statistics

Example:

```text
phylogenetic_support/whole/raw_node_hist/gt2.CDS.node_hist.tsv
```

### Occupancy distributions

Example:

```text
phylogenetic_support/whole/raw_occupancy_pairs/gt2.CDS.occupancy_pairs.tsv
```

### Feature summaries

```text
summary/whole/feature_support_summary.tsv
summary/pedC/feature_support_summary.tsv
summary/pedD/feature_support_summary.tsv
```

The main GERP>2 node table is:

```text
summary/whole/GERPgt2.phylogenetic_support.tsv
```

## 10. Critical QC after completion

Run:

```bash
OUT=Ped94_phylogenetic_support_from97MAF

cat "$OUT/qc/ROADIES97_vs_MAF.validation.tsv"
cat "$OUT/qc/support_by_chrom.tsv"

# Confirm the new grass-only breadth never exceeds 93.
awk 'NR>1 && $7>m{m=$7} END{print "max_n_nonref =",m}' \
    "$OUT/summary/whole/feature_support_summary.tsv"

# Inspect how the old BED column-6 count differs from the new grass-only count.
head -50 "$OUT/summary/whole/source_minus_grass_count_distribution.tsv"

# Example histogram tail; the last possible bin is 93.
tail "$OUT/species_support/whole/raw_hist/gt0.4-fold_sites.hist.tsv"
```

Interpretation of the column-6 comparison:

- difference 0: no excluded outgroup contributed an unambiguous base (or source count was already grass-only);
- difference 1..3: one to three excluded outgroups contributed to the old source count;
- difference <0 or >3: inspect the counting convention / MAF source naming / original GERP input.

## 11. Files in this package

```text
config.sh
00_prepare_targets.sh
build_target_arrays.py
01_parse_97maf.py
02_summarize_support.py
00_prepare_targets.bsub
01_parse_97maf.bsub
02_summarize_support.bsub
submit_pipeline.sh
README.md
```
