#!/usr/bin/env bash
set -euo pipefail

CONFIG=${1:-config.sh}
source "$CONFIG"

mkdir -p "$OUTDIR"/{dedup,targets,logs,qc,tmp_sort}
mkdir -p "$SORT_TMP"

QC="$OUTDIR/qc/dedup_input_qc.tsv"
printf 'threshold\tsubgenome\tfeature\tinput_rows\tunique_sites\tduplicate_rows\tconflicting_source_n\tnon_1bp_rows\n' > "$QC"

# The intersect BED files are expected to be grouped by chromosome and sorted by start.
# We collapse duplicate annotation hits at the same reference coordinate and retain column 6
# only as a source-count QC value. Final grass support is recomputed from the original MAF.
for gt in $THRESHOLDS; do
    mkdir -p "$OUTDIR/dedup/gt${gt}"
    for sub in $SUBGENOMES; do
        for feat in $FEATURES; do
            in="$INTERSECT_DIR/gerp_gt${gt}/${sub}_gt${gt}.${feat}.intersect.bed"
            out="$OUTDIR/dedup/gt${gt}/${sub}_gt${gt}.${feat}.bed"
            tmpqc="$out.qc"

            [[ -s "$in" ]] || { echo "ERROR: missing input: $in" >&2; exit 2; }

            awk -v OFS='\t' -v qc="$tmpqc" '
                BEGIN { n=0; u=0; dup=0; conflict=0; badlen=0; prev_chr=""; prev_s=-1; prev_e=-1; prev_n=""; }
                {
                    n++;
                    chr=$1; s=$2+0; e=$3+0; srcn=$6;
                    if (e-s != 1) badlen++;

                    # Require each chromosome to occur in one contiguous, coordinate-sorted block.
                    if (chr != prev_chr) {
                        if (seen_chr[chr]) {
                            printf("ERROR: chromosome %s reappears later in %s; input is not chromosome-grouped\n", chr, FILENAME) > "/dev/stderr";
                            exit 3;
                        }
                        seen_chr[chr]=1;
                    }
                    if (chr==prev_chr && s < prev_s) {
                        printf("ERROR: input not sorted within chromosome: %s at %s:%d after %d\n", FILENAME, chr, s, prev_s) > "/dev/stderr";
                        exit 3;
                    }

                    if (chr==prev_chr && s==prev_s && e==prev_e) {
                        dup++;
                        if (srcn != prev_n) conflict++;
                        next;
                    }

                    print chr, s, e, srcn;
                    u++;
                    prev_chr=chr; prev_s=s; prev_e=e; prev_n=srcn;
                }
                END {
                    print n, u, dup, conflict, badlen > qc;
                }
            ' "$in" > "$out"

            read -r n u dup conflict badlen < "$tmpqc"
            printf 'gt%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\n' \
                "$gt" "$sub" "$feat" "$n" "$u" "$dup" "$conflict" "$badlen" >> "$QC"
            rm -f "$tmpqc"
        done
    done
done

# All gt2/gt4/gt6 feature sites should be subsets of the corresponding gt0 sets.
# Therefore, the union of deduplicated gt0 coordinates is sufficient as the MAF target set.
# This avoids sorting the same nested sites four times.
UNION_BED="$OUTDIR/targets/gt0_all_features.unique.bed"
{
    for f in "$OUTDIR"/dedup/gt0/*.bed; do
        cut -f1-3 "$f"
    done
} | LC_ALL=C sort --parallel="$SORT_THREADS" -S "$SORT_MEM" -T "$SORT_TMP" \
        -k1,1 -k2,2n -k3,3n -u > "$UNION_BED"

python3 "$SCRIPT_DIR/build_target_arrays.py" \
    --bed "$UNION_BED" \
    --outdir "$OUTDIR/targets/by_chr"

echo "Prepared deduplicated feature BEDs and unique gt0 target coordinates."
echo "QC:      $QC"
echo "Targets: $OUTDIR/targets/by_chr"
