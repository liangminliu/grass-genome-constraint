#!/usr/bin/env python3
import argparse
from pathlib import Path
import numpy as np


def flush(chrom, vals, outdir, manifest):
    if chrom is None:
        return
    arr = np.asarray(vals, dtype=np.int64)
    if arr.size and np.any(arr[1:] <= arr[:-1]):
        raise RuntimeError(f"Target coordinates are not strictly increasing for {chrom}")
    out = outdir / f"{chrom}.positions.npy"
    np.save(out, arr)
    manifest.write(f"{chrom}\t{arr.size}\t{out}\n")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--bed", required=True)
    ap.add_argument("--outdir", required=True)
    args = ap.parse_args()

    outdir = Path(args.outdir)
    outdir.mkdir(parents=True, exist_ok=True)
    manifest_path = outdir.parent / "chromosomes.tsv"

    chrom = None
    vals = []
    last = None
    with open(args.bed, "rt") as fh, open(manifest_path, "wt") as manifest:
        manifest.write("chrom\tn_target_sites\tpositions_npy\n")
        for line_no, line in enumerate(fh, 1):
            if not line.strip():
                continue
            f = line.rstrip("\n").split("\t")
            if len(f) < 3:
                raise RuntimeError(f"Malformed BED line {line_no}: {line.rstrip()}")
            c, s, e = f[0], int(f[1]), int(f[2])
            if e != s + 1:
                raise RuntimeError(f"Target is not 1 bp at line {line_no}: {c}:{s}-{e}")
            if chrom is None:
                chrom = c
            if c != chrom:
                flush(chrom, vals, outdir, manifest)
                chrom = c
                vals = []
                last = None
            if last is not None and s <= last:
                raise RuntimeError(f"Non-increasing target position in {c}: {s} after {last}")
            vals.append(s)
            last = s
        flush(chrom, vals, outdir, manifest)

    print(manifest_path)


if __name__ == "__main__":
    main()
