#!/usr/bin/env python3
"""
Parse the original 97-species roast MAF directly, exclude configured Poales outgroups
in memory, and calculate phylogenetic support for only the requested reference sites.

No filtered 94-species MAF is written.
"""
from __future__ import annotations

import argparse
import json
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, Iterable, List, Optional, Set, Tuple

import numpy as np


DNA = {65, 67, 71, 84, 97, 99, 103, 116}  # A,C,G,T, a,c,g,t


@dataclass
class Node:
    name: str = ""
    children: List["Node"] = field(default_factory=list)
    parent: Optional["Node"] = None
    desc_included: Set[str] = field(default_factory=set)

    @property
    def is_leaf(self):
        return not self.children


class NewickParser:
    def __init__(self, text: str):
        self.s = text.strip()
        self.i = 0
        self.auto = 0

    def peek(self):
        return self.s[self.i] if self.i < len(self.s) else ""

    def skip_ws(self):
        while self.i < len(self.s) and self.s[self.i].isspace():
            self.i += 1

    def read_label(self):
        self.skip_ws()
        if self.peek() in "':":
            if self.peek() == "'":
                self.i += 1
                start = self.i
                while self.i < len(self.s) and self.s[self.i] != "'":
                    self.i += 1
                label = self.s[start:self.i]
                if self.peek() == "'":
                    self.i += 1
                return label
            return ""
        start = self.i
        while self.i < len(self.s) and self.s[self.i] not in ",():;" and not self.s[self.i].isspace():
            self.i += 1
        return self.s[start:self.i]

    def skip_branch_length(self):
        self.skip_ws()
        if self.peek() != ":":
            return
        self.i += 1
        while self.i < len(self.s) and self.s[self.i] not in ",();":
            self.i += 1

    def parse_subtree(self) -> Node:
        self.skip_ws()
        if self.peek() == "(":
            self.i += 1
            children = []
            while True:
                child = self.parse_subtree()
                children.append(child)
                self.skip_ws()
                ch = self.peek()
                if ch == ",":
                    self.i += 1
                    continue
                if ch == ")":
                    self.i += 1
                    break
                raise ValueError(f"Unexpected Newick token at position {self.i}: {self.s[self.i:self.i+20]}")
            label = self.read_label()
            self.skip_branch_length()
            if not label:
                self.auto += 1
                label = f"AUTO_INTERNAL_{self.auto:04d}"
            node = Node(name=label, children=children)
            for c in children:
                c.parent = node
            return node
        else:
            label = self.read_label()
            if not label:
                raise ValueError(f"Missing leaf label at position {self.i}")
            self.skip_branch_length()
            return Node(name=label)

    def parse(self) -> Node:
        root = self.parse_subtree()
        self.skip_ws()
        if self.peek() == ";":
            self.i += 1
        self.skip_ws()
        if self.i != len(self.s):
            raise ValueError(f"Unparsed Newick suffix: {self.s[self.i:self.i+100]}")
        return root


def collect_leaves(root: Node) -> Dict[str, Node]:
    leaves = {}
    stack = [root]
    while stack:
        n = stack.pop()
        if n.is_leaf:
            if n.name in leaves:
                raise RuntimeError(f"Duplicate tree leaf: {n.name}")
            leaves[n.name] = n
        else:
            stack.extend(n.children)
    return leaves


def annotate_desc(node: Node, included: Set[str]) -> Set[str]:
    if node.is_leaf:
        node.desc_included = {node.name} if node.name in included else set()
    else:
        d = set()
        for c in node.children:
            d.update(annotate_desc(c, included))
        node.desc_included = d
    return node.desc_included


def make_reference_path(root: Node, leaves: Dict[str, Node], included: Set[str], ref: str):
    annotate_desc(root, included)
    n = leaves[ref]
    raw = []
    while n is not None:
        raw.append(n)
        n = n.parent

    # Collapse path steps that become identical after excluding outgroups.
    path = []
    previous = None
    for n in raw:
        signature = frozenset(n.desc_included)
        if not signature:
            continue
        if signature != previous:
            path.append(n)
            previous = signature

    join_level = {}
    for taxon in included:
        for level, n in enumerate(path):
            if taxon in n.desc_included:
                join_level[taxon] = level
                break
        if taxon not in join_level:
            raise RuntimeError(f"Included taxon does not occur on {ref} reference path: {taxon}")

    return path, join_level


def taxon_from_src(src: str) -> str:
    # roast/MAF source names are expected as taxon.contig. We deliberately split only once.
    return src.split(".", 1)[0]


def contig_from_src(src: str, ref_taxon: str) -> str:
    prefix = ref_taxon + "."
    if src.startswith(prefix):
        return src[len(prefix):]
    # Fallback for an unusual MAF source naming convention.
    parts = src.split(".", 1)
    if len(parts) == 2:
        return parts[1]
    return src


def iter_maf_blocks(path: str):
    rows = []
    with open(path, "rt", buffering=1024 * 1024) as fh:
        for line in fh:
            if not line.strip():
                if rows:
                    yield rows
                    rows = []
                continue
            if line.startswith("s ") or line.startswith("s\t"):
                f = line.split()
                if len(f) < 7:
                    raise RuntimeError(f"Malformed MAF s-line: {line.rstrip()}")
                rows.append((f[1], int(f[2]), int(f[3]), f[4], int(f[5]), f[6]))
        if rows:
            yield rows


def ref_span(start: int, size: int, strand: str, src_size: int):
    if strand == "+":
        return start, start + size
    if strand == "-":
        return src_size - start - size, src_size - start
    raise RuntimeError(f"Unexpected MAF strand: {strand}")


def map_positions_to_columns(ref_text: str, positions: np.ndarray, fstart: int, fend: int, strand: str):
    if positions.size == 0:
        return np.empty(0, dtype=np.int64)

    # Fast path when the reference row contains no alignment gaps.
    if "-" not in ref_text:
        if strand == "+":
            return positions - fstart
        return (fend - 1) - positions

    cols = np.empty(positions.size, dtype=np.int64)
    if strand == "+":
        j = 0
        coord = fstart
        for col, ch in enumerate(ref_text):
            if ch == "-":
                continue
            if j < positions.size and coord == positions[j]:
                cols[j] = col
                j += 1
                if j == positions.size:
                    break
            coord += 1
        if j != positions.size:
            raise RuntimeError(f"Failed to map {positions.size-j} target positions in a + strand MAF block")
    else:
        j = positions.size - 1
        coord = fend - 1
        for col, ch in enumerate(ref_text):
            if ch == "-":
                continue
            if j >= 0 and coord == positions[j]:
                cols[j] = col
                j -= 1
                if j < 0:
                    break
            coord -= 1
        if j >= 0:
            raise RuntimeError(f"Failed to map {j+1} target positions in a - strand MAF block")
    return cols


def valid_dna_codes(codes: np.ndarray) -> np.ndarray:
    return ((codes == 65) | (codes == 67) | (codes == 71) | (codes == 84) |
            (codes == 97) | (codes == 99) | (codes == 103) | (codes == 116))


class ChromState:
    def __init__(self, chrom: str, positions_path: Path):
        self.chrom = chrom
        self.positions = np.load(positions_path, mmap_mode="r")
        n = self.positions.size
        self.found = np.zeros(n, dtype=np.bool_)
        self.n_all = np.zeros(n, dtype=np.uint8)
        self.n_nonref = np.zeros(n, dtype=np.uint8)
        self.deepest = np.full(n, 255, dtype=np.uint8)
        self.ref_valid = np.zeros(n, dtype=np.bool_)
        self.duplicate_hits = 0

    def save(self, outdir: Path):
        out = outdir / f"{self.chrom}.support.npz"
        np.savez_compressed(
            out,
            pos=np.asarray(self.positions, dtype=np.int64),
            found=self.found,
            n_all=self.n_all,
            n_nonref=self.n_nonref,
            deepest_level=self.deepest,
            ref_valid=self.ref_valid,
        )
        return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--maf", required=True)
    ap.add_argument("--tree", required=True)
    ap.add_argument("--targets", required=True, help="Directory containing *.positions.npy")
    ap.add_argument("--outdir", required=True)
    ap.add_argument("--ref", required=True)
    ap.add_argument("--exclude", default="")
    ap.add_argument("--expected-tree-tips", type=int, default=97)
    ap.add_argument("--expected-grass-tips", type=int, default=94)
    args = ap.parse_args()

    outdir = Path(args.outdir)
    support_dir = outdir / "support_npz"
    tree_dir = outdir / "tree"
    qc_dir = outdir / "qc"
    support_dir.mkdir(parents=True, exist_ok=True)
    tree_dir.mkdir(parents=True, exist_ok=True)
    qc_dir.mkdir(parents=True, exist_ok=True)

    excluded = {x for x in re.split(r"[,\s]+", args.exclude) if x}

    tree_text = Path(args.tree).read_text().strip()
    root = NewickParser(tree_text).parse()
    leaves = collect_leaves(root)
    tree_taxa = set(leaves)

    missing_excluded = sorted(excluded - tree_taxa)
    if missing_excluded:
        raise RuntimeError(f"Configured excluded taxa absent from tree: {','.join(missing_excluded)}")
    included = tree_taxa - excluded

    if len(tree_taxa) != args.expected_tree_tips:
        raise RuntimeError(f"Tree has {len(tree_taxa)} tips; expected {args.expected_tree_tips}")
    if len(included) != args.expected_grass_tips:
        raise RuntimeError(f"After excluding {sorted(excluded)}, tree retains {len(included)} tips; expected {args.expected_grass_tips}")
    if args.ref not in included:
        raise RuntimeError(f"Reference taxon {args.ref} is not in retained grass taxa")

    path, join_level = make_reference_path(root, leaves, included, args.ref)
    path_desc = np.asarray([len(n.desc_included) for n in path], dtype=np.uint16)

    with open(tree_dir / f"{args.ref}.reference_path.tsv", "wt") as fh:
        fh.write("path_level\tnode_id\tclade_label\tn_descendant_grasses\n")
        for level, n in enumerate(path):
            label = n.name if n.name else f"PathNode_{level}"
            fh.write(f"{level}\t{n.name}\t{label}\t{len(n.desc_included)}\n")

    with open(tree_dir / "retained_grass_taxa.txt", "wt") as fh:
        for x in sorted(included):
            fh.write(x + "\n")
    with open(tree_dir / "excluded_outgroups.txt", "wt") as fh:
        for x in sorted(excluded):
            fh.write(x + "\n")
    with open(tree_dir / "taxon_join_level.tsv", "wt") as fh:
        fh.write("taxon\tpath_level\n")
        for x in sorted(included):
            fh.write(f"{x}\t{join_level[x]}\n")

    target_dir = Path(args.targets)
    target_paths = {p.name[:-len(".positions.npy")]: p for p in target_dir.glob("*.positions.npy")}
    if not target_paths:
        raise RuntimeError(f"No target arrays found in {target_dir}")

    taxa_order = sorted(included)
    taxon_index = {t: i for i, t in enumerate(taxa_order)}
    levels = np.asarray([join_level[t] for t in taxa_order], dtype=np.int16)
    ref_idx = taxon_index[args.ref]

    current: Optional[ChromState] = None
    finished: Set[str] = set()
    seen_target_chroms: Set[str] = set()
    observed_maf_taxa: Set[str] = set()
    n_blocks = 0
    n_target_blocks = 0
    n_target_sites_seen = 0
    n_ref_ambiguous = 0
    duplicate_taxon_rows = 0

    def activate(chrom: str):
        nonlocal current
        if current is not None and current.chrom == chrom:
            return current
        if current is not None:
            current.save(support_dir)
            finished.add(current.chrom)
        if chrom in finished:
            raise RuntimeError(
                f"Reference contig {chrom} reappeared after it was finished. "
                "This parser expects the MAF to be grouped by reference contig."
            )
        current = ChromState(chrom, target_paths[chrom])
        seen_target_chroms.add(chrom)
        return current

    for rows in iter_maf_blocks(args.maf):
        n_blocks += 1
        for src, *_ in rows:
            observed_maf_taxa.add(taxon_from_src(src))

        ref_rows = [r for r in rows if taxon_from_src(r[0]) == args.ref]
        if not ref_rows:
            continue
        if len(ref_rows) != 1:
            raise RuntimeError(f"MAF block {n_blocks} contains {len(ref_rows)} rows for reference taxon {args.ref}")

        ref_src, ref_start, ref_size, ref_strand, ref_srcsize, ref_text = ref_rows[0]
        chrom = contig_from_src(ref_src, args.ref)
        if chrom not in target_paths:
            continue

        fstart, fend = ref_span(ref_start, ref_size, ref_strand, ref_srcsize)
        state = activate(chrom)
        i0 = int(np.searchsorted(state.positions, fstart, side="left"))
        i1 = int(np.searchsorted(state.positions, fend, side="left"))
        if i0 >= i1:
            continue

        n_target_blocks += 1
        positions = np.asarray(state.positions[i0:i1], dtype=np.int64)
        cols = map_positions_to_columns(ref_text, positions, fstart, fend, ref_strand)
        k = positions.size

        valid = np.zeros((len(taxa_order), k), dtype=np.bool_)
        per_taxon_seen = set()
        for src, _start, _size, _strand, _srcsize, seq in rows:
            taxon = taxon_from_src(src)
            if taxon not in taxon_index:
                continue
            if len(seq) != len(ref_text):
                raise RuntimeError(f"Alignment-row length mismatch in MAF block {n_blocks}: {src}")
            idx = taxon_index[taxon]
            if taxon in per_taxon_seen:
                duplicate_taxon_rows += 1
            per_taxon_seen.add(taxon)
            codes = np.frombuffer(seq.encode("ascii"), dtype=np.uint8)
            valid[idx] |= valid_dna_codes(codes[cols])

        n_all = valid.sum(axis=0).astype(np.uint8)
        ref_valid = valid[ref_idx]
        n_nonref = (n_all.astype(np.int16) - ref_valid.astype(np.int16)).astype(np.uint8)
        weighted = np.where(valid, levels[:, None], -1)
        deepest = weighted.max(axis=0).astype(np.int16)

        bad = deepest < 0
        if np.any(bad):
            raise RuntimeError(f"No retained grass taxon has A/C/G/T at {int(bad.sum())} target sites in MAF block {n_blocks}")

        already = state.found[i0:i1]
        if np.any(already):
            state.duplicate_hits += int(already.sum())
            # Keep the first occurrence; only write newly observed targets.
            write_mask = ~already
        else:
            write_mask = np.ones(k, dtype=np.bool_)

        sl = slice(i0, i1)
        local_found = state.found[sl]
        local_n_all = state.n_all[sl]
        local_n_nonref = state.n_nonref[sl]
        local_deepest = state.deepest[sl]
        local_ref_valid = state.ref_valid[sl]

        local_found[write_mask] = True
        local_n_all[write_mask] = n_all[write_mask]
        local_n_nonref[write_mask] = n_nonref[write_mask]
        local_deepest[write_mask] = deepest[write_mask].astype(np.uint8)
        local_ref_valid[write_mask] = ref_valid[write_mask]

        state.found[sl] = local_found
        state.n_all[sl] = local_n_all
        state.n_nonref[sl] = local_n_nonref
        state.deepest[sl] = local_deepest
        state.ref_valid[sl] = local_ref_valid

        n_target_sites_seen += int(write_mask.sum())
        n_ref_ambiguous += int((~ref_valid & write_mask).sum())

    if current is not None:
        current.save(support_dir)
        finished.add(current.chrom)
        current = None

    # Write all target chromosomes absent from the MAF as explicit all-missing support arrays.
    for chrom, pos_path in target_paths.items():
        if chrom not in finished:
            state = ChromState(chrom, pos_path)
            state.save(support_dir)

    retained_observed = observed_maf_taxa & included
    observed_excluded = observed_maf_taxa & excluded
    tree_not_maf = sorted(tree_taxa - observed_maf_taxa)
    maf_not_tree = sorted(observed_maf_taxa - tree_taxa)

    with open(qc_dir / "ROADIES97_vs_MAF.validation.tsv", "wt") as fh:
        fh.write("metric\tvalue\n")
        fh.write(f"tree_tips\t{len(tree_taxa)}\n")
        fh.write(f"configured_excluded\t{','.join(sorted(excluded))}\n")
        fh.write(f"retained_grass_tree_tips\t{len(included)}\n")
        fh.write(f"observed_maf_taxa\t{len(observed_maf_taxa)}\n")
        fh.write(f"observed_retained_grass_taxa\t{len(retained_observed)}\n")
        fh.write(f"observed_excluded_taxa\t{','.join(sorted(observed_excluded))}\n")
        fh.write(f"tree_not_maf\t{','.join(tree_not_maf)}\n")
        fh.write(f"maf_not_tree\t{','.join(maf_not_tree)}\n")
        fh.write(f"reference_taxon\t{args.ref}\n")
        fh.write(f"reference_path_levels\t{len(path)}\n")
        fh.write(f"target_chromosomes\t{len(target_paths)}\n")
        fh.write(f"target_chromosomes_seen\t{len(seen_target_chroms)}\n")
        fh.write(f"maf_blocks\t{n_blocks}\n")
        fh.write(f"target_overlapping_blocks\t{n_target_blocks}\n")
        fh.write(f"unique_target_sites_seen\t{n_target_sites_seen}\n")
        fh.write(f"target_sites_with_ambiguous_reference_base\t{n_ref_ambiguous}\n")
        fh.write(f"duplicate_taxon_rows_across_target_blocks\t{duplicate_taxon_rows}\n")

    # Manifest/QC per chromosome.
    with open(qc_dir / "support_by_chrom.tsv", "wt") as fh:
        fh.write("chrom\tn_targets\tn_found\tn_missing\tmax_n_nonref\tmax_n_all\n")
        for chrom in sorted(target_paths):
            z = np.load(support_dir / f"{chrom}.support.npz")
            found = z["found"]
            if np.any(found):
                max_nonref = int(z["n_nonref"][found].max())
                max_all = int(z["n_all"][found].max())
            else:
                max_nonref = -1
                max_all = -1
            fh.write(
                f"{chrom}\t{found.size}\t{int(found.sum())}\t{int((~found).sum())}\t{max_nonref}\t{max_all}\n"
            )

    metadata = {
        "tree_tips": len(tree_taxa),
        "retained_grass_tips": len(included),
        "reference_taxon": args.ref,
        "excluded_taxa": sorted(excluded),
        "species_breadth_definition": "number of retained non-reference grass taxa with A/C/G/T",
        "n_all_grass_definition": "number of retained grass taxa including the reference with A/C/G/T",
        "deepest_node_definition": "MRCA of the reference taxon and all represented non-reference grass taxa; represented non-reference taxa require A/C/G/T",
        "occupancy_definition": "n_all_grass / number of retained grass descendants of deepest node",
        "max_species_breadth": len(included) - 1,
        "max_n_all_grass": len(included),
    }
    (outdir / "analysis_definition.json").write_text(json.dumps(metadata, indent=2) + "\n")

    print(f"Retained grasses: {len(included)}; non-reference maximum: {len(included)-1}")
    print(f"Support arrays: {support_dir}")
    print(f"Validation: {qc_dir / 'ROADIES97_vs_MAF.validation.tsv'}")


if __name__ == "__main__":
    main()
