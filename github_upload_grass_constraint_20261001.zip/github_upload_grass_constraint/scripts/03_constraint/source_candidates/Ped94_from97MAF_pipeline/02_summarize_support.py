#!/usr/bin/env python3
from __future__ import annotations

import argparse
from collections import Counter, defaultdict
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, List, Tuple

import numpy as np


FEATURE_LABELS = {
    "CDS_jcvi": "CDS",
    "five_prime_UTR": "5UTR",
    "genes": "genes",
    "intergenic_final": "intergenic",
    "introns": "introns",
    "ped_chr_0-fold_sites": "0-fold_sites",
    "ped_chr_4-fold_sites": "4-fold_sites",
    "promoters": "promoters",
    "TE": "TE",
    "three_prime_UTR": "3UTR",
    "updown5k": "updown5k",
}


@dataclass
class PathInfo:
    level: int
    node_id: str
    label: str
    n_desc: int


class Stats:
    def __init__(self, max_nonref: int, path: List[PathInfo]):
        self.max_nonref = max_nonref
        self.path = path
        self.n_total = 0
        self.n_exact_target = 0
        self.n_maf_found = 0
        self.n_maf_missing = 0
        self.n_ref_ambiguous = 0
        self.source_mismatch = 0
        self.source_diff = Counter()
        self.species_hist = np.zeros(max_nonref + 1, dtype=np.int64)
        self.node_hist = np.zeros(len(path), dtype=np.int64)
        self.node_nonref_sum = np.zeros(len(path), dtype=np.float64)
        self.node_all_sum = np.zeros(len(path), dtype=np.float64)
        self.node_occ_sum = np.zeros(len(path), dtype=np.float64)
        # Exact occupancy distribution represented by (path_level, n_all) pairs.
        self.occ_pair = Counter()

    def add_arrays(self, source_n, exact, found, ref_valid, n_nonref, n_all, deepest):
        self.n_total += int(source_n.size)
        self.n_exact_target += int(exact.sum())
        ok = exact & found
        self.n_maf_found += int(ok.sum())
        self.n_maf_missing += int((exact & ~found).sum()) + int((~exact).sum())
        if not np.any(ok):
            return

        self.n_ref_ambiguous += int((~ref_valid[ok]).sum())
        nn = n_nonref[ok].astype(np.int16)
        na = n_all[ok].astype(np.int16)
        dl = deepest[ok].astype(np.int16)
        src = source_n[ok].astype(np.int16)

        if np.any(nn < 0) or np.any(nn > self.max_nonref):
            raise RuntimeError(f"n_nonref outside 0..{self.max_nonref}")
        if np.any(dl < 0) or np.any(dl >= len(self.path)):
            raise RuntimeError("deepest path level outside reference path")

        self.species_hist += np.bincount(nn, minlength=self.max_nonref + 1)[: self.max_nonref + 1]
        self.node_hist += np.bincount(dl, minlength=len(self.path))[: len(self.path)]

        diffs = src - nn
        self.source_mismatch += int((diffs != 0).sum())
        vals, counts = np.unique(diffs, return_counts=True)
        for v, c in zip(vals, counts):
            self.source_diff[int(v)] += int(c)

        for level in np.unique(dl):
            m = dl == level
            desc = self.path[int(level)].n_desc
            occ = na[m] / float(desc)
            self.node_nonref_sum[level] += float(nn[m].sum())
            self.node_all_sum[level] += float(na[m].sum())
            self.node_occ_sum[level] += float(occ.sum())

            v, c = np.unique(na[m], return_counts=True)
            for nall, count in zip(v, c):
                self.occ_pair[(int(level), int(nall))] += int(count)

    def merge(self, other: "Stats"):
        self.n_total += other.n_total
        self.n_exact_target += other.n_exact_target
        self.n_maf_found += other.n_maf_found
        self.n_maf_missing += other.n_maf_missing
        self.n_ref_ambiguous += other.n_ref_ambiguous
        self.source_mismatch += other.source_mismatch
        self.source_diff.update(other.source_diff)
        self.species_hist += other.species_hist
        self.node_hist += other.node_hist
        self.node_nonref_sum += other.node_nonref_sum
        self.node_all_sum += other.node_all_sum
        self.node_occ_sum += other.node_occ_sum
        self.occ_pair.update(other.occ_pair)
        return self

    def mean_nonref(self):
        if self.n_maf_found == 0:
            return float("nan")
        x = np.arange(self.species_hist.size)
        return float((x * self.species_hist).sum() / self.n_maf_found)

    def median_nonref(self):
        return weighted_quantile_from_hist(self.species_hist, 0.5)

    def mean_occupancy(self):
        if self.n_maf_found == 0:
            return float("nan")
        total = 0.0
        for (level, nall), count in self.occ_pair.items():
            total += (nall / self.path[level].n_desc) * count
        return total / self.n_maf_found

    def median_occupancy(self):
        if self.n_maf_found == 0:
            return float("nan")
        vals = []
        for (level, nall), count in self.occ_pair.items():
            vals.append((nall / self.path[level].n_desc, count))
        vals.sort()
        target = (self.n_maf_found - 1) * 0.5
        cum = 0
        for val, count in vals:
            if cum + count > target:
                return float(val)
            cum += count
        return float(vals[-1][0])


def weighted_quantile_from_hist(hist: np.ndarray, q: float):
    total = int(hist.sum())
    if total == 0:
        return float("nan")
    target = (total - 1) * q
    cum = 0
    for i, c in enumerate(hist):
        if cum + int(c) > target:
            return float(i)
        cum += int(c)
    return float(len(hist) - 1)


def load_path(path_file: Path):
    out = []
    with open(path_file, "rt") as fh:
        header = fh.readline().rstrip().split("\t")
        idx = {x: i for i, x in enumerate(header)}
        for line in fh:
            if not line.strip():
                continue
            f = line.rstrip().split("\t")
            out.append(
                PathInfo(
                    level=int(f[idx["path_level"]]),
                    node_id=f[idx["node_id"]],
                    label=f[idx["clade_label"]],
                    n_desc=int(f[idx["n_descendant_grasses"]]),
                )
            )
    for i, p in enumerate(out):
        if p.level != i:
            raise RuntimeError("Reference path levels are not contiguous from 0")
    return out


class SupportCache:
    def __init__(self, support_dir: Path):
        self.support_dir = support_dir
        self.chrom = None
        self.data = None

    def get(self, chrom):
        if chrom == self.chrom:
            return self.data
        p = self.support_dir / f"{chrom}.support.npz"
        if not p.exists():
            raise RuntimeError(f"Missing support file for chromosome {chrom}: {p}")
        z = np.load(p)
        self.chrom = chrom
        self.data = {
            "pos": z["pos"],
            "found": z["found"],
            "n_all": z["n_all"],
            "n_nonref": z["n_nonref"],
            "deepest": z["deepest_level"],
            "ref_valid": z["ref_valid"],
        }
        return self.data


def consume_chunk(stats: Stats, cache: SupportCache, chrom: str, pos_list, source_list):
    if not pos_list:
        return
    pos = np.asarray(pos_list, dtype=np.int64)
    source = np.asarray(source_list, dtype=np.int16)
    d = cache.get(chrom)
    idx = np.searchsorted(d["pos"], pos, side="left")
    inrange = idx < d["pos"].size
    exact = np.zeros(pos.size, dtype=np.bool_)
    exact[inrange] = d["pos"][idx[inrange]] == pos[inrange]

    # Dummy arrays for non-exact coordinates; they are excluded by exact before use.
    safe_idx = np.where(inrange, idx, 0)
    found = np.zeros(pos.size, dtype=np.bool_)
    ref_valid = np.zeros(pos.size, dtype=np.bool_)
    n_all = np.zeros(pos.size, dtype=np.uint8)
    n_nonref = np.zeros(pos.size, dtype=np.uint8)
    deepest = np.zeros(pos.size, dtype=np.uint8)
    found[inrange] = d["found"][safe_idx[inrange]]
    ref_valid[inrange] = d["ref_valid"][safe_idx[inrange]]
    n_all[inrange] = d["n_all"][safe_idx[inrange]]
    n_nonref[inrange] = d["n_nonref"][safe_idx[inrange]]
    deepest[inrange] = d["deepest"][safe_idx[inrange]]

    stats.add_arrays(source, exact, found, ref_valid, n_nonref, n_all, deepest)


def summarize_bed(path: Path, stats: Stats, cache: SupportCache, chunk_size=500_000):
    chrom = None
    pos_list = []
    src_list = []
    with open(path, "rt", buffering=1024 * 1024) as fh:
        for line_no, line in enumerate(fh, 1):
            if not line.strip():
                continue
            f = line.rstrip().split("\t")
            if len(f) < 4:
                f = line.split()
            if len(f) < 4:
                raise RuntimeError(f"Malformed deduplicated BED {path}:{line_no}")
            c, s, src = f[0], int(f[1]), int(float(f[3]))
            if chrom is None:
                chrom = c
            if c != chrom or len(pos_list) >= chunk_size:
                consume_chunk(stats, cache, chrom, pos_list, src_list)
                pos_list = []
                src_list = []
                if c != chrom:
                    chrom = c
            pos_list.append(s)
            src_list.append(src)
    if pos_list:
        consume_chunk(stats, cache, chrom, pos_list, src_list)


def write_hist_files(outdir: Path, region: str, gt: int, feat_label: str, st: Stats):
    sdir = outdir / "species_support" / region / "raw_hist"
    ndir = outdir / "phylogenetic_support" / region / "raw_node_hist"
    odir = outdir / "phylogenetic_support" / region / "raw_occupancy_pairs"
    sdir.mkdir(parents=True, exist_ok=True)
    ndir.mkdir(parents=True, exist_ok=True)
    odir.mkdir(parents=True, exist_ok=True)

    with open(sdir / f"gt{gt}.{feat_label}.hist.tsv", "wt") as fh:
        fh.write("threshold\tfeature\tn_species\tn_sites\n")
        for n, count in enumerate(st.species_hist):
            fh.write(f"gt{gt}\t{feat_label}\t{n}\t{int(count)}\n")

    with open(ndir / f"gt{gt}.{feat_label}.node_hist.tsv", "wt") as fh:
        fh.write("threshold\tfeature\tpath_level\tnode_id\tclade_label\tn_descendant_grasses\tn_sites\tmean_n_nonref\tmean_n_all\tmean_occupancy\n")
        for p in st.path:
            n = int(st.node_hist[p.level])
            if n:
                mn = st.node_nonref_sum[p.level] / n
                ma = st.node_all_sum[p.level] / n
                mo = st.node_occ_sum[p.level] / n
            else:
                mn = ma = mo = float("nan")
            fh.write(
                f"gt{gt}\t{feat_label}\t{p.level}\t{p.node_id}\t{p.label}\t{p.n_desc}\t{n}\t{mn:.6f}\t{ma:.6f}\t{mo:.6f}\n"
            )

    with open(odir / f"gt{gt}.{feat_label}.occupancy_pairs.tsv", "wt") as fh:
        fh.write("threshold\tfeature\tpath_level\tn_descendant_grasses\tn_all_grass\toccupancy\tn_sites\n")
        for (level, nall), count in sorted(st.occ_pair.items()):
            desc = st.path[level].n_desc
            fh.write(f"gt{gt}\t{feat_label}\t{level}\t{desc}\t{nall}\t{nall/desc:.8f}\t{count}\n")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--outdir", required=True)
    ap.add_argument("--thresholds", default="0,2,4,6")
    ap.add_argument("--subgenomes", default="pedC,pedD")
    ap.add_argument("--features", required=True)
    ap.add_argument("--ref", default="ped")
    ap.add_argument("--max-nonref", type=int, default=93)
    args = ap.parse_args()

    outdir = Path(args.outdir)
    thresholds = [int(x) for x in args.thresholds.replace(",", " ").split()]
    subs = args.subgenomes.replace(",", " ").split()
    feats = args.features.replace(",", " ").split()
    path = load_path(outdir / "tree" / f"{args.ref}.reference_path.tsv")
    cache = SupportCache(outdir / "support_npz")

    all_stats: Dict[Tuple[str, int, str], Stats] = {}

    for gt in thresholds:
        for feat in feats:
            label = FEATURE_LABELS.get(feat, feat)
            per_sub = []
            for sub in subs:
                bed = outdir / "dedup" / f"gt{gt}" / f"{sub}_gt{gt}.{feat}.bed"
                if not bed.exists():
                    raise RuntimeError(f"Missing deduplicated BED: {bed}")
                st = Stats(args.max_nonref, path)
                summarize_bed(bed, st, cache)
                all_stats[(sub, gt, label)] = st
                per_sub.append(st)
                write_hist_files(outdir, sub, gt, label, st)

            whole = Stats(args.max_nonref, path)
            for st in per_sub:
                whole.merge(st)
            all_stats[("whole", gt, label)] = whole
            write_hist_files(outdir, "whole", gt, label, whole)

    # Feature-level summary tables.
    for region in ["whole"] + subs:
        sdir = outdir / "summary" / region
        sdir.mkdir(parents=True, exist_ok=True)
        with open(sdir / "feature_support_summary.tsv", "wt") as fh:
            fh.write(
                "threshold\tfeature\tn_unique_sites\tn_maf_found\tn_maf_missing\t"
                "mean_n_nonref\tmedian_n_nonref\tmax_n_nonref\tmean_occupancy\tmedian_occupancy\t"
                "reference_ambiguous_sites\tsource_vs_grass_count_mismatches\tmismatch_fraction\n"
            )
            for gt in thresholds:
                for feat in feats:
                    label = FEATURE_LABELS.get(feat, feat)
                    st = all_stats[(region, gt, label)]
                    nz = np.flatnonzero(st.species_hist)
                    maxn = int(nz[-1]) if nz.size else -1
                    frac = st.source_mismatch / st.n_maf_found if st.n_maf_found else float("nan")
                    fh.write(
                        f"gt{gt}\t{label}\t{st.n_total}\t{st.n_maf_found}\t{st.n_maf_missing}\t"
                        f"{st.mean_nonref():.6f}\t{st.median_nonref():.6f}\t{maxn}\t"
                        f"{st.mean_occupancy():.8f}\t{st.median_occupancy():.8f}\t"
                        f"{st.n_ref_ambiguous}\t{st.source_mismatch}\t{frac:.8f}\n"
                    )

        with open(sdir / "source_minus_grass_count_distribution.tsv", "wt") as fh:
            fh.write("threshold\tfeature\tsource_n_minus_n_nonref_grass\tn_sites\n")
            for gt in thresholds:
                for feat in feats:
                    label = FEATURE_LABELS.get(feat, feat)
                    st = all_stats[(region, gt, label)]
                    for diff, count in sorted(st.source_diff.items()):
                        fh.write(f"gt{gt}\t{label}\t{diff}\t{count}\n")

    # Main GERP>2 table: directly useful for the deepest-node/occupancy figure.
    main_gt = 2 if 2 in thresholds else thresholds[0]
    for region in ["whole"] + subs:
        sdir = outdir / "summary" / region
        with open(sdir / f"GERPgt{main_gt}.phylogenetic_support.tsv", "wt") as fh:
            fh.write(
                "feature\tpath_level\tnode_id\tclade_label\tn_descendant_grasses\tn_sites\t"
                "mean_n_nonref\tmean_n_all\tmean_occupancy\n"
            )
            for feat in feats:
                label = FEATURE_LABELS.get(feat, feat)
                st = all_stats[(region, main_gt, label)]
                for p in path:
                    n = int(st.node_hist[p.level])
                    if n == 0:
                        continue
                    fh.write(
                        f"{label}\t{p.level}\t{p.node_id}\t{p.label}\t{p.n_desc}\t{n}\t"
                        f"{st.node_nonref_sum[p.level]/n:.6f}\t{st.node_all_sum[p.level]/n:.6f}\t"
                        f"{st.node_occ_sum[p.level]/n:.8f}\n"
                    )

    print(f"Summary complete: {outdir / 'summary'}")


if __name__ == "__main__":
    main()
