#!/usr/bin/env bash
set -euo pipefail
CONFIG=${1:-config.sh}
source "$CONFIG"

cd "$SCRIPT_DIR"
mkdir -p logs "$OUTDIR/logs"

extract_id() { sed -n 's/Job <\([0-9][0-9]*\)>.*/\1/p'; }

j0=$(bsub -env "all,CONFIG=$CONFIG" < 00_prepare_targets.bsub | extract_id)
echo "prepare_targets job: $j0"

j1=$(bsub -w "done($j0)" -env "all,CONFIG=$CONFIG" < 01_parse_97maf.bsub | extract_id)
echo "parse_97maf job:   $j1"

j2=$(bsub -w "done($j1)" -env "all,CONFIG=$CONFIG" < 02_summarize_support.bsub | extract_id)
echo "summarize job:     $j2"

echo "Pipeline submitted with dependencies: $j0 -> $j1 -> $j2"
