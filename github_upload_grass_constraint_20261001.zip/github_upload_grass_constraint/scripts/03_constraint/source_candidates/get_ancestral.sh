#!/bin/bash
#BSUB -J get_ancestral_atau[1-7]
#BSUB -q Q96C1T_X12
#BSUB -n 4
#BSUB -R "span[hosts=1]"
#BSUB -o get_ancestral.%J.%I.out
#BSUB -e get_ancestral.%J.%I.err

set -euo pipefail

mkdir -p ancestral_results

# 1D-7D
CHRS=(1D 2D 3D 4D 5D 6D 7D)
CHR="${CHRS[$((LSB_JOBINDEX-1))]}"

IN_FILE="merged_results/${CHR}.merged.txt"
OUT_FILE="ancestral_results/${CHR}.ancestral.bed"

echo "[INFO] Job ID       : ${LSB_JOBID}"
echo "[INFO] Job Index    : ${LSB_JOBINDEX}"
echo "[INFO] Chromosome   : ${CHR}"
echo "[INFO] Input        : ${IN_FILE}"
echo "[INFO] Output       : ${OUT_FILE}"
echo "[INFO] Start time   : $(date)"

[[ -f "${IN_FILE}" ]] || { echo "[ERROR] Missing input: ${IN_FILE}" >&2; exit 1; }

python ./get_ancestral.py \
    -sfsout "${IN_FILE}" \
    -output "${OUT_FILE}"

[[ -s "${OUT_FILE}" ]] || { echo "[ERROR] Output file is empty: ${OUT_FILE}" >&2; exit 1; }

echo "[INFO] Finished ${CHR} at $(date)"