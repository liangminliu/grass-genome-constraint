#!/bin/bash
# 生成器脚本保存为 generate_final_scripts.sh

# 基础路径设置
ref_path="../01.ref/Zmay.fa"
bam_base="step3_MarkDuplicates"
mkdir -p batch_logs

# 遍历样本列表
while read rra sample; do
    # 创建样本专属目录
    sample_dir="${sample}"
    mkdir -p "${sample_dir}/tmp"

    # 计算染色体总数
    chr_count=$(wc -l < chr.list)
    
    # 在当前目录生成sbatch脚本
    cat << EOF > "haplotype_scripts/HC_${sample}.sbatch"
#!/bin/bash
#SBATCH --job-name=HC5.${sample}
#SBATCH --output=${sample_dir}/HC.${sample}.%A_%a.out
#SBATCH --error=${sample_dir}/HC.${sample}.%A_%a.err
#SBATCH --partition=FAT2
#SBATCH --nodes=1
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=1
#SBATCH --mem=400000 
#SBATCH --nodelist=cu
#SBATCH --array=1-${chr_count}%10  # 关键并行控制

# 获取当前染色体
chrom=\$(sed -n \${SLURM_ARRAY_TASK_ID}p chr.list | awk '{print \$1}')

# 定义带路径的输出文件
output_file="${sample_dir}/${sample}.\${chrom}.g.vcf.gz"
index_file="\${output_file}.tbi"
log_file="${sample_dir}/${sample}.\${chrom}.HC.log"
tmp_dir="${sample_dir}/tmp"

# 检查文件是否存在
if [ ! -f "\${index_file}" ]; then
    echo "=== 开始处理 ${sample}.\${chrom} ==="
    start_time=\$(date +%s)
    
    singularity exec ../software/Reseq_genek.sif \\
    gatk --java-options "-DGATK_STACKTRACE_ON_USER_EXCEPTION=true \\
    -Xms80g -Xmx100g \\
    -Djava.io.tmpdir=\${tmp_dir}" \\
    HaplotypeCaller \\
    -R ${ref_path} \\
    -I ${bam_base}/${sample}.sort.rmdup.bam \\
    -L \${chrom} \\
    -ERC GVCF \\
    -O \${output_file} \\
    > \${log_file} 2>&1

    # 状态检查
    if [ \$? -eq 0 ]; then
        end_time=\$(date +%s)
        echo "完成 ${sample}.\${chrom} 耗时:\$((end_time - start_time))秒"
    else
        echo "错误：${sample}.\${chrom} 处理失败" >&2
        exit 1
    fi
else
    echo "跳过已存在的 ${sample}.\${chrom}"
fi
EOF

    echo "生成的脚本：HC5_${sample}.sbatch" >> batch_logs/generation.log
done < sra1.list

# 创建提交脚本
cat << 'EOF' > submit_all_jobs.sh
#!/bin/bash
# 查找所有sbatch脚本并提交
find . -maxdepth 1 -name "haplotype_scripts/HC5_*.sbatch" | while read script; do
    echo "正在提交：${script}"
    sbatch ${script}
done
echo "监控命令："
echo "watch -n 30 'squeue -u \$(whoami) -o \"%.18i %.9P %.30j %.8u %.8T %.10M %.9l %.6D %R %S\"'"
EOF
chmod +x submit_all_jobs.sh

echo "生成完成！执行以下步骤："
echo "1. 检查生成的脚本：ls HC_*.sbatch"
echo "2. 提交作业：./submit_all_jobs.sh"
echo "3. 结果文件将保存在各样本目录中"
