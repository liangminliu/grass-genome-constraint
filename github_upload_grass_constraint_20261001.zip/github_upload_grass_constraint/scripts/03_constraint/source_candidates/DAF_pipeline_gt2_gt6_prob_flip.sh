#!/bin/bash
#SBATCH -J DAF_pipeline_gt2_gt6
#SBATCH -p parallel
#SBATCH -N 1
#SBATCH -n 1
#SBATCH --cpus-per-task=20
#SBATCH -o DAF_pipeline_gt2_gt6.%j.out
#SBATCH -e DAF_pipeline_gt2_gt6.%j.err

###############################################################################
# Pipeline extension:
#   Add GERP > 2 and GERP > 6 DAF calculations
#   using BOTH probabilistic and FLIP ancestral inference
#
# Reference logic:
#   - Original prob-ancestral DAF pipeline
#   - Original FLIP-ancestral DAF pipeline
#
# NOTE:
#   - GERP > 4 results already exist and are NOT recomputed here
#   - This script ONLY adds gt2 / gt6 results into new directories
###############################################################################

set -euo pipefail

###############################################################################
# Global parameters
###############################################################################

NALLELE=124
BIN=0.05
CHRS=(Ped{01..12}{C,D} Ped09X)

###############################################################################
# Step 0. Prepare BED files (GERP > 2 / GERP > 6)
###############################################################################

echo "[Step 0] Preparing BED files for GERP > 2 and GERP > 6"

mkdir -p bed_classes

cat pedC_gt2_snps.bed pedD_gt2_snps.bed \
  | sort -k1,1 -k2,2n > bed_classes/gerp2.bed

cat pedC_gt6_snps.bed pedD_gt6_snps.bed \
  | sort -k1,1 -k2,2n > bed_classes/gerp6.bed


###############################################################################
# Function: run DAF pipeline (aligned with original scripts)
# Arguments:
#   $1 = CLASS  (gerp2 / gerp6)
#   $2 = MODE   (prob / flip)
###############################################################################

run_daf () {

  local CLASS=$1
  local MODE=$2

  echo "[Running] ${CLASS} (${MODE})"

  if [[ "${MODE}" == "prob" ]]; then
    ANC_DIR="anc"
    ANC_SUFFIX="ancestral.prob0.6.bed"
    SUBSET_DIR="subset_${CLASS}"
    SFS_DIR="sfs_${CLASS}"
    DAF_DIR="daf_${CLASS}"
  else
    ANC_DIR="anc_flip"
    ANC_SUFFIX="ancestral.bed"
    SUBSET_DIR="subset_${CLASS}_flip"
    SFS_DIR="sfs_${CLASS}_flip"
    DAF_DIR="daf_${CLASS}_flip"
  fi

  mkdir -p ${SUBSET_DIR} ${SFS_DIR} ${DAF_DIR}

  ###########################################################################
  # Step 1–2. Subset SNPs & compute unfolded SFS
  ###########################################################################

  for CHR in "${CHRS[@]}"; do

    MERGED=merged_results/${CHR}.merged.txt
    ANC=${ANC_DIR}/${CHR}.${ANC_SUFFIX}

    [[ -f ${MERGED} && -f ${ANC} ]] || continue

    bedtools intersect -wa -u \
      -a ${MERGED} \
      -b bed_classes/${CLASS}.bed \
      > ${SUBSET_DIR}/${CHR}.${CLASS}.merged.txt

    python3 build_unfolded_sfs.py \
      --merged ${SUBSET_DIR}/${CHR}.${CLASS}.merged.txt \
      --ancestral ${ANC} \
      --Nallele ${NALLELE} \
      --out ${SFS_DIR}/${CHR}.${CLASS}.sfs.tsv \
      --skip_na
  done

  ###########################################################################
  # Step 3. Merge per-chromosome SFS
  ###########################################################################

  echo -e "derived_count\tsites" > ${SFS_DIR}/genome.${CLASS}.sfs.tsv

  awk '
    FNR==1 { next }
    NF==2 { sum[$1] += $2 }
    END {
      for (k in sum) print k "\t" sum[k]
    }
  ' ${SFS_DIR}/Ped*.${CLASS}.sfs.tsv \
    | sort -n >> ${SFS_DIR}/genome.${CLASS}.sfs.tsv

  ###########################################################################
  # Step 4. Convert unfolded SFS → DAF
  ###########################################################################

  python3 << EOF
import pandas as pd

N=${NALLELE}
BIN=${BIN}

sfs = pd.read_csv(
    "${SFS_DIR}/genome.${CLASS}.sfs.tsv",
    sep="\\t"
)

sfs["derived_count"] = pd.to_numeric(sfs["derived_count"])
sfs["sites"] = pd.to_numeric(sfs["sites"])

assert sfs["derived_count"].between(0, N).all()

sfs["daf"] = sfs["derived_count"] / N
sfs["bin"] = (sfs["daf"] // BIN) * BIN
sfs.loc[sfs["bin"] >= 1.0, "bin"] = 1.0 - BIN

daf = (
    sfs.groupby("bin", as_index=False)["sites"]
    .sum()
)
daf["proportion"] = daf["sites"] / daf["sites"].sum()

daf[["bin", "proportion"]].to_csv(
    "${DAF_DIR}/genome.${CLASS}.daf.tsv",
    sep="\\t",
    index=False
)
EOF

  echo "[Finished] ${CLASS} (${MODE})"
}

###############################################################################
# Run ONLY newly required computations
###############################################################################

run_daf gerp2 prob
run_daf gerp2 flip

run_daf gerp6 prob
run_daf gerp6 flip

echo "[DAF gt2 / gt6 prob + flip pipeline finished successfully]"
