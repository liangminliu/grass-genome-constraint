#!/usr/bin/env bash
#SBATCH --job-name=gerp_target_stats_byList
#SBATCH --partition=parallel
#SBATCH --nodes=1
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=10
#SBATCH --array=1-4
#SBATCH --output=logs/gerp_target_byList_%A_%a.out
#SBATCH --error=logs/gerp_target_byList_%A_%a.err

set -euo pipefail
module load bedtools 2>/dev/null || true

############################################################
# 0. 路径配置
############################################################
BASE_GERP_DIR="/gpfs/hpc/home/kib_unit/lidezhu/liuliangmin/2.msa/Atau_msa/results/GERP_output/02.constrain_stat/gerp_conservation_results"

GENE_BED="genes.bed"
CDS_BED="CDS.gene.merged.bed"

# 需要处理的基因列表
TARGET_LISTS=(
  "Atau_Pol.list"
  "Atau_Veg.list"
)

OUT_ROOT="target_gene_CDS_GERP_stats_byList"
mkdir -p logs "${OUT_ROOT}"

############################################################
# 1. array 参数：GERP 阈值
############################################################
CLASSES=("gt0" "gt2" "gt4" "gt6")
IDX=$((SLURM_ARRAY_TASK_ID - 1))
if [[ $IDX -lt 0 || $IDX -ge ${#CLASSES[@]} ]]; then
  echo "[ERROR] Bad SLURM_ARRAY_TASK_ID=${SLURM_ARRAY_TASK_ID}" >&2
  exit 1
fi
CLASS="${CLASSES[$IDX]}"

echo "[INFO] Processing GERP class: ${CLASS}"

############################################################
# 2. 自动识别 gene / CDS GERP 文件
############################################################
GENE_GERP1="${BASE_GERP_DIR}/${CLASS}/bed_files/genes_GERP_feature.bed"
GENE_GERP2="${BASE_GERP_DIR}/${CLASS}/bed_files/genes_conserved_sites.bed"

if [[ -s "${GENE_GERP1}" ]]; then
  GENE_GERP="${GENE_GERP1}"
elif [[ -s "${GENE_GERP2}" ]]; then
  GENE_GERP="${GENE_GERP2}"
else
  echo "[ERROR] No gene GERP file found for ${CLASS}" >&2
  exit 1
fi

CDS_GERP1="${BASE_GERP_DIR}/${CLASS}/bed_files/CDS_GERP_feature.bed"
CDS_GERP2="${BASE_GERP_DIR}/${CLASS}/bed_files/CDS_conserved_sites.bed"

HAS_CDS=1
if [[ -s "${CDS_GERP1}" ]]; then
  CDS_GERP="${CDS_GERP1}"
elif [[ -s "${CDS_GERP2}" ]]; then
  CDS_GERP="${CDS_GERP2}"
else
  echo "[WARN] No CDS GERP file found for ${CLASS}; CDS-related stats will be set to 0"
  HAS_CDS=0
  CDS_GERP=""
fi

echo "[INFO] gene GERP: $(basename "${GENE_GERP}")"
if [[ "${HAS_CDS}" -eq 1 ]]; then
  echo "[INFO] CDS  GERP: $(basename "${CDS_GERP}")"
fi

############################################################
# 3. 规范化全基因组 gene / CDS bed
#    统一去掉 gene: 前缀，便于和 Atau_Pol.list / Atau_Veg.list 对齐
############################################################
GENE4="${OUT_ROOT}/genes.4col.bed"
CDS4="${OUT_ROOT}/CDS.4col.bed"

awk 'BEGIN{OFS="\t"}
{
  g=$4
  sub(/^gene:/, "", g)
  print $1, $2, $3, g
}' "${GENE_BED}" | sort -k1,1 -k2,2n > "${GENE4}"

awk 'BEGIN{OFS="\t"}
{
  g=$4
  sub(/^gene:/, "", g)
  print $1, $2, $3, g
}' "${CDS_BED}" | sort -k1,1 -k2,2n > "${CDS4}"

############################################################
# 4. 循环处理每个目标基因列表
############################################################
for LIST in "${TARGET_LISTS[@]}"; do
  if [[ ! -s "${LIST}" ]]; then
    echo "[WARN] Skip missing or empty list: ${LIST}"
    continue
  fi

  GROUP=$(basename "${LIST}")
  GROUP=${GROUP%.list}

  echo "[INFO] ----------------------------------------"
  echo "[INFO] Processing gene list: ${GROUP}"
  echo "[INFO] Source list: ${LIST}"

  OUT_DIR="${OUT_ROOT}/${GROUP}/${CLASS}"
  BED_DIR="${OUT_DIR}/bed_files"
  STAT_DIR="${OUT_DIR}/stats"
  mkdir -p "${BED_DIR}" "${STAT_DIR}"

  ##########################################################
  # 4.1 标准化目标 gene ID
  ##########################################################
  TARGET_GENE_LIST="${OUT_DIR}/target_gene_ids.txt"
  awk '
    {
      g=$1
      sub(/^gene:/, "", g)
      if(g!="") print g
    }
  ' "${LIST}" | sort -u > "${TARGET_GENE_LIST}"

  N_TARGET=$(wc -l < "${TARGET_GENE_LIST}")
  echo "[INFO] ${GROUP} target genes: ${N_TARGET}"

  ##########################################################
  # 4.2 提取 target gene / target CDS
  ##########################################################
  TARGET_GENE_BED="${BED_DIR}/target_genes.bed"
  TARGET_CDS_BED="${BED_DIR}/target_CDS.bed"

  awk 'NR==FNR{a[$1]=1; next} a[$4]' \
    "${TARGET_GENE_LIST}" "${GENE4}" \
    > "${TARGET_GENE_BED}"

  awk 'NR==FNR{a[$1]=1; next} a[$4]' \
    "${TARGET_GENE_LIST}" "${CDS4}" \
    > "${TARGET_CDS_BED}"

  N_GENE_BED=$(wc -l < "${TARGET_GENE_BED}" || echo 0)
  N_CDS_BED=$(wc -l < "${TARGET_CDS_BED}" || echo 0)

  echo "[INFO] ${GROUP} target gene BED records: ${N_GENE_BED}"
  echo "[INFO] ${GROUP} target CDS  BED records: ${N_CDS_BED}"

  ##########################################################
  # 4.3 GERP 位点 ∩ target gene / CDS
  ##########################################################
  GENE_CONS="${BED_DIR}/gene_conserved_sites.bed"
  CDS_CONS="${BED_DIR}/CDS_conserved_sites.bed"

  if [[ -s "${TARGET_GENE_BED}" ]]; then
    bedtools intersect -wa -wb \
      -a "${GENE_GERP}" \
      -b "${TARGET_GENE_BED}" \
      > "${GENE_CONS}"
  else
    : > "${GENE_CONS}"
  fi

  if [[ "${HAS_CDS}" -eq 1 && -s "${TARGET_CDS_BED}" ]]; then
    bedtools intersect -wa -wb \
      -a "${CDS_GERP}" \
      -b "${TARGET_CDS_BED}" \
      > "${CDS_CONS}"
  else
    : > "${CDS_CONS}"
  fi

  ##########################################################
  # 4.4 gene 长度
  ##########################################################
  awk 'BEGIN{OFS="\t"}{ print $4, $3-$2 }' "${TARGET_GENE_BED}" \
    | sort -k1,1 \
    > "${STAT_DIR}/gene_length.tsv"

  ##########################################################
  # 4.5 CDS 长度（按 gene 合并重叠区间后求和）
  ##########################################################
  TARGET_CDS_SORTED="${OUT_DIR}/target_CDS.byGene.sorted.bed"
  sort -k4,4 -k1,1 -k2,2n "${TARGET_CDS_BED}" > "${TARGET_CDS_SORTED}"

  if [[ -s "${TARGET_CDS_SORTED}" ]]; then
    awk '
    BEGIN{OFS="\t"}
    {
      g=$4; chr=$1; s=$2; e=$3
      if(NR==1){
        cg=g; cchr=chr; cs=s; ce=e; sum=0
        next
      }
      if(g!=cg || chr!=cchr){
        sum += (ce - cs)
        print cg, sum
        cg=g; cchr=chr; cs=s; ce=e; sum=0
        next
      }
      if(s <= ce){
        if(e > ce) ce=e
      } else {
        sum += (ce - cs)
        cs=s; ce=e
      }
    }
    END{
      if(NR>0){
        sum += (ce - cs)
        print cg, sum
      }
    }' "${TARGET_CDS_SORTED}" | sort -k1,1 > "${STAT_DIR}/cds_length.tsv"
  else
    : > "${STAT_DIR}/cds_length.tsv"
  fi

  ##########################################################
  # 4.6 gene / CDS conserved site 数（按 1bp 去重）
  ##########################################################
  if [[ -s "${GENE_CONS}" ]]; then
    awk 'BEGIN{OFS="\t"}
    {
      gid=$NF
      key=$1"\t"$2"\t"$3"\t"gid
      if(!seen[key]++) c[gid]++
    }
    END{
      for(g in c) print g, c[g]
    }' "${GENE_CONS}" | sort -k1,1 > "${STAT_DIR}/gene_site_count.tsv"
  else
    : > "${STAT_DIR}/gene_site_count.tsv"
  fi

  if [[ -s "${CDS_CONS}" ]]; then
    awk 'BEGIN{OFS="\t"}
    {
      gid=$NF
      key=$1"\t"$2"\t"$3"\t"gid
      if(!seen[key]++) c[gid]++
    }
    END{
      for(g in c) print g, c[g]
    }' "${CDS_CONS}" | sort -k1,1 > "${STAT_DIR}/cds_site_count.tsv"
  else
    : > "${STAT_DIR}/cds_site_count.tsv"
  fi

  ##########################################################
  # 4.7 以 target_gene_ids.txt 为主表，合并所有结果
  #     保证没有 conserved site 的基因也保留下来
  ##########################################################
  awk '
  BEGIN{
    OFS="\t"
    print "gene_id","gene_len","cds_len","gene_sites","gene_pct","cds_sites","cds_pct"
  }
  FNR==NR {order[++n]=$1; next}
  ARGIND==2 {gene_len[$1]=$2; next}
  ARGIND==3 {cds_len[$1]=$2; next}
  ARGIND==4 {gene_sites[$1]=$2; next}
  ARGIND==5 {cds_sites[$1]=$2; next}
  END{
    for(i=1;i<=n;i++){
      g=order[i]
      gl=(g in gene_len)?gene_len[g]:0
      cl=(g in cds_len)?cds_len[g]:0
      gs=(g in gene_sites)?gene_sites[g]:0
      cs=(g in cds_sites)?cds_sites[g]:0
      gp=(gl>0)?gs/gl*100:0
      cp=(cl>0)?cs/cl*100:0
      printf "%s\t%d\t%d\t%d\t%.6f\t%d\t%.6f\n", g, gl, cl, gs, gp, cs, cp
    }
  }' \
  "${TARGET_GENE_LIST}" \
  "${STAT_DIR}/gene_length.tsv" \
  "${STAT_DIR}/cds_length.tsv" \
  "${STAT_DIR}/gene_site_count.tsv" \
  "${STAT_DIR}/cds_site_count.tsv" \
  > "${OUT_DIR}/per_gene_stats.tsv"

  ##########################################################
  # 4.8 汇总结果
  ##########################################################
  awk -v grp="${GROUP}" -v cls="${CLASS}" '
  BEGIN{
    OFS="\t"
    print "group","class","n_target_genes","n_gene_with_anno","n_cds_with_anno","total_gene_len","total_cds_len","total_gene_sites","total_cds_sites","gene_pct","cds_pct"
  }
  NR==1{next}
  {
    n_target++
    if($2>0) n_gene++
    if($3>0) n_cds++
    sum_gl += $2
    sum_cl += $3
    sum_gs += $4
    sum_cs += $6
  }
  END{
    gp = (sum_gl>0)?sum_gs/sum_gl*100:0
    cp = (sum_cl>0)?sum_cs/sum_cl*100:0
    printf "%s\t%s\t%d\t%d\t%d\t%d\t%d\t%d\t%d\t%.6f\t%.6f\n",
           grp, cls, n_target, n_gene, n_cds, sum_gl, sum_cl, sum_gs, sum_cs, gp, cp
  }' "${OUT_DIR}/per_gene_stats.tsv" > "${OUT_DIR}/summary_stats.tsv"

  echo "[INFO] Finished ${GROUP} / ${CLASS}"
  echo "[INFO] Output: ${OUT_DIR}/per_gene_stats.tsv"
  echo "[INFO] Output: ${OUT_DIR}/summary_stats.tsv"
done

echo "[INFO] All done for ${CLASS}"