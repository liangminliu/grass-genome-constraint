#!/bin/bash
#BSUB -J snpEff_pedC
#BSUB -q Q96C1T_X12
#BSUB -n 20
#BSUB -o snpEff_pedC.%J.out
#BSUB -e snpEff_pedC.%J.err

set -euo pipefail

mkdir -p GERP_del

singularity exec ~/workspace/4.reseq-chr/software/Reseq_genek.sif \
  java -jar /opt/snpEff/snpEff.jar \
  -c ./snpEff.config \
  -ud 5000 \
  -csvStats GERP_del/pedC.csv \
  -htmlStats GERP_del/pedC.html \
  -o vcf \
  ped \
  GERP_del/pedC_gt4_snps.vcf.gz \
  > GERP_del/pedC_gt4.snp.ann.vcf