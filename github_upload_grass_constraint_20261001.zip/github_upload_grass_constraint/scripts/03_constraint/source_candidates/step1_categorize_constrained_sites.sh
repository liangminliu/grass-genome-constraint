#!/bin/bash
#BSUB -q Q96C1T_X12
#BSUB -J categorize_constrained
#BSUB -o categorize_constrained.out
#BSUB -e categorize_constrained.err
#BSUB -n 2

set -e

# 定义文件路径
GFF_FILE="ped.gff"
CONSTRAINED_FILE="Ped01C_output.txt"
CHROM_SIZES_FILE="chrom_sizes.bed"
CHROM_IDS_FILE="chrom_ids.txt"

# Function to validate BED files (accept 6 or 7 fields)
validate_bed() {
    awk '{
        if (NF != 6 && NF != 7) {
            print "Error in " FILENAME " at line " NR ": expected 6 or 7 fields, found " NF;
            exit 1
        }
    }' "$1"
    echo "$1 is valid."
}

echo "=== 开始修复 chrom_sizes.bed 的字段分隔符 ==="
# 1. 修复 chrom_sizes.bed，确保所有行使用制表符分隔
awk '{print $1 "\t" $2 "\t" $3}' "$CHROM_SIZES_FILE" > chrom_sizes_fixed.bed
mv chrom_sizes_fixed.bed "$CHROM_SIZES_FILE"
echo "已修复 $CHROM_SIZES_FILE 文件。"

echo "=== 生成 chrom_ids.txt ==="
# 2. 提取染色体 ID
cut -f1 "$CHROM_SIZES_FILE" | sort | uniq > "$CHROM_IDS_FILE"

# 3. 验证 chrom_ids.txt
echo "染色体 ID 列表："
cat "$CHROM_IDS_FILE"

echo "=== 过滤 GFF 文件，仅保留染色体级别的注释 ==="
# 4. 过滤 GFF 文件，仅保留染色体级别的注释
awk 'BEGIN { 
        while ((getline line < "'"$CHROM_IDS_FILE"'") > 0) { 
            chrom[line] = 1 
        } 
    }
    chrom[$1] {print}' "$GFF_FILE" > filtered_ped.gff

# 5. 验证 filtered_ped.gff
if [ -s filtered_ped.gff ]; then
    echo "filtered_ped.gff 已成功生成，包含 $(wc -l < filtered_ped.gff) 行。"
else
    echo "错误: filtered_ped.gff 为空，请检查 chrom_ids.txt 和 ped.gff 中的染色体 ID 是否匹配。"
    exit 1
fi

echo "=== 提取功能区域 ==="
# 6. 提取基因并包含基因 ID
awk 'BEGIN {OFS="\t"}
     $3 == "gene" {
         match($9, /ID=([^;]+)/, arr)
         gene_id = arr[1]
         print $1, $4-1, $5, gene_id, ".", $7
     }' filtered_ped.gff > genes.bed
validate_bed genes.bed

# 7. 提取外显子并包含 Parent ID
awk 'BEGIN {OFS="\t"}
     $3 == "exon" {
         match($9, /Parent=([^;]+)/, arr)
         parent_id = arr[1]
         print $1, $4-1, $5, parent_id, ".", $7
     }' filtered_ped.gff > exons.bed
validate_bed exons.bed

# 8. 提取 CDS 并包含 Parent ID
awk 'BEGIN {OFS="\t"}
     $3 == "CDS" {
         match($9, /Parent=([^;]+)/, arr)
         parent_id = arr[1]
         print $1, $4-1, $5, parent_id, ".", $7
     }' filtered_ped.gff > CDS.bed
validate_bed CDS.bed

# 9. 提取 5' UTR 并包含 Parent ID
awk 'BEGIN {OFS="\t"}
     $3 == "five_prime_UTR" {
         match($9, /Parent=([^;]+)/, arr)
         parent_id = arr[1]
         print $1, $4-1, $5, parent_id, ".", $7
     }' filtered_ped.gff > five_prime_UTR.bed
validate_bed five_prime_UTR.bed

# 10. 提取 3' UTR 并包含 Parent ID
awk 'BEGIN {OFS="\t"}
     $3 == "three_prime_UTR" {
         match($9, /Parent=([^;]+)/, arr)
         parent_id = arr[1]
         print $1, $4-1, $5, parent_id, ".", $7
     }' filtered_ped.gff > three_prime_UTR.bed
validate_bed three_prime_UTR.bed

# 11. 定义启动子并包含 Parent ID
awk 'BEGIN {OFS="\t"}
($3 == "gene") {
    chrom = $1
    strand = $7
    gff_start = $4
    gff_end = $5

    # 提取基因 ID
    match($9, /ID=([^;]+)/, arr)
    gene_id = arr[1]

    if (strand == "+") {
        promoter_start = gff_start - 1 - 1000  # 转换为 BED 坐标并向上游扩展 1000 bp
        if (promoter_start < 0) promoter_start = 0
        promoter_end = gff_start - 1          # 结束于基因起始位置前一位
    }
    else if (strand == "-") {
        promoter_start = gff_end               # 起始于基因结束位置
        promoter_end = gff_end + 1000          # 向下游扩展 1000 bp
    }
    else {
        # 处理未知链向的情况（可选）
        next
    }

    promoter_id = gene_id "_promoter_" strand

    print chrom, promoter_start, promoter_end, promoter_id, ".", strand, "promoter"
}' filtered_ped.gff > promoters.bed


# 12. 定义 UpDown5K 并包含 Parent ID
aawk 'BEGIN {OFS="\t"} 
     $3 == "gene" {
         chrom = $1
         strand = $7
         gff_start = $4
         gff_end = $5
         
         # 提取基因 ID
         match($9, /ID=([^;]+)/, arr)
         gene_id = arr[1]
         
         if (strand == "+") {
             # 正链
             up_start = gff_start - 5000 - 1  # 转换为 BED 坐标并向上游扩展 5000 bp
             if (up_start < 0) up_start = 0
             up_end = gff_start - 1          # 结束于基因起始位置前一位
             
             down_start = gff_end             # 起始于基因终止位置
             down_end = gff_end + 5000         # 向下游扩展 5000 bp
         }
         else if (strand == "-") {
             # 负链
             up_start = gff_end               # 起始于基因终止位置
             up_end = gff_end + 5000           # 向上游扩展 5000 bp
             
             down_start = gff_start - 5000 - 1  # 转换为 BED 坐标并向下游扩展 5000 bp
             if (down_start < 0) down_start = 0
             down_end = gff_start - 1          # 结束于基因起始位置前一位
         }
         else {
             # 处理未知链向的情况（可选）
             next
         }
         
         # 生成上下游区域的唯一 ID
         up_id = gene_id "_up5k_" strand
         down_id = gene_id "_down5k_" strand
         
         # 输出上游区域
         print chrom, up_start, up_end, up_id, ".", strand, "up5k"
         
         # 输出下游区域
         print chrom, down_start, down_end, down_id, ".", strand, "down5k"
     }' filtered_ped.gff > updown5k.bed


# 13. 定义内含子并添加类别标签
echo "定义内含子区域..."
# 对基因和外显子进行排序并保存为 *_sorted.bed
sort -k1,1 -k2,2n genes.bed > genes_sorted.bed
sort -k1,1 -k2,2n exons.bed > exons_sorted.bed

# 使用 bedtools 减去外显子，得到内含子
bedtools subtract -a genes_sorted.bed -b exons_sorted.bed | awk '{OFS="\t"; print $1, $2, $3, ".", ".", "+"}' > introns.bed
validate_bed introns.bed

# 为内含子区域添加类别标签
awk 'BEGIN {OFS="\t"} {print $1, $2, $3, ".", ".", "intron"}' introns.bed > introns_final.bed
validate_bed introns_final.bed

# 14. 合并所有注释区域并排序
echo "合并所有注释区域..."
cat genes_sorted.bed exons_sorted.bed CDS.bed five_prime_UTR.bed three_prime_UTR.bed promoters.bed updown5k.bed introns_final.bed | awk '{$1=$1; OFS="\t"; print $1, $2, $3, $4, $5, $6}' | sort -k1,1 -k2,2n > annotated_regions_sorted.bed
validate_bed annotated_regions_sorted.bed

#cat genes_sorted.bed exons_sorted.bed CDS.bed five_prime_UTR.bed three_prime_UTR.bed promoters.bed updown5k.bed introns_final.bed | sort -k1,1 -k2,2n | bedtools merge -i - -c 4,5,6 -o distinct > re_annotated_regions_sorted.bed
# 15. 生成基因间区（Intergenic Regions）
echo "=== 生成基因间区 (Intergenic Regions) ==="
bedtools complement -i annotated_regions_sorted.bed -g "$CHROM_SIZES_FILE" > re_intergenic.bed

# 为基因间区添加类别标签
awk 'BEGIN {OFS="\t"} {print $1, $2, $3, ".", ".", ".", "intergenic"}' re_intergenic.bed > re_intergenic_final.bed
validate_bed intergenic_final.bed

# 15. 生成间隔区域 ###这个包括了其他的注释功能，长度比较长
awk 'BEGIN { 
        FS="\t"
        OFS="\t"
        # 读取染色体长度
        while (getline < "chr.txt") {
            chrom_length[$1] = $2
        }
    }
    {
        chrom = $1
        start = $2
        end = $3
        gene_id = $4
        score = $5
        strand = $6

        # 标记有基因的染色体
        genes_seen[chrom] = 1

        # 如果切换到新的染色体
        if (chrom != prev_chrom) {
            # 处理前一染色体的最后一个基因到染色体末端的基因间区
            if (prev_chrom != "") {
                intergenic_start = prev_end
                intergenic_end = chrom_length[prev_chrom]
                if (intergenic_start < intergenic_end) {
                    intergenic_id = prev_gene_id "_to_" prev_chrom "_end"
                    print prev_chrom, intergenic_start, intergenic_end, intergenic_id, ".", ".", "intergenic"
                }
            }

            # 定义新染色体的起始到第一个基因的基因间区
            intergenic_start = 0
            intergenic_end = start
            if (intergenic_start < intergenic_end) {
                intergenic_id = chrom "_start_to_" gene_id
                print chrom, intergenic_start, intergenic_end, intergenic_id, ".", ".", "intergenic"
            }

            # 更新前一个基因信息
            prev_chrom = chrom
            prev_end = end
            prev_gene_id = gene_id
            next
        }

        # 在同一染色体内，定义前一个基因到当前基因的基因间区
        if (prev_end < start) {
            intergenic_start = prev_end
            intergenic_end = start
            intergenic_id = prev_gene_id "_to_" gene_id
            print chrom, intergenic_start, intergenic_end, intergenic_id, ".", ".", "intergenic"
        }

        # 更新前一个基因信息
        prev_end = end
        prev_gene_id = gene_id
    }
    END {
        # 处理最后一个染色体的基因间区
        if (prev_chrom in chrom_length) {
            intergenic_start = prev_end
            intergenic_end = chrom_length[prev_chrom]
            if (intergenic_start < intergenic_end) {
                intergenic_id = prev_gene_id "_to_" prev_chrom "_end"
                print prev_chrom, intergenic_start, intergenic_end, intergenic_id, ".", ".", "intergenic"
            }
        }

        # 处理没有基因的染色体，定义整个染色体为基因间区
        for (chrom in chrom_length) {
            if (!(chrom in genes_seen)) {
                intergenic_start = 0
                intergenic_end = chrom_length[chrom]
                intergenic_id = chrom "_entire"
                print chrom, intergenic_start, intergenic_end, intergenic_id, ".", ".", "intergenic"
            }
        }
    }' genes_sorted.bed > intergenic.bed


# 16. 排序所有功能区域 BED 文件并保存为 *_sorted.bed
echo "排序所有功能区域 BED 文件..."
for bed_file in CDS.bed five_prime_UTR.bed three_prime_UTR.bed promoters.bed updown5k.bed introns_final.bed intergenic_final.bed; do
    sort -k1,1 -k2,2n "$bed_file" > "${bed_file%.bed}_sorted.bed"
    echo "已将 $bed_file 排序为 ${bed_file%.bed}_sorted.bed。"
done

# 17. 准备受限位点 BED 文件并排序
echo "准备受限位点 BED 文件..."
awk 'BEGIN {OFS="\t"} {print $1, $2, $3, ".", ".", ".", $7}' "$CONSTRAINED_FILE" > Ped01C_output.bed

# 确保使用制表符分隔
awk 'BEGIN {OFS="\t"} {print $1, $2, $3, $4, $5, $6, $7}' Ped01C_output.bed > Ped01C_output_tab.bed
mv Ped01C_output_tab.bed Ped01C_output.bed

# 对受限位点进行排序并保存为 Ped01C_output_sorted.bed
sort -k1,1 -k2,2n Ped01C_output.bed > Ped01C_output_sorted.bed

# 18. 定义类别及其对应的排序后的 BED 文件
declare -A categories=(
    ["CDS"]="CDS_sorted.bed"
    ["Five_prime_UTR"]="five_prime_UTR_sorted.bed"
    ["Three_prime_UTR"]="three_prime_UTR_sorted.bed"
    ["Promoter"]="promoters_sorted.bed"
    ["UpDown5K"]="updown5k_sorted.bed"
    ["Intron"]="introns_final_sorted.bed"
    ["Intergenic"]="intergenic_final_sorted.bed"
)

# 19. 创建输出目录
mkdir -p categorized_constrained_sites

# 20. 分类受限位点
echo "分类受限位点到各功能区域..."
for category in "${!categories[@]}"; do
    bed_file="${categories[$category]}"
    if [ ! -f "$bed_file" ]; then
        echo "错误: 找不到文件 $bed_file。请确保该文件存在并已正确生成。"
        exit 1
    fi
    bedtools intersect -a Ped01C_output_sorted.bed -b "$bed_file" -wa -u > "categorized_constrained_sites/${category}_constrained.bed"
    echo "  - $category: $(wc -l < "categorized_constrained_sites/${category}_constrained.bed") constrained sites"
done

echo "分类完成。请查看 'categorized_constrained_sites' 目录中的结果。"
