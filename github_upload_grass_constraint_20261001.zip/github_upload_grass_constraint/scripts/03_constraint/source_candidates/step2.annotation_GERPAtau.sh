#!/bin/bash
#BSUB -J step2.annotation_GERPAtau
#BSUB -q Q96C1T_X12
#BSUB -n 20
#BSUB -o logs/step2.annotation_GERPAtau.%J.out
#BSUB -e logs/step2.annotation_GERPAtau.%J.err

set -euo pipefail

mkdir -p logs
mkdir -p GERP_del

########################################
# Input / output
########################################
VCF_IN="GERP_del/merged_gt4_snps.vcf.gz"
VCF_OUT="GERP_del/merged_gt4.snp.ann.vcf"
CSV_OUT="GERP_del/Atau_gt4.csv"
HTML_OUT="GERP_del/Atau_gt4.html"

########################################
# snpEff settings
########################################
SIF="$HOME/workspace/4.reseq-chr/software/Reseq_genek.sif"
CONFIG="./snpEff.config"
GENOME_DB="Atau"   # 改成你 snpEff.config 中实际的 Atau genome ID

########################################
# Check input
########################################
[[ -f "${VCF_IN}" ]] || { echo "[ERROR] Input not found: ${VCF_IN}"; exit 1; }

echo "[INFO] Start: $(date)"
echo "[INFO] Input : ${VCF_IN}"
echo "[INFO] Output: ${VCF_OUT}"
echo "[INFO] DB    : ${GENOME_DB}"

singularity exec "${SIF}" \
  java -Xmx200g -jar /opt/snpEff/snpEff.jar \
  -c "${CONFIG}" \
  -ud 5000 \
  -csvStats "${CSV_OUT}" \
  -htmlStats "${HTML_OUT}" \
  -o vcf \
  "${GENOME_DB}" \
  "${VCF_IN}" \
  > "${VCF_OUT}"

echo "[INFO] Done: $(date)"

bgzip -f $VCF_OUT
tabix -f -p vcf $VCF_OUT

bgzip -f 141sp.filtered.bi-allelic.snp.ann.vcf
tabix -f -p vcf 141sp.filtered.bi-allelic.snp.ann.vcf.gz
