#!/bin/bash
#BSUB -J potato_struct_v63_chr
#BSUB -q Q64C1T_X4
#BSUB -n 4
#BSUB -o logs/potato_struct_v63_chr.%J.out
#BSUB -e logs/potato_struct_v63_chr.%J.err

set -euo pipefail

mkdir -p logs
mkdir -p results

PY_SCRIPT="potato_genome_structure_from_gff3_v63_chr_only.py"
GENE_GFF="Stuberosum_686_v6.1.gene_exons.gff3"
REPEAT_GFF="DM_1-3_516_R44_potato_genome_assembly.v6.1.hm.out.gff"
REPEAT_TBL="DM_1-3_516_R44_potato_genome_assembly.v6.1.hm.tbl"
GENOME_FA="DM_1-3_516_R44_potato_genome_assembly.v6.1.fa"

OUTDIR="results/potato_structure_v63_chr"
PREFIX="Stuberosum_686_v6.1.chromosome"

for f in "$PY_SCRIPT" "$GENE_GFF" "$REPEAT_GFF" "$GENOME_FA"; do
    if [[ ! -s "$f" ]]; then
        echo "[ERROR] missing or empty: $f" >&2
        exit 1
    fi
done

EXTRA_TBL=()
if [[ -s "$REPEAT_TBL" ]]; then
    EXTRA_TBL+=(--repeat-tbl "$REPEAT_TBL")
else
    echo "[WARN] repeat tbl not found, continue without it: $REPEAT_TBL"
fi

python3 "$PY_SCRIPT" \
    --gene-gff3 "$GENE_GFF" \
    --repeat-gff "$REPEAT_GFF" \
    --genome-fa "$GENOME_FA" \
    "${EXTRA_TBL[@]}" \
    --chrom-regex '^chr[0-9]{2}$' \
    --promoter-bp 1000 \
    --flank-bp 5000 \
    --outdir "$OUTDIR" \
    --prefix "$PREFIX"

ls -lh "$OUTDIR"/* || true
ls -lh "$OUTDIR"/features | head || true
