#!/bin/bash
#BSUB -J plot_gerp_pubstyle
#BSUB -q Q64C1T_X4
#BSUB -n 10
#BSUB -o logs/plot_gerp_pubstyle.%J.out
#BSUB -e logs/plot_gerp_pubstyle.%J.err



mkdir -p logs

echo "[INFO] Job started at: $(date)"
echo "[INFO] Host: $(hostname)"
echo "[INFO] Workdir: $(pwd)"

# 如需激活环境，取消下面注释并改成你的环境
# source ~/miniforge3/etc/profile.d/conda.sh
# conda activate base

# 检查输入文件
for f in plot_gerp_pubstyle.py ALL_gerp.tsv C_CDS_gerp.tsv D_CDS_gerp.tsv; do
    [[ -f "$f" ]] || { echo "[ERROR] Missing file: $f"; exit 1; }
done

python3 plot_gerp_mbe_final.py \
  --all_file ALL_gerp.tsv \
  --c_cds_file C_CDS_gerp.tsv \
  --d_cds_file D_CDS_gerp.tsv \
  --bin_size 0.4 \
  --output_prefix ped_gerp_mbe_final_0.4v5 \
  --annotate_overflow \
  --show_break_note \
  --panel_label B \
  --fig_width 4.8 \
  --fig_height 4.2

echo "[INFO] Job finished at: $(date)"