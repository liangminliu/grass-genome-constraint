 #!/usr/bin/env bash
#BSUB -J step12
#BSUB -q Q96C1T_X12
#BSUB -n 16
#BSUB -o step12.%J.out
#BSUB -e step12.%J.err

set -euo pipefail
 python3 15_CNS60_gene60_statistics.py

 python3 16_TB1_finalize_statistics.py

 python3 17_WUS1_WUS2_CNS_GERP.py

 awk 'BEGIN{FS=OFS="\t"}
     $0 !~ /^#/ &&
     $3=="gene" &&
     (
       $9 ~ /Zm00001eb067310/ ||
       $9 ~ /Zm00001eb433010/
     )
     {
         name="WUS"
         if($9 ~ /Zm00001eb067310/)
             name="ZmWUS1|Zm00001eb067310"
         if($9 ~ /Zm00001eb433010/)
             name="ZmWUS2|Zm00001eb433010"

         print $1,$4-1,$5,name,$6,$7
     }' \
Zmay.filtered.gff \
> 08_WUS/WUS1_WUS2.genes.raw.bed

bedtools sort \
    -faidx 07_final_stats/background/Zmay_v5.chr.order \
    -i 08_WUS/WUS1_WUS2.genes.raw.bed \
> 08_WUS/WUS1_WUS2.genes.bed

bedtools slop \
    -i 08_WUS/WUS1_WUS2.genes.bed \
    -g 07_final_stats/background/Zmay_v5.genome \
    -b 100000 \
> 08_WUS/WUS1_WUS2.plusminus100kb.bed


awk 'BEGIN{FS=OFS="\t"}
     NR>1 {
        print $1,$2,$3,$5,$7,$16,$18,$20,$23
     }' \
04_tables/CNS_level_GERP_summary_chr.tsv \
> 08_WUS/all_CNS.for_track.bed

bedtools intersect \
    -a 08_WUS/all_CNS.for_track.sorted.bed \
    -b 08_WUS/WUS1_WUS2.plusminus100kb.bed \
    -wa \
> 08_WUS/WUS1_WUS2.plusminus100kb.all_CNS.bed

