#!/bin/bash
#SBATCH --job-name=functional_intersect_Zmay
#SBATCH --output=logs/functional_intersect_Zmay_%A_%a.log
#SBATCH --error=logs/functional_intersect_Zmay_%A_%a.err
#SBATCH --cpus-per-task=8
#SBATCH --array=1-4%4

set -euo pipefail
mkdir -p logs

############################################################
# 1. GERP class mapping
############################################################
GERP_DIRS=(merged_gt0 merged_gt2 merged_gt4 merged_gt6)

IDX=$((SLURM_ARRAY_TASK_ID - 1))
GERP_DIR=${GERP_DIRS[$IDX]}

INPUT_GERP_BED="${GERP_DIR}/${GERP_DIR}_gerp_regions.bed"

echo "=== Processing Zmay ${GERP_DIR} ==="

if [ ! -s "$INPUT_GERP_BED" ]; then
    echo "ERROR: missing or empty $INPUT_GERP_BED"
    exit 1
fi

GERP_TOTAL_LEN=$(awk '{s+=$3-$2} END{print s}' "$INPUT_GERP_BED")
echo "GERP regions: $(wc -l < "$INPUT_GERP_BED")"
echo "GERP total length: $GERP_TOTAL_LEN bp"

############################################################
# 2. Functional BEDs
############################################################
FUNCTIONAL_DIR=$(readlink -f genomic_features_results)
[ -d "$FUNCTIONAL_DIR" ] || { echo "ERROR: functional directory not found"; exit 1; }

FUNCTIONAL_BEDS=($(find "$FUNCTIONAL_DIR" -name "*processed.bed" | sort))
[ ${#FUNCTIONAL_BEDS[@]} -gt 0 ] || { echo "ERROR: no functional BEDs found"; exit 1; }

############################################################
# 3. Output
############################################################
OUTDIR="${GERP_DIR}/functional_analysis"
mkdir -p "$OUTDIR"

SUMMARY="${OUTDIR}/${GERP_DIR}_summary.tsv"
echo -e "Region\tOverlap_intervals\tOverlap_bp\tGERP_coverage(%)\tFUNC_coverage(%)" > "$SUMMARY"

############################################################
# 4. GERP × functional intersect
############################################################
for FUNC_BED in "${FUNCTIONAL_BEDS[@]}"; do
    FUNC_NAME=$(basename "$FUNC_BED" _processed.bed)

    OVL="${OUTDIR}/${GERP_DIR}_${FUNC_NAME}_overlap.bed"
    DETAIL="${OUTDIR}/${GERP_DIR}_${FUNC_NAME}_detailed.bed"

    # 实际 overlap 区间（用于统计）
    bedtools intersect -a "$INPUT_GERP_BED" -b "$FUNC_BED" > "$OVL" || true

    # 详细 overlap（GERP × FUNC，保留两侧信息）
    bedtools intersect -a "$INPUT_GERP_BED" -b "$FUNC_BED" -wa -wb > "$DETAIL" || true

    if [ -s "$OVL" ]; then
        OVL_N=$(wc -l < "$OVL")
        OVL_LEN=$(awk '{s+=$3-$2} END{print s}' "$OVL")
        FUNC_LEN=$(awk '{s+=$3-$2} END{print s}' "$FUNC_BED")

        GERP_COV=$(awk -v a="$OVL_LEN" -v b="$GERP_TOTAL_LEN" \
            'BEGIN{printf "%.4f", (b>0?a/b*100:0)}')

        FUNC_COV=$(awk -v a="$OVL_LEN" -v b="$FUNC_LEN" \
            'BEGIN{printf "%.4f", (b>0?a/b*100:0)}')
    else
        OVL_N=0
        OVL_LEN=0
        GERP_COV=0
        FUNC_COV=0
        rm -f "$OVL" "$DETAIL"
    fi

    echo -e "${FUNC_NAME}\t${OVL_N}\t${OVL_LEN}\t${GERP_COV}\t${FUNC_COV}" >> "$SUMMARY"
done

echo "=== DONE Zmay ${GERP_DIR} ==="
echo "Summary: $SUMMARY"
