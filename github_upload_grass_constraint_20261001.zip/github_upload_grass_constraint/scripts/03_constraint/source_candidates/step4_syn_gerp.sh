#!/bin/bash
#SBATCH --job-name=functional_intersect
#SBATCH --output=logs/functional_intersect_%A_%a.log
#SBATCH --error=logs/functional_intersect_%A_%a.err
#SBATCH --cpus-per-task=10
#SBATCH --array=1-4%4

# ============================================================
# Purpose:
#   Intersect GERP-constrained SNPs with functional regions
#   GERP merged_gt*.bed contains header -> skipped on-the-fly
# ============================================================

set -euo pipefail

mkdir -p logs

# ============================================================
# Singularity tmp dir
# ============================================================

WORK_TMP_DIR="$(pwd)/singularity_tmp_$$"
export SINGULARITY_TMPDIR="$WORK_TMP_DIR"
export TMPDIR="$WORK_TMP_DIR"
mkdir -p "$SINGULARITY_TMPDIR"

cleanup() {
    echo "Cleaning tmp dir: $SINGULARITY_TMPDIR"
    rm -rf "$SINGULARITY_TMPDIR"
}
trap cleanup EXIT

echo "TMPDIR: $SINGULARITY_TMPDIR"
df -h "$(pwd)"

# ============================================================
# Input definition
# ============================================================

# SNP VCF base dir (generated in previous step)
BASE_INPUT_DIR="../../02.deleterious"

# GERP classes (array-controlled)
GERP_CLASSES=("gt0" "gt2" "gt4" "gt6")

# GERP BED base (SAME SPECIES: Atau)
GERP_BED_BASE="/gpfs/hpc/home/kib_unit/lidezhu/liuliangmin/2.msa/Atau_msa/results/GERP_final_output"

IDX=$((SLURM_ARRAY_TASK_ID - 1))
GERP_CLASS="${GERP_CLASSES[$IDX]}"

GERP_BED="${GERP_BED_BASE}/merged_${GERP_CLASS}.bed"

if [ ! -f "$GERP_BED" ]; then
    echo "ERROR: GERP BED not found: $GERP_BED"
    exit 1
fi

echo "GERP class : ${GERP_CLASS}"
echo "GERP BED   : ${GERP_BED}"

# Input SNP VCF (compressed)
INPUT_VCF="${BASE_INPUT_DIR}/merged_${GERP_CLASS}/merged_${GERP_CLASS}_snps.vcf.gz"

if [ ! -f "$INPUT_VCF" ]; then
    echo "ERROR: Input VCF not found: $INPUT_VCF"
    exit 1
fi

# ============================================================
# Output dir
# ============================================================

OUTPUT_DIR="$(pwd)/functional_analysis/merged_${GERP_CLASS}"
mkdir -p "$OUTPUT_DIR"

echo "Input VCF : $INPUT_VCF"
echo "Output dir: $OUTPUT_DIR"

# ============================================================
# Functional BEDs (assumed NO header)
# ============================================================

FUNCTIONAL_BEDS=($(find . -maxdepth 1 -name "*.bed" -type f | sort))

if [ ${#FUNCTIONAL_BEDS[@]} -eq 0 ]; then
    echo "ERROR: no functional BED files found"
    exit 1
fi

echo "Found ${#FUNCTIONAL_BEDS[@]} functional BEDs:"
for f in "${FUNCTIONAL_BEDS[@]}"; do
    echo "  - $(basename "$f")"
done

# ============================================================
# Main loop
# ============================================================

for FUNC_BED in "${FUNCTIONAL_BEDS[@]}"; do
    FUNC_NAME=$(basename "$FUNC_BED" .bed)

    echo "=================================================="
    echo "Functional region: $FUNC_NAME"

    OUT_VCF="${OUTPUT_DIR}/merged_${GERP_CLASS}_${FUNC_NAME}_overlap.vcf"
    OUT_SNP_BED="${OUTPUT_DIR}/merged_${GERP_CLASS}_${FUNC_NAME}_overlap.bed"
    OUT_FUNC_BED="${OUTPUT_DIR}/merged_${GERP_CLASS}_${FUNC_NAME}_func_regions.bed"

    # --------------------------------------------------------
    # 1. SNP ∩ Functional region (VCF)
    # --------------------------------------------------------

    singularity exec ~/liuliangmin/4.may/software/Reseq_genek.sif \
      bcftools view "$INPUT_VCF" | \
      bedtools intersect -a stdin -b "$FUNC_BED" -header \
      > "$OUT_VCF"

    if [ -s "$OUT_VCF" ]; then
        VCF_N=$(grep -vc '^#' "$OUT_VCF")
        echo "  VCF SNPs : $VCF_N"
    else
        echo "  VCF SNPs : 0"
        rm -f "$OUT_VCF"
    fi

    # --------------------------------------------------------
    # 2. SNP coordinates (BED)
    # --------------------------------------------------------

    singularity exec ~/liuliangmin/4.may/software/Reseq_genek.sif \
      bcftools view "$INPUT_VCF" | \
      bedtools intersect -a stdin -b "$FUNC_BED" | \
      awk 'BEGIN{OFS="\t"} !/^#/ {print $1, $2-1, $2, $3}' \
      > "$OUT_SNP_BED"

    if [ -s "$OUT_SNP_BED" ]; then
        echo "  BED SNPs : $(wc -l < "$OUT_SNP_BED")"
    else
        rm -f "$OUT_SNP_BED"
    fi

    # --------------------------------------------------------
    # 3. Functional regions overlapped by SNPs
    # --------------------------------------------------------

    bedtools intersect \
      -a "$FUNC_BED" \
      -b <(singularity exec ~/liuliangmin/4.may/software/Reseq_genek.sif \
           bcftools view "$INPUT_VCF" | \
           awk 'BEGIN{OFS="\t"} !/^#/ {print $1, $2-1, $2}') \
      -wa > "$OUT_FUNC_BED"

    if [ -s "$OUT_FUNC_BED" ]; then
        echo "  Func regions: $(wc -l < "$OUT_FUNC_BED")"
    else
        rm -f "$OUT_FUNC_BED"
    fi

    echo "DONE: $FUNC_NAME"
    echo ""
done

echo "All functional intersections finished."
echo "Results in: $OUTPUT_DIR"
