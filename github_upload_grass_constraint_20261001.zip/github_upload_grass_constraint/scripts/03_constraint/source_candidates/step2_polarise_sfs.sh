#!/bin/bash
#SBATCH --job-name=polarise_Atau_all_chr
#SBATCH --cpus-per-task=40
#SBATCH --partition=parallel
#SBATCH --output=%x_%j.out
#SBATCH --error=%x_%j.err

set -euo pipefail

############################
source ~/miniforge3/etc/profile.d/conda.sh
conda activate base
echo "=== Environment Information ==="
echo "GSL version: $(gsl-config --version)"
echo "GSL prefix: $(gsl-config --prefix)"
echo "Python version: $(python3 --version)"
echo "================================"

############################
# Chromosomes (Atau)
############################
chromosomes=("1D" "2D" "3D" "4D" "5D" "6D" "7D")

############################
# Set working directory to current directory
wd=$(pwd)
bin="$HOME/biosoftware/est-sfs-release-2.04/est-sfs"

# Verify est-sfs is available and working
if ldd "$bin" | grep -q "not found"; then
    echo "Error: missing shared libraries:"
    ldd "$bin" | grep "not found"
    exit 1
fi
echo "est-sfs shared libraries OK"


############################
# Default parameters
############################
outd="${outd:-est_sfs_results}"
config="${config:-config-kimura.txt}"
focfreq="${focfreq:-table.acgt.format.tsv}"
outgr="${outgr:-Atau.Aspe.Telo.wga.bed}"

############################
# Required files
############################
echo "=== Checking required files ==="
for f in "$focfreq" "$outgr" "$config" seedfile.txt; do
    [[ -f $f ]] || { echo "ERROR: missing $f"; exit 1; }
    echo "✓ $f"
done
echo "================================"

############################
# Output directory
############################
mkdir -p "$outd"

############################
# Prepare outgroup WGA (once)
############################
echo "=== Preparing outgroup alignment ==="

# remove indels in the bed alignment (keep sites with A/C/G/T only)
awk '{if ($8 ~ /.,.,./) print $0}' "$outgr" \
  | sort -k1,1 -k2,2n \
  > "${outgr/.bed/.noindel.bed}"

# fix ambiguities (optional)
if [[ -f polar_2_fix.outgroups.py ]]; then
    echo "Fixing outgroup ambiguities..."
    python3 polar_2_fix.outgroups.py \
        -bed "${outgr/.bed/.noindel.bed}" \
        > fix.outgroup.log 2>&1 \
    && processed_outgr="${outgr/.bed/.noindel.fixed.bed}" \
    || processed_outgr="${outgr/.bed/.noindel.bed}"
else
    processed_outgr="${outgr/.bed/.noindel.bed}"
fi

echo "Using outgroup file: $processed_outgr"
echo "===================================="

############################
# Summary stats
############################
total_missing=0
processed_count=0
failed_count=0
start_time=$(date +%s)

# Initialize per-chromosome missing stats (overwrite each run)
echo -e "chr\tmissing\ttotal" > outgroup_missing.stats.tsv

############################
# Main loop
############################
for chr in "${chromosomes[@]}"; do

    echo ""
    echo "=========================================="
    echo "Processing chromosome: $chr"
    echo "=========================================="

    ############################
    # Intersect focal with outgroup
    ############################
    # IMPORTANT: bedtools -sorted requires both -a and -b sorted by chr/start
    bedtools intersect -sorted -loj \
      -a <(grep "^${chr}[[:space:]]" "$focfreq" | sort -k1,1 -k2,2n || true) \
      -b "$processed_outgr" \
      > "${chr}.intersected" \
      2> "${chr}.intersect.err" || {
          echo "bedtools intersect failed for $chr"
          failed_count=$((failed_count+1))
          continue
      }

    [[ -s ${chr}.intersected ]] || {
        echo "No data for $chr"
        failed_count=$((failed_count+1))
        continue
    }

    ############################
    # Build est-sfs input
    ############################
    paste \
      <(cut -f4 "${chr}.intersected") \
      <(cut -f12 "${chr}.intersected" | awk -F, '
{
  as=cs=gs=ts=af=cf=gf=tf=0;
  if($3 ~ /[aA]/) as=1; if($3 ~ /[cC]/) cs=1;
  if($3 ~ /[gG]/) gs=1; if($3 ~ /[tT]/) ts=1;
  if($2 ~ /[aA]/) af=1; if($2 ~ /[cC]/) cf=1;
  if($2 ~ /[gG]/) gf=1; if($2 ~ /[tT]/) tf=1;
  printf "%d,%d,%d,%d %d,%d,%d,%d\n", as,cs,gs,ts,af,cf,gf,tf
}') > "${chr}.est_sfs.input"

    ############################
    # Missing outgroup sites
    ############################
    missing=$(grep -c "0,0,0,0 0,0,0,0" "${chr}.est_sfs.input" || echo 0)
    total=$(wc -l < "${chr}.est_sfs.input")

    echo "[INFO] Missing outgroup sites: $missing / $total"
    echo -e "${chr}\t${missing}\t${total}" >> outgroup_missing.stats.tsv

    # accumulate summary
    total_missing=$((total_missing + missing))
    processed_count=$((processed_count + 1))

done

############################
# Final report
############################
end_time=$(date +%s)

echo ""
echo "=========================================="
echo "Atau polarisation finished"
echo "Processed: $processed_count"
echo "Failed:    $failed_count"
echo "Total missing outgroup sites: $total_missing"
echo "Elapsed time: $((end_time-start_time)) s"
echo "Outputs:"
echo "  - outgroup_missing.stats.tsv"
echo "  - per-chr: *.intersected, *.est_sfs.input"
echo "=========================================="
