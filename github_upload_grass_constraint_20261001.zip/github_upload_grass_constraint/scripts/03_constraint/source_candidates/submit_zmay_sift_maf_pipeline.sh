#!/bin/bash
#BSUB -J Zmaize_sift_MAF
#BSUB -q Q64C1T_X4
#BSUB -n 10
#BSUB -o logs/Zmaize_sift_MAF.%J.out
#BSUB -e logs/Zmaize_sift_MAF.%J.err

set -euo pipefail

mkdir -p logs
mkdir -p results

VCF="Zmay.sift_lt0.05.vcf.gz"
PREFIX="results/Zmay.sift_lt0.05"

echo "[INFO] job started at $(date)"
echo "[INFO] host: $(hostname)"
echo "[INFO] workdir: $(pwd)"

bash 01_calc_maf_vcftools.sh "${VCF}" "${PREFIX}"


# 参数说明：
# 0.01    -> bin width
# count   -> 纵坐标画绝对数，更接近你给的三面板参考图
# FALSE   -> 去掉 MAF=0 的固定位点
Rscript 02_plot_maf_hist.R results/Zmay.sift_lt0.05.frq results/Zmay.sift_lt0.05 0.005 count FALSE

echo "[INFO] finished at $(date)"