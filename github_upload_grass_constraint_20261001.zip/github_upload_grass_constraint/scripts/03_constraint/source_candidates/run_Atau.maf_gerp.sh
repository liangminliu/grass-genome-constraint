#!/bin/bash
#SBATCH --job-name=deleterious_maf
#SBATCH --partition=parallel
#SBATCH --cpus-per-task=8
#SBATCH --output=deleterious_maf.%j.out
#SBATCH --error=deleterious_maf.%j.err

set -euo pipefail

############################################
# Paths
############################################
SIF="/gpfs/hpc/home/kib_unit/lidezhu/liuliangmin/4.may/software/Reseq_genek.sif"

VCF_GT2="Atau.merged_gt2_snps.vcf.gz"
VCF_GT4="Atau.merged_gt4_snps.vcf.gz"

############################################
# Function
############################################
calc_maf_vcftools () {
  vcf=$1
  prefix=$2

  echo ">>> Processing $vcf"

  if [ ! -f "$vcf" ]; then
    echo "❌ VCF not found: $vcf"
    exit 1
  fi

  # ----------------------------------------
  # 1. Calculate allele frequencies
  # ----------------------------------------
  singularity exec "$SIF" vcftools \
    --gzvcf "$vcf" \
    --freq \
    --out "$prefix"

  # ----------------------------------------
  # 2. Convert .frq to MAF with position
  # ----------------------------------------
  awk '
  NR > 1 {
    split($5, a, ":");
    split($6, b, ":");
    maf = (a[2] < b[2]) ? a[2] : b[2];
    if (maf > 0) print $1, $2, maf;
  }' OFS="\t" \
  "${prefix}.frq" > "${prefix}.maf.with_pos.tsv"

  echo ">>> Output: ${prefix}.maf.with_pos.tsv"
  wc -l "${prefix}.maf.with_pos.tsv"
}

############################################
# Run
############################################
calc_maf_vcftools "$VCF_GT2" "Atau_gt2"
calc_maf_vcftools "$VCF_GT4" "Atau_gt4"

echo "✅ Done"
