#!/bin/bash
#BSUB -J bedtoos
#BSUB -q Q96C1T_X12
#BSUB -n 16
#BSUB -o bedtools.%J.out
#BSUB -e bedtools.%J.err

for T in 0
do
    bedtools coverage \
        -a CNS_GERP_analysis/01_CNS/CNS_all.sorted.bed \
        -b CNS_GERP_analysis/02_GERP/GERP_gt${T}.unique.bed \
        > CNS_GERP_analysis/03_overlap/CNS_GERPgt${T}.coverage.tsv
done

#for T in 0 2 4 6 
#do
#    bedtools coverage -a CNS_GERP_analysis/01_CNS/CNS_all.sorted.bed  -b CNS_GERP_analysis/02_GERP/GERP_gt${T}.unique.bed > CNS_GERP_analysis/03_overlap/CNS_GERPgt${T}.coverage.tsv
#done


for T in 0 2 4 6
do
    bedtools coverage \
        -a CNS_GERP_analysis/01_CNS/gene_CNS_union_segments.sorted.bed \
        -b CNS_GERP_analysis/02_GERP/GERP_gt${T}.unique.bed \
        > CNS_GERP_analysis/03_overlap/gene_CNS_GERPgt${T}.coverage.tsv
done