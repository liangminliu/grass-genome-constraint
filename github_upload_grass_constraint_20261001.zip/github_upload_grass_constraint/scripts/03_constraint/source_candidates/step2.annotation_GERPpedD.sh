#!/bin/bash
#BSUB -J snpEff_pedD
#BSUB -q Q96C1T_X12
#BSUB -n 20
#BSUB -o snpEff_pedD.%J.out
#BSUB -e snpEff_pedD.%J.err

set -euo pipefail

mkdir -p GERP_del

singularity exec ~/workspace/4.reseq-chr/software/Reseq_genek.sif \
  java -jar /opt/snpEff/snpEff.jar \
  -c ./snpEff.config \
  -ud 5000 \
  -csvStats GERP_del/pedD.csv \
  -htmlStats GERP_del/pedD.html \
  -o vcf \
  ped \
  GERP_del/pedD_gt4_snps.vcf.gz \
  > GERP_del/pedD_gt4.snp.ann.vcf