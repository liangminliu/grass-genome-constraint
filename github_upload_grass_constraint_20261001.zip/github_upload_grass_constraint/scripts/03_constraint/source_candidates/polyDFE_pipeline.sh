#!/bin/bash
#SBATCH --job-name=polyDFE_pipeline
#SBATCH --output=polyDFE_pipeline_%j.out
#SBATCH --error=polyDFE_pipeline_%j.err
#SBATCH --cpus-per-task=20
#SBATCH --partition=parallel

# 设置输入文件路径
VCF_FILE="../63sp.filtered.bi-allelic.snp.renamed.sorted.vcf.gz"  # 输入 VCF 文件路径
ANC_BED_DIR="ancestral_results"  # 祖先位点目录
HICONF_BED="bed_classes/hiconf.bed"  # 高选择性位点文件（GERP > 2 且 SIFT < 0.05）
TOL_SYN_BED="bed_classes/tol_syn.bed"  # 同义位点文件（SIFT > 0.05）
REF_FA="../ped.fa"  # 参考基因组文件
REF_FAI="../ped.fa.fai"  # 参考基因组索引文件
FRAGMENT_BED="fragments.bed"  # 输出的 fragment 切片文件
OUTPUT_DIR="./output"  # 输出目录

# 创建输出目录
mkdir -p "$OUTPUT_DIR"

# 1. 生成染色体分片的 fragments.bed 文件
echo "Generating fragments.bed (by chromosome)..."
awk '{print $1 "\t0\t" $2 "\t" $1}' "$REF_FAI" > "$OUTPUT_DIR/fragments.bed"

# 2. 生成中性位点集（来自同义突变位点，SIFT > 0.05）
bedtools intersect -a "$TOL_SYN_BED" -b "$ANC_BED_DIR"/* > "$OUTPUT_DIR/neutral.polarizable.bed"

# 3. 生成选择性位点集（来自 GERP > 2 且 SIFT < 0.05）
bedtools intersect -a "$HICONF_BED" -b "$ANC_BED_DIR"/* > "$OUTPUT_DIR/deleterious_sites.polarizable.bed"

# 4. 获取每个变异位点的基因型数据
echo "Extracting genotypes from VCF..."
bcftools query -f '%CHROM\t%POS\t%REF\t%ALT[\t%GT]\n' "$VCF_FILE" > "$OUTPUT_DIR/genotypes.txt"

# 5. 读取祖先位点数据，构建祖先基因字典
declare -A ancestral_dict
echo "Building ancestral allele dictionary..."
find "$ANC_BED_DIR" -type f | while read -r file; do
    while read -r line; do
        chrom=$(echo "$line" | cut -f1)
        pos=$(echo "$line" | cut -f2)
        ancestral_allele=$(echo "$line" | cut -f4)
        ancestral_dict["$chrom:$pos"]="$ancestral_allele"
    done < "$file"
done

# 初始化 SFS 数组
declare -A SFS_neut
declare -A SFS_sel

# 6. 计算每个位点的衍生等位基因频率
echo "Calculating SFS for neutral and selected sites..."
while read -r line; do
    chrom=$(echo "$line" | cut -f1)
    pos=$(echo "$line" | cut -f2)
    ref=$(echo "$line" | cut -f3)
    alt=$(echo "$line" | cut -f4)
    genotypes=$(echo "$line" | cut -f5-)

    # 获取祖先基因
    ancestral_allele=${ancestral_dict["$chrom:$pos"]}

    # 计算每个样本的衍生等位基因
    derived_count=0
    total_samples=0
    for genotype in $genotypes; do
        if [[ "$genotype" == "0/0" || "$genotype" == "1/1" ]]; then
            total_samples=$((total_samples + 1))
            if [[ "$ref" != "$ancestral_allele" ]]; then
                derived_count=$((derived_count + 1))
            fi
        fi
    done

    # 计算衍生等位基因频率
    if [ $total_samples -gt 0 ]; then
        derived_freq=$(echo "scale=4; $derived_count / $total_samples" | bc)
        if [[ "$alt" == "$ancestral_allele" ]]; then
            SFS_neut[$derived_freq]=$((SFS_neut[$derived_freq] + 1))
        else
            SFS_sel[$derived_freq]=$((SFS_sel[$derived_freq] + 1))
        fi
    fi
done < "$OUTPUT_DIR/genotypes.txt"

# 7. 输出 SFS（中性位点和选择性位点）
echo "Generating SFS files..."
for freq in "${!SFS_neut[@]}"; do
    echo "$freq ${SFS_neut[$freq]}" >> "$OUTPUT_DIR/SFS_neut.txt"
done

for freq in "${!SFS_sel[@]}"; do
    echo "$freq ${SFS_sel[$freq]}" >> "$OUTPUT_DIR/SFS_sel.txt"
done

# 8. 计算每个 fragment 的 L_neut 和 L_sel
bedtools intersect -a "$OUTPUT_DIR/fragments.bed" -b "$OUTPUT_DIR/neutral.polarizable.bed" -c > "$OUTPUT_DIR/L_neut.tmp"
bedtools intersect -a "$OUTPUT_DIR/fragments.bed" -b "$OUTPUT_DIR/deleterious_sites.polarizable.bed" -c > "$OUTPUT_DIR/L_sel.tmp"

# 提取 L_neut 和 L_sel 的数量
awk '{print $4 "\t" $5}' "$OUTPUT_DIR/L_neut.tmp" > "$OUTPUT_DIR/L_neut.tsv"
awk '{print $4 "\t" $5}' "$OUTPUT_DIR/L_sel.tmp" > "$OUTPUT_DIR/L_sel.tsv"

# 9. 生成最终的 polyDFE 输入文件
echo "Generating polydfe.input.txt..."
echo "1  $(wc -l < "$OUTPUT_DIR/neutral.polarizable.bed")  $(wc -l < "$OUTPUT_DIR/deleterious_sites.polarizable.bed")  126" > "$OUTPUT_DIR/polydfe.input.txt"
paste "$OUTPUT_DIR/SFS_neut.txt" "$OUTPUT_DIR/L_neut.tsv" >> "$OUTPUT_DIR/polydfe.input.txt"
paste "$OUTPUT_DIR/SFS_sel.txt" "$OUTPUT_DIR/L_sel.tsv" >> "$OUTPUT_DIR/polydfe.input.txt"

# 完成
echo "polyDFE input file created: $OUTPUT_DIR/polydfe.input.txt"

