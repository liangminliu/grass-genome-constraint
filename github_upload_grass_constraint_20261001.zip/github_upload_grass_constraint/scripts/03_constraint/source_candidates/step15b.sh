 #!/usr/bin/env bash
#BSUB -J step15
#BSUB -q Q96C1T_X12
#BSUB -n 16
#BSUB -o step15.%J.out
#BSUB -e step15.%J.err

python3 15b_add_site_fraction_to_CNS60_summary.py
