#!/bin/bash
#SBATCH --job-name=genomic_features
#SBATCH --output=genomic_features_%j.out
#SBATCH --error=genomic_features_%j.err
#SBATCH --nodes=1
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=20
#SBATCH --partition=parallel

echo "Starting genomic features analysis at $(date)"
echo "Working directory: $(pwd)"

# Step 0: 生成简并位点文件
echo "Step 0: Generating degeneracy sites using Python script..."
python degeneracy.py ../data/Zmay.gff ../data/Zmay.fa 0-fold_sites.bed 4-fold_sites.bed

# 创建结果目录
RESULT_DIR="genomic_features_results"
mkdir -p $RESULT_DIR
echo "Results will be saved in: $RESULT_DIR"
cp all_TE_merged.bed $RESULT_DIR/TE_processed.bed
# 定义输入文件列表
declare -a input_files=(
    "CDS_sorted.bed"
    "exons_sorted.bed"
    "five_prime_UTR_sorted.bed"
    "genes_sorted.bed"
    "intergenic_sorted.bed"
    "introns_sorted.bed"
    "promoter_sorted.bed"
    "three_prime_UTR_sorted.bed"
    "updown5k_sorted.bed"
    "0-fold_sites.bed"
    "4-fold_sites.bed"
)

# 定义不需要合并的文件（简并位点）
declare -a no_merge_files=(
    "0-fold_sites.bed"
    "4-fold_sites.bed"
)

# 检查输入文件是否存在
echo "Checking input files..."
existing_files=()
for file in "${input_files[@]}"; do
    if [[ ! -f "$file" ]]; then
        echo "Warning: $file not found!"
    else
        lines=$(wc -l < "$file")
        echo "Found: $file ($lines entries)"
        existing_files+=("$file")
    fi
done

if [[ ${#existing_files[@]} -eq 0 ]]; then
    echo "Error: No input files found. Exiting."
    exit 1
fi

# 初始化统计文件
STATS_FILE="$RESULT_DIR/genomic_features_statistics.txt"
cat > $STATS_FILE << EOF
Genomic Features Length Analysis
===============================
Analysis Date: $(date)
Working Directory: $(pwd)

Processing Strategy:
- Standard features: Merge overlapping regions
- Degeneracy sites (0-fold, 4-fold): Direct copy (no overlaps)

EOF

echo "Processing genomic features..."

# 初始化统计变量
declare -A original_counts
declare -A final_counts
declare -A total_lengths

# 处理每个功能区域文件
echo "Processing individual feature files..."

for file in "${existing_files[@]}"; do
    # 提取基础文件名
    basename=$(basename "$file" .bed)
    feature_name=${basename%_sorted}
    
    echo "Processing: $file -> $feature_name"
    
    # 统计原始条目数
    original_count=$(wc -l < "$file")
    original_counts[$feature_name]=$original_count
    
    if [[ $original_count -eq 0 ]]; then
        echo "  Warning: $file is empty, skipping..."
        continue
    fi
    
    # 检查是否为简并位点文件
    is_degenerate=false
    for no_merge_file in "${no_merge_files[@]}"; do
        if [[ "$file" == "$no_merge_file" ]]; then
            is_degenerate=true
            break
        fi
    done
    
    output_file="$RESULT_DIR/${feature_name}_processed.bed"
    
    if [[ "$is_degenerate" == true ]]; then
        echo "  Degeneracy site - copying without merge..."
        cp "$file" "$output_file"
        final_count=$original_count
    else
        echo "  Merging overlapping regions..."
        bedtools merge -i "$file" > "$output_file"
        final_count=$(wc -l < "$output_file")
    fi
    
    final_counts[$feature_name]=$final_count
    
    # 计算总长度
    total_length=$(awk '{sum += ($3 - $2)} END {print sum + 0}' "$output_file")
    total_lengths[$feature_name]=$total_length
    
    echo "  Original: $original_count regions"
    echo "  Final: $final_count regions"
    echo "  Total length: $(echo $total_length | sed ':a;s/\B[0-9]\{3\}\>/,&/;ta') bp"
    echo ""
done

# 生成统计报告
echo "Generating statistics..."

# 按字母顺序排序功能区域
sorted_features=($(printf '%s\n' "${!total_lengths[@]}" | sort))

cat >> $STATS_FILE << EOF

Individual Feature Statistics
============================

EOF

printf "%-20s %15s %15s %18s %s\n" "Feature" "Original" "Final" "Total_Length(bp)" "Processing" >> $STATS_FILE
printf "%-20s %15s %15s %18s %s\n" "-------" "--------" "-----" "---------------" "----------" >> $STATS_FILE

for feature in "${sorted_features[@]}"; do
    formatted_length=$(echo ${total_lengths[$feature]} | sed ':a;s/\B[0-9]\{3\}\>/,&/;ta')
    
    # 确定处理类型
    processing_type="Merged"
    for no_merge_file in "${no_merge_files[@]}"; do
        basename=$(basename "$no_merge_file" .bed)
        no_merge_feature=${basename%_sorted}
        if [[ "$feature" == "$no_merge_feature" ]]; then
            processing_type="Direct"
            break
        fi
    done
    
    printf "%-20s %15s %15s %18s %s\n" \
        "$feature" \
        "${original_counts[$feature]}" \
        "${final_counts[$feature]}" \
        "$formatted_length" \
        "$processing_type" >> $STATS_FILE
done

# 计算总体统计
total_original=0
total_final=0
total_bp=0

for feature in "${sorted_features[@]}"; do
    total_original=$((total_original + ${original_counts[$feature]}))
    total_final=$((total_final + ${final_counts[$feature]}))
    total_bp=$((total_bp + ${total_lengths[$feature]}))
done

formatted_total_bp=$(echo $total_bp | sed ':a;s/\B[0-9]\{3\}\>/,&/;ta')

cat >> $STATS_FILE << EOF

Summary Statistics
==================
Total original regions: $(echo $total_original | sed ':a;s/\B[0-9]\{3\}\>/,&/;ta')
Total final regions: $(echo $total_final | sed ':a;s/\B[0-9]\{3\}\>/,&/;ta')
Total genomic coverage: $formatted_total_bp bp

EOF

# 简并位点分析
if [[ -n "${total_lengths[0-fold_sites]:-}" && -n "${total_lengths[4-fold_sites]:-}" ]]; then
    zero_fold=${total_lengths[0-fold_sites]}
    four_fold=${total_lengths[4-fold_sites]}
    total_degenerate=$((zero_fold + four_fold))
    
    if [[ $total_degenerate -gt 0 ]]; then
        zero_fold_percent=$(awk -v zero="$zero_fold" -v total="$total_degenerate" 'BEGIN {printf "%.1f", (zero/total)*100}')
        four_fold_percent=$(awk -v four="$four_fold" -v total="$total_degenerate" 'BEGIN {printf "%.1f", (four/total)*100}')
        
        cat >> $STATS_FILE << EOF
Degeneracy Sites Analysis
========================
0-fold sites (non-synonymous): $(echo $zero_fold | sed ':a;s/\B[0-9]\{3\}\>/,&/;ta') bp ($zero_fold_percent%)
4-fold sites (synonymous): $(echo $four_fold | sed ':a;s/\B[0-9]\{3\}\>/,&/;ta') bp ($four_fold_percent%)
Total degenerate sites: $(echo $total_degenerate | sed ':a;s/\B[0-9]\{3\}\>/,&/;ta') bp
Synonymous/Non-synonymous ratio: $(awk -v four="$four_fold" -v zero="$zero_fold" 'BEGIN {if(zero>0) printf "%.2f", four/zero; else print "N/A"}')

EOF
    fi
fi

# 按长度排序
cat >> $STATS_FILE << EOF
Length Ranking
==============
EOF

for feature in "${sorted_features[@]}"; do
    echo "${total_lengths[$feature]} $feature"
done | sort -nr | awk '{
    printf "%2d. %-20s: %15d bp\n", NR, $2, $1
}' >> $STATS_FILE

cat >> $STATS_FILE << EOF

Generated Files
===============
- Processed BED files: *_processed.bed
- This summary: genomic_features_statistics.txt

Analysis completed at: $(date)
EOF

echo ""
echo "Analysis completed successfully at $(date)"
echo ""
echo "Results directory: $RESULT_DIR"
echo "Summary statistics: $STATS_FILE"
echo ""
echo "Generated files:"
ls -la $RESULT_DIR/
echo ""
echo "Total genomic coverage: $formatted_total_bp bp"

# 输出简并位点统计
if [[ -n "${total_lengths[0-fold_sites]:-}" && -n "${total_lengths[4-fold_sites]:-}" ]]; then
    echo ""
    echo "Degeneracy sites summary:"
    echo "  0-fold (non-synonymous): $(echo ${total_lengths[0-fold_sites]} | sed ':a;s/\B[0-9]\{3\}\>/,&/;ta') bp"
    echo "  4-fold (synonymous): $(echo ${total_lengths[4-fold_sites]} | sed ':a;s/\B[0-9]\{3\}\>/,&/;ta') bp"
    echo "  Ratio (4-fold/0-fold): $(awk -v four="${total_lengths[4-fold_sites]}" -v zero="${total_lengths[0-fold_sites]}" 'BEGIN {if(zero>0) printf "%.2f", four/zero; else print "N/A"}')"
fi

echo ""
echo "All files ready for downstream analysis!"