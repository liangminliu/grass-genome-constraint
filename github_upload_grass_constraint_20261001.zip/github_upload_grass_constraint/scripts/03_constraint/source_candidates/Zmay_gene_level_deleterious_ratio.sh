#!/usr/bin/env bash
#BSUB -J "zmay_core_deleterious[1-3]"
#BSUB -q Q96C1T_X12
#BSUB -n 8
#BSUB -o logs/zmay_core_deleterious_%J_%I.out
#BSUB -e logs/zmay_core_deleterious_%J_%I.err

set -euo pipefail
export LC_ALL=C

module load bedtools 2>/dev/null || true

############################################################
# 0. 脚本版本和固定输入
############################################################
SCRIPT_VERSION="2026-07-15-Zmay-core-deleterious-expanded-ID-strict-5108-bsub-v1"

STAT_ROOT="Zmay_target_gene_CDS_GERP_stats"

# 基因和 CDS 注释
GENE_BED="genes.merged.bed"
CDS_BED="CDS_gene_merged/CDS.gene.merged.bed"

# 全部 SNP 与 gene/CDS 区域的预处理交集文件
# 文件本身不含 gene ID
GENE_SNP_INTERSECT="genes_processed.intersect.bed"
CDS_SNP_INTERSECT="CDS_processed.intersect.bed"

# 5108 个 strict-core 基因信息
CORE_PAN="core_5sp_1to1.SG.pan"

OUT_ROOT="Zmay_gene_deleterious_stats"

EXPECTED_CORE_N=5108

# 是否要求所有目标基因都能在注释 BED 中找到
# strict-core 蛋白编码基因理论上应该都有 gene 和 CDS 注释
REQUIRE_ALL_GENE_ANNOTATION=1
REQUIRE_ALL_CDS_ANNOTATION=1

mkdir -p "${OUT_ROOT}"

echo "[SCRIPT] Version: ${SCRIPT_VERSION}"
echo "[SCRIPT] Job ID: ${LSB_JOBID:-NA}"
echo "[SCRIPT] Array index: ${LSB_JOBINDEX:-NA}"
echo "[SCRIPT] Host: $(hostname)"
echo "[SCRIPT] Working directory: $(pwd)"
echo "[SCRIPT] Start time: $(date '+%F %T')"

############################################################
# 1. 检查 LSF 数组编号并确定阈值
############################################################
CLASSES=("gt2" "gt4" "gt6")

if [[ -z "${LSB_JOBINDEX:-}" ]]; then
    echo "[ERROR] LSB_JOBINDEX is not defined." >&2
    echo "[ERROR] Please submit this script using bsub as an array job." >&2
    exit 1
fi

IDX=$((LSB_JOBINDEX - 1))

if [[ "${IDX}" -lt 0 || "${IDX}" -ge "${#CLASSES[@]}" ]]; then
    echo "[ERROR] Invalid LSB_JOBINDEX=${LSB_JOBINDEX}" >&2
    exit 1
fi

CLASS="${CLASSES[$IDX]}"

OUT_DIR="${OUT_ROOT}/${CLASS}"
mkdir -p "${OUT_DIR}"

echo "[INFO] Threshold: ${CLASS}"
echo "[INFO] Output directory: ${OUT_DIR}"

############################################################
# 2. 当前阈值对应的输入文件
############################################################
PER_GENE_STAT="${STAT_ROOT}/${CLASS}/per_gene_stats.tsv"

GENE_DEL_BED="merged_${CLASS}_genes_detailed.bed"
CDS_DEL_BED="merged_${CLASS}_CDS_detailed.bed"

############################################################
# 3. 检查软件和输入文件
############################################################
if ! command -v bedtools >/dev/null 2>&1; then
    echo "[ERROR] bedtools is not available." >&2
    exit 1
fi

for f in \
    "${PER_GENE_STAT}" \
    "${GENE_BED}" \
    "${CDS_BED}" \
    "${GENE_SNP_INTERSECT}" \
    "${CDS_SNP_INTERSECT}" \
    "${GENE_DEL_BED}" \
    "${CDS_DEL_BED}" \
    "${CORE_PAN}"
do
    if [[ ! -s "${f}" ]]; then
        echo "[ERROR] Missing or empty input file: ${f}" >&2
        exit 1
    fi
done

echo "[INFO] All required input files exist."

############################################################
# 4. 辅助函数：拆分逗号连接的 gene ID
#
# 输入示例：
# chr1  11388591  11390370  geneA,geneB  .  -
#
# 输出：
# chr1  11388591  11390370  geneA
# chr1  11388591  11390370  geneB
#
# 最终统一输出为 BED4：
# chromosome start end gene_id
############################################################
expand_bed_gene_ids() {
    awk '
    BEGIN {
        FS = "[ \t]+"
        OFS = "\t"
        malformed = 0
    }

    /^[[:space:]]*$/ {
        next
    }

    /^[[:space:]]*#/ {
        next
    }

    NF < 4 {
        malformed++
        next
    }

    {
        chr   = $1
        start = $2
        end   = $3
        ids   = $4

        if (start !~ /^[0-9]+$/ ||
            end   !~ /^[0-9]+$/ ||
            end <= start) {
            malformed++
            next
        }

        n = split(ids, gene_array, ",")

        for (i = 1; i <= n; i++) {
            gene = gene_array[i]

            gsub(/^[[:space:]]+/, "", gene)
            gsub(/[[:space:]]+$/, "", gene)

            if (gene != "" &&
                gene != "." &&
                gene != "-" &&
                gene != "NA") {
                print chr, start, end, gene
            }
        }
    }

    END {
        if (malformed > 0) {
            print "[WARN] Skipped " malformed \
                  " malformed BED records." > "/dev/stderr"
        }
    }
    ' "$@"
}

############################################################
# 5. 辅助函数：过滤 5108 个目标基因
#
# 参数：
# $1 = 目标基因列表
# $2 = 已标准化的 BED4
# $3 = 输出 BED4
############################################################
filter_target_bed() {
    local target_list="$1"
    local input_bed="$2"
    local output_bed="$3"
    local tmp_file="${output_bed}.tmp.${LSB_JOBID}.${LSB_JOBINDEX}"

    awk '
    BEGIN {
        FS = OFS = "\t"
    }

    NR == FNR {
        target[$1] = 1
        next
    }

    ($4 in target) {
        print $1, $2, $3, $4
    }
    ' "${target_list}" "${input_bed}" |
        sort -t$'\t' \
            -k1,1 \
            -k2,2n \
            -k3,3n \
            -k4,4 |
        uniq > "${tmp_file}"

    mv -f "${tmp_file}" "${output_bed}"
}

############################################################
# 6. 辅助函数：统计每个基因中的唯一 SNP 位点
#
# A 文件：
# SNP/有害 SNP BED，不包含 gene ID
#
# B 文件：
# 标准 BED4，最后一列为 gene ID
#
# 统计规则保持原脚本不变：
# 相同 chromosome:start-end 在同一个基因中只统计一次
############################################################
count_unique_sites_by_gene() {
    local snp_bed="$1"
    local annotation_bed="$2"
    local output_tsv="$3"
    local tmp_file="${output_tsv}.tmp.${LSB_JOBID}.${LSB_JOBINDEX}"

    bedtools intersect \
        -wa \
        -wb \
        -a "${snp_bed}" \
        -b "${annotation_bed}" |
        awk '
        BEGIN {
            FS = OFS = "\t"
        }

        {
            # B 文件已经标准化为 BED4，
            # 所以 intersect 结果最后一列始终为 gene ID
            gene = $NF

            # 保持原来的 SNP 位点去重定义
            key = $1 SUBSEP $2 SUBSEP $3 SUBSEP gene

            if (!seen[key]++) {
                count[gene]++
            }
        }

        END {
            for (gene in count) {
                print gene, count[gene]
            }
        }
        ' |
        sort -t$'\t' -k1,1 > "${tmp_file}"

    mv -f "${tmp_file}" "${output_tsv}"
}

############################################################
# 7. 提取 5108 个 Zmay strict-core 基因
#
# core_5sp_1to1.SG.pan 的 Zmay 基因位于第9列
############################################################
CORE_GENE_LIST="${OUT_DIR}/core_gene.list"
CORE_GENE_LIST_TMP="${CORE_GENE_LIST}.tmp.${LSB_JOBID}.${LSB_JOBINDEX}"

awk '
BEGIN {
    FS = "[ \t]+"
}

NF >= 9 {
    gene = $9

    if (gene == "" ||
        gene == "." ||
        gene == "-" ||
        gene == "NA") {
        next
    }

    sub(/^Zmay_/, "", gene)
    print gene
}
' "${CORE_PAN}" |
    sort -u > "${CORE_GENE_LIST_TMP}"

mv -f "${CORE_GENE_LIST_TMP}" "${CORE_GENE_LIST}"

CORE_N=$(wc -l < "${CORE_GENE_LIST}")

echo "[CHECK] Core genes extracted from PAN: ${CORE_N}"

if [[ "${CORE_N}" -ne "${EXPECTED_CORE_N}" ]]; then
    echo "[ERROR] Expected ${EXPECTED_CORE_N} unique Zmay core genes," >&2
    echo "[ERROR] but found ${CORE_N}." >&2
    exit 1
fi

############################################################
# 8. 检查 per_gene_stats.tsv 是否同样包含 5108 个基因
############################################################
PER_GENE_ID_LIST="${OUT_DIR}/per_gene_stats_gene_ids.list"

awk '
BEGIN {
    FS = "\t"
}

NR > 1 && $1 != "" {
    print $1
}
' "${PER_GENE_STAT}" |
    sort -u > "${PER_GENE_ID_LIST}"

PER_GENE_N=$(wc -l < "${PER_GENE_ID_LIST}")

echo "[CHECK] Genes in per_gene_stats.tsv: ${PER_GENE_N}"

if [[ "${PER_GENE_N}" -ne "${EXPECTED_CORE_N}" ]]; then
    echo "[ERROR] ${PER_GENE_STAT} contains ${PER_GENE_N} unique genes," >&2
    echo "[ERROR] expected ${EXPECTED_CORE_N}." >&2
    exit 1
fi

if ! cmp -s "${CORE_GENE_LIST}" "${PER_GENE_ID_LIST}"; then
    echo "[ERROR] Gene set in per_gene_stats.tsv differs from core_gene.list." >&2

    echo "[ERROR] Genes present in core list but missing from per_gene_stats:" >&2
    comm -23 \
        "${CORE_GENE_LIST}" \
        "${PER_GENE_ID_LIST}" >&2 || true

    echo "[ERROR] Genes present in per_gene_stats but absent from core list:" >&2
    comm -13 \
        "${CORE_GENE_LIST}" \
        "${PER_GENE_ID_LIST}" >&2 || true

    exit 1
fi

############################################################
# 9. 标准化 gene BED，并拆分逗号连接的 ID
############################################################
GENE_BED4="${OUT_DIR}/genes.expanded.4col.bed"
GENE_BED4_TMP="${GENE_BED4}.tmp.${LSB_JOBID}.${LSB_JOBINDEX}"

GENE_COMMA_N=$(
    awk '
    BEGIN {
        FS = "[ \t]+"
    }

    NF >= 4 && $4 ~ /,/ {
        n++
    }

    END {
        print n+0
    }
    ' "${GENE_BED}"
)

echo "[INFO] Gene BED records containing comma-separated IDs: ${GENE_COMMA_N}"

expand_bed_gene_ids "${GENE_BED}" |
    sort -t$'\t' \
        -k1,1 \
        -k2,2n \
        -k3,3n \
        -k4,4 |
    uniq > "${GENE_BED4_TMP}"

mv -f "${GENE_BED4_TMP}" "${GENE_BED4}"

echo "[INFO] Expanded gene BED records: $(wc -l < "${GENE_BED4}")"
echo "[INFO] Expanded gene BED unique IDs: $(cut -f4 "${GENE_BED4}" | sort -u | wc -l)"

############################################################
# 10. 标准化 CDS BED，并拆分逗号连接的 ID
############################################################
CDS_BED4="${OUT_DIR}/CDS.expanded.4col.bed"
CDS_BED4_TMP="${CDS_BED4}.tmp.${LSB_JOBID}.${LSB_JOBINDEX}"

CDS_COMMA_N=$(
    awk '
    BEGIN {
        FS = "[ \t]+"
    }

    NF >= 4 && $4 ~ /,/ {
        n++
    }

    END {
        print n+0
    }
    ' "${CDS_BED}"
)

echo "[INFO] CDS BED records containing comma-separated IDs: ${CDS_COMMA_N}"

expand_bed_gene_ids "${CDS_BED}" |
    sort -t$'\t' \
        -k1,1 \
        -k2,2n \
        -k3,3n \
        -k4,4 |
    uniq > "${CDS_BED4_TMP}"

mv -f "${CDS_BED4_TMP}" "${CDS_BED4}"

echo "[INFO] Expanded CDS BED records: $(wc -l < "${CDS_BED4}")"
echo "[INFO] Expanded CDS BED unique IDs: $(cut -f4 "${CDS_BED4}" | sort -u | wc -l)"

############################################################
# 11. 构建 5108 个目标基因对应的 gene/CDS BED
############################################################
CORE_GENE_BED="${OUT_DIR}/core_gene.bed"
CORE_CDS_BED="${OUT_DIR}/core_cds.bed"

filter_target_bed \
    "${CORE_GENE_LIST}" \
    "${GENE_BED4}" \
    "${CORE_GENE_BED}"

filter_target_bed \
    "${CORE_GENE_LIST}" \
    "${CDS_BED4}" \
    "${CORE_CDS_BED}"

echo "[INFO] core_gene.bed records: $(wc -l < "${CORE_GENE_BED}")"
echo "[INFO] core_cds.bed records:  $(wc -l < "${CORE_CDS_BED}")"

############################################################
# 12. 检查全部 5108 个基因是否进入 gene BED
############################################################
PRESENT_GENE_IDS="${OUT_DIR}/core_gene.annotation.present.list"
MISSING_GENE_IDS="${OUT_DIR}/core_gene.annotation.missing.list"

cut -f4 "${CORE_GENE_BED}" |
    sort -u > "${PRESENT_GENE_IDS}"

comm -23 \
    "${CORE_GENE_LIST}" \
    "${PRESENT_GENE_IDS}" \
    > "${MISSING_GENE_IDS}"

PRESENT_GENE_N=$(wc -l < "${PRESENT_GENE_IDS}")
MISSING_GENE_N=$(wc -l < "${MISSING_GENE_IDS}")

echo "[CHECK] Core genes represented in gene BED: ${PRESENT_GENE_N}"
echo "[CHECK] Core genes missing from gene BED:  ${MISSING_GENE_N}"

if [[ "${MISSING_GENE_N}" -gt 0 ]]; then
    echo "[WARN] Missing gene annotation IDs:" >&2
    cat "${MISSING_GENE_IDS}" >&2

    if [[ "${REQUIRE_ALL_GENE_ANNOTATION}" -eq 1 ]]; then
        echo "[ERROR] REQUIRE_ALL_GENE_ANNOTATION=1; stopping." >&2
        exit 1
    fi
fi

############################################################
# 13. 检查全部 5108 个基因是否进入 CDS BED
############################################################
PRESENT_CDS_IDS="${OUT_DIR}/core_cds.annotation.present.list"
MISSING_CDS_IDS="${OUT_DIR}/core_cds.annotation.missing.list"

cut -f4 "${CORE_CDS_BED}" |
    sort -u > "${PRESENT_CDS_IDS}"

comm -23 \
    "${CORE_GENE_LIST}" \
    "${PRESENT_CDS_IDS}" \
    > "${MISSING_CDS_IDS}"

PRESENT_CDS_N=$(wc -l < "${PRESENT_CDS_IDS}")
MISSING_CDS_N=$(wc -l < "${MISSING_CDS_IDS}")

echo "[CHECK] Core genes represented in CDS BED: ${PRESENT_CDS_N}"
echo "[CHECK] Core genes missing from CDS BED:  ${MISSING_CDS_N}"

if [[ "${MISSING_CDS_N}" -gt 0 ]]; then
    echo "[WARN] Missing CDS annotation IDs:" >&2
    cat "${MISSING_CDS_IDS}" >&2

    if [[ "${REQUIRE_ALL_CDS_ANNOTATION}" -eq 1 ]]; then
        echo "[ERROR] REQUIRE_ALL_CDS_ANNOTATION=1; stopping." >&2
        exit 1
    fi
fi

############################################################
# 14. Gene SNP 数量
############################################################
GENE_SNP_TSV="${OUT_DIR}/core_gene.snp.tsv"

count_unique_sites_by_gene \
    "${GENE_SNP_INTERSECT}" \
    "${CORE_GENE_BED}" \
    "${GENE_SNP_TSV}"

echo "[INFO] Genes with at least one gene-region SNP: $(wc -l < "${GENE_SNP_TSV}")"

############################################################
# 15. CDS SNP 数量
############################################################
CDS_SNP_TSV="${OUT_DIR}/core_cds.snp.tsv"

count_unique_sites_by_gene \
    "${CDS_SNP_INTERSECT}" \
    "${CORE_CDS_BED}" \
    "${CDS_SNP_TSV}"

echo "[INFO] Genes with at least one CDS SNP: $(wc -l < "${CDS_SNP_TSV}")"

############################################################
# 16. Gene deleterious SNP 数量
############################################################
GENE_DEL_TSV="${OUT_DIR}/core_gene.del.tsv"

count_unique_sites_by_gene \
    "${GENE_DEL_BED}" \
    "${CORE_GENE_BED}" \
    "${GENE_DEL_TSV}"

echo "[INFO] Genes with at least one gene-region deleterious SNP: $(wc -l < "${GENE_DEL_TSV}")"

############################################################
# 17. CDS deleterious SNP 数量
############################################################
CDS_DEL_TSV="${OUT_DIR}/core_cds.del.tsv"

count_unique_sites_by_gene \
    "${CDS_DEL_BED}" \
    "${CORE_CDS_BED}" \
    "${CDS_DEL_TSV}"

echo "[INFO] Genes with at least one CDS deleterious SNP: $(wc -l < "${CDS_DEL_TSV}")"

############################################################
# 18. 从 per_gene_stats.tsv 提取 gene_len 和 cds_len
#
# 该文件包含：
# gene_id gene_len cds_len gene_sites gene_pct cds_sites cds_pct
#
# 这里只保留：
# gene_id gene_len cds_len
############################################################
GENE_LEN_TSV="${OUT_DIR}/gene_len.tsv"
GENE_LEN_TMP="${GENE_LEN_TSV}.tmp.${LSB_JOBID}.${LSB_JOBINDEX}"

awk '
BEGIN {
    FS = OFS = "\t"
}

NR > 1 {
    print $1, $2, $3
}
' "${PER_GENE_STAT}" |
    sort -t$'\t' -k1,1 > "${GENE_LEN_TMP}"

mv -f "${GENE_LEN_TMP}" "${GENE_LEN_TSV}"

GENE_LEN_N=$(wc -l < "${GENE_LEN_TSV}")

echo "[CHECK] gene_len.tsv rows: ${GENE_LEN_N}"

if [[ "${GENE_LEN_N}" -ne "${EXPECTED_CORE_N}" ]]; then
    echo "[ERROR] gene_len.tsv contains ${GENE_LEN_N} rows," >&2
    echo "[ERROR] expected ${EXPECTED_CORE_N}." >&2
    exit 1
fi

############################################################
# 19. 最终合并和比例计算
#
# 保持原计算公式：
#
# gene_snp_ratio =
#     gene_snp_total / gene_len
#
# gene_deleterious_ratio =
#     gene_deleterious_snp / gene_snp_total
#
# cds_snp_ratio =
#     cds_snp_total / cds_len
#
# cds_deleterious_ratio =
#     cds_deleterious_snp / cds_snp_total
#
# 最终始终以 gene_len.tsv 中的 5108 个基因为主表。
# 未检测到 SNP 或有害 SNP的基因填 0。
############################################################
FINAL_OUTPUT="${OUT_DIR}/zmay_gene_deleterious_stats.core1to1.tsv"

FINAL_DATA_TMP="${FINAL_OUTPUT}.data.tmp.${LSB_JOBID}.${LSB_JOBINDEX}"
FINAL_SORTED_TMP="${FINAL_OUTPUT}.sorted.tmp.${LSB_JOBID}.${LSB_JOBINDEX}"
FINAL_OUTPUT_TMP="${FINAL_OUTPUT}.tmp.${LSB_JOBID}.${LSB_JOBINDEX}"

awk '
BEGIN {
    FS = OFS = "\t"
}

# 第一个文件：5108 个目标基因及其长度
FNR == NR {
    gene_len[$1] = $2 + 0
    cds_len[$1]  = $3 + 0
    target[$1]   = 1
    next
}

FILENAME ~ /core_gene\.snp\.tsv$/ {
    gene_snp[$1] = $2 + 0
    next
}

FILENAME ~ /core_cds\.snp\.tsv$/ {
    cds_snp[$1] = $2 + 0
    next
}

FILENAME ~ /core_gene\.del\.tsv$/ {
    gene_del[$1] = $2 + 0
    next
}

FILENAME ~ /core_cds\.del\.tsv$/ {
    cds_del[$1] = $2 + 0
    next
}

END {
    # 只输出第一个文件中的 5108 个目标基因
    for (gene in target) {
        gl = gene_len[gene] + 0
        cl = cds_len[gene] + 0

        gs = gene_snp[gene] + 0
        cs = cds_snp[gene] + 0

        gd = gene_del[gene] + 0
        cd = cds_del[gene] + 0

        gene_snp_ratio = (gl > 0) \
            ? gs / gl \
            : 0

        cds_snp_ratio = (cl > 0) \
            ? cs / cl \
            : 0

        gene_deleterious_ratio = (gs > 0) \
            ? gd / gs \
            : 0

        cds_deleterious_ratio = (cs > 0) \
            ? cd / cs \
            : 0

        printf "%s\t%d\t%d\t%.6f\t%d\t%.6f\t%d\t%d\t%.6f\t%d\t%.6f\n", \
            gene, \
            gl, \
            gs, \
            gene_snp_ratio, \
            gd, \
            gene_deleterious_ratio, \
            cl, \
            cs, \
            cds_snp_ratio, \
            cd, \
            cds_deleterious_ratio
    }
}
' \
    "${GENE_LEN_TSV}" \
    "${GENE_SNP_TSV}" \
    "${CDS_SNP_TSV}" \
    "${GENE_DEL_TSV}" \
    "${CDS_DEL_TSV}" \
    > "${FINAL_DATA_TMP}"

sort -t$'\t' -k1,1 "${FINAL_DATA_TMP}" \
    > "${FINAL_SORTED_TMP}"

# 表头固定写在第一行，不参与排序
{
    printf '%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\n' \
        "gene_id" \
        "gene_len" \
        "gene_snp_total" \
        "gene_snp_ratio" \
        "gene_deleterious_snp" \
        "gene_deleterious_ratio" \
        "cds_len" \
        "cds_snp_total" \
        "cds_snp_ratio" \
        "cds_deleterious_snp" \
        "cds_deleterious_ratio"

    cat "${FINAL_SORTED_TMP}"
} > "${FINAL_OUTPUT_TMP}"

############################################################
# 20. 最终结果严格校验
############################################################
FINAL_DATA_N=$(
    awk '
    NR > 1 {
        n++
    }

    END {
        print n+0
    }
    ' "${FINAL_OUTPUT_TMP}"
)

FINAL_ID_LIST="${OUT_DIR}/final_gene_ids.list"

tail -n +2 "${FINAL_OUTPUT_TMP}" |
    cut -f1 |
    sort -u > "${FINAL_ID_LIST}"

FINAL_UNIQUE_N=$(wc -l < "${FINAL_ID_LIST}")

echo "[CHECK] Expected core genes: ${EXPECTED_CORE_N}"
echo "[CHECK] Final data rows: ${FINAL_DATA_N}"
echo "[CHECK] Final unique gene IDs: ${FINAL_UNIQUE_N}"

if [[ "${FINAL_DATA_N}" -ne "${EXPECTED_CORE_N}" ]]; then
    echo "[ERROR] Final result contains ${FINAL_DATA_N} data rows," >&2
    echo "[ERROR] expected ${EXPECTED_CORE_N}." >&2
    rm -f "${FINAL_OUTPUT_TMP}"
    exit 1
fi

if [[ "${FINAL_UNIQUE_N}" -ne "${EXPECTED_CORE_N}" ]]; then
    echo "[ERROR] Final result contains ${FINAL_UNIQUE_N} unique genes," >&2
    echo "[ERROR] expected ${EXPECTED_CORE_N}." >&2
    rm -f "${FINAL_OUTPUT_TMP}"
    exit 1
fi

if ! cmp -s "${CORE_GENE_LIST}" "${FINAL_ID_LIST}"; then
    echo "[ERROR] Final gene set differs from the 5108-gene core list." >&2

    echo "[ERROR] Core genes missing from final output:" >&2
    comm -23 \
        "${CORE_GENE_LIST}" \
        "${FINAL_ID_LIST}" >&2 || true

    echo "[ERROR] Unexpected genes in final output:" >&2
    comm -13 \
        "${CORE_GENE_LIST}" \
        "${FINAL_ID_LIST}" >&2 || true

    rm -f "${FINAL_OUTPUT_TMP}"
    exit 1
fi

############################################################
# 21. 检查有害 SNP 数是否超过全部 SNP 数
############################################################
INVALID_COUNT_FILE="${OUT_DIR}/invalid_deleterious_counts.tsv"

awk '
BEGIN {
    FS = OFS = "\t"
}

NR == 1 {
    print
    next
}

($5 > $3 || $10 > $8) {
    print
}
' "${FINAL_OUTPUT_TMP}" > "${INVALID_COUNT_FILE}"

INVALID_COUNT_N=$(
    awk '
    NR > 1 {
        n++
    }

    END {
        print n+0
    }
    ' "${INVALID_COUNT_FILE}"
)

if [[ "${INVALID_COUNT_N}" -gt 0 ]]; then
    echo "[ERROR] Found ${INVALID_COUNT_N} genes for which deleterious SNP count" >&2
    echo "[ERROR] exceeds total SNP count." >&2
    echo "[ERROR] Problematic rows: ${INVALID_COUNT_FILE}" >&2

    rm -f "${FINAL_OUTPUT_TMP}"
    exit 1
else
    rm -f "${INVALID_COUNT_FILE}"
fi

############################################################
# 22. 所有检查通过后覆盖原结果
############################################################
mv -f "${FINAL_OUTPUT_TMP}" "${FINAL_OUTPUT}"

rm -f \
    "${FINAL_DATA_TMP}" \
    "${FINAL_SORTED_TMP}"

echo "[INFO] core_gene.snp.tsv head:"
head -n 5 "${GENE_SNP_TSV}" || true

echo "[INFO] core_gene.del.tsv head:"
head -n 5 "${GENE_DEL_TSV}" || true

echo "[OK] Finished threshold: ${CLASS}"
echo "[OK] Output: ${FINAL_OUTPUT}"
echo "[OK] Data rows: ${FINAL_DATA_N}"
echo "[OK] Total lines including header: $(wc -l < "${FINAL_OUTPUT}")"
echo "[OK] End time: $(date '+%F %T')"