#!/usr/bin/env bash
#BSUB -J "ped_core_deleterious[1-3]"
#BSUB -q Q96C1T_X12
#BSUB -n 4
#BSUB -o logs/ped_core_deleterious.%J.%I.out
#BSUB -e logs/ped_core_deleterious.%J.%I.err

set -euo pipefail
export LC_ALL=C

############################################################
# 提交前执行：
#
# mkdir -p logs
# bsub < ped_core_deleterious.bsub.sh
#
# LSF会在脚本运行前创建日志文件，因此logs目录必须提前存在。
############################################################

############################################################
# 0. Fixed inputs
############################################################

CORE_STAT_ROOT="ped_target_gene_CDS_GERP_stats"

GENE_SNP_INTERSECT="genes.intersect.bed"
CDS_SNP_INTERSECT="CDS_jcvi.intersect.bed"

OUT_ROOT="ped_core_gene_deleterious_stats"

mkdir -p "${OUT_ROOT}"

############################################################
# 1. GERP thresholds
#
# LSB_JOBINDEX=1 -> gt2
# LSB_JOBINDEX=2 -> gt4
# LSB_JOBINDEX=3 -> gt6
############################################################

CLASSES=("gt2" "gt4" "gt6")

TASK_ID="${LSB_JOBINDEX:-}"

if [[ -z "${TASK_ID}" ]]; then
    echo "[ERROR] LSB_JOBINDEX is not defined." >&2
    echo "[ERROR] Submit this script as an LSF array job." >&2
    exit 1
fi

if (( TASK_ID < 1 || TASK_ID > ${#CLASSES[@]} )); then
    echo "[ERROR] Invalid LSB_JOBINDEX=${TASK_ID}" >&2
    exit 1
fi

IDX=$((TASK_ID - 1))
CLASS="${CLASSES[$IDX]}"

echo "============================================================"
echo "[INFO] LSF job ID      = ${LSB_JOBID:-NA}"
echo "[INFO] LSF array index = ${TASK_ID}"
echo "[INFO] GERP threshold  = ${CLASS}"
echo "============================================================"

############################################################
# 2. Function: count unique SNP positions per core gene
#
# Arguments:
#   $1 = core gene file: gene_id gene_len cds_len
#   $2 = SNP/intersect input file
#   $3 = gene ID column number
#   $4 = output file
#
# Counting unit:
#   chromosome + start + end + gene_id
#
# Only genes present in gene_cds_len.tsv are retained.
############################################################

count_unique_sites_by_gene() {

    local core_file="$1"
    local input_file="$2"
    local gene_col="$3"
    local output_file="$4"

    awk -v GC="${gene_col}" '
    BEGIN {
        FS = OFS = "\t"
    }

    ########################################################
    # First file: strict-core gene list
    ########################################################

    FNR == NR {
        if (NF >= 1 && $1 != "") {
            core[$1] = 1
        }
        next
    }

    ########################################################
    # Second file: SNP-feature intersection
    ########################################################

    {
        if (NF < GC) {
            malformed++
            next
        }

        gene = $(GC)

        # Remove transcript or feature suffixes
        sub(/:.*/, "", gene)
        sub(/\..*/, "", gene)

        if (gene == "") {
            empty_gene++
            next
        }

        # Keep only the current strict-core genes
        if (!(gene in core)) {
            next
        }

        # Count each SNP coordinate once per gene
        key = $1 SUBSEP $2 SUBSEP $3 SUBSEP gene

        if (!seen[key]++) {
            count[gene]++
        }
    }

    END {
        if (malformed > 0) {
            printf "[WARN] Rows with fewer than %d columns: %d\n", GC, malformed > "/dev/stderr"
        }

        if (empty_gene > 0) {
            printf "[WARN] Rows with empty gene ID: %d\n", empty_gene > "/dev/stderr"
        }

        for (gene in count) {
            print gene, count[gene]
        }
    }
    ' "${core_file}" "${input_file}" \
    | LC_ALL=C sort -t $'\t' -k1,1 \
    > "${output_file}"
}

############################################################
# 3. Process pedC and pedD
############################################################

for SUB in pedC pedD; do

    echo
    echo "------------------------------------------------------------"
    echo "[INFO] Subgenome = ${SUB}"
    echo "------------------------------------------------------------"

    ########################################################
    # 3.1 Input files
    ########################################################

    PER_GENE_STAT="${CORE_STAT_ROOT}/gerp_${CLASS}/${SUB}/per_gene_stats.tsv"

    GENE_DEL_BED="${SUB}_${CLASS}_genes_detailed.bed"
    CDS_DEL_BED="${SUB}_${CLASS}_CDS_jcvi_detailed.bed"

    for FILE in \
        "${PER_GENE_STAT}" \
        "${GENE_SNP_INTERSECT}" \
        "${CDS_SNP_INTERSECT}" \
        "${GENE_DEL_BED}" \
        "${CDS_DEL_BED}"
    do
        if [[ ! -s "${FILE}" ]]; then
            echo "[ERROR] Missing or empty input file: ${FILE}" >&2
            exit 1
        fi
    done

    echo "[INFO] Input files checked."

    ########################################################
    # 3.2 Output files
    ########################################################

    OUT_DIR="${OUT_ROOT}/${CLASS}/${SUB}"
    mkdir -p "${OUT_DIR}"

    GENE_LEN_FILE="${OUT_DIR}/gene_cds_len.tsv"

    GENE_SNP_FILE="${OUT_DIR}/gene_snp_total.tsv"
    CDS_SNP_FILE="${OUT_DIR}/cds_snp_total.tsv"

    GENE_DEL_FILE="${OUT_DIR}/gene_deleterious_snp.tsv"
    CDS_DEL_FILE="${OUT_DIR}/cds_deleterious_snp.tsv"

    FINAL_FILE="${OUT_DIR}/core_gene_deleterious_stats.tsv"

    ########################################################
    # 4. Extract gene_len and cds_len
    #
    # Input per_gene_stats.tsv:
    #   gene_id
    #   gene_len
    #   cds_len
    #   gene_sites
    #   gene_pct
    #   cds_sites
    #   cds_pct
    #
    # Output gene_cds_len.tsv:
    #   gene_id gene_len cds_len
    #
    # gene_cds_len.tsv has no header.
    ########################################################

    awk '
    BEGIN {
        FS = OFS = "\t"
    }

    FNR == 1 {
        first_field = tolower($1)

        if (first_field == "gene_id" || first_field == "gene") {
            next
        }
    }

    NF >= 3 {
        print $1, $2, $3
    }
    ' "${PER_GENE_STAT}" \
    | LC_ALL=C sort -t $'\t' -k1,1 \
    > "${GENE_LEN_FILE}"

    N_CORE=$(wc -l < "${GENE_LEN_FILE}")

    if (( N_CORE == 0 )); then
        echo "[ERROR] No core genes extracted from ${PER_GENE_STAT}" >&2
        exit 1
    fi

    echo "[INFO] Core genes loaded: ${N_CORE}"

    ########################################################
    # 4.1 Check duplicated core gene IDs
    ########################################################

    DUP_GENE=$(
        cut -f1 "${GENE_LEN_FILE}" \
        | LC_ALL=C sort \
        | uniq -d \
        | head -n 1 || true
    )

    if [[ -n "${DUP_GENE}" ]]; then
        echo "[ERROR] Duplicate core gene ID detected: ${DUP_GENE}" >&2
        exit 1
    fi

    ########################################################
    # 4.2 Check gene/CDS lengths
    ########################################################

    BAD_LENGTH=$(
        awk '
        BEGIN {
            FS = "\t"
        }

        NF < 3 || $2 !~ /^[0-9]+$/ || $3 !~ /^[0-9]+$/ || $2 <= 0 || $3 <= 0 {
            print
            exit
        }
        ' "${GENE_LEN_FILE}"
    )

    if [[ -n "${BAD_LENGTH}" ]]; then
        echo "[ERROR] Invalid gene/CDS length row:" >&2
        echo "${BAD_LENGTH}" >&2
        exit 1
    fi

    ########################################################
    # 5. Whole-gene total SNP counts
    #
    # genes.intersect.bed:
    # gene ID is assumed to be column 8.
    ########################################################

    count_unique_sites_by_gene \
        "${GENE_LEN_FILE}" \
        "${GENE_SNP_INTERSECT}" \
        8 \
        "${GENE_SNP_FILE}"

    echo "[INFO] Whole-gene SNP count entries: $(wc -l < "${GENE_SNP_FILE}")"

    ########################################################
    # 6. CDS total SNP counts
    #
    # CDS_jcvi.intersect.bed:
    # gene ID is assumed to be column 8.
    ########################################################

    count_unique_sites_by_gene \
        "${GENE_LEN_FILE}" \
        "${CDS_SNP_INTERSECT}" \
        8 \
        "${CDS_SNP_FILE}"

    echo "[INFO] CDS SNP count entries: $(wc -l < "${CDS_SNP_FILE}")"

    ########################################################
    # 7. Whole-gene deleterious SNP counts
    #
    # *_genes_detailed.bed:
    # gene ID is assumed to be column 11.
    ########################################################

    count_unique_sites_by_gene \
        "${GENE_LEN_FILE}" \
        "${GENE_DEL_BED}" \
        11 \
        "${GENE_DEL_FILE}"

    echo "[INFO] Whole-gene deleterious SNP entries: $(wc -l < "${GENE_DEL_FILE}")"

    ########################################################
    # 8. CDS deleterious SNP counts
    #
    # *_CDS_jcvi_detailed.bed:
    # gene ID is assumed to be column 11.
    ########################################################

    count_unique_sites_by_gene \
        "${GENE_LEN_FILE}" \
        "${CDS_DEL_BED}" \
        11 \
        "${CDS_DEL_FILE}"

    echo "[INFO] CDS deleterious SNP entries: $(wc -l < "${CDS_DEL_FILE}")"

    ########################################################
    # 9. Merge all statistics and calculate ratios
    #
    # Important bug fix:
    # gene_cds_len.tsv has no header, so its first line must
    # not be skipped.
    ########################################################

    BODY_TMP="${OUT_DIR}/.core_gene_deleterious_stats.body.${LSB_JOBID:-$$}.${TASK_ID}"
    FINAL_TMP="${OUT_DIR}/.core_gene_deleterious_stats.final.${LSB_JOBID:-$$}.${TASK_ID}"

    rm -f "${BODY_TMP}" "${FINAL_TMP}"

    awk '
    BEGIN {
        FS = OFS = "\t"
    }

    ########################################################
    # File 1: gene_id, gene_len, cds_len
    ########################################################

    FILENAME == ARGV[1] {
        if (NF < 3) {
            next
        }

        gene = $1

        gene_len[gene] = $2 + 0
        cds_len[gene] = $3 + 0
        genes[gene] = 1

        next
    }

    ########################################################
    # File 2: total SNPs in whole-gene regions
    ########################################################

    FILENAME == ARGV[2] {
        if (NF >= 2) {
            gene_snp[$1] = $2 + 0
        }
        next
    }

    ########################################################
    # File 3: deleterious SNPs in whole-gene regions
    ########################################################

    FILENAME == ARGV[3] {
        if (NF >= 2) {
            gene_del[$1] = $2 + 0
        }
        next
    }

    ########################################################
    # File 4: total SNPs in CDS regions
    ########################################################

    FILENAME == ARGV[4] {
        if (NF >= 2) {
            cds_snp[$1] = $2 + 0
        }
        next
    }

    ########################################################
    # File 5: deleterious SNPs in CDS regions
    ########################################################

    FILENAME == ARGV[5] {
        if (NF >= 2) {
            cds_del[$1] = $2 + 0
        }
        next
    }

    ########################################################
    # Generate final data rows
    ########################################################

    END {
        error_count = 0

        for (gene in genes) {

            gl = gene_len[gene]
            cl = cds_len[gene]

            gs = (gene in gene_snp) ? gene_snp[gene] : 0
            gd = (gene in gene_del) ? gene_del[gene] : 0

            cs = (gene in cds_snp) ? cds_snp[gene] : 0
            cd = (gene in cds_del) ? cds_del[gene] : 0

            if (gl <= 0) {
                printf "[ERROR] Non-positive gene length: %s, gene_len=%s\n", gene, gl > "/dev/stderr"
                error_count++
                continue
            }

            if (cl <= 0) {
                printf "[ERROR] Non-positive CDS length: %s, cds_len=%s\n", gene, cl > "/dev/stderr"
                error_count++
                continue
            }

            if (gd > gs) {
                printf "[ERROR] Gene deleterious SNPs exceed total SNPs: %s, deleterious=%d, total=%d\n", gene, gd, gs > "/dev/stderr"
                error_count++
                continue
            }

            if (cd > cs) {
                printf "[ERROR] CDS deleterious SNPs exceed total SNPs: %s, deleterious=%d, total=%d\n", gene, cd, cs > "/dev/stderr"
                error_count++
                continue
            }

            gene_snp_ratio = (gl > 0) ? gs / gl : 0
            gene_deleterious_ratio = (gs > 0) ? gd / gs : 0
            cds_snp_ratio = (cl > 0) ? cs / cl : 0
            cds_deleterious_ratio = (cs > 0) ? cd / cs : 0

            printf "%s\t%d\t%d\t%.6f\t%d\t%.6f\t%d\t%d\t%.6f\t%d\t%.6f\n", gene, gl, gs, gene_snp_ratio, gd, gene_deleterious_ratio, cl, cs, cds_snp_ratio, cd, cds_deleterious_ratio
        }

        if (error_count > 0) {
            exit 2
        }
    }
    ' "${GENE_LEN_FILE}" \
      "${GENE_SNP_FILE}" \
      "${GENE_DEL_FILE}" \
      "${CDS_SNP_FILE}" \
      "${CDS_DEL_FILE}" \
    | LC_ALL=C sort -t $'\t' -k1,1 \
    > "${BODY_TMP}"

    ########################################################
    # 9.1 Add unchanged 11-column header
    ########################################################

    {
        printf '%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\n' \
            "gene_id" \
            "gene_len" \
            "gene_snp_total" \
            "gene_snp_ratio" \
            "gene_deleterious_snp" \
            "gene_deleterious_ratio" \
            "cds_len" \
            "cds_snp_total" \
            "cds_snp_ratio" \
            "cds_deleterious_snp" \
            "cds_deleterious_ratio"

        cat "${BODY_TMP}"

    } > "${FINAL_TMP}"

    ########################################################
    # Replace final file only after successful completion
    ########################################################

    mv "${FINAL_TMP}" "${FINAL_FILE}"
    rm -f "${BODY_TMP}"

    ########################################################
    # 10. Final row-count validation
    ########################################################

    N_OUTPUT=$(awk 'END{print NR-1}' "${FINAL_FILE}")
    N_TOTAL=$(wc -l < "${FINAL_FILE}")

    if (( N_OUTPUT != N_CORE )); then

        echo "[ERROR] Final gene count mismatch." >&2
        echo "[ERROR] Expected core genes: ${N_CORE}" >&2
        echo "[ERROR] Observed output genes: ${N_OUTPUT}" >&2

        comm -23 \
            <(
                cut -f1 "${GENE_LEN_FILE}" \
                | LC_ALL=C sort
            ) \
            <(
                tail -n +2 "${FINAL_FILE}" \
                | cut -f1 \
                | LC_ALL=C sort
            ) \
            > "${OUT_DIR}/missing_core_genes.tsv"

        comm -13 \
            <(
                cut -f1 "${GENE_LEN_FILE}" \
                | LC_ALL=C sort
            ) \
            <(
                tail -n +2 "${FINAL_FILE}" \
                | cut -f1 \
                | LC_ALL=C sort
            ) \
            > "${OUT_DIR}/unexpected_genes.tsv"

        echo "[ERROR] Missing genes written to:" >&2
        echo "        ${OUT_DIR}/missing_core_genes.tsv" >&2

        echo "[ERROR] Unexpected genes written to:" >&2
        echo "        ${OUT_DIR}/unexpected_genes.tsv" >&2

        exit 1
    fi

    ########################################################
    # 10.1 Check duplicate genes in final output
    ########################################################

    DUP_FINAL=$(
        tail -n +2 "${FINAL_FILE}" \
        | cut -f1 \
        | LC_ALL=C sort \
        | uniq -d \
        | head -n 1 || true
    )

    if [[ -n "${DUP_FINAL}" ]]; then
        echo "[ERROR] Duplicate gene in final output: ${DUP_FINAL}" >&2
        exit 1
    fi

    ########################################################
    # 10.2 Check ratios outside the expected 0-1 range
    ########################################################

    BAD_RATIO=$(
        awk '
        BEGIN {
            FS = "\t"
        }

        NR > 1 {
            if ($4 < 0 || $6 < 0 || $6 > 1 || $9 < 0 || $11 < 0 || $11 > 1) {
                print
                exit
            }
        }
        ' "${FINAL_FILE}"
    )

    if [[ -n "${BAD_RATIO}" ]]; then
        echo "[ERROR] Invalid ratio detected:" >&2
        echo "${BAD_RATIO}" >&2
        exit 1
    fi

    ########################################################
    # 11. QC summary
    ########################################################

    awk '
    BEGIN {
        FS = "\t"
    }

    NR > 1 {
        n++

        gene_snp_sum += $3
        gene_del_sum += $5

        cds_snp_sum += $8
        cds_del_sum += $10

        if ($3 > 0) {
            gene_snp_positive++
        }

        if ($5 > 0) {
            gene_del_positive++
        }

        if ($8 > 0) {
            cds_snp_positive++
        }

        if ($10 > 0) {
            cds_del_positive++
        }
    }

    END {
        printf "[QC] genes_total=%d\n", n
        printf "[QC] genes_with_gene_SNP=%d\n", gene_snp_positive + 0
        printf "[QC] genes_with_gene_deleterious_SNP=%d\n", gene_del_positive + 0
        printf "[QC] genes_with_CDS_SNP=%d\n", cds_snp_positive + 0
        printf "[QC] genes_with_CDS_deleterious_SNP=%d\n", cds_del_positive + 0
        printf "[QC] total_gene_SNP_count=%d\n", gene_snp_sum + 0
        printf "[QC] total_gene_deleterious_SNP_count=%d\n", gene_del_sum + 0
        printf "[QC] total_CDS_SNP_count=%d\n", cds_snp_sum + 0
        printf "[QC] total_CDS_deleterious_SNP_count=%d\n", cds_del_sum + 0
    }
    ' "${FINAL_FILE}"

    echo "[OK] Final core genes: ${N_OUTPUT}"
    echo "[OK] Total file lines including header: ${N_TOTAL}"
    echo "[OK] Wrote: ${FINAL_FILE}"

done

echo
echo "============================================================"
echo "[OK] DONE threshold ${CLASS}"
echo "============================================================"