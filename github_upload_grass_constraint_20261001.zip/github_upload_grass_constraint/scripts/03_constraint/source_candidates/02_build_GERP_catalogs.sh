#!/usr/bin/env bash
#BSUB -q Q96C1T_X12
#BSUB -n 8
#BSUB -J build_GERP_catalogs
#BSUB -o build_GERP_catalogs_%J.out
#BSUB -e build_GERP_catalogs_%J.err






set -euo pipefail

OUT="CNS_GERP_analysis/02_GERP"
TMP="CNS_GERP_analysis/tmp"

mkdir -p "${OUT}" "${TMP}"

for T in 0 2 4 6
do
    echo "[INFO] Building unique GERP>${T} site catalog"

    GENE="gt${T}/bed_files/genes_conserved_sites.bed"
    INTER="gt${T}/bed_files/intergenic_conserved_sites.bed"

    if [[ ! -s "${GENE}" || ! -s "${INTER}" ]]
    then
        echo "[WARNING] Missing gt${T}; skipping"
        continue
    fi

    {
        awk 'BEGIN{OFS="\t"} NF>=7{
            print $1,$2,$3,$4,$5,$6,$7
        }' "${GENE}"

        awk 'BEGIN{OFS="\t"} NF>=7{
            print $1,$2,$3,$4,$5,$6,$7
        }' "${INTER}"

    } |
    LC_ALL=C sort \
        -T "${TMP}" \
        -S 8G \
        --parallel=8 \
        -k1,1 \
        -k2,2n \
        -k3,3n \
        -u \
    > "${OUT}/GERP_gt${T}.unique.bed"

    echo -n "[INFO] GERP>${T} sites: "
    wc -l < "${OUT}/GERP_gt${T}.unique.bed"
done
