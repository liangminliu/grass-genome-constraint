#!/usr/bin/env python3
import pandas as pd
from pathlib import Path

# ===============================
# 1. 长度常数
# ===============================
LEN = {
    "C": {
        "CDS": 31648281,
        "0-fold": 20423908,
        "4-fold": 5272177,
        "Intron": 74264096,
        "UTR": 8234031,
        "Promoter": 28052664,
        "UpDown5K": 280524231,
        "TE": 810939937,
        "Inter-genic (Control)": 628780837,
        "Total": 948618255
    },
    "D": {
        "CDS": 29648493,
        "0-fold": 19128982,
        "4-fold": 4941273,
        "Intron": 72281817,
        "UTR": 7639060,
        "Promoter": 26491000,
        "UpDown5K": 264906763,
        "TE": 851774596,
        "Inter-genic (Control)": 822676580,
        "Total": 931369844
    }
}

# ===============================
# 2. category 映射
# ===============================
MAP = {
    "CDS_jcvi": "CDS",
    "ped_chr_0-fold_sites": "0-fold",
    "ped_chr_4-fold_sites": "4-fold",
    "genes": "Intron",
    "five_prime_UTR": "UTR",
    "three_prime_UTR": "UTR",
    "promoters": "Promoter",
    "updown5k": "UpDown5K",
    "intergenic_final": "Inter-genic (Control)"
}

THRESHOLD_NAME = {
    "gerp_gt0": "Mild threshold (GERP>0) – Mildly, moderately and strongly constrained sites",
    "gerp_gt2": "Mild threshold (GERP>2) – Mildly, moderately and strongly constrained sites",
    "gerp_gt4": "Moderate threshold (GERP>4)",
    "gerp_gt6": "Strong threshold (GERP>6)"
}

# ===============================
# 3. 主循环
# ===============================
records = []

for gt in ["gerp_gt0", "gerp_gt2", "gerp_gt4", "gerp_gt6"]:
    for sg in ["C", "D"]:
        f = Path(f"intersect_results/{gt}/ped{sg}_{gt.split('_')[1]}.category_stats.tsv")
        if not f.exists():
            continue

        df = pd.read_csv(f, sep="\t")
        df["Region"] = df["category"].map(MAP)
        df = df.dropna(subset=["Region"])

        # 合并 UTR
        df_sum = df.groupby("Region", as_index=False)["count"].sum()

        # 补 TE
        df_sum = pd.concat([
            df_sum,
            pd.DataFrame({"Region": ["TE"], "count": [0]})
        ], ignore_index=True)

        for _, r in df_sum.iterrows():
            region = r["Region"]
            count = int(r["count"])
            length = LEN[sg][region]
            prop = count / length * 100

            records.append([
                THRESHOLD_NAME[gt],
                f"subgenome {sg}",
                region,
                length,
                count,
                round(prop, 6)
            ])

# ===============================
# 4. 输出
# ===============================
out = pd.DataFrame(records, columns=[
    "Threshold of evolutionary constrained site",
    "Group",
    "Region category",
    "Length (bp)",
    "No. of constrained sites",
    "Constrained sites Proportion (% , constrained sites divided by subgenome sites)"
])

out.to_csv("GERP_constrained_sites_summary.tsv", sep="\t", index=False)
