#!/bin/bash
#SBATCH --job-name=gerp_region_intersect_pedC
#SBATCH --output=logs/gerp_region_intersect_pedC_%A_%a.log
#SBATCH --error=logs/gerp_region_intersect_pedC_%A_%a.err
#SBATCH --cpus-per-task=6
#SBATCH --array=1-4%4

set -euo pipefail
mkdir -p logs

############################################################
# 1. Array mapping (GERP threshold)
############################################################
GERP_CLASSES=("gt0" "gt2" "gt4" "gt6")
IDX=$((SLURM_ARRAY_TASK_ID - 1))
GT=${GERP_CLASSES[$IDX]}

SUB="pedC"

echo "GERP class : $GT"
echo "Subgenome  : $SUB"

############################################################
# 2. Input GERP constrained sites (BED)
############################################################
BASE_DIR="/gpfs/hpc/home/kib_unit/lidezhu/liuliangmin/5.deleterious/01.snp_calling/01.filtering/01.3.filter_all_individual/63sp"

GERP_BED="${BASE_DIR}/gerp_${GT}/${SUB}_${GT}_gerp_regions.bed"

if [[ ! -f "$GERP_BED" ]]; then
    echo "ERROR: GERP BED not found: $GERP_BED"
    exit 1
fi

############################################################
# 3. Functional BEDs (STRICT whitelist)
############################################################
FUNC_BED_DIR="./"
# 这里只放：CDS / exons / introns / UTR / missense / synonymous / intergenic 等

mapfile -t FUNCTIONAL_BEDS < <(
    find "$FUNC_BED_DIR" -maxdepth 1 -name "*.bed" | sort
)

if [[ ${#FUNCTIONAL_BEDS[@]} -eq 0 ]]; then
    echo "ERROR: no functional BEDs found in $FUNC_BED_DIR"
    exit 1
fi

############################################################
# 4. Output
############################################################
OUTDIR="functional_analysis/gerp_${GT}/${SUB}"
mkdir -p "$OUTDIR"

############################################################
# 5. Main loop
############################################################
for FUNC_BED in "${FUNCTIONAL_BEDS[@]}"; do
    FUNC_NAME=$(basename "$FUNC_BED" .bed)

    echo "==> ${SUB} ${GT} × ${FUNC_NAME}"

    OUT_SITE_BED="${OUTDIR}/${SUB}_${GT}_${FUNC_NAME}_constrained_sites.bed"
    OUT_FUNC_BED="${OUTDIR}/${SUB}_${GT}_${FUNC_NAME}_func_regions.bed"

    ########################################################
    # Constrained sites ∩ Functional category
    ########################################################
    bedtools intersect \
        -a "$GERP_BED" \
        -b "$FUNC_BED" \
        -wa \
    > "$OUT_SITE_BED"

    if [[ ! -s "$OUT_SITE_BED" ]]; then
        rm -f "$OUT_SITE_BED"
        continue
    fi

    ########################################################
    # 被 constrained sites 命中的功能区
    ########################################################
    bedtools intersect \
        -a "$FUNC_BED" \
        -b "$OUT_SITE_BED" \
        -wa \
    > "$OUT_FUNC_BED"

    [[ -s "$OUT_FUNC_BED" ]] || rm -f "$OUT_FUNC_BED"
done

echo "ALL DONE: ${SUB} ${GT}"
