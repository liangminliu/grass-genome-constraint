#!/bin/bash
#SBATCH --job-name=gerp_annotation_array
#SBATCH --output=logs/gerp_annotate_%A_%a.out
#SBATCH --error=logs/gerp_annotate_%A_%a.err
#SBATCH --partition=parallel
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=2
#SBATCH --array=1-160%30  # 将NUM_TASKS替换为实际任务总数，最多同时运行20个任务

# 设置路径变量
GERP_DIR="/gpfs/hpc/home/kib_unit/lidezhu/liuliangmin/2.msa/84sp_ped/94sp_ped_results/GERPnew_output"
INPUT_BED_DIR="output_bed"
OUTPUT_DIR="./"

# 仅在第一个任务运行时创建统计文件头
if [ "$SLURM_ARRAY_TASK_ID" -eq 1 ]; then
    STATS_FILE="${OUTPUT_DIR}/gerp_stats.tsv"
    echo -e "GERP_Type\tCategory\tBED_File\tSNP_Count" > $STATS_FILE
fi

# 获取所有输入文件和GERP文件的列表
BED_FILES=($INPUT_BED_DIR/*.intersect.bed)
GERP_FILES=($GERP_DIR/gerp_ge*/*.clean.bed)

# 计算总任务数
NUM_BED=${#BED_FILES[@]}
NUM_GERP=${#GERP_FILES[@]}
TOTAL_TASKS=$((NUM_BED * NUM_GERP))

# 根据数组任务ID计算当前处理的BED和GERP文件索引
BED_INDEX=$(( (SLURM_ARRAY_TASK_ID - 1) / NUM_GERP ))
GERP_INDEX=$(( (SLURM_ARRAY_TASK_ID - 1) % NUM_GERP ))

# 获取当前任务处理的文件
INTERSECT_BED=${BED_FILES[$BED_INDEX]}
GERP_BED=${GERP_FILES[$GERP_INDEX]}

# 提取基本信息
BASENAME=$(basename "$INTERSECT_BED" .intersect.bed)
GERP_TYPE=$(basename $(dirname $GERP_BED))
GERP_CATEGORY=$(basename $GERP_BED | cut -d'_' -f2 | sed 's/.clean.bed//')

# 创建输出目录
mkdir -p "${OUTPUT_DIR}/${GERP_TYPE}"

# 处理当前任务
echo "Processing task $SLURM_ARRAY_TASK_ID/$TOTAL_TASKS: $BASENAME with ${GERP_TYPE}/${GERP_CATEGORY}"

# 提取功能注释（第8列）
awk -v OFS="\t" '{print $1,$2,$3,$8}' $INTERSECT_BED > ${BASENAME}_${GERP_TYPE}_${GERP_CATEGORY}_func_annot.tmp

# 计算交集
bedtools intersect -wa \
    -a ${BASENAME}_${GERP_TYPE}_${GERP_CATEGORY}_func_annot.tmp \
    -b $GERP_BED \
    > "${OUTPUT_DIR}/${GERP_TYPE}/${BASENAME}_${GERP_CATEGORY}.bed"

# 统计计数
COUNT=$(wc -l < "${OUTPUT_DIR}/${GERP_TYPE}/${BASENAME}_${GERP_CATEGORY}.bed")
echo -e "${GERP_TYPE}\t${GERP_CATEGORY}\t${BASENAME}\t${COUNT}" >> ${OUTPUT_DIR}/gerp_stats_${SLURM_ARRAY_TASK_ID}.tmp

# 清理临时文件
rm ${BASENAME}_${GERP_TYPE}_${GERP_CATEGORY}_func_annot.tmp

# 最后一个任务负责合并统计结果
if [ "$SLURM_ARRAY_TASK_ID" -eq "$TOTAL_TASKS" ]; then
    echo "All tasks completed. Merging statistics..."
    cat ${OUTPUT_DIR}/gerp_stats_*.tmp >> $STATS_FILE
    rm ${OUTPUT_DIR}/gerp_stats_*.tmp
    echo "GERP annotation completed."
    echo "Results organized in ${OUTPUT_DIR}/gerp_ge*/ directories"
    echo "Statistics saved to $STATS_FILE"
    echo -e "\nOutput directory structure:"
    tree -d $OUTPUT_DIR
fi
