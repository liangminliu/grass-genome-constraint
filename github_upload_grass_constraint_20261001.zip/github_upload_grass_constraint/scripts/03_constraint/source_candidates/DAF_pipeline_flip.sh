#!/bin/bash
#SBATCH -J DAF_pipeline_flip
#SBATCH -p parallel
#SBATCH -N 1
#SBATCH -n 1
#SBATCH --cpus-per-task=20
#SBATCH -o DAF_pipeline_flip.%j.out
#SBATCH -e DAF_pipeline_flip.%j.err

###############################################################################
# Pipeline: VCF → merged → FLIP-ancestral → category-SFS → DAF (bin=0.05)
#
# Purpose:
# Direct comparison between probabilistic ancestral polarization
# and hard-flipped ancestral polarization.
###############################################################################

set -euo pipefail

###############################################################################
# Parameters
###############################################################################

NALLELE=124
BIN=0.05

CLASSES=("syn" "tolerant" "gerp4" "hiconf")

###############################################################################
# Step 0. Prepare directories
###############################################################################

echo "[Step 0] Preparing directories for FLIP ancestral pipeline"

mkdir -p anc_flip subset_flip sfs_flip daf_flip

# 直接使用你已有的 flip 祖先结果
ln -sf $(pwd)/ancestral_results/*.ancestral.bed anc_flip/

###############################################################################
# Step 1. Subset merged SNP tables by functional category
###############################################################################

echo "[Step 1] Subsetting merged SNP tables (FLIP)"

for CLASS in "${CLASSES[@]}"; do
  mkdir -p subset_flip/${CLASS} sfs_flip/${CLASS}
done

###############################################################################
# Step 2. Compute unfolded SFS (FLIP ancestral)
###############################################################################

echo "[Step 2] Computing unfolded SFS using FLIP ancestral"

for CLASS in "${CLASSES[@]}"; do
  for CHR in Ped{01..12}{C,D} Ped09X; do

    MERGED=merged_results/${CHR}.merged.txt
    ANC=anc_flip/${CHR}.ancestral.bed

    [[ -f ${MERGED} && -f ${ANC} ]] || continue

    bedtools intersect -wa -u \
      -a ${MERGED} \
      -b bed_classes/${CLASS}.bed \
      > subset_flip/${CLASS}/${CHR}.${CLASS}.merged.txt

    python3 build_unfolded_sfs.py \
      --merged subset_flip/${CLASS}/${CHR}.${CLASS}.merged.txt \
      --ancestral ${ANC} \
      --Nallele ${NALLELE} \
      --out sfs_flip/${CLASS}/${CHR}.${CLASS}.sfs.tsv \
      --skip_na
  done
done

###############################################################################
# Step 3. Merge per-chromosome SFS (FLIP)
###############################################################################

echo "[Step 3] Merging per-chromosome SFS (FLIP)"

for CLASS in "${CLASSES[@]}"; do
  echo -e "derived_count\tsites" > sfs_flip/genome.${CLASS}.sfs.tsv

  awk '
    FNR==1 { next }
    NF==2 { sum[$1] += $2 }
    END {
      for (k in sum) {
        print k "\t" sum[k]
      }
    }
  ' sfs_flip/${CLASS}/Ped*.${CLASS}.sfs.tsv \
    | sort -n >> sfs_flip/genome.${CLASS}.sfs.tsv
done

###############################################################################
# Step 4. Convert unfolded SFS to DAF (FLIP)
###############################################################################

echo "[Step 4] Converting SFS to DAF distributions (FLIP)"

for CLASS in "${CLASSES[@]}"; do
  python3 << EOF
import pandas as pd

N = ${NALLELE}
BIN = ${BIN}

sfs = pd.read_csv(
    "sfs_flip/genome.${CLASS}.sfs.tsv",
    sep="\\t"
)

sfs["derived_count"] = pd.to_numeric(sfs["derived_count"])
sfs["sites"] = pd.to_numeric(sfs["sites"])

assert sfs["derived_count"].between(0, N).all()

sfs["daf"] = sfs["derived_count"] / N
sfs["bin"] = (sfs["daf"] // BIN) * BIN
sfs.loc[sfs["bin"] >= 1.0, "bin"] = 1.0 - BIN

daf = (
    sfs.groupby("bin", as_index=False)["sites"]
    .sum()
)
daf["proportion"] = daf["sites"] / daf["sites"].sum()

daf[["bin", "proportion"]].to_csv(
    "daf_flip/genome.${CLASS}.daf.tsv",
    sep="\\t",
    index=False
)
EOF
done

echo "[FLIP ancestral DAF pipeline finished successfully]"
