#!/bin/bash
#SBATCH --job-name=bedtools_intersect
#SBATCH --output=logs/bedtools_intersect_%A_%a.log
#SBATCH --error=logs/bedtools_intersect_%A_%a.err
#SBATCH --cpus-per-task=8
#SBATCH --array=1-8%8

set -euo pipefail

############################################
# 0. 基本准备
############################################
mkdir -p logs

VCF="63sp.filtered.bi-allelic.snp.renamed.vcf.gz"

BASE_DIR="/gpfs/hpc/home/kib_unit/lidezhu/liuliangmin/2.msa/84sp_ped/94sp_ped_results/GERP_final_output"

SIF="/gpfs/hpc/home/kib_unit/lidezhu/liuliangmin/4.may/software/Reseq_genek.sif"

############################################
# 0.1 Singularity 临时目录（解决 /tmp 空间不足）
# 每个 array task 一个独立 tmp，避免并行冲突
############################################
WORK_TMP_DIR="$(pwd)/singularity_tmp_${SLURM_JOB_ID:-nojob}_${SLURM_ARRAY_TASK_ID:-0}_$$"
export SINGULARITY_TMPDIR="$WORK_TMP_DIR"
export TMPDIR="$WORK_TMP_DIR"
mkdir -p "$WORK_TMP_DIR"

cleanup() {
    echo "Cleaning tmp dir: $WORK_TMP_DIR"
    rm -rf "$WORK_TMP_DIR"
}
trap cleanup EXIT

echo "TMPDIR: $WORK_TMP_DIR"
echo "Disk usage for $(pwd):"
df -h "$(pwd)"

############################################
# 0.2 依赖检查（宿主机）
############################################
command -v bedtools >/dev/null 2>&1 || { echo "ERROR: bedtools not found in PATH"; exit 10; }
command -v bgzip   >/dev/null 2>&1 || { echo "ERROR: bgzip not found in PATH"; exit 11; }
command -v tabix   >/dev/null 2>&1 || { echo "ERROR: tabix not found in PATH"; exit 12; }

############################################
# 1. 收集 GERP BED（真实文件）
############################################
BED_FILES=($(ls \
  ${BASE_DIR}/gerp_gt0/ped*.bed \
  ${BASE_DIR}/gerp_gt2/ped*.bed \
  ${BASE_DIR}/gerp_gt4/ped*.bed \
  ${BASE_DIR}/gerp_gt6/ped*.bed \
))

TOTAL=${#BED_FILES[@]}

if [ "$SLURM_ARRAY_TASK_ID" -gt "$TOTAL" ]; then
    echo "ERROR: SLURM_ARRAY_TASK_ID ($SLURM_ARRAY_TASK_ID) exceeds number of BED files ($TOTAL)"
    exit 1
fi

BED_FILE="${BED_FILES[$SLURM_ARRAY_TASK_ID-1]}"
BED_NAME=$(basename "$BED_FILE" .bed)
GERP_DIR=$(basename "$(dirname "$BED_FILE")")

############################################
# 2. 输出目录
############################################
OUTDIR="./${GERP_DIR}"
mkdir -p "$OUTDIR"

OUT_VCF_GZ="${OUTDIR}/${BED_NAME}_snps.vcf.gz"
OUT_SNP_BED="${OUTDIR}/${BED_NAME}_snps.bed"
OUT_GERP_BED="${OUTDIR}/${BED_NAME}_gerp_regions.bed"

echo "$(date) Processing BED: $BED_FILE"
echo "$(date) Output dir: $OUTDIR"

############################################
# 3. SNP ∩ GERP（VCF，输出 bgzip 压缩 + tabix）
# - bcftools 在容器内
# - bedtools/bgzip/tabix 在宿主机
############################################
singularity exec "$SIF" bcftools view "$VCF" | \
bedtools intersect \
  -a stdin \
  -b <(awk 'NR>1 {print $1,$2,$3}' OFS="\t" "$BED_FILE") \
  -header | \
bgzip -c > "$OUT_VCF_GZ"

tabix -f -p vcf "$OUT_VCF_GZ"

############################################
# 4. SNP ∩ GERP（BED，SNP 位点）
############################################
singularity exec "$SIF" bcftools view "$VCF" | \
awk 'BEGIN{OFS="\t"} !/^#/ {print $1,$2-1,$2,$3}' | \
bedtools intersect \
  -a stdin \
  -b <(awk 'NR>1 {print $1,$2,$3}' OFS="\t" "$BED_FILE") \
> "$OUT_SNP_BED"

############################################
# 5. GERP 区间 ∩ SNP（保留 GERP 分数）
############################################
bedtools intersect \
  -a <(awk 'NR>1' "$BED_FILE") \
  -b <(
      singularity exec "$SIF" bcftools view "$VCF" | \
      awk 'BEGIN{OFS="\t"} !/^#/ {print $1,$2-1,$2}'
     ) \
  -wa \
> "$OUT_GERP_BED"

############################################
# 6. 简要统计
############################################
SNP_COUNT=$(singularity exec "$SIF" bcftools view -H "$OUT_VCF_GZ" | wc -l)
echo "DONE: $BED_NAME"
echo "  SNPs in VCF.gz : ${SNP_COUNT}"
echo "  SNP BED        : $(wc -l < "$OUT_SNP_BED")"
echo "  GERP sites     : $(wc -l < "$OUT_GERP_BED")"
echo "$(date) Finished processing $BED_NAME"
