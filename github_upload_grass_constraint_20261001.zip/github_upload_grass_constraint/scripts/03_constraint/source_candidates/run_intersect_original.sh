#!/bin/bash
#SBATCH --job-name=gerp_intersect
#SBATCH --partition=parallel
#SBATCH --nodes=1
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=10
#SBATCH --array=1-8
#SBATCH --output=logs/intersect_%A_%a.out
#SBATCH --error=logs/intersect_%A_%a.err

module load bedtools 2>/dev/null

############################################
# 目录定义
############################################
GERP_DIR="/gpfs/hpc/home/kib_unit/lidezhu/liuliangmin/2.msa/84sp_ped/94sp_ped_results/GERP_final_output"
CAT_DIR="../2.1.constrained_category"
OUT_BASE="./intersect_results"

mkdir -p logs


############################################
# GERP 输入文件列表
############################################
GERP_LIST=(
"${GERP_DIR}/gerp_gt0/pedC_gt0.bed"
"${GERP_DIR}/gerp_gt0/pedD_gt0.bed"
"${GERP_DIR}/gerp_gt2/pedC_gt2.bed"
"${GERP_DIR}/gerp_gt2/pedD_gt2.bed"
"${GERP_DIR}/gerp_gt4/pedC_gt4.bed"
"${GERP_DIR}/gerp_gt4/pedD_gt4.bed"
"${GERP_DIR}/gerp_gt6/pedC_gt6.bed"
"${GERP_DIR}/gerp_gt6/pedD_gt6.bed"
)

GERP_FILE="${GERP_LIST[$SLURM_ARRAY_TASK_ID-1]}"
base=$(basename "$GERP_FILE" .bed)

# 提取分组目录名称，例如 gerp_gt0
group=$(basename "$(dirname "$GERP_FILE")")

OUT_DIR="${OUT_BASE}/${group}"
mkdir -p "${OUT_DIR}"

echo "Processing: $GERP_FILE"
echo "Output dir: $OUT_DIR"


############################################
# 去掉 GERP 文件表头（分类文件无表头，无需处理）
############################################
GERP_CLEAN="${OUT_DIR}/${base}.clean"
tail -n +2 "$GERP_FILE" > "$GERP_CLEAN"


############################################
# 统计结果文件
############################################
STAT_FILE="${OUT_DIR}/${base}.category_stats.tsv"
echo -e "category\tcount\tproportion" > "$STAT_FILE"

mkdir -p "${OUT_DIR}/tmp_count"


############################################
# 并行 intersect
############################################
CPUS=${SLURM_CPUS_PER_TASK:-10}
running=0

declare -A COUNTS
TOTAL=0

echo "Using $CPUS CPUs for parallel intersect tasks"

for cat in ${CAT_DIR}/*.bed; do
    cname=$(basename "$cat" .bed)
    out="${OUT_DIR}/${base}.${cname}.intersect.bed"

    (
        bedtools intersect -wa -wb \
            -a "$GERP_CLEAN" \
            -b "$cat" \
            > "$out"

        wc -l < "$out" > "${OUT_DIR}/tmp_count/${cname}.count"
        echo "Generated: $out"
    ) &

    running=$((running + 1))

    if [ "$running" -ge "$CPUS" ]; then
        wait
        running=0
    fi
done

wait  # 等所有后台任务完成


############################################
# 删除临时 GERP clean 文件
############################################
rm -f "$GERP_CLEAN"


############################################
# 汇总分类统计
############################################
for f in ${OUT_DIR}/tmp_count/*.count; do
    cname=$(basename "$f" .count)
    count=$(cat "$f")
    COUNTS[$cname]=$count
    TOTAL=$((TOTAL + count))
done

echo "Total intersected = $TOTAL"

for cname in "${!COUNTS[@]}"; do
    count=${COUNTS[$cname]}
    if [ "$TOTAL" -eq 0 ]; then
        proportion=0
    else
        proportion=$(awk -v c=$count -v t=$TOTAL 'BEGIN{printf "%.6f", c/t}')
    fi
    echo -e "${cname}\t${count}\t${proportion}" >> "$STAT_FILE"
done

echo "Statistics saved to: $STAT_FILE"
echo "Task $SLURM_ARRAY_TASK_ID finished."
