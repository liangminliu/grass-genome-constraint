#!/bin/bash
#SBATCH --job-name=snpEff
#SBATCH --output=snpEff.%A_%a.out
#SBATCH --error=snpEff.%A_%a.err
#SBATCH --cpus-per-task=40
#SBATCH --partition=parallel

singularity exec  ~/liuliangmin/4.may/software/Reseq_genek.sif java -jar /opt/snpEff/snpEff.jar -c  ./snpEff.config -ud 5000 -csvStats Zmay_v5.csv -htmlStats Zmay_v5.html -o vcf  Zmay all.filtered.bi-allelic.miss0.5.snp.vcf.gz > all.filtered.bi-allelic.miss0.5.snp.ann.vcf
