#!/bin/bash
#SBATCH --job-name=vcftools_parallel
#SBATCH --output=vcftools_parallel.out
#SBATCH --error=vcftools_parallel.err
#SBATCH --cpus-per-task=20
#SBATCH --partition=parallel

# 激活环境
conda activate /gpfs/hpc/home/kib_unit/lidezhu/miniforge3/envs/cactus

# —— 第二步：定义文件名 ——
vcf1=pedC_moderate.clean_snps.vcf
vcf2=pedD_moderate.clean_snps.vcf
# 压缩后文件
vcf1gz=${vcf1}.gz
vcf2gz=${vcf2}.gz

# —— 第三步：如果没有压缩并索引，就先做 bgzip + tabix —— 
for vcf in ${vcf1} ${vcf2}; do
  if [ ! -f ${vcf}.gz ]; then
    echo "Compress and index ${vcf} ……"
    bgzip -@20 ${vcf}
    tabix -p vcf ${vcf}.gz
  else
    echo "${vcf}.gz already exists, skip compressing."
  fi
done

# —— 第四步：连接不同染色体的VCF文件 —— 
merged=combined_pedC_pedD.clean_snps.vcf.gz
[ -f ${merged} ] && rm -f ${merged} ${merged}.tbi

echo "开始连接 ${vcf1gz} 和 ${vcf2gz} (不同染色体位点)……"

# 使用 bcftools concat 连接不同染色体的数据
singularity exec /gpfs/hpc/home/kib_unit/lidezhu/liuliangmin/4.may/software/Reseq_genek.sif \
  bcftools concat \
    -O z \
    -o ${merged} \
    ${vcf1gz} ${vcf2gz}

# 如果需要确保按染色体位置排序，可以使用以下命令替代上面的concat：
# echo "连接并排序VCF文件..."
# singularity exec /gpfs/hpc/home/kib_unit/lidezhu/liuliangmin/4.may/software/Reseq_genek.sif \
#   bcftools concat \
#     -O z \
#     -o temp_concat.vcf.gz \
#     ${vcf1gz} ${vcf2gz}
# 
# singularity exec /gpfs/hpc/home/kib_unit/lidezhu/liuliangmin/4.may/software/Reseq_genek.sif \
#   bcftools sort \
#     -O z \
#     -o ${merged} \
#     temp_concat.vcf.gz
# 
# rm temp_concat.vcf.gz

# —— 第五步：给合并后的文件建索引 —— 
echo "为合并后的文件建立索引 ……"
tabix -p vcf ${merged}

# —— 第六步：用 plink 计算等位基因频率 —— 
out=merged_pedC_pedD
echo "开始用 plink 计算等位基因频率 ……"
singularity exec /gpfs/hpc/home/kib_unit/lidezhu/liuliangmin/4.may/software/Reseq_genek.sif \
  plink \
    --vcf ${merged} \
    --freq \
    --recode \
    --out ${out}_allele_freq \
    --allow-extra-chr \
    --snps-only \
    --threads 20

singularity exec /gpfs/hpc/home/kib_unit/lidezhu/liuliangmin/4.may/software/Reseq_genek.sif \
  plink \
    --vcf ${vcf1gz} \
    --freq \
    --recode \
    --out ${vcf1}_allele_freq \
    --allow-extra-chr \
    --snps-only \
    --threads 20

singularity exec /gpfs/hpc/home/kib_unit/lidezhu/liuliangmin/4.may/software/Reseq_genek.sif \
  plink \
    --vcf ${vcf2gz} \
    --freq \
    --recode \
    --out ${vcf2}_allele_freq \
    --allow-extra-chr \
    --snps-only \
    --threads 20
       
echo "全部完成！"