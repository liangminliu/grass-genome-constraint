#!/usr/bin/env bash
#BSUB -q Q96C1T_X12
#BSUB -n 8
#BSUB -JHopscotch_catalogs
#BSUB -oHopscotch_catalogs_%J.out
#BSUB -eHopscotch_catalogs_%J.err


set -euo pipefail

HOP="05_TB1/Hopscotch_v5.bed"

BGDIR="07_final_stats/background"
OUTDIR="07_final_stats/TB1"

mkdir -p "$OUTDIR"

OUT="${OUTDIR}/Hopscotch_GERP_summary.tsv"

if [[ ! -s "$HOP" ]]; then
    echo "[ERROR] Missing $HOP" >&2
    exit 1
fi

N=$(wc -l < "$HOP")

if [[ "$N" -ne 1 ]]; then
    echo "[ERROR] Hopscotch BED must contain exactly one interval." >&2
    echo "[ERROR] Current lines = $N" >&2
    exit 1
fi

LEN=$(awk '{print $3-$2}' "$HOP")

echo -e \
"region\tchr\tstart0\tend\tlength_bp\tthreshold\tGERP_bp\tGERP_fraction\tge60pct" \
> "$OUT"

CHR=$(awk '{print $1}' "$HOP")
START=$(awk '{print $2}' "$HOP")
END=$(awk '{print $3}' "$HOP")

for t in 0 2 4 6
do

    G="${BGDIR}/GERPgt${t}.sorted.merged.bed"

    if [[ ! -s "$G" ]]; then
        echo "[ERROR] Missing $G" >&2
        exit 1
    fi

    BP=$(
        bedtools intersect \
            -a "$HOP" \
            -b "$G" \
            -wo \
        | awk '{
            s += $NF
        }
        END{
            print s+0
        }'
    )

    awk \
      -v C="$CHR" \
      -v S="$START" \
      -v E="$END" \
      -v L="$LEN" \
      -v T="$t" \
      -v B="$BP" \
      'BEGIN{
          OFS="\t"

          f=B/L

          ge60=(f>=0.60 ? "YES" : "NO")

          print \
              "Hopscotch_LTRRT",
              C,
              S,
              E,
              L,
              "GERP>"T,
              B,
              f,
              ge60
      }' \
      >> "$OUT"

done

column -t -s $'\t' "$OUT"
