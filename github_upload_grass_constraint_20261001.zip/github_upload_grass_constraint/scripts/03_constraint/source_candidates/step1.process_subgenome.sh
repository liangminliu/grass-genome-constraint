#!/usr/bin/env bash
#SBATCH --job-name=process_subgenome
#SBATCH --output=logs/process_subgenome.out
#SBATCH --error=logs/process_subgenome.err
#SBATCH --cpus-per-task=1
#SBATCH --partition=parallel

set -euo pipefail
##python计算并画图
#python all_subgenome.py 

# 1. Ped09X 分界坐标
BOUNDARY=58257725

# 2. 临时目录
TMPDIR="subgenome_beds"
rm -rf "${TMPDIR}"
mkdir -p "${TMPDIR}"

# 3. 拆分 Ped09X.gerp.final.bed
echo "[$(date)] Splitting Ped09X.gerp.final.bed ..."
# 先把表头拷过去
head -n1 Ped09X.gerp.final.bed > "${TMPDIR}/Ped09X.C.bed"
head -n1 Ped09X.gerp.final.bed > "${TMPDIR}/Ped09X.D.bed"
# 再把数据分段落进去
awk -v B="${BOUNDARY}" 'FNR==1{next} $3 <= B {print}' Ped09X.gerp.final.bed >> "${TMPDIR}/Ped09X.D.bed"
awk -v B="${BOUNDARY}" 'FNR==1{next} $2 >  B {print}' Ped09X.gerp.final.bed >> "${TMPDIR}/Ped09X.C.bed"

# 4. 拷贝其他 C.bed / D.bed
echo "[$(date)] Copying other *C.bed and *D.bed ..."
for f in *C.bed; do
  [[ "$f" == "Ped09X.gerp.final.bed" ]] && continue
  cp "$f" "${TMPDIR}/"
done
for f in *D.bed; do
  [[ "$f" == "Ped09X.gerp.final.bed" ]] && continue
  cp "$f" "${TMPDIR}/"
done

# 5. 进入临时目录，计算 coverage
echo "[$(date)] Calculating coverage ..."
cd "${TMPDIR}"

calc_cov(){
  local pattern="$1"
  local outfile="../$2"
  awk '
    BEGIN { total=0 }
    FNR==1 { next }
    {
      k = $6
      counts[k]++
      total++
    }
    END {
      # 找最大 k
      max_k = 0
      for(i in counts) if (i+0 > max_k) max_k = i+0
      # 累积并输出
      cum = 0
      for(i=1; i<=max_k; i++){
        if (i in counts) cum += counts[i]
        prop = (total - cum + (counts[i]?counts[i]:0)) / total * 100
        printf "%d\t%.4f\n", i, prop
      }
    }
  ' ${pattern} > "${outfile}"
  echo "  -> ${outfile}"
}

# All = C + D
calc_cov '*.bed'   total_coverage.tsv
# 只算 C
calc_cov '*C.bed'  C_coverage.tsv
# 只算 D
calc_cov '*D.bed'  D_coverage.tsv

echo "[$(date)] Done."