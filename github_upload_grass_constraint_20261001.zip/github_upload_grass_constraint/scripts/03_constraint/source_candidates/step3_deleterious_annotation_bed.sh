#!/bin/bash
#SBATCH --job-name=functional_intersect
#SBATCH --output=logs/functional_intersect_%A_%a.log
#SBATCH --error=logs/functional_intersect_%A_%a.err
#SBATCH --cpus-per-task=8
#SBATCH --array=1-6%6

set -euo pipefail

############################################################
# 0. Singularity / TMP
############################################################
mkdir -p logs

WORK_TMP_DIR="$(pwd)/singularity_tmp_${SLURM_JOB_ID}_${SLURM_ARRAY_TASK_ID}"
export SINGULARITY_TMPDIR="$WORK_TMP_DIR"
export TMPDIR="$WORK_TMP_DIR"
mkdir -p "$WORK_TMP_DIR"

cleanup() {
    rm -rf "$WORK_TMP_DIR"
}
trap cleanup EXIT

############################################################
# 1. Array 映射：GERP × subgenome
############################################################
GERP_CLASSES=("gt2" "gt4" "gt6")
SUBGENOMES=("pedC" "pedD")

IDX=$((SLURM_ARRAY_TASK_ID - 1))
GERP_IDX=$((IDX / 2))
SUB_IDX=$((IDX % 2))

GERP=${GERP_CLASSES[$GERP_IDX]}
SUB=${SUBGENOMES[$SUB_IDX]}

GERP_DIR="gerp_${GERP}"
INPUT_GERP_BED="${GERP_DIR}/${SUB}_${GERP}_gerp_regions.bed"

echo "=== Processing ${SUB} ${GERP} ==="

if [ ! -s "$INPUT_GERP_BED" ]; then
    echo "ERROR: missing or empty $INPUT_GERP_BED"
    exit 1
fi

echo "GERP regions: $(wc -l < "$INPUT_GERP_BED")"

############################################################
# 2. 功能区 BED 目录
############################################################
FUNCTIONAL_DIR="2.1.constrained_category"

if [ ! -d "$FUNCTIONAL_DIR" ]; then
    echo "ERROR: functional directory not found"
    exit 1
fi

FUNCTIONAL_BEDS=($(ls "$FUNCTIONAL_DIR"/*.bed | sort))

if [ ${#FUNCTIONAL_BEDS[@]} -eq 0 ]; then
    echo "ERROR: no functional BEDs found"
    exit 1
fi

############################################################
# 3. 输出目录
############################################################
OUTDIR="${GERP_DIR}/functional_analysis_${SUB}"
mkdir -p "$OUTDIR"

############################################################
# 4. 主循环：GERP × 功能区
############################################################
for FUNC_BED in "${FUNCTIONAL_BEDS[@]}"; do
    FUNC_NAME=$(basename "$FUNC_BED" .bed)

    echo "---- ${FUNC_NAME} ----"

    OUT_OVERLAP="${OUTDIR}/${SUB}_${GERP}_${FUNC_NAME}_overlap.bed"
    OUT_GERP="${OUTDIR}/${SUB}_${GERP}_${FUNC_NAME}_gerp_regions.bed"
    OUT_FUNC="${OUTDIR}/${SUB}_${GERP}_${FUNC_NAME}_func_regions.bed"
    OUT_DETAIL="${OUTDIR}/${SUB}_${GERP}_${FUNC_NAME}_detailed.bed"

    # 1. GERP ∩ FUNC（保留 GERP）
    bedtools intersect -a "$INPUT_GERP_BED" -b "$FUNC_BED" -wa > "$OUT_GERP" || true
    [ -s "$OUT_GERP" ] || rm -f "$OUT_GERP"

    # 2. FUNC ∩ GERP（保留 FUNC）
    bedtools intersect -a "$FUNC_BED" -b "$INPUT_GERP_BED" -wa > "$OUT_FUNC" || true
    [ -s "$OUT_FUNC" ] || rm -f "$OUT_FUNC"

    # 3. 实际 overlap 区间
    bedtools intersect -a "$INPUT_GERP_BED" -b "$FUNC_BED" > "$OUT_OVERLAP" || true
    [ -s "$OUT_OVERLAP" ] || rm -f "$OUT_OVERLAP"

    # 4. 详细 overlap（-wa -wb）
    bedtools intersect -a "$INPUT_GERP_BED" -b "$FUNC_BED" -wa -wb > "$OUT_DETAIL" || true
    [ -s "$OUT_DETAIL" ] || rm -f "$OUT_DETAIL"
done

############################################################
# 5. 汇总统计
############################################################
SUMMARY="${OUTDIR}/${SUB}_${GERP}_summary.tsv"

echo -e "Region\tOverlap_intervals\tGERP_regions\tFUNC_regions\tOverlap_bp\tGERP_coverage(%)\tFUNC_coverage(%)" \
> "$SUMMARY"

GERP_TOTAL_LEN=$(awk '{s+=$3-$2} END{print s}' "$INPUT_GERP_BED")

for FUNC_BED in "${FUNCTIONAL_BEDS[@]}"; do
    FUNC_NAME=$(basename "$FUNC_BED" .bed)

    OVL="${OUTDIR}/${SUB}_${GERP}_${FUNC_NAME}_overlap.bed"
    GERP_BED="${OUTDIR}/${SUB}_${GERP}_${FUNC_NAME}_gerp_regions.bed"
    FUNC_OUT="${OUTDIR}/${SUB}_${GERP}_${FUNC_NAME}_func_regions.bed"

    if [ -s "$OVL" ]; then
        OVL_N=$(wc -l < "$OVL")
        OVL_LEN=$(awk '{s+=$3-$2} END{print s}' "$OVL")
        GERP_N=$( [ -s "$GERP_BED" ] && wc -l < "$GERP_BED" || echo 0 )
        FUNC_N=$( [ -s "$FUNC_OUT" ] && wc -l < "$FUNC_OUT" || echo 0 )
        FUNC_LEN=$(awk '{s+=$3-$2} END{print s}' "$FUNC_BED")

        GERP_COV=$(awk -v a="$OVL_LEN" -v b="$GERP_TOTAL_LEN" 'BEGIN{printf "%.4f", (b>0?a/b*100:0)}')
        FUNC_COV=$(awk -v a="$OVL_LEN" -v b="$FUNC_LEN" 'BEGIN{printf "%.4f", (b>0?a/b*100:0)}')

        echo -e "${FUNC_NAME}\t${OVL_N}\t${GERP_N}\t${FUNC_N}\t${OVL_LEN}\t${GERP_COV}\t${FUNC_COV}" \
        >> "$SUMMARY"
    else
        echo -e "${FUNC_NAME}\t0\t0\t0\t0\t0\t0" >> "$SUMMARY"
    fi
done

echo "=== DONE ${SUB} ${GERP} ==="
echo "Summary: $SUMMARY"
