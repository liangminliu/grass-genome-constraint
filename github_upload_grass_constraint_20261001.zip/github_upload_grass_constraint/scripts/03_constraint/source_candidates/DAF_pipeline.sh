#!/bin/bash
#SBATCH -J DAF_pipeline
#SBATCH -p parallel
#SBATCH -N 1
#SBATCH -n 1
#SBATCH --cpus-per-task=8
#SBATCH -o DAF_pipeline.%j.out
#SBATCH -e DAF_pipeline.%j.err

###############################################################################
# Pipeline: VCF → merged → prob-ancestral → category-SFS → DAF (bin=0.05)
#
# Scientific goal:
# Compare unfolded derived allele frequency (DAF) spectra across functional
# classes (syn, tolerant nonsyn, constrained, high-confidence deleterious)
# using a unified probabilistic ancestral inference.
###############################################################################

set -euo pipefail


###############################################################################
# Step 0. Prepare BED files for SNP functional categories
###############################################################################

echo "[Step 0] Preparing BED files for SNP categories"

mkdir -p bed_classes

# 0.1 Neutral sites: all synonymous SNPs
awk '{OFS="\t"; print $1,$2-1,$2}' all_SYNONYMOUS.xls \
  | sort -k1,1 -k2,2n > bed_classes/syn.bed

# 0.2 Tolerant nonsynonymous SNPs (SIFT >= 0.05)
awk '{OFS="\t"; print $1,$2-1,$2}' TOLERATED_NONSYNONYMOUS.xls \
  | sort -k1,1 -k2,2n > bed_classes/tolerant.bed

# 0.3 Constrained sites (GERP > 4)
cat pedC_gt4_snps.bed pedD_gt4_snps.bed \
  | sort -k1,1 -k2,2n > bed_classes/gerp4.bed

# 0.4 High-confidence deleterious sites (GERP > 4 & SIFT < 0.05)
sort -k1,1 -k2,2n gerp4_sift005_bed/pedCD_GERPgt4_SIFTlt005.merged.bed \
  > bed_classes/hiconf.bed


###############################################################################
# Step 1. Subset merged SNP table by functional category
###############################################################################

echo "[Step 1] Subsetting merged SNP tables by category"

mkdir -p subset sfs

CLASSES=("syn" "tolerant" "gerp4" "hiconf")

for CLASS in "${CLASSES[@]}"; do
  mkdir -p subset/${CLASS} sfs/${CLASS}
done


###############################################################################
# Step 2. Compute unfolded SFS using probabilistic ancestral states
###############################################################################

echo "[Step 2] Computing unfolded SFS per chromosome and class"

NALLELE=124   # 2N

for CLASS in "${CLASSES[@]}"; do
  for CHR in Ped{01..12}{C,D} Ped09X; do
    MERGED=merged_results/${CHR}.merged.txt
    ANC=anc/${CHR}.ancestral.prob0.6.bed

    [[ -f ${MERGED} && -f ${ANC} ]] || continue

    bedtools intersect -wa -u \
      -a ${MERGED} \
      -b bed_classes/${CLASS}.bed \
      > subset/${CLASS}/${CHR}.${CLASS}.merged.txt

    python3 build_unfolded_sfs.py \
      --merged subset/${CLASS}/${CHR}.${CLASS}.merged.txt \
      --ancestral ${ANC} \
      --Nallele ${NALLELE} \
      --out sfs/${CLASS}/${CHR}.${CLASS}.sfs.tsv \
      --skip_na
  done
done


###############################################################################
# Step 3. Merge per-chromosome SFS into genome-wide SFS
###############################################################################

echo "[Step 3] Merging per-chromosome SFS"

for CLASS in "${CLASSES[@]}"; do
  echo -e "derived_count\tsites" > sfs/genome.${CLASS}.sfs.tsv

  awk '
    FNR==1 { next }      # skip header of EACH file
    NF==2 {
      sum[$1] += $2
    }
    END {
      for (k in sum) {
        print k "\t" sum[k]
      }
    }
  ' sfs/${CLASS}/Ped*.${CLASS}.sfs.tsv \
    | sort -n >> sfs/genome.${CLASS}.sfs.tsv
done


###############################################################################
# Step 4. Convert unfolded SFS to DAF distribution (bin = 0.05)
###############################################################################

echo "[Step 4] Converting SFS to DAF distributions"

mkdir -p daf

for CLASS in "${CLASSES[@]}"; do
  python3 << EOF
import pandas as pd

N = ${NALLELE}
BIN = 0.05

sfs = pd.read_csv(
    "sfs/genome.${CLASS}.sfs.tsv",
    sep="\t"
)

sfs["derived_count"] = pd.to_numeric(sfs["derived_count"])
sfs["sites"] = pd.to_numeric(sfs["sites"])

assert sfs["derived_count"].between(0, N).all()

# Derived allele frequency
sfs["daf"] = sfs["derived_count"] / N

# Bin
sfs["bin"] = (sfs["daf"] // BIN) * BIN

# Prevent 1.0 overflow
sfs.loc[sfs["bin"] >= 1.0, "bin"] = 1.0 - BIN

# Normalize to proportion
daf = (
    sfs.groupby("bin", as_index=False)["sites"]
    .sum()
)
daf["proportion"] = daf["sites"] / daf["sites"].sum()

daf[["bin", "proportion"]].to_csv(
    "daf/genome.${CLASS}.daf.tsv",
    sep="\t",
    index=False
)
EOF
done

echo "[Pipeline finished successfully]"
