#!/bin/bash
#BSUB -J Zmay_structure_v2
#BSUB -q Q64C1T_X4
#BSUB -n 4
#BSUB -o logs/Zmay_structure_v2.%J.out
#BSUB -e logs/Zmay_structure_v2.%J.err

set -euo pipefail

mkdir -p logs results

############################################
# 0. Input files
############################################
PY_SCRIPT="genome_structure_final_v2.py"

GENE="../genes_sorted.bed"
EXON="../exons_sorted.bed"
CDS="../CDS_sorted.bed"
PROMOTER="../promoter_sorted.bed"
TE="../all_TE_merged_detailed.bed"
UTR5="../five_prime_UTR_sorted.bed"
UTR3="../three_prime_UTR_sorted.bed"
UPDOWN5K="../updown5k_sorted.bed"
CHROM_SIZES="../Zmay.chrom_sizes.txt"

OUT_PREFIX="results/Zmay_structure_v2"

############################################
# 1. Sanity check
############################################
echo "[INFO] Job started at: $(date)"
echo "[INFO] Host: $(hostname)"
echo "[INFO] Workdir: $(pwd)"
echo "[INFO] Python: $(command -v python3 || true)"

for f in \
    "${PY_SCRIPT}" \
    "${GENE}" \
    "${EXON}" \
    "${CDS}" \
    "${PROMOTER}" \
    "${TE}" \
    "${UTR5}" \
    "${UTR3}" \
    "${UPDOWN5K}" \
    "${CHROM_SIZES}"
do
    if [[ ! -s "${f}" ]]; then
        echo "[ERROR] Missing or empty file: ${f}" >&2
        exit 1
    fi
done

echo "[INFO] Input files checked."

############################################
# 2. Run
############################################
python3 "${PY_SCRIPT}" \
    --gene "${GENE}" \
    --exon "${EXON}" \
    --cds "${CDS}" \
    --promoter "${PROMOTER}" \
    --te "${TE}" \
    --utr5 "${UTR5}" \
    --utr3 "${UTR3}" \
    --updown5k "${UPDOWN5K}" \
    --chrom-sizes "${CHROM_SIZES}" \
    --out "${OUT_PREFIX}"

############################################
# 3. Check outputs
############################################
for f in \
    "${OUT_PREFIX}.all_metrics.tsv" \
    "${OUT_PREFIX}.te_subclass.tsv" \
    "${OUT_PREFIX}.qc.tsv"
do
    if [[ ! -s "${f}" ]]; then
        echo "[ERROR] Output not generated: ${f}" >&2
        exit 1
    fi
done

echo "[INFO] Output summary:"
ls -lh \
    "${OUT_PREFIX}.all_metrics.tsv" \
    "${OUT_PREFIX}.te_subclass.tsv" \
    "${OUT_PREFIX}.qc.tsv"

echo "[INFO] Preview metrics:"
head -20 "${OUT_PREFIX}.all_metrics.tsv" || true

echo "[INFO] Preview QC:"
cat "${OUT_PREFIX}.qc.tsv" || true

echo "[INFO] Job finished at: $(date)"