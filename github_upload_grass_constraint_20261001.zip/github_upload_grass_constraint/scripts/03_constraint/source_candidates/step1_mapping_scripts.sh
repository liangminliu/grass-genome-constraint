#!/bin/bash

### 全局变量定义
ref="../01.ref/Zmay.fa"
fastq_dir="../data/fastq"
bam_dir="step3_MarkDuplicates"
software_sif="../software/Reseq_genek.sif"
tmp_dir="./tmp"
NODES=(cu13 cu14 cu15 cu16 cu17 cu18 cu19 cu20 cu01 cu02 cu03 cu04 cu05 cu06 cu07 cu08 cu09 cu10 cu21 cu22 cu23 cu24 cu25 cu26 cu27)

mkdir -p step1_bwa_results step2_add.filter step3_MarkDuplicates \
         step4.bam_stat haplotype_scripts genotyping_scripts ${tmp_dir}
mkdir -p mapping_scripts logs

i=0

while read srr sample; do
    fq1="${fastq_dir}/${sample}_1.fastq.gz"
    fq2="${fastq_dir}/${sample}_2.fastq.gz"
    node=${NODES[$i]}
    ((i++))

    script="mapping_scripts/mapping.${sample}.sh"

    cat > $script <<EOF
#!/usr/bin/env bash
#SBATCH -p parallel
#SBATCH --job-name=mapping_${sample}
#SBATCH --output=logs/mapping_${sample}.%J.out
#SBATCH --error=logs/mapping_${sample}.%J.err
#SBATCH --nodelist=${node}
#SBATCH --cpus-per-task=10

set -euo pipefail

ref="${ref}"
software_sif="${software_sif}"

fq1="${fq1}"
fq2="${fq2}"

out_bam="step1_bwa_results/${sample}.sort.bam"
filtered_bam="step2_add.filter/${sample}.filter.sort.bam"
rmdup_bam="${bam_dir}/${sample}.sort.rmdup.bam"
dup_metrics="${bam_dir}/${sample}.marked_dup_metrics.txt"

# ================================
# Step 1: BWA 比对 + Sort
# ================================
if [ ! -f "\${out_bam}" ]; then
    singularity exec \${software_sif} bwa mem -t 10 -R '@RG\tID:${sample}\tSM:${sample}\tPL:illumina' \${ref} \
        \${fq1} \${fq2} 2>logs/${sample}.bwa.log | \
    singularity exec \${software_sif} samtools sort -@ 10 -m 20G -o \${out_bam} -
fi

# ================================
# Step 2: 筛选
# ================================
if [ ! -f "\${filtered_bam}" ]; then
    singularity exec \${software_sif} samtools view -b -h -F 4 -q 20 \${out_bam} > \${filtered_bam}
fi

# ================================
# Step 3: 去重复
# ================================
if [ ! -f "\${rmdup_bam}" ]; then
    singularity exec \${software_sif} java -Xms32g -Xmx60g -jar /opt/picard.jar \
        MarkDuplicates -I \${filtered_bam} -O \${rmdup_bam} \
        -CREATE_INDEX true -REMOVE_DUPLICATES true -M \${dup_metrics}
fi

# ================================
# Step 4: 统计
# ================================
singularity exec \${software_sif} samtools flagstat \${out_bam} > step4.bam_stat/${sample}.flagstat
singularity exec \${software_sif} samtools coverage \${out_bam} > step4.bam_stat/${sample}.coverage

singularity exec \${software_sif} samtools flagstat \${rmdup_bam} > step4.bam_stat/${sample}.rmdup.flagstat
singularity exec \${software_sif} samtools coverage \${rmdup_bam} > step4.bam_stat/${sample}.rmdup.coverage
EOF

    chmod +x $script

done < sra1.list

# 生成一个自动提交所有任务的脚本
echo "#!/bin/bash" > submit_all.sh
ls mapping_scripts/*.sh | while read f; do echo "sbatch $f"; done >> submit_all.sh
chmod +x submit_all.sh

echo "脚本生成完毕！运行  ./submit_all.sh  即可批量提交所有 mapping 任务。"
