#!/bin/bash
#SBATCH --job-name=prepare_genome
#SBATCH --output=prepare_genome.%A_%a.out
#SBATCH --error=prepare_genome.%A_%a.err
#SBATCH --cpus-per-task=20
#SBATCH --partition=parallel

## 编辑config文件
echo  "# my own genome, version Zmay
Zmay.genome : Zmay
" >> snpEff.config


 singularity exec  ~/liuliangmin/4.may/software/Reseq_genek.sif  java -jar /opt/snpEff/snpEff.jar build -c ./snpEff.config  -gff3 -v Zmay

## 查看构建好的数据库
 singularity exec  ~/liuliangmin/4.may/software/Reseq_genek.sif  -jar /opt/snpEff/snpEff.jar dump -c ./snpEff.config Zmay