#!/bin/bash
#SBATCH --job-name=TE_analysis
#SBATCH --output=TE_analysis_%j.out
#SBATCH --error=TE_analysis_%j.err
#SBATCH --nodes=1
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=10
#SBATCH --partition=parallel

echo "Starting TE analysis at $(date)"
echo "Working directory: $(pwd)"

# Read chromosome IDs from file
CHROMOSOMES=($(cat chr_ids.txt))

# Step 1: Convert GFF to BED and filter chromosome-level TEs
echo "Step 1: Converting GFF to BED and filtering chromosome-level TEs..."
awk -v chr_str="${CHROMOSOMES[*]}" '
BEGIN {
    split(chr_str, chrs, " ")
    for (i in chrs) valid_chr[chrs[i]]
    OFS="\t"
}
!/^#/ && ($1 in valid_chr) {print $1,$4-1,$5,$9,$6,$7}' Zm-B73-REFERENCE-NAM-5.0.TE.gff3 > all_TE.bed
echo "Generated all_TE.bed with $(wc -l < all_TE.bed) chromosome-level entries"

# Step 2: Sort and merge overlapping regions
echo "Step 2: Sorting and merging overlapping regions..."
bedtools sort -i all_TE.bed > all_TE_sorted.bed
bedtools merge -i all_TE_sorted.bed > all_TE_merged.bed
echo "Generated all_TE_merged.bed with $(wc -l < all_TE_merged.bed) non-overlapping regions"

# Step 3: Generate comprehensive statistics
echo "Step 3: Generating comprehensive statistics..."
{
    # Header
    echo "TE Analysis Statistics"
    echo "======================"
    echo ""
    
    # Basic counts
    original_count=$(wc -l < all_TE.bed)
    merged_count=$(wc -l < all_TE_merged.bed)
    echo "Original TE elements: $original_count"
    echo "Non-overlapping regions: $merged_count"
    echo "Merge efficiency: $(awk -v o=$original_count -v m=$merged_count 'BEGIN{printf "%.1f%%", (o-m)/o*100}') reduction"
    echo ""
    
    # Length statistics
    awk '{
        len = $3-$2
        sum += len
        if (len < 100) bin["<100bp"]++
        else if (len < 500) bin["100-500bp"]++
        else if (len < 1000) bin["500-1000bp"]++
        else if (len < 5000) bin["1-5kb"]++
        else if (len < 10000) bin["5-10kb"]++
        else bin[">10kb"]++
    } END {
        print "Length Statistics:"
        print "------------------"
        printf "Total length: %\047d bp\n", sum
        printf "Average length: %.1f bp\n", sum/NR
        print ""
        print "Length Distribution:"
        for (b in bin) {
            printf "%-12s: %6d (%.1f%%)\n", b, bin[b], (bin[b]/NR)*100
        }
    }' all_TE_merged.bed
    
    # TE type distribution
    echo ""
    echo "TE Type Distribution:"
    echo "--------------------"
    awk -F'#' '$2 != "" {type[$2]++} END {
        for (t in type) {
            printf "%-15s: %6d (%.1f%%)\n", t, type[t], (type[t]/NR)*100
        }
    }' all_TE.bed | sort -k2,2nr
    
    # Chromosome-wise summary
    echo ""
    echo "Chromosome-wise Summary:"
    echo "-----------------------"
    for chr in "${CHROMOSOMES[@]}"; do
        awk -v chr="$chr" '$1 == chr {sum += $3-$2} END {
            if (sum > 0) printf "%s: %\047d bp\n", chr, sum
        }' all_TE_merged.bed
    done
    
} > TE_length_stats.txt

# Step 4: Generate detailed merge info (optional)
echo "Step 4: Generating detailed merge information..."
bedtools merge -i all_TE_sorted.bed -c 4 -o count,collapse > all_TE_merged_detailed.bed

# Final summary
echo ""
echo "Analysis completed at $(date)"
echo ""
echo "Generated files:"
echo "- all_TE.bed: Filtered TE elements"
echo "- all_TE_sorted.bed: Sorted TE elements"
echo "- all_TE_merged.bed: Merged non-overlapping regions"
echo "- all_TE_merged_detailed.bed: Detailed merge information"
echo "- TE_length_stats.txt: Comprehensive statistics"
echo ""
echo "For downstream analysis:"
echo "# Find conserved sites overlapping with TEs:"
echo "bedtools intersect -a conserved_sites.bed -b all_TE_merged.bed -wa -wb > conserved_in_TE.bed"
echo ""
echo "# Find conserved sites NOT in TEs:"
echo "bedtools intersect -a conserved_sites.bed -b all_TE_merged.bed -v > conserved_nonTE.bed"