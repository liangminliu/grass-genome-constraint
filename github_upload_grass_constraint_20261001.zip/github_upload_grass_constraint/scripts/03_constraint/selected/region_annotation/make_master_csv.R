library(readr)
library(dplyr)
library(stringr)
library(tidyr)

# 1. Read original TSV (your current file)
raw <- read_tsv(
  "ped.constrain.tsv",
  col_types = cols(.default = "c"),
  trim_ws = TRUE
)

# 2. Clean and standardize
master <- raw |>
  rename(
    threshold_raw = `Threshold of evolutionary constrained site`,
    region_raw    = `Region category`,
    constrained   = `No. of constrained sites`
  ) |>
  mutate(
    constrained = as.numeric(str_remove_all(constrained, ",")),
    threshold_raw = str_trim(threshold_raw),

    threshold = case_when(
      str_detect(threshold_raw, "GERP>0") ~ "GERP>0",
      str_detect(threshold_raw, "GERP>2") ~ "GERP>2",
      str_detect(threshold_raw, "GERP>4") ~ "GERP>4",
      str_detect(threshold_raw, "GERP>6") ~ "GERP>6",
      TRUE ~ NA_character_
    ),

    subgenome = case_when(
      str_detect(region_raw, "subgenome C") ~ "C",
      str_detect(region_raw, "subgenome D") ~ "D",
      TRUE ~ NA_character_
    ),

    region = region_raw
  ) |>
  fill(subgenome, .direction = "down") |>
  filter(
    !region %in% c(
      "subgenome C",
      "subgenome D",
      "CDS",
      "Promoter"
    )
  ) |>
  select(threshold, subgenome, region, constrained) |>
  arrange(threshold, subgenome)

# 3. Write master CSV
write_csv(master, "gerp_constrained_master.csv")
