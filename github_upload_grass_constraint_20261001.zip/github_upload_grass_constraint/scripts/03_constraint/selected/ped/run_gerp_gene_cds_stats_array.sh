#!/bin/bash
#SBATCH --job-name=ped_core_GERP
#SBATCH --partition=parallel
#SBATCH --nodes=1
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=10
#SBATCH --array=1-4
#SBATCH --output=logs/ped_core_GERP_%A_%a.out
#SBATCH --error=logs/ped_core_GERP_%A_%a.err

set -euo pipefail
module load bedtools 2>/dev/null || true

############################################################
# 0. Inputs (fixed as you requested)
############################################################
PAN="core_5sp_1to1.SG.pan"
INTERSECT_ROOT="intersect_results"
GENE_BED="genes.bed"
CDS_BED="CDS_jcvi.bed"

OUT_ROOT="ped_target_gene_CDS_GERP_stats"
mkdir -p logs "${OUT_ROOT}"

############################################################
# 1. Thresholds
############################################################
CLASSES=("gerp_gt0" "gerp_gt2" "gerp_gt4" "gerp_gt6")

IDX=$((SLURM_ARRAY_TASK_ID-1))
if [[ ${IDX} -lt 0 || ${IDX} -ge ${#CLASSES[@]} ]]; then
  echo "[ERROR] Bad SLURM_ARRAY_TASK_ID=${SLURM_ARRAY_TASK_ID}" >&2
  exit 1
fi
CLASS="${CLASSES[$IDX]}"
echo "[INFO] Threshold = ${CLASS}"

############################################################
# 2. Subgenomes
############################################################
for SUB in pedC pedD; do
  echo "[INFO] Subgenome = ${SUB}"

  OUT_DIR="${OUT_ROOT}/${CLASS}/${SUB}"
  BED_DIR="${OUT_DIR}/bed_files"
  STAT_DIR="${OUT_DIR}/stats"
  mkdir -p "${BED_DIR}" "${STAT_DIR}"

  ##########################################################
  # 3. core gene list from PAN (pedC col7, pedD col8)
  ##########################################################
  if [[ "${SUB}" == "pedC" ]]; then COL=7; else COL=8; fi
  CORE_GENE_LIST="${OUT_DIR}/core_${SUB}_gene_ids.txt"

  awk -v c=${COL} 'BEGIN{FS="\t"}{
    g=$c
    sub(/^ped[CD]_/, "", g)
    print g
  }' "${PAN}" | sort -u > "${CORE_GENE_LIST}"

  echo "[INFO] core genes = $(wc -l < "${CORE_GENE_LIST}")"

  ##########################################################
  # 4. core gene / core CDS bed
  #    CDS gene_id unify: remove ":..." then keep before first "."
  ##########################################################
  CORE_GENE_BED="${BED_DIR}/core_${SUB}_genes.bed"
  CORE_CDS_BED="${BED_DIR}/core_${SUB}_CDS.bed"

  awk 'BEGIN{OFS="\t"}{print $1,$2,$3,$4}' "${GENE_BED}" \
  | awk 'NR==FNR{a[$1]=1;next} a[$4]' "${CORE_GENE_LIST}" - \
  > "${CORE_GENE_BED}"

  awk 'BEGIN{OFS="\t"}{
    gene=$4
    sub(/:.*/, "", gene)
    sub(/\..*/, "", gene)
    print $1,$2,$3,gene
  }' "${CDS_BED}" \
  | awk 'NR==FNR{a[$1]=1;next} a[$4]' "${CORE_GENE_LIST}" - \
  > "${CORE_CDS_BED}"

  ##########################################################
  # 5. Genome-wide conserved sites (from INTERSECT_ROOT)
  ##########################################################
  GENE_GERP_ALL="${INTERSECT_ROOT}/${CLASS}/${SUB}_*.genes.intersect.bed"
  CDS_GERP_ALL="${INTERSECT_ROOT}/${CLASS}/${SUB}_*.CDS_jcvi.intersect.bed"

  # basic existence check (avoid silent empty)
  if ! ls ${GENE_GERP_ALL} >/dev/null 2>&1; then
    echo "[ERROR] Missing ${GENE_GERP_ALL}" >&2
    exit 1
  fi
  if ! ls ${CDS_GERP_ALL} >/dev/null 2>&1; then
    echo "[ERROR] Missing ${CDS_GERP_ALL}" >&2
    exit 1
  fi

  ##########################################################
  # 6. Core conserved sites = genome-wide sites ∩ core feature bed
  ##########################################################
  CORE_GENE_CONS="${BED_DIR}/core_${SUB}_gene_conserved_sites.bed"
  CORE_CDS_CONS="${BED_DIR}/core_${SUB}_CDS_conserved_sites.bed"

  bedtools intersect -wa -a ${GENE_GERP_ALL} -b "${CORE_GENE_BED}" \
    > "${CORE_GENE_CONS}"

  bedtools intersect -wa -a ${CDS_GERP_ALL} -b "${CORE_CDS_BED}" \
    > "${CORE_CDS_CONS}"

  ##########################################################
  # 7. Gene-level site bed (4-col): chr start end gene_id
  ##########################################################
  CORE_GENE_SITE_BED="${BED_DIR}/core_${SUB}_gene_sites.gene.bed"
  CORE_CDS_SITE_BED="${BED_DIR}/core_${SUB}_CDS_sites.gene.bed"

  # gene: appended feature gene_id sits at (NF-2)
  awk 'BEGIN{OFS="\t"}{
    gene=$(NF-2)
    print $1,$2,$3,gene
  }' "${CORE_GENE_CONS}" > "${CORE_GENE_SITE_BED}"

  # CDS: appended CDS id at (NF-2) like Ped01Cg00030.1:CDS:1
  awk 'BEGIN{OFS="\t"}{
    gene=$(NF-2)
    sub(/:.*/, "", gene)
    sub(/\..*/, "", gene)
    print $1,$2,$3,gene
  }' "${CORE_CDS_CONS}" > "${CORE_CDS_SITE_BED}"

  ##########################################################
  # 8. Length stats (TAB output guaranteed)
  ##########################################################
  # gene length (sum all intervals per gene)
  awk 'BEGIN{OFS="\t"}{len[$4]+=$3-$2} END{for(g in len) print g,len[g]}' \
    "${CORE_GENE_BED}" | sort -k1,1 > "${STAT_DIR}/gene_length.tsv"

  # CDS union length per gene (properly prints EVERY gene)
  sort -k4,4 -k1,1 -k2,2n "${CORE_CDS_BED}" \
  | awk 'BEGIN{OFS="\t"}
    NR==1{
      cg=$4; cchr=$1; cs=$2; ce=$3; sum=0; next
    }
    {
      g=$4; chr=$1; s=$2; e=$3
      if(g!=cg || chr!=cchr){
        sum += (ce - cs)
        print cg, sum
        cg=g; cchr=chr; cs=s; ce=e; sum=0
        next
      }
      if(s <= ce){
        if(e > ce) ce=e
      } else {
        sum += (ce - cs)
        cs=s; ce=e
      }
    }
    END{
      if(NR>0){
        sum += (ce - cs)
        print cg, sum
      }
    }' \
  | sort -k1,1 > "${STAT_DIR}/cds_length.tsv"

  ##########################################################
  # 9. Site counts (TAB output guaranteed; optional 1bp dedup)
  ##########################################################
  # gene sites (dedup by chr,start,end,gene)
  awk 'BEGIN{OFS="\t"}{
    key=$1"\t"$2"\t"$3"\t"$4
    if(!seen[key]++) c[$4]++
  } END{for(g in c) print g,c[g]}' \
    "${CORE_GENE_SITE_BED}" | sort -k1,1 > "${STAT_DIR}/gene_site_count.tsv"

  # CDS sites (dedup)
  awk 'BEGIN{OFS="\t"}{
    key=$1"\t"$2"\t"$3"\t"$4
    if(!seen[key]++) c[$4]++
  } END{for(g in c) print g,c[g]}' \
    "${CORE_CDS_SITE_BED}" | sort -k1,1 > "${STAT_DIR}/cds_site_count.tsv"

  ##########################################################
  # 10. Merge per-gene stats (join requires TAB-delimited & sorted)
  ##########################################################
  join -t $'\t' -a 1 -e 0 -o 1.1,1.2,2.2 \
    "${STAT_DIR}/gene_length.tsv" "${STAT_DIR}/cds_length.tsv" \
    > "${STAT_DIR}/tmp_len.tsv"

  join -t $'\t' -a 1 -e 0 -o 1.1,1.2,2.2 \
    "${STAT_DIR}/gene_site_count.tsv" "${STAT_DIR}/cds_site_count.tsv" \
    > "${STAT_DIR}/tmp_site.tsv"

  join -t $'\t' -a 1 -e 0 \
    "${STAT_DIR}/tmp_len.tsv" "${STAT_DIR}/tmp_site.tsv" \
  | awk 'BEGIN{
      OFS="\t";
      print "gene_id","gene_len","cds_len","gene_sites","gene_pct","cds_sites","cds_pct"
    }{
      gid=$1
      gl=$2+0; cl=$3+0
      gs=$4+0; cs=$5+0
      gp=(gl>0)?gs/gl*100:0
      cp=(cl>0)?cs/cl*100:0
      printf "%s\t%d\t%d\t%d\t%.6f\t%d\t%.6f\n", gid, gl, cl, gs, gp, cs, cp
    }' \
  > "${OUT_DIR}/per_gene_stats.tsv"

  rm -f "${STAT_DIR}/tmp_len.tsv" "${STAT_DIR}/tmp_site.tsv"

  ##########################################################
  # 11. Minimal sanity prints
  ##########################################################
  echo "[INFO] ${SUB} ${CLASS} gene_sites lines: $(wc -l < "${CORE_GENE_SITE_BED}")"
  echo "[INFO] ${SUB} ${CLASS} cds_sites  lines: $(wc -l < "${CORE_CDS_SITE_BED}")"
  echo "[INFO] ${SUB} ${CLASS} gene_site_count entries: $(wc -l < "${STAT_DIR}/gene_site_count.tsv")"
  echo "[INFO] ${SUB} ${CLASS} cds_site_count  entries: $(wc -l < "${STAT_DIR}/cds_site_count.tsv")"

done

echo "[INFO] DONE ${CLASS}"
