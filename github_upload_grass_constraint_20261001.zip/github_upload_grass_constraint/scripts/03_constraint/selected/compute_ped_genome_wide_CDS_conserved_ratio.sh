#!/usr/bin/env bash
set -euo pipefail

BASE_DIR="ped_target_gene_CDS_GERP_stats"
OUT="ped_genome_wide_CDS_conserved_ratio.tsv"

echo -e "species\tsubgenome\tgerp_threshold\tcds_conserved_sites\tcds_length\tcds_conserved_ratio" > "${OUT}"

for TH in gerp_gt2 gerp_gt4 gerp_gt6; do

  ############################################
  # pedC / pedD
  ############################################
  for SG in pedC pedD; do
    FILE="${BASE_DIR}/${TH}/${SG}/per_gene_stats.tsv"

    awk -v th="${TH}" -v sg="${SG}" '
    BEGIN{OFS="\t"; sum_sites=0; sum_len=0}
    NR>1{
      sum_len   += $3   # cds_len
      sum_sites += $6   # cds_sites  ✅ 修正
    }
    END{
      ratio = (sum_len>0)? sum_sites/sum_len : 0
      printf "ped\t%s\t%s\t%d\t%d\t%.8f\n",
             sg, th, sum_sites, sum_len, ratio
    }' "${FILE}" >> "${OUT}"
  done

  ############################################
  # pedC + pedD
  ############################################
  awk -v th="${TH}" '
  BEGIN{OFS="\t"; sum_sites=0; sum_len=0}
  NR>1{
    sum_len   += $3
    sum_sites += $6   # cds_sites  ✅ 修正
  }
  END{
    ratio = (sum_len>0)? sum_sites/sum_len : 0
    printf "ped\tC+D\t%s\t%d\t%d\t%.8f\n",
           th, sum_sites, sum_len, ratio
  }' \
  "${BASE_DIR}/${TH}/pedC/per_gene_stats.tsv" \
  "${BASE_DIR}/${TH}/pedD/per_gene_stats.tsv" \
  >> "${OUT}"

done

echo "[INFO] Wrote ${OUT}"
