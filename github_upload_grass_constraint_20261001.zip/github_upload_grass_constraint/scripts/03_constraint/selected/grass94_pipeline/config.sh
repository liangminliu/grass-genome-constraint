#!/usr/bin/env bash
set -euo pipefail

# Working directory requested by the user
WORKDIR=/ds3200_1/users_root/liuliangmin/workspace/PHD/2.msa/2.2.ped_result_stat/2.2.constrain_stat

# Original 97-species MAF. DO NOT create a separate 94-species MAF.
MAF=/ds3200_1/users_root/liuliangmin/workspace/PHD/2.msa/84sp_ped/97sp_ped.results/roast/roast.maf

# Original 97-tip ROADIES tree.
TREE=/ds3200_1/users_root/liuliangmin/workspace/PHD/run97/treePL/ROADIES_treePL_LSF/01_ROADIES97_rooted_substitutions_per_site.nwk

INTERSECT_DIR=${WORKDIR}/intersect_results
OUTDIR=${WORKDIR}/Ped94_phylogenetic_support_from97MAF
SCRIPT_DIR=$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)

REF_TAXON=ped
# Three non-grass outgroups present in the 97-species MAF/tree.
EXCLUDE_TAXA=Acom,Jeff,Ssto

# Existing GERP thresholds.
THRESHOLDS="0 2 4 6"
MAIN_THRESHOLD=2

# Optional: temporary directory for logs / scratch.
TMPDIR_BASE=${TMPDIR:-${WORKDIR}/tmp_Ped94_support}
mkdir -p "$TMPDIR_BASE"
