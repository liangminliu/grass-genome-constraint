#!/usr/bin/env python3
import argparse
import glob
import gzip
import heapq
import json
import math
import os
import re
import sys
from collections import Counter, defaultdict
from dataclasses import dataclass, field
from pathlib import Path

import numpy as np

VALID_BASES = set("ACGTacgt")
MISSING_U8 = np.uint8(255)


def eprint(*args, **kwargs):
    print(*args, file=sys.stderr, **kwargs)


def open_text(path):
    return gzip.open(path, "rt") if str(path).endswith(".gz") else open(path, "rt")


def taxon_from_src(src):
    # roast MAF source is usually taxon.sequence; keep the prefix as taxon id.
    return src.split(".", 1)[0]


def contig_from_ref_src(src, ref_taxon):
    prefix = ref_taxon + "."
    if src.startswith(prefix):
        return src[len(prefix):]
    # Fallback for MAFs where the reference src itself is the contig.
    return src


@dataclass
class Node:
    name: str = ""
    length: float = 0.0
    children: list = field(default_factory=list)
    parent: object = None
    uid: str = ""
    grass_mask: int = 0
    grass_count: int = 0

    def is_leaf(self):
        return not self.children


def _tokenize_newick(s):
    # Minimal but robust tokenizer for ordinary ROADIES Newick files.
    tokens = []
    i = 0
    buf = []
    in_quote = None
    while i < len(s):
        c = s[i]
        if in_quote:
            if c == in_quote:
                in_quote = None
            else:
                buf.append(c)
            i += 1
            continue
        if c in "'\"":
            in_quote = c
            i += 1
            continue
        if c in "(),:;":
            if buf:
                tokens.append("".join(buf).strip())
                buf = []
            tokens.append(c)
        elif c.isspace():
            if buf:
                tokens.append("".join(buf).strip())
                buf = []
        else:
            buf.append(c)
        i += 1
    if buf:
        tokens.append("".join(buf).strip())
    return [t for t in tokens if t != ""]


def parse_newick(path):
    text = Path(path).read_text().strip()
    toks = _tokenize_newick(text)
    idx = 0

    def parse_subtree():
        nonlocal idx
        if toks[idx] == "(":
            idx += 1
            children = []
            while True:
                child = parse_subtree()
                children.append(child)
                if toks[idx] == ",":
                    idx += 1
                    continue
                if toks[idx] == ")":
                    idx += 1
                    break
                raise ValueError(f"Unexpected Newick token {toks[idx]!r} at {idx}")
            name = ""
            if idx < len(toks) and toks[idx] not in [",", ")", ":", ";"]:
                name = toks[idx]
                idx += 1
            length = 0.0
            if idx < len(toks) and toks[idx] == ":":
                idx += 1
                length = float(toks[idx])
                idx += 1
            node = Node(name=name, length=length, children=children)
            for ch in children:
                ch.parent = node
            return node
        else:
            name = toks[idx]
            idx += 1
            length = 0.0
            if idx < len(toks) and toks[idx] == ":":
                idx += 1
                length = float(toks[idx])
                idx += 1
            return Node(name=name, length=length)

    root = parse_subtree()
    if idx < len(toks) and toks[idx] == ";":
        idx += 1
    if idx != len(toks):
        raise ValueError(f"Unparsed Newick tokens remain at index {idx}")
    return root


def walk_nodes(root):
    stack = [root]
    while stack:
        n = stack.pop()
        yield n
        stack.extend(reversed(n.children))


def assign_uids(root):
    internal_i = 1
    leaf_i = 1
    for n in walk_nodes(root):
        if n.is_leaf():
            n.uid = n.name or f"leaf_{leaf_i}"
            leaf_i += 1
        else:
            if n.name:
                n.uid = n.name
            else:
                n.uid = f"N{internal_i:04d}"
            internal_i += 1


def build_tree_context(tree_path, ref_taxon, exclude_taxa):
    root = parse_newick(tree_path)
    assign_uids(root)
    leaves = [n for n in walk_nodes(root) if n.is_leaf()]
    leaf_by_name = {n.name: n for n in leaves}
    if len(leaf_by_name) != len(leaves):
        raise ValueError("Duplicate leaf names detected in tree")
    tree_taxa = set(leaf_by_name)
    exclude = set(exclude_taxa)
    missing_excluded = exclude - tree_taxa
    if missing_excluded:
        raise ValueError(f"Excluded taxa not found in tree: {sorted(missing_excluded)}")
    grass_taxa = sorted(tree_taxa - exclude)
    if ref_taxon not in grass_taxa:
        raise ValueError(f"Reference taxon {ref_taxon!r} not retained among grass taxa")

    bit_of = {t: i for i, t in enumerate(grass_taxa)}

    def annotate(node):
        if node.is_leaf():
            if node.name in bit_of:
                node.grass_mask = 1 << bit_of[node.name]
                node.grass_count = 1
            else:
                node.grass_mask = 0
                node.grass_count = 0
            return node.grass_mask
        m = 0
        for ch in node.children:
            m |= annotate(ch)
        node.grass_mask = m
        node.grass_count = m.bit_count()
        return m

    annotate(root)
    ref_leaf = leaf_by_name[ref_taxon]
    path = []
    d = 0.0
    cur = ref_leaf
    rank = 0
    while cur is not None:
        path.append((rank, cur, d))
        if cur.parent is not None:
            d += cur.length
        cur = cur.parent
        rank += 1

    return {
        "root": root,
        "tree_taxa": sorted(tree_taxa),
        "grass_taxa": grass_taxa,
        "bit_of": bit_of,
        "ref_leaf": ref_leaf,
        "ref_path": path,
    }


def rank_node_for_mask(mask, ref_path):
    # Because ped is included at each target site, the MRCA must lie on the
    # ped->root path. We ignore excluded outgroups when calculating descendant
    # counts, so this is equivalent to using an induced 94-grass tree in memory.
    for rank, node, _dist in ref_path:
        if mask & ~node.grass_mask == 0:
            return rank, node
    rank, node, _ = ref_path[-1]
    return rank, node


def feature_from_filename(path, threshold, subgenome):
    b = os.path.basename(path)
    prefix = f"{subgenome}_gt{threshold}."
    suffix = ".intersect.bed"
    if not (b.startswith(prefix) and b.endswith(suffix)):
        return None
    raw = b[len(prefix):-len(suffix)]
    mapping = {
        "CDS_jcvi": "CDS",
        "ped_chr_0-fold_sites": "0-fold_sites",
        "ped_chr_4-fold_sites": "4-fold_sites",
        "five_prime_UTR": "5UTR",
        "three_prime_UTR": "3UTR",
        "intergenic_final": "intergenic",
        "introns": "intron",
        "promoters": "promoter",
        "updown5k": "updown5k",
        "genes": "gene",
        "TE": "TE",
    }
    return mapping.get(raw, raw)


def sort_key_coord(chrom, start):
    # Chromosome names in these inputs are Ped01C ... Ped12D. Lexical order is
    # already stable, so a string+integer key is sufficient and reproducible.
    return (chrom, int(start))


def iter_unique_bed_sites(path, require_sorted=True, include_source_count=False):
    last = None
    last_key = None
    with open_text(path) as fh:
        for ln, line in enumerate(fh, 1):
            if not line.strip() or line.startswith("#"):
                continue
            f = line.rstrip("\n").split()
            if len(f) < 3:
                continue
            chrom = f[0]
            start = int(f[1])
            key = sort_key_coord(chrom, start)
            if require_sorted and last_key is not None and key < last_key:
                raise RuntimeError(
                    f"Input is not coordinate-sorted: {path}:{ln}: {key} < {last_key}. "
                    "Sort the BED before rerunning."
                )
            last_key = key
            if last == key:
                continue
            last = key
            if include_source_count:
                src_count = None
                if len(f) >= 6:
                    try:
                        src_count = int(float(f[5]))
                    except ValueError:
                        src_count = None
                yield chrom, start, src_count
            else:
                yield chrom, start


def cmd_prepare(args):
    inter = Path(args.intersect_dir)
    out = Path(args.outdir)
    target_dir = out / "targets"
    target_dir.mkdir(parents=True, exist_ok=True)

    gt0_files = []
    for sub in ("pedC", "pedD"):
        pattern = str(inter / "gerp_gt0" / f"{sub}_gt0.*.intersect.bed")
        gt0_files.extend(sorted(glob.glob(pattern)))
    if not gt0_files:
        raise SystemExit(f"No gt0 intersect BEDs found under {inter}")

    streams = []
    for i, p in enumerate(gt0_files):
        it = iter_unique_bed_sites(p, require_sorted=True, include_source_count=False)
        try:
            first = next(it)
        except StopIteration:
            continue
        heapq.heappush(streams, (sort_key_coord(*first), i, first, it, p))

    manifests = []
    current_chrom = None
    current_positions = []
    last_coord = None

    def flush(chrom, arr):
        if chrom is None:
            return
        a = np.asarray(arr, dtype=np.int64)
        p = target_dir / f"{chrom}.positions.npy"
        np.save(p, a)
        manifests.append((chrom, len(a), str(p)))
        eprint(f"[prepare] {chrom}: {len(a):,} unique target sites")

    while streams:
        _key, i, coord, it, p = heapq.heappop(streams)
        chrom, start = coord
        if current_chrom is None:
            current_chrom = chrom
        if chrom != current_chrom:
            flush(current_chrom, current_positions)
            current_chrom = chrom
            current_positions = []
            last_coord = None
        if last_coord != (chrom, start):
            current_positions.append(start)
            last_coord = (chrom, start)
        try:
            nxt = next(it)
            heapq.heappush(streams, (sort_key_coord(*nxt), i, nxt, it, p))
        except StopIteration:
            pass
    flush(current_chrom, current_positions)

    manifest_path = target_dir / "target_manifest.tsv"
    with open(manifest_path, "w") as oh:
        oh.write("chrom\tn_target_sites\tpositions_file\n")
        for row in manifests:
            oh.write("\t".join(map(str, row)) + "\n")

    with open(target_dir / "gt0_source_files.txt", "w") as oh:
        for p in gt0_files:
            oh.write(p + "\n")

    print(manifest_path)


def init_support_arrays(target_dir, support_dir):
    support_dir.mkdir(parents=True, exist_ok=True)
    cache = {}
    for p in sorted(target_dir.glob("*.positions.npy")):
        chrom = p.name.replace(".positions.npy", "")
        pos = np.load(p, mmap_mode="r")
        n = len(pos)
        nsp_path = support_dir / f"{chrom}.n_species.npy"
        rank_path = support_dir / f"{chrom}.node_rank.npy"
        desc_path = support_dir / f"{chrom}.node_desc.npy"
        if not nsp_path.exists() or os.path.getsize(nsp_path) == 0:
            a = np.lib.format.open_memmap(nsp_path, mode="w+", dtype=np.uint8, shape=(n,))
            a[:] = MISSING_U8
            del a
            a = np.lib.format.open_memmap(rank_path, mode="w+", dtype=np.uint8, shape=(n,))
            a[:] = MISSING_U8
            del a
            a = np.lib.format.open_memmap(desc_path, mode="w+", dtype=np.uint8, shape=(n,))
            a[:] = 0
            del a
        cache[chrom] = {
            "pos_path": p,
            "nsp_path": nsp_path,
            "rank_path": rank_path,
            "desc_path": desc_path,
        }
    return cache


def parse_maf_blocks(path):
    block = []
    with open_text(path) as fh:
        for line in fh:
            if line.startswith("a"):
                if block:
                    yield block
                    block = []
            elif line.startswith("s "):
                f = line.rstrip("\n").split()
                if len(f) < 7:
                    continue
                block.append({
                    "src": f[1],
                    "start": int(f[2]),
                    "size": int(f[3]),
                    "strand": f[4],
                    "srcSize": int(f[5]),
                    "text": f[6],
                })
            elif not line.strip():
                if block:
                    yield block
                    block = []
        if block:
            yield block


def ref_forward_interval(r):
    if r["strand"] == "+":
        return r["start"], r["start"] + r["size"]
    return r["srcSize"] - r["start"] - r["size"], r["srcSize"] - r["start"]


def map_target_positions_to_columns(refrow, wanted_positions):
    wanted = set(map(int, wanted_positions))
    pos_to_col = {}
    if refrow["strand"] == "+":
        coord = refrow["start"]
        for col, ch in enumerate(refrow["text"]):
            if ch != "-":
                if coord in wanted:
                    pos_to_col[coord] = col
                coord += 1
    else:
        coord = refrow["srcSize"] - refrow["start"] - 1
        for col, ch in enumerate(refrow["text"]):
            if ch != "-":
                if coord in wanted:
                    pos_to_col[coord] = col
                coord -= 1
    return pos_to_col


def cmd_scan(args):
    out = Path(args.outdir)
    target_dir = out / "targets"
    support_dir = out / "support"
    tree_dir = out / "tree"
    qc_dir = out / "qc"
    tree_dir.mkdir(parents=True, exist_ok=True)
    qc_dir.mkdir(parents=True, exist_ok=True)

    exclude = [x for x in args.exclude_taxa.split(",") if x]
    ctx = build_tree_context(args.tree, args.ref_taxon, exclude)
    if len(ctx["tree_taxa"]) != 97:
        eprint(f"WARNING: tree has {len(ctx['tree_taxa'])} tips, expected 97")
    if len(ctx["grass_taxa"]) != 94:
        raise SystemExit(f"Retained grass taxa = {len(ctx['grass_taxa'])}, expected 94")

    # Write tree validation and ped-to-root path before the expensive MAF pass.
    validation = tree_dir / "ROADIES97_to_grass94.validation.tsv"
    with open(validation, "w") as oh:
        oh.write("metric\tvalue\n")
        oh.write(f"tree_tip_count\t{len(ctx['tree_taxa'])}\n")
        oh.write(f"excluded_taxa_count\t{len(exclude)}\n")
        oh.write(f"excluded_taxa\t{','.join(sorted(exclude))}\n")
        oh.write(f"retained_grass_taxa_count\t{len(ctx['grass_taxa'])}\n")
        oh.write(f"reference_taxon\t{args.ref_taxon}\n")

    pathfile = tree_dir / "ped.reference_path.tsv"
    with open(pathfile, "w") as oh:
        oh.write("ref_age_rank\tnode_id\tgrass_descendants\tref_to_node\tclade_label\n")
        for rank, node, dist in ctx["ref_path"]:
            label = node.name if node.name else f"Node {rank} ({node.grass_count} grasses)"
            oh.write(f"{rank}\t{node.uid}\t{node.grass_count}\t{dist:.10g}\t{label}\n")

    files = init_support_arrays(target_dir, support_dir)
    opened = {}

    def arrays_for(chrom):
        if chrom not in files:
            return None
        if chrom not in opened:
            meta = files[chrom]
            opened[chrom] = (
                np.load(meta["pos_path"], mmap_mode="r"),
                np.lib.format.open_memmap(meta["nsp_path"], mode="r+"),
                np.lib.format.open_memmap(meta["rank_path"], mode="r+"),
                np.lib.format.open_memmap(meta["desc_path"], mode="r+"),
            )
        return opened[chrom]

    observed_maf_taxa = set()
    n_blocks = 0
    n_target_blocks = 0
    n_target_observations = 0
    duplicate_same = 0
    duplicate_conflict = 0
    unexpected_taxa = Counter()

    ref_bit = ctx["bit_of"][args.ref_taxon]

    for block in parse_maf_blocks(args.maf):
        n_blocks += 1
        for r in block:
            observed_maf_taxa.add(taxon_from_src(r["src"]))
        refrows = [r for r in block if taxon_from_src(r["src"]) == args.ref_taxon]
        if not refrows:
            continue
        # A reference-centered roast MAF should have one ped row per block.
        refrow = refrows[0]
        chrom = contig_from_ref_src(refrow["src"], args.ref_taxon)
        arrays = arrays_for(chrom)
        if arrays is None:
            continue
        posarr, nsp_arr, rank_arr, desc_arr = arrays
        fstart, fend = ref_forward_interval(refrow)
        lo = int(np.searchsorted(posarr, fstart, side="left"))
        hi = int(np.searchsorted(posarr, fend, side="left"))
        if lo >= hi:
            continue
        wanted = posarr[lo:hi]
        p2c = map_target_positions_to_columns(refrow, wanted)
        if not p2c:
            continue
        n_target_blocks += 1
        coords = sorted(p2c)
        cols = [p2c[p] for p in coords]
        masks = [0] * len(coords)

        for r in block:
            tax = taxon_from_src(r["src"])
            if tax in exclude:
                continue
            bitidx = ctx["bit_of"].get(tax)
            if bitidx is None:
                unexpected_taxa[tax] += 1
                continue
            seq = r["text"]
            bit = 1 << bitidx
            for j, col in enumerate(cols):
                if col < len(seq) and seq[col] in VALID_BASES:
                    masks[j] |= bit

        for coord, mask in zip(coords, masks):
            # GERP target sites are expected to have a valid ped reference base.
            # Enforce inclusion of ped only when ped really has A/C/G/T at this column.
            if not (mask & (1 << ref_bit)):
                continue
            n_species = mask.bit_count()  # includes ped; therefore range 1..94
            rank, node = rank_node_for_mask(mask, ctx["ref_path"])
            idx = int(np.searchsorted(posarr, coord))
            old = int(nsp_arr[idx])
            if old != 255:
                if old == n_species and int(rank_arr[idx]) == rank and int(desc_arr[idx]) == node.grass_count:
                    duplicate_same += 1
                else:
                    duplicate_conflict += 1
                continue
            nsp_arr[idx] = np.uint8(n_species)
            rank_arr[idx] = np.uint8(rank)
            desc_arr[idx] = np.uint8(node.grass_count)
            n_target_observations += 1

        if n_blocks % 100000 == 0:
            eprint(f"[scan] blocks={n_blocks:,} target_blocks={n_target_blocks:,} target_sites={n_target_observations:,}")

    # Flush memmaps.
    for posarr, nsp_arr, rank_arr, desc_arr in opened.values():
        nsp_arr.flush(); rank_arr.flush(); desc_arr.flush()

    maf_grass = sorted(observed_maf_taxa.intersection(ctx["grass_taxa"]))
    maf_excluded = sorted(observed_maf_taxa.intersection(exclude))
    tree_not_maf = sorted(set(ctx["tree_taxa"]) - observed_maf_taxa)
    maf_not_tree = sorted(observed_maf_taxa - set(ctx["tree_taxa"]))

    with open(validation, "a") as oh:
        oh.write(f"maf_observed_taxa_count\t{len(observed_maf_taxa)}\n")
        oh.write(f"maf_observed_grass_taxa_count\t{len(maf_grass)}\n")
        oh.write(f"maf_observed_excluded_taxa\t{','.join(maf_excluded)}\n")
        oh.write(f"tree_not_maf\t{','.join(tree_not_maf)}\n")
        oh.write(f"maf_not_tree\t{','.join(maf_not_tree)}\n")
        oh.write(f"maf_blocks\t{n_blocks}\n")
        oh.write(f"target_blocks\t{n_target_blocks}\n")
        oh.write(f"target_site_observations\t{n_target_observations}\n")
        oh.write(f"duplicate_same\t{duplicate_same}\n")
        oh.write(f"duplicate_conflict\t{duplicate_conflict}\n")

    if unexpected_taxa:
        with open(qc_dir / "unexpected_maf_taxa.tsv", "w") as oh:
            oh.write("taxon\tn_rows\n")
            for tax, n in unexpected_taxa.most_common():
                oh.write(f"{tax}\t{n}\n")

    if len(maf_grass) != 94:
        eprint(f"WARNING: only {len(maf_grass)} of the 94 retained grasses were observed somewhere in the MAF")
    if duplicate_conflict:
        eprint(f"WARNING: {duplicate_conflict:,} target-site duplicate conflicts detected; inspect validation/QC")
    print(validation)


def median_from_hist(hist):
    n = int(hist.sum())
    if n == 0:
        return float("nan")
    c = np.cumsum(hist)
    if n % 2:
        return float(np.searchsorted(c, n // 2 + 1))
    a = int(np.searchsorted(c, n // 2))
    b = int(np.searchsorted(c, n // 2 + 1))
    return (a + b) / 2.0


def process_bed_summary(path, support_dir):
    n_hist = np.zeros(95, dtype=np.int64)  # 0..94; 0 should be absent
    node_hist = Counter()
    delta_hist = Counter()
    n_total_unique = 0
    n_observed = 0
    occ_sum = 0.0
    occ_n = 0
    cache = {}

    def arrs(chrom):
        if chrom not in cache:
            pp = support_dir.parent / "targets" / f"{chrom}.positions.npy"
            np_ = support_dir / f"{chrom}.n_species.npy"
            rp = support_dir / f"{chrom}.node_rank.npy"
            dp = support_dir / f"{chrom}.node_desc.npy"
            if not (pp.exists() and np_.exists() and rp.exists() and dp.exists()):
                cache[chrom] = None
            else:
                cache[chrom] = (
                    np.load(pp, mmap_mode="r"),
                    np.load(np_, mmap_mode="r"),
                    np.load(rp, mmap_mode="r"),
                    np.load(dp, mmap_mode="r"),
                )
        return cache[chrom]

    for chrom, start, source_count in iter_unique_bed_sites(path, require_sorted=True, include_source_count=True):
        n_total_unique += 1
        a = arrs(chrom)
        if a is None:
            continue
        pos, nsp, rank, desc = a
        idx = int(np.searchsorted(pos, start))
        if idx >= len(pos) or int(pos[idx]) != start:
            continue
        ns = int(nsp[idx])
        if ns == 255:
            continue
        n_observed += 1
        if 0 <= ns <= 94:
            n_hist[ns] += 1
        rr = int(rank[idx])
        dd = int(desc[idx])
        node_hist[rr] += 1
        if dd > 0:
            occ_sum += ns / dd
            occ_n += 1
        if source_count is not None:
            delta_hist[source_count - ns] += 1

    return {
        "n_hist": n_hist,
        "node_hist": node_hist,
        "delta_hist": delta_hist,
        "n_total_unique": n_total_unique,
        "n_observed": n_observed,
        "mean_n_species": (sum(i * int(n_hist[i]) for i in range(95)) / n_observed) if n_observed else float("nan"),
        "median_n_species": median_from_hist(n_hist),
        "mean_occupancy": (occ_sum / occ_n) if occ_n else float("nan"),
    }


def write_hist(path, threshold, feature, hist):
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w") as oh:
        oh.write("threshold\tfeature\tn_species\tn_sites\n")
        for i, n in enumerate(hist):
            if n:
                oh.write(f"gt{threshold}\t{feature}\t{i}\t{int(n)}\n")


def write_node_hist(path, threshold, feature, hist):
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w") as oh:
        oh.write("threshold\tfeature\tref_age_rank\tn_sites\n")
        for rank in sorted(hist):
            oh.write(f"gt{threshold}\t{feature}\t{rank}\t{hist[rank]}\n")


def write_delta_hist(path, threshold, feature, hist):
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w") as oh:
        oh.write("threshold\tfeature\tsource_col6_minus_grass94_count\tn_sites\n")
        for d in sorted(hist):
            oh.write(f"gt{threshold}\t{feature}\t{d}\t{hist[d]}\n")


def cmd_summarize(args):
    out = Path(args.outdir)
    inter = Path(args.intersect_dir)
    support_dir = out / "support"
    species_dir = out / "species_support"
    summary_dir = out / "summary"
    qc_dir = out / "qc"
    qc_dir.mkdir(parents=True, exist_ok=True)

    thresholds = [int(x) for x in args.thresholds.split(",") if x]
    rows_by_scope = defaultdict(list)
    combined_hist = defaultdict(lambda: np.zeros(95, dtype=np.int64))
    combined_node = defaultdict(Counter)
    combined_delta = defaultdict(Counter)
    combined_counts = defaultdict(lambda: [0, 0, 0.0, 0])  # total, observed, occsum, occn

    for t in thresholds:
        for sub in ("pedC", "pedD"):
            pattern = str(inter / f"gerp_gt{t}" / f"{sub}_gt{t}.*.intersect.bed")
            files = sorted(glob.glob(pattern))
            if not files:
                eprint(f"WARNING: no files for {pattern}")
                continue
            for p in files:
                feature = feature_from_filename(p, t, sub)
                if feature is None:
                    continue
                eprint(f"[summary] gt{t} {sub} {feature}: {p}")
                res = process_bed_summary(p, support_dir)
                write_hist(species_dir / sub / "raw_hist" / f"gt{t}.{feature}.hist.tsv", t, feature, res["n_hist"])
                write_node_hist(summary_dir / sub / "node_hist" / f"gt{t}.{feature}.node_hist.tsv", t, feature, res["node_hist"])
                write_delta_hist(qc_dir / sub / f"gt{t}.{feature}.source_delta.tsv", t, feature, res["delta_hist"])
                rows_by_scope[sub].append((t, feature, res))

                k = (t, feature)
                combined_hist[k] += res["n_hist"]
                combined_node[k].update(res["node_hist"])
                combined_delta[k].update(res["delta_hist"])
                combined_counts[k][0] += res["n_total_unique"]
                combined_counts[k][1] += res["n_observed"]
                # Reconstruct occupancy sum from mean*n; safe except when nan.
                if not math.isnan(res["mean_occupancy"]):
                    combined_counts[k][2] += res["mean_occupancy"] * res["n_observed"]
                    combined_counts[k][3] += res["n_observed"]

    for (t, feature), hist in sorted(combined_hist.items()):
        n_total, n_obs, occsum, occn = combined_counts[(t, feature)]
        res = {
            "n_hist": hist,
            "node_hist": combined_node[(t, feature)],
            "delta_hist": combined_delta[(t, feature)],
            "n_total_unique": n_total,
            "n_observed": n_obs,
            "mean_n_species": (sum(i * int(hist[i]) for i in range(95)) / n_obs) if n_obs else float("nan"),
            "median_n_species": median_from_hist(hist),
            "mean_occupancy": (occsum / occn) if occn else float("nan"),
        }
        write_hist(species_dir / "whole" / "raw_hist" / f"gt{t}.{feature}.hist.tsv", t, feature, hist)
        write_node_hist(summary_dir / "whole" / "node_hist" / f"gt{t}.{feature}.node_hist.tsv", t, feature, res["node_hist"])
        write_delta_hist(qc_dir / "whole" / f"gt{t}.{feature}.source_delta.tsv", t, feature, res["delta_hist"])
        rows_by_scope["whole"].append((t, feature, res))

    for scope, rows in rows_by_scope.items():
        p = summary_dir / scope / "feature_summary.tsv"
        p.parent.mkdir(parents=True, exist_ok=True)
        with open(p, "w") as oh:
            oh.write("threshold\tfeature\tn_unique_bed_sites\tn_sites_observed_in_97maf\tmean_grass_species\tmedian_grass_species\tmean_node_occupancy\n")
            for t, feature, res in sorted(rows, key=lambda x: (x[0], x[1])):
                oh.write(
                    f"gt{t}\t{feature}\t{res['n_total_unique']}\t{res['n_observed']}\t"
                    f"{res['mean_n_species']:.6f}\t{res['median_n_species']:.6f}\t{res['mean_occupancy']:.6f}\n"
                )

    print(summary_dir)


def cmd_qc(args):
    out = Path(args.outdir)
    val = out / "tree" / "ROADIES97_to_grass94.validation.tsv"
    if not val.exists():
        raise SystemExit(f"Missing {val}; run scan first")
    kv = {}
    with open(val) as fh:
        next(fh)
        for line in fh:
            k, v = line.rstrip("\n").split("\t", 1)
            kv[k] = v
    checks = []
    checks.append(("tree_tip_count", kv.get("tree_tip_count") == "97", kv.get("tree_tip_count")))
    checks.append(("retained_grass_taxa_count", kv.get("retained_grass_taxa_count") == "94", kv.get("retained_grass_taxa_count")))
    checks.append(("maf_observed_taxa_count", kv.get("maf_observed_taxa_count") == "97", kv.get("maf_observed_taxa_count")))
    checks.append(("maf_observed_grass_taxa_count", kv.get("maf_observed_grass_taxa_count") == "94", kv.get("maf_observed_grass_taxa_count")))
    checks.append(("maf_observed_excluded_taxa", set(kv.get("maf_observed_excluded_taxa", "").split(",")) == set(args.exclude_taxa.split(",")), kv.get("maf_observed_excluded_taxa")))
    checks.append(("tree_not_maf_empty", kv.get("tree_not_maf", "") == "", kv.get("tree_not_maf")))
    checks.append(("maf_not_tree_empty", kv.get("maf_not_tree", "") == "", kv.get("maf_not_tree")))
    checks.append(("duplicate_conflict_zero", kv.get("duplicate_conflict", "0") == "0", kv.get("duplicate_conflict")))

    qcp = out / "qc" / "pipeline_qc.tsv"
    qcp.parent.mkdir(parents=True, exist_ok=True)
    with open(qcp, "w") as oh:
        oh.write("check\tstatus\tvalue\n")
        for name, ok, value in checks:
            oh.write(f"{name}\t{'PASS' if ok else 'WARN'}\t{value if value is not None else ''}\n")
    print(qcp)


def build_parser():
    ap = argparse.ArgumentParser(
        description="Moso bamboo: compute 94-grass phylogenetic support directly from the original 97-species MAF, without generating a 94-species MAF."
    )
    sp = ap.add_subparsers(dest="cmd", required=True)

    p = sp.add_parser("prepare", help="Build the union of target coordinates from existing gt0 intersect BEDs")
    p.add_argument("--intersect-dir", required=True)
    p.add_argument("--outdir", required=True)
    p.set_defaults(func=cmd_prepare)

    p = sp.add_parser("scan", help="Scan the 97-species MAF once and retain only the 94 grass taxa in memory")
    p.add_argument("--maf", required=True)
    p.add_argument("--tree", required=True)
    p.add_argument("--outdir", required=True)
    p.add_argument("--ref-taxon", default="ped")
    p.add_argument("--exclude-taxa", default="Acom,Jeff,Ssto")
    p.set_defaults(func=cmd_scan)

    p = sp.add_parser("summarize", help="Summarize MAF-derived 94-grass support for all existing GERP/feature BEDs")
    p.add_argument("--intersect-dir", required=True)
    p.add_argument("--outdir", required=True)
    p.add_argument("--thresholds", default="0,2,4,6")
    p.set_defaults(func=cmd_summarize)

    p = sp.add_parser("qc", help="Create compact validation table")
    p.add_argument("--outdir", required=True)
    p.add_argument("--exclude-taxa", default="Acom,Jeff,Ssto")
    p.set_defaults(func=cmd_qc)
    return ap


def main():
    ap = build_parser()
    args = ap.parse_args()
    args.func(args)


if __name__ == "__main__":
    main()
