# Moso bamboo 97-MAF -> 94-grass support pipeline

## Goal

Use the **original 97-species `roast.maf` directly**. Do **not** generate a second 94-species MAF.

The original MAF/tree contain 97 taxa:

- 94 Poaceae taxa retained for statistics, **including reference `ped`**;
- 3 non-grass outgroups excluded during counting: `Acom`, `Jeff`, `Ssto`.

Therefore the reported per-site species breadth is:

`n_species = number of retained 94 grass taxa with A/C/G/T at the aligned column`

and its maximum is **94**, not 93.

The MAF file itself is never altered. Filtering occurs only in memory while scanning each MAF block.

## Existing inputs

Working directory:

`/ds3200_1/users_root/liuliangmin/workspace/PHD/2.msa/2.2.ped_result_stat/2.2.constrain_stat`

Expected inputs:

- `/ds3200_1/users_root/liuliangmin/workspace/PHD/2.msa/84sp_ped/97sp_ped.results/roast/roast.maf`
- `/ds3200_1/users_root/liuliangmin/workspace/PHD/run97/treePL/ROADIES_treePL_LSF/01_ROADIES97_rooted_substitutions_per_site.nwk`
- `intersect_results/gerp_gt0`
- `intersect_results/gerp_gt2`
- `intersect_results/gerp_gt4`
- `intersect_results/gerp_gt6`

No GERP recalculation and no BED re-intersection are required.

## Statistical definition

For every unique target reference site:

1. Read its alignment column directly from the 97-species MAF.
2. Ignore rows from `Acom`, `Jeff`, and `Ssto`.
3. Among the remaining 94 grasses, a taxon is represented only when the aligned base is `A/C/G/T`.
4. `n_species` includes `ped`, so the range is 1-94.
5. The deepest phylogenetic node is the MRCA of represented grass taxa.
6. Node occupancy is:

   `n_species / number of retained grass descendants of that MRCA`

The original 97-tip tree is also kept unchanged. Descendant counts are calculated after ignoring the same three outgroups in memory; no 94-tip tree file is required.

## Important change relative to the older pipeline

The old workflow expected a physically pruned 94-species MAF and therefore expected:

- MAF taxa = 94
- `tree_not_maf = Acom,Jeff,Ssto`

That expectation is **not valid here**.

For the new direct-97-MAF workflow, the normal QC result is:

- tree tips = 97
- taxa observed in MAF = 97
- retained grass taxa = 94
- excluded taxa observed in MAF = `Acom,Jeff,Ssto`
- `tree_not_maf` = empty
- `maf_not_tree` = empty

Also, BED column 6 is retained only as a QC comparator. It is **not** used as the final species breadth because it was generated from the original alignment and may include non-grass taxa depending on the upstream GERP counting convention.

## Installation

Copy this directory into the working directory, for example:

```bash
cd /ds3200_1/users_root/liuliangmin/workspace/PHD/2.msa/2.2.ped_result_stat/2.2.constrain_stat
cp -r Ped97MAF_grass94_pipeline ./
cd Ped97MAF_grass94_pipeline
```

Edit `config.sh` only if your paths differ.

## Run

### Recommended: submit the complete dependency chain

```bash
cd /ds3200_1/users_root/liuliangmin/workspace/PHD/2.msa/2.2.ped_result_stat/2.2.constrain_stat/Ped97MAF_grass94_pipeline
bash submit_pipeline.sh config.sh
```

### Or submit step by step

```bash
bsub -env "all,CONFIG=config.sh" < 01_prepare_targets.bsub
```

After it finishes:

```bash
bsub -env "all,CONFIG=config.sh" < 02_scan_97maf_keep94grasses.bsub
```

After it finishes:

```bash
bsub -env "all,CONFIG=config.sh" < 03_summarize.bsub
```

## Output

Main output directory:

`Ped94_phylogenetic_support_from97MAF/`

Key files/directories:

```text
Ped94_phylogenetic_support_from97MAF/
├── targets/
│   ├── Ped01C.positions.npy
│   └── target_manifest.tsv
├── support/
│   ├── Ped01C.n_species.npy
│   ├── Ped01C.node_rank.npy
│   └── Ped01C.node_desc.npy
├── tree/
│   ├── ROADIES97_to_grass94.validation.tsv
│   └── ped.reference_path.tsv
├── species_support/
│   ├── whole/raw_hist/
│   ├── pedC/raw_hist/
│   └── pedD/raw_hist/
├── summary/
│   ├── whole/feature_summary.tsv
│   ├── pedC/feature_summary.tsv
│   ├── pedD/feature_summary.tsv
│   └── */node_hist/
└── qc/
    ├── pipeline_qc.tsv
    └── */gt*.feature.source_delta.tsv
```

Example species-breadth histogram:

```text
threshold  feature       n_species  n_sites
gt0        4-fold_sites  84         ...
gt0        4-fold_sites  85         ...
...
gt0        4-fold_sites  94         ...
```

A maximum of 94 is correct for moso bamboo under this definition.

## First QC to inspect

```bash
cat Ped94_phylogenetic_support_from97MAF/tree/ROADIES97_to_grass94.validation.tsv
cat Ped94_phylogenetic_support_from97MAF/qc/pipeline_qc.tsv
cat Ped94_phylogenetic_support_from97MAF/tree/ped.reference_path.tsv | head -20
```

Expected core values:

```text
tree_tip_count                 97
retained_grass_taxa_count      94
maf_observed_taxa_count        97
maf_observed_grass_taxa_count  94
maf_observed_excluded_taxa     Acom,Jeff,Ssto
```

## Why `gt0` is used to build the target union

`prepare` builds the coordinate union from all existing `gerp_gt0` feature BEDs. The higher thresholds (`gt2`, `gt4`, `gt6`) are subsets of `gt0` in this analysis, so their sites are already included. The final summarization still reads the original BED for each threshold and feature separately.

## Dependency

- Python 3
- NumPy
- LSF `bsub`

No Biopython/ETE3 is required; the script includes a lightweight Newick parser.
