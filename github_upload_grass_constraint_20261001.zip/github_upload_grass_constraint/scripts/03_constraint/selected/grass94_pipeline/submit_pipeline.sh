#!/usr/bin/env bash
set -euo pipefail
CONFIG=${1:-config.sh}
mkdir -p logs

j1=$(bsub -env "all,CONFIG=$CONFIG" < 01_prepare_targets.bsub | awk -F'[<>]' '{print $2}')
echo "prepare job: $j1"
j2=$(bsub -w "done($j1)" -env "all,CONFIG=$CONFIG" < 02_scan_97maf_keep94grasses.bsub | awk -F'[<>]' '{print $2}')
echo "scan job: $j2"
j3=$(bsub -w "done($j2)" -env "all,CONFIG=$CONFIG" < 03_summarize.bsub | awk -F'[<>]' '{print $2}')
echo "summary job: $j3"
echo "Submitted chain: $j1 -> $j2 -> $j3"
