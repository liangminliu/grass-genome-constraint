#!/usr/bin/env Rscript

options(stringsAsFactors = FALSE)
options(warn = 1)

args <- commandArgs(trailingOnly = TRUE)
if (length(args) != 4) {
  stop(
    "Usage: Rscript 02_plot_one_species_phylo_support.R prepared_dir species_key display_name outdir",
    call. = FALSE
  )
}

prepared_dir <- normalizePath(args[1], mustWork = TRUE)
species_key  <- args[2]
display_name <- args[3]
outdir       <- args[4]

dir.create(outdir, recursive = TRUE, showWarnings = FALSE)

suppressPackageStartupMessages({
  library(ggplot2)
  library(dplyr)
  library(patchwork)
})

MAIN_THRESHOLD <- "gt2"

MAIN_FEATURES <- c(
  "0fold", "4fold", "CDS", "UTR5", "UTR3",
  "promoter", "intron", "intergenic", "TE"
)

FEATURE_LABELS <- c(
  "0fold" = "0-fold",
  "4fold" = "4-fold",
  "CDS" = "CDS",
  "UTR5" = "5′ UTR",
  "UTR3" = "3′ UTR",
  "promoter" = "Promoter",
  "intron" = "Intron",
  "intergenic" = "Intergenic",
  "TE" = "TE"
)

## V4.1 final sequential palette.
## 1 = shallowest; 7 = deepest.
## The lightest class is intentionally darker than the former #F1EDF6,
## and the deepest class darker than the former #4B317F.
PHYLO_PURPLE_7 <- c(
  "1" = "#E4DDEE",
  "2" = "#D2C2E3",
  "3" = "#BDA3D4",
  "4" = "#A07DC2",
  "5" = "#8358AB",
  "6" = "#653C90",
  "7" = "#2F1B59"
)

read_tsv <- function(f) {
  if (!file.exists(f)) stop("Missing input: ", f, call. = FALSE)
  read.delim(
    f, sep = "\t", header = TRUE, quote = "",
    comment.char = "", check.names = FALSE,
    stringsAsFactors = FALSE
  )
}

## ------------------------------------------------------------
## Read standardized inputs
## ------------------------------------------------------------

deepest <- read_tsv(file.path(prepared_dir, "phylo.deepest_node.tsv"))
breadth <- read_tsv(file.path(prepared_dir, "taxonomic_breadth.summary.tsv"))
occupancy <- read_tsv(file.path(prepared_dir, "phylo.node_occupancy.summary.tsv"))
status <- read_tsv(file.path(prepared_dir, "prep_status.tsv"))
class_legend <- read_tsv(file.path(prepared_dir, "classification_legend.tsv"))

if (nrow(status) != 1) {
  stop("prep_status.tsv should contain exactly one row.", call. = FALSE)
}

TARGET_GRASSES <- as.integer(status$target_grasses[1])
obs <- suppressWarnings(as.integer(status$observed_total_grasses[1]))
strict94 <- identical(Sys.getenv("STRICT_94", "1"), "1")
allow_atau93 <- identical(Sys.getenv("ALLOW_ATAU_93", "1"), "1")

known_atau93_exception <- (
  species_key == "atau" &&
  allow_atau93 &&
  is.finite(obs) &&
  obs == 93L &&
  TARGET_GRASSES == 94L
)

if (
  strict94 &&
  is.finite(obs) &&
  obs != TARGET_GRASSES &&
  !known_atau93_exception
) {
  stop(
    display_name, " currently has ", obs,
    " grasses in its phylogenetic-support data rather than ",
    TARGET_GRASSES, ".",
    call. = FALSE
  )
}

if (known_atau93_exception) {
  warning(
    "A. tauschii uses the documented 93-tip phylogenetic-support dataset; ",
    "the common taxonomic-breadth denominator remains 94 grasses."
  )
}

## ------------------------------------------------------------
## Restrict to GERP > 2 and publication features
## ------------------------------------------------------------

deepest <- deepest %>%
  filter(threshold == MAIN_THRESHOLD, feature %in% MAIN_FEATURES)

breadth <- breadth %>%
  filter(threshold == MAIN_THRESHOLD, feature %in% MAIN_FEATURES)

occupancy <- occupancy %>%
  filter(threshold == MAIN_THRESHOLD, feature %in% MAIN_FEATURES)

if (nrow(deepest) == 0) stop("No GERP >2 deepest-node data.", call. = FALSE)
if (nrow(breadth) == 0) stop("No GERP >2 breadth data.", call. = FALSE)
if (nrow(occupancy) == 0) stop("No GERP >2 occupancy data.", call. = FALSE)

feature_levels <- unname(FEATURE_LABELS[MAIN_FEATURES])

make_feature_factor <- function(x) {
  factor(
    unname(FEATURE_LABELS[as.character(x)]),
    levels = rev(feature_levels)
  )
}

deepest$Feature <- make_feature_factor(deepest$feature)
breadth$Feature <- make_feature_factor(breadth$feature)
occupancy$Feature <- make_feature_factor(occupancy$feature)

if (any(is.na(deepest$Feature))) stop("Panel a contains an unmapped feature label.", call. = FALSE)
if (any(is.na(breadth$Feature))) stop("Panel b contains an unmapped feature label.", call. = FALSE)
if (any(is.na(occupancy$Feature))) stop("Panel c contains an unmapped feature label.", call. = FALSE)

## ------------------------------------------------------------
## Seven-level phylogenetic legend
## ------------------------------------------------------------

node_key <- class_legend %>%
  transmute(
    node_order = as.integer(node_order),
    node_label = trimws(as.character(node_label))
  ) %>%
  distinct() %>%
  arrange(node_order)

node_key$node_label <- trimws(
  gsub(
    "\\s*[\\(\\[][^\\)\\]]*(taxa|tips|grass|grasses|species)[^\\)\\]]*[\\)\\]]\\s*$",
    "",
    node_key$node_label,
    ignore.case = TRUE,
    perl = TRUE
  )
)

if (
  nrow(node_key) != 7 ||
  !identical(node_key$node_order, 1:7) ||
  any(is.na(node_key$node_label) | !nzchar(node_key$node_label))
) {
  stop(
    display_name,
    ": classification_legend.tsv must contain exactly seven ordered, named classes (1..7).",
    call. = FALSE
  )
}

## ------------------------------------------------------------
## Panel-a plotting table and hard 100% QC
## ------------------------------------------------------------

needed_depth <- c("feature", "node_order", "node_label", "n_sites")
miss_depth <- setdiff(needed_depth, names(deepest))
if (length(miss_depth) > 0) {
  stop("phylo.deepest_node.tsv missing: ", paste(miss_depth, collapse = ", "), call. = FALSE)
}

deepest$node_order <- as.integer(deepest$node_order)
deepest$n_sites <- as.numeric(deepest$n_sites)

if (any(!is.finite(deepest$n_sites) | deepest$n_sites < 0)) {
  stop("Panel a contains non-finite or negative n_sites.", call. = FALSE)
}

if (any(!deepest$node_order %in% 1:7)) {
  stop("Panel a contains node_order values outside 1..7.", call. = FALSE)
}

## Re-aggregate defensively and recalculate proportions from n_sites.
## The geometry itself also uses position_fill(), so panel a cannot depend
## on a previously calculated fraction column.
depth_plot <- deepest %>%
  group_by(feature, Feature, node_order) %>%
  summarise(n_sites = sum(n_sites), .groups = "drop") %>%
  left_join(node_key, by = "node_order") %>%
  group_by(feature, Feature) %>%
  mutate(
    feature_total_sites = sum(n_sites),
    plot_fraction = n_sites / feature_total_sites,
    plot_percent = 100 * plot_fraction
  ) %>%
  ungroup()

## Every feature should have all seven classes explicitly represented.
## Preparation already inserts zero-count rows; verify that contract here.
depth_qc <- depth_plot %>%
  group_by(feature) %>%
  summarise(
    total_sites = unique(feature_total_sites)[1],
    n_depth_classes = n_distinct(node_order),
    n_nonzero_classes = sum(n_sites > 0),
    sum_fraction = sum(plot_fraction),
    sum_percent = sum(plot_percent),
    .groups = "drop"
  )

write.table(
  depth_plot,
  file.path(outdir, "panel_a_phylogenetic_depth.plotting_table.tsv"),
  sep = "\t", quote = FALSE, row.names = FALSE
)

write.table(
  depth_qc,
  file.path(outdir, "panel_a_phylogenetic_depth.qc.tsv"),
  sep = "\t", quote = FALSE, row.names = FALSE
)

bad_qc <- !is.finite(depth_qc$total_sites) |
  depth_qc$total_sites <= 0 |
  depth_qc$n_depth_classes != 7 |
  !is.finite(depth_qc$sum_fraction) |
  abs(depth_qc$sum_fraction - 1) > 1e-10

if (any(bad_qc)) {
  stop(
    display_name,
    ": panel a failed the seven-class / 100% composition QC. ",
    "Inspect panel_a_phylogenetic_depth.qc.tsv.",
    call. = FALSE
  )
}

depth_plot$node_order_f <- factor(
  depth_plot$node_order,
  levels = 1:7,
  labels = as.character(1:7)
)

## ------------------------------------------------------------
## Publication theme
## ------------------------------------------------------------

theme_support <- theme_classic(
  base_size = 7.2,
  base_family = "sans"
) +
  theme(
    axis.line = element_line(linewidth = 0.34, colour = "#303030"),
    axis.ticks = element_line(linewidth = 0.30, colour = "#303030"),
    axis.text = element_text(size = 6.6, colour = "#303030"),
    axis.title = element_text(size = 7.15, colour = "#202020"),
    strip.background = element_blank(),
    strip.text = element_text(size = 6.8, face = "bold", colour = "#202020"),
    plot.tag = element_text(size = 9.1, face = "bold", colour = "#111111"),
    plot.tag.position = c(0, 1),
    plot.margin = margin(3.5, 4, 3.5, 4),
    legend.title = element_text(size = 6.25, face = "plain", colour = "#222222"),
    legend.text = element_text(size = 5.85, colour = "#222222"),
    legend.key = element_blank(),
    legend.key.height = grid::unit(2.6, "mm"),
    legend.key.width = grid::unit(4.0, "mm"),
    legend.spacing.x = grid::unit(1.3, "mm"),
    legend.spacing.y = grid::unit(0.5, "mm"),
    legend.box.spacing = grid::unit(0.6, "mm"),
    legend.margin = margin(0, 0, 0, 0),
    legend.box.margin = margin(0, 0, 0, 0)
  )

## ------------------------------------------------------------
## a | phylogenetic-depth composition
## Each feature is a true 100% stacked bar.
## ------------------------------------------------------------

pA <- ggplot(
  depth_plot,
  aes(
    y = Feature,
    x = n_sites,
    fill = node_order_f
  )
) +
  geom_col(
    width = 0.70,
    position = position_fill(reverse = TRUE),
    colour = NA
  ) +
  scale_x_continuous(
    limits = c(0, 1),
    breaks = seq(0, 1, 0.25),
    labels = function(x) paste0(round(100 * x), "%"),
    expand = expansion(mult = c(0, 0))
  ) +
  scale_fill_manual(
    values = PHYLO_PURPLE_7,
    breaks = as.character(1:7),
    labels = node_key$node_label,
    drop = FALSE
  ) +
  labs(
    x = "Fraction of GERP >2 sites",
    y = NULL,
    fill = "Phylogenetic depth class",
    tag = "a"
  ) +
  guides(
    fill = guide_legend(
      nrow = 2,
      byrow = TRUE,
      reverse = FALSE,
      title.position = "top",
      title.hjust = 0,
      label.position = "right"
    )
  ) +
  theme_support

## ------------------------------------------------------------
## b | taxonomic breadth
## Grey IQR + filled mean + open median.
## ------------------------------------------------------------

pB <- ggplot(breadth, aes(y = Feature)) +
  geom_segment(
    aes(x = q1, xend = q3, yend = Feature),
    linewidth = 0.72,
    colour = "#777777",
    lineend = "round"
  ) +
  geom_point(
    aes(x = mean),
    shape = 16,
    size = 2.05,
    colour = "black"
  ) +
  geom_point(
    aes(x = median),
    shape = 21,
    size = 2.25,
    fill = "white",
    colour = "black",
    stroke = 0.68
  ) +
  scale_x_continuous(
    limits = c(0, TARGET_GRASSES),
    breaks = c(0, 25, 50, 75, TARGET_GRASSES),
    expand = expansion(mult = c(0, 0.015))
  ) +
  labs(
    x = paste0("Aligned grass species per site (of ", TARGET_GRASSES, ")"),
    y = NULL,
    tag = "b"
  ) +
  theme_support +
  theme(
    axis.text.y = element_blank(),
    axis.ticks.y = element_blank(),
    legend.position = "none"
  )

## ------------------------------------------------------------
## c | descendant-taxon occupancy
## Current Zmay and Atau summaries lack occupancy IQR; to preserve
## cross-species statistical symmetry, all three figures show the
## mean–median connector rather than Ped-only IQR.
## ------------------------------------------------------------

pC <- ggplot(occupancy, aes(y = Feature)) +
  geom_segment(
    aes(x = mean, xend = median, yend = Feature),
    linewidth = 0.56,
    colour = "#888888",
    lineend = "round"
  ) +
  geom_point(
    aes(x = mean),
    shape = 16,
    size = 2.05,
    colour = "black"
  ) +
  geom_point(
    aes(x = median),
    shape = 21,
    size = 2.25,
    fill = "white",
    colour = "black",
    stroke = 0.68
  ) +
  scale_x_continuous(
    limits = c(0, 1),
    breaks = seq(0, 1, 0.2),
    labels = function(x) paste0(round(100 * x), "%"),
    expand = expansion(mult = c(0, 0.015))
  ) +
  labs(
    x = "Descendant-taxon occupancy",
    y = NULL,
    tag = "c"
  ) +
  theme_support +
  theme(
    axis.text.y = element_blank(),
    axis.ticks.y = element_blank(),
    legend.position = "none"
  )

## ------------------------------------------------------------
## Compact statistical-symbol key
## ------------------------------------------------------------

p_key <- ggplot() +
  geom_segment(
    aes(x = 0.30, xend = 0.39, y = 1, yend = 1),
    colour = "#777777",
    linewidth = 0.72,
    lineend = "round"
  ) +
  geom_point(
    aes(x = 0.53, y = 1),
    shape = 16,
    size = 2.05
  ) +
  geom_point(
    aes(x = 0.72, y = 1),
    shape = 21,
    size = 2.25,
    fill = "white",
    stroke = 0.68
  ) +
  annotate("text", x = 0.405, y = 1, label = "IQR (breadth)", hjust = 0, size = 2.02) +
  annotate("text", x = 0.545, y = 1, label = "Mean", hjust = 0, size = 2.02) +
  annotate("text", x = 0.735, y = 1, label = "Median", hjust = 0, size = 2.02) +
  coord_cartesian(xlim = c(0.24, 0.86), ylim = c(0.86, 1.14), clip = "off") +
  theme_void(base_family = "sans") +
  theme(plot.margin = margin(0, 0, 0, 0))

## ------------------------------------------------------------
## Assemble figure
## ------------------------------------------------------------

main <- pA + pB + pC +
  plot_layout(
    widths = c(1.60, 0.94, 0.94),
    guides = "collect"
  ) &
  theme(
    legend.position = "bottom",
    legend.direction = "horizontal",
    legend.justification = "left",
    legend.box.just = "left",
    legend.box = "vertical"
  )

fig <- main / p_key +
  plot_layout(heights = c(1, 0.055))

prefix <- paste0("FigS_", species_key, "_GERPgt2_phylogenetic_support")
pdf_file <- file.path(outdir, paste0(prefix, ".pdf"))
png_file <- file.path(outdir, paste0(prefix, ".png"))

if (capabilities("cairo")) {
  ggsave(
    pdf_file, fig,
    width = 7.20, height = 4.05,
    units = "in", device = cairo_pdf
  )
} else {
  ggsave(
    pdf_file, fig,
    width = 7.20, height = 4.05,
    units = "in"
  )
}

ggsave(
  png_file, fig,
  width = 7.20, height = 4.05,
  units = "in", dpi = 600
)

write.table(
  node_key,
  file.path(outdir, paste0(prefix, ".node_legend.tsv")),
  sep = "\t", quote = FALSE, row.names = FALSE
)

message("Saved: ", pdf_file)
message("Saved: ", png_file)
