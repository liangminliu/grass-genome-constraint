#!/usr/bin/env Rscript

options(stringsAsFactors = FALSE)
options(warn = 1)

args <- commandArgs(trailingOnly = TRUE)
if (length(args) < 6 || length(args) > 8) {
  stop(
    paste(
      "Usage: Rscript 01_prepare_one_species.R",
      "species_key display_name phylo_root breadth_root outdir target_grasses",
      "[reference_path.tsv|NA] [classification_nodes.tsv|NA]"
    ),
    call. = FALSE
  )
}

species_key    <- args[1]
display_name   <- args[2]
phylo_root     <- normalizePath(args[3], mustWork = TRUE)
breadth_root   <- normalizePath(args[4], mustWork = TRUE)
outdir         <- args[5]
target_grasses <- as.integer(args[6])
ref_override   <- if (length(args) >= 7 && nzchar(args[7]) && args[7] != "NA") args[7] else NA_character_
class_file     <- if (length(args) >= 8 && nzchar(args[8]) && args[8] != "NA") args[8] else NA_character_

dir.create(outdir, recursive = TRUE, showWarnings = FALSE)

## Remove stale QC/failure markers from an earlier run.
stale_files <- file.path(
  outdir,
  c(
    "UNMAPPED_CLASSIFICATION_NODES.tsv",
    "OVERLAPPING_CLASSIFICATION_NODES.tsv",
    "BAD_PHYLO_DEPTH_COMPOSITION.tsv",
    "PREPARED_CLASSIFICATION_LEVELS.tsv"
  )
)
unlink(stale_files[file.exists(stale_files)])

suppressPackageStartupMessages({
  library(dplyr)
})

MAIN_FEATURES <- c(
  "0fold", "4fold", "CDS", "UTR5", "UTR3",
  "promoter", "intron", "intergenic", "TE"
)

FEATURE_LABELS <- c(
  "0fold" = "0-fold",
  "4fold" = "4-fold",
  "CDS" = "CDS",
  "UTR5" = "5′ UTR",
  "UTR3" = "3′ UTR",
  "promoter" = "Promoter",
  "intron" = "Intron",
  "intergenic" = "Intergenic",
  "TE" = "TE"
)

normalize_feature <- function(x) {
  z <- trimws(as.character(x))
  out <- z
  out[z %in% c("0-fold_sites", "0-fold", "0fold", "0_fold", "0-fold site")] <- "0fold"
  out[z %in% c("4-fold_sites", "4-fold", "4fold", "4_fold", "4-fold site")] <- "4fold"
  out[z %in% c("CDS", "CDS_jcvi", "cds")] <- "CDS"
  out[z %in% c("5UTR", "five_prime_UTR", "5_prime_UTR", "5' UTR", "5′ UTR")] <- "UTR5"
  out[z %in% c("3UTR", "three_prime_UTR", "3_prime_UTR", "3' UTR", "3′ UTR")] <- "UTR3"
  out[z %in% c("promoter", "promoters")] <- "promoter"
  out[z %in% c("intron", "introns")] <- "intron"
  out[z %in% c("intergenic", "intergenic_final")] <- "intergenic"
  out[z %in% c("TE", "te", "transposable_element", "transposable_elements")] <- "TE"
  out
}

normalize_threshold <- function(x) {
  z <- trimws(as.character(x))
  z <- gsub("^GERP\\s*>\\s*", "gt", z, ignore.case = TRUE)
  z <- gsub("^>", "gt", z)
  gsub("\\s+", "", z)
}

read_tsv <- function(f) {
  read.delim(
    f, header = TRUE, sep = "\t", quote = "",
    comment.char = "", check.names = FALSE,
    stringsAsFactors = FALSE
  )
}

first_existing <- function(paths) {
  paths <- unique(paths)
  hit <- paths[file.exists(paths)]
  if (length(hit) == 0) return(NA_character_)
  hit[1]
}

## ------------------------------------------------------------
## Species-specific reference-path fallback metadata
## ------------------------------------------------------------
##
## Z. mays ROADIES94_deepest_node does not contain a
## Zmay.reference_path.tsv. In some versions of
## feature.deepest_node.distribution.tsv, node_n_desc is present
## only for the shallowest node or is NA for internal nodes.
##
## The following mapping is taken directly from the supplied
## 94-grass rooted Newick topology and the node IDs used by the
## existing maize deepest-node output. It is used ONLY to fill
## missing descendant counts; non-missing values are never
## overwritten.
##
## Reference-to-root path:
## Zmay(1) -> N0038(2) -> N0031(9) -> N0030(11) ->
## N0016(25) -> N0004(37) -> N0003(92) -> N0002(93) ->
## N0001(94)
## ------------------------------------------------------------

fill_species_descendant_fallback <- function(df) {
  if (!"n_descendant_grasses" %in% names(df) ||
      !"node_id" %in% names(df)) {
    return(df)
  }

  if (species_key == "zmay") {
    zmay_desc <- c(
      "Zmay"  = 1,
      "N0038" = 2,
      "N0031" = 9,
      "N0030" = 11,
      "N0016" = 25,
      "N0004" = 37,
      "N0003" = 92,
      "N0002" = 93,
      "N0001" = 94
    )

    idx <- match(as.character(df$node_id), names(zmay_desc))
    miss <- !is.finite(suppressWarnings(as.numeric(df$n_descendant_grasses))) &
            !is.na(idx)

    if (any(miss)) {
      message(
        "[QC] Z. mays: filling descendant counts from the ",
        "ROADIES94 reference-to-root topology for ",
        sum(miss), " row(s)."
      )
      df$n_descendant_grasses[miss] <- unname(zmay_desc[idx[miss]])
    }
  }

  df
}

weighted_quantile <- function(x, w, p) {
  x <- as.numeric(x)
  w <- as.numeric(w)
  ok <- is.finite(x) & is.finite(w) & w > 0
  x <- x[ok]
  w <- w[ok]
  if (length(x) == 0) return(NA_real_)
  ord <- order(x)
  x <- x[ord]
  w <- w[ord]
  n <- sum(w)
  if (n <= 1) return(x[1])
  cw <- cumsum(w)
  kth <- function(k) {
    k <- max(1, min(k, n))
    x[which(cw >= k)[1]]
  }
  h <- (n - 1) * p + 1
  j <- floor(h)
  g <- h - j
  (1 - g) * kth(j) + g * kth(j + 1)
}

weighted_summary <- function(df, value_col, weight_col) {
  combos <- unique(df[, c("threshold", "feature"), drop = FALSE])
  ans <- lapply(seq_len(nrow(combos)), function(i) {
    z <- df[
      as.character(df$threshold) == as.character(combos$threshold[i]) &
      as.character(df$feature) == as.character(combos$feature[i]),
      , drop = FALSE
    ]
    x <- as.numeric(z[[value_col]])
    w <- as.numeric(z[[weight_col]])
    ok <- is.finite(x) & is.finite(w) & w > 0
    x <- x[ok]
    w <- w[ok]
    out <- combos[i, , drop = FALSE]
    if (length(x) == 0) {
      out$n_weight <- 0
      out$mean <- out$q1 <- out$median <- out$q3 <- NA_real_
      return(out)
    }
    out$n_weight <- sum(w)
    out$mean <- sum(x * w) / sum(w)
    out$q1 <- weighted_quantile(x, w, 0.25)
    out$median <- weighted_quantile(x, w, 0.50)
    out$q3 <- weighted_quantile(x, w, 0.75)
    out
  })
  bind_rows(ans)
}

## ------------------------------------------------------------
## Optional reference path
## ------------------------------------------------------------

get_refpath <- function() {
  if (!is.na(ref_override)) {
    if (!file.exists(ref_override)) {
      stop("Reference-path override does not exist: ", ref_override, call. = FALSE)
    }
    return(normalizePath(ref_override, mustWork = TRUE))
  }
  species_candidates <- switch(
    species_key,
    ped = c("ped.reference_path.tsv", "Ped.reference_path.tsv"),
    zmay = c("Zmay.reference_path.tsv", "zmay.reference_path.tsv"),
    atau = c("Atau.reference_path.tsv", "atau.reference_path.tsv"),
    paste0(species_key, ".reference_path.tsv")
  )
  first_existing(c(
    file.path(phylo_root, "tree", species_candidates),
    file.path(dirname(phylo_root), "tree", species_candidates),
    file.path(phylo_root, species_candidates)
  ))
}

refpath_file <- get_refpath()
ref_std <- NULL
observed_total_grasses <- NA_integer_

if (!is.na(refpath_file)) {
  rr <- read_tsv(refpath_file)
  path_col <- if ("path_level" %in% names(rr)) "path_level" else if ("ref_age_rank" %in% names(rr)) "ref_age_rank" else NA_character_
  node_col <- if ("node_id" %in% names(rr)) "node_id" else NA_character_
  desc_col <- if ("grass_descendants" %in% names(rr)) "grass_descendants" else if ("n_descendant_grasses" %in% names(rr)) "n_descendant_grasses" else if ("n_desc_tips" %in% names(rr)) "n_desc_tips" else NA_character_

  ref_std <- data.frame(
    path_level = if (!is.na(path_col)) suppressWarnings(as.numeric(rr[[path_col]])) else NA_real_,
    node_id = if (!is.na(node_col)) as.character(rr[[node_col]]) else NA_character_,
    n_descendant_grasses = if (!is.na(desc_col)) suppressWarnings(as.numeric(rr[[desc_col]])) else NA_real_,
    stringsAsFactors = FALSE
  )

  vals <- ref_std$n_descendant_grasses
  vals <- vals[is.finite(vals) & vals <= target_grasses]
  if (length(vals) > 0) observed_total_grasses <- max(vals)

  write.table(
    ref_std,
    file.path(outdir, "reference_path.standardized.tsv"),
    sep = "\t", quote = FALSE, row.names = FALSE
  )
}

## ------------------------------------------------------------
## Classification-node map
## Multiple raw/internal nodes may map to one biological branch.
## This is intentional: figures show taxonomic/evolutionary levels,
## not every numerical internal node in the tree.
## ------------------------------------------------------------

class_map <- NULL
if (!is.na(class_file)) {
  if (!file.exists(class_file)) stop("Classification map not found: ", class_file, call. = FALSE)
  cc <- read_tsv(class_file)
  need <- c(
    "species_key", "min_descendant_grasses", "max_descendant_grasses",
    "node_order", "node_label"
  )
  miss <- setdiff(need, names(cc))
  if (length(miss) > 0) stop("classification_nodes.tsv missing: ", paste(miss, collapse = ", "), call. = FALSE)
  class_map <- cc[cc$species_key == species_key, , drop = FALSE]
  if (nrow(class_map) == 0) stop("No classification rows for species_key=", species_key, call. = FALSE)
  class_map$min_descendant_grasses <- as.numeric(class_map$min_descendant_grasses)
  class_map$max_descendant_grasses <- as.numeric(class_map$max_descendant_grasses)
  class_map$node_order <- as.numeric(class_map$node_order)

  ## Publication figures are deliberately standardized to seven
  ## ordered phylogenetic categories for every focal species.
  key7 <- class_map %>%
    select(node_order, node_label) %>%
    distinct() %>%
    arrange(node_order)

  if (nrow(key7) != 7 || !identical(as.integer(key7$node_order), 1:7)) {
    stop(
      species_key,
      ": classification_nodes.tsv must define exactly seven unique ",
      "ordered categories (node_order 1..7).",
      call. = FALSE
    )
  }

  dup_label <- key7 %>% count(node_order) %>% filter(n != 1)
  if (nrow(dup_label) > 0) {
    stop(species_key, ": each node_order must have exactly one node_label.", call. = FALSE)
  }

  write.table(
    key7,
    file.path(outdir, "classification_legend.tsv"),
    sep = "\t", quote = FALSE, row.names = FALSE
  )
}

apply_classification <- function(df) {
  if (is.null(class_map)) {
    df$node_order <- df$path_level
    df$node_label <- ifelse(
      is.finite(df$n_descendant_grasses),
      paste0("Branch ", df$n_descendant_grasses),
      paste0("Path ", df$path_level)
    )
    return(df)
  }

  df$node_order <- NA_real_
  df$node_label <- NA_character_
  df$.classification_hits <- 0L

  for (i in seq_len(nrow(class_map))) {
    hit <- is.finite(df$n_descendant_grasses) &
      df$n_descendant_grasses >= class_map$min_descendant_grasses[i] &
      df$n_descendant_grasses <= class_map$max_descendant_grasses[i]
    df$.classification_hits[hit] <- df$.classification_hits[hit] + 1L
    df$node_order[hit] <- class_map$node_order[i]
    df$node_label[hit] <- class_map$node_label[i]
  }

  if (any(df$.classification_hits > 1L)) {
    overlap <- unique(
      df[df$.classification_hits > 1L,
         c("path_level", "node_id", "n_descendant_grasses"),
         drop = FALSE]
    )
    write.table(
      overlap,
      file.path(outdir, "OVERLAPPING_CLASSIFICATION_NODES.tsv"),
      sep = "\t", quote = FALSE, row.names = FALSE
    )
    stop(
      display_name,
      ": one or more phylogenetic nodes match multiple classification rows. ",
      "Inspect OVERLAPPING_CLASSIFICATION_NODES.tsv.",
      call. = FALSE
    )
  }

  bad <- !is.finite(df$node_order) | is.na(df$node_label) | !nzchar(trimws(df$node_label))
  if (any(bad)) {
    unmapped <- unique(df[bad, c("path_level", "node_id", "n_descendant_grasses"), drop = FALSE])
    write.table(
      unmapped,
      file.path(outdir, "UNMAPPED_CLASSIFICATION_NODES.tsv"),
      sep = "\t", quote = FALSE, row.names = FALSE
    )
    stop(
      display_name,
      ": one or more phylogenetic nodes are not covered by classification_nodes.tsv. ",
      "Inspect UNMAPPED_CLASSIFICATION_NODES.tsv and update the classification map.",
      call. = FALSE
    )
  }

  df$.classification_hits <- NULL
  df
}

## ------------------------------------------------------------
## Locate raw phylogenetic support, if available.
## ------------------------------------------------------------

raw_node_dirs <- c(
  file.path(phylo_root, "phylogenetic_support", "whole", "raw_node_hist"),
  file.path(phylo_root, "whole", "raw_node_hist"),
  file.path(phylo_root, "raw_node_hist")
)
raw_occ_dirs <- c(
  file.path(phylo_root, "phylogenetic_support", "whole", "raw_occupancy_pairs"),
  file.path(phylo_root, "whole", "raw_occupancy_pairs"),
  file.path(phylo_root, "raw_occupancy_pairs")
)

node_files <- unlist(lapply(raw_node_dirs[dir.exists(raw_node_dirs)], function(d) Sys.glob(file.path(d, "*.node_hist.tsv"))))
occ_files <- unlist(lapply(raw_occ_dirs[dir.exists(raw_occ_dirs)], function(d) Sys.glob(file.path(d, "*.occupancy_pairs.tsv"))))
raw_mode <- length(node_files) > 0 && length(occ_files) > 0

raw_nodes <- NULL
raw_occ <- NULL

if (raw_mode) {
  raw_nodes <- bind_rows(lapply(sort(unique(node_files)), read_tsv))
  raw_occ <- bind_rows(lapply(sort(unique(occ_files)), read_tsv))

  needed_node <- c("threshold", "feature", "path_level", "n_sites")
  needed_occ <- c("threshold", "feature", "path_level", "n_all_grass", "occupancy", "n_sites")
  mn <- setdiff(needed_node, names(raw_nodes))
  mo <- setdiff(needed_occ, names(raw_occ))
  if (length(mn) > 0) stop("Raw node tables missing: ", paste(mn, collapse = ", "), call. = FALSE)
  if (length(mo) > 0) stop("Raw occupancy tables missing: ", paste(mo, collapse = ", "), call. = FALSE)

  raw_nodes$threshold <- normalize_threshold(raw_nodes$threshold)
  raw_nodes$feature <- normalize_feature(raw_nodes$feature)
  raw_nodes$path_level <- as.numeric(raw_nodes$path_level)
  raw_nodes$n_sites <- as.numeric(raw_nodes$n_sites)

  if (!"node_id" %in% names(raw_nodes)) raw_nodes$node_id <- NA_character_
  if (!"n_descendant_grasses" %in% names(raw_nodes)) raw_nodes$n_descendant_grasses <- NA_real_
  raw_nodes$n_descendant_grasses <- suppressWarnings(as.numeric(raw_nodes$n_descendant_grasses))

  ## Fill node metadata from reference path if needed.
  if (!is.null(ref_std)) {
    m <- match(raw_nodes$path_level, ref_std$path_level)
    miss_desc <- !is.finite(raw_nodes$n_descendant_grasses)
    raw_nodes$n_descendant_grasses[miss_desc] <- ref_std$n_descendant_grasses[m][miss_desc]
    miss_node <- is.na(raw_nodes$node_id) | !nzchar(as.character(raw_nodes$node_id))
    raw_nodes$node_id[miss_node] <- ref_std$node_id[m][miss_node]
  }

  raw_occ$threshold <- normalize_threshold(raw_occ$threshold)
  raw_occ$feature <- normalize_feature(raw_occ$feature)
  raw_occ$path_level <- as.numeric(raw_occ$path_level)
  raw_occ$n_all_grass <- as.numeric(raw_occ$n_all_grass)
  raw_occ$occupancy <- as.numeric(raw_occ$occupancy)
  raw_occ$n_sites <- as.numeric(raw_occ$n_sites)

  if (any(raw_occ$n_all_grass > target_grasses, na.rm = TRUE)) stop("n_all_grass exceeds target_grasses", call. = FALSE)
  if (any(raw_occ$occupancy < 0 | raw_occ$occupancy > 1, na.rm = TRUE)) stop("occupancy outside [0,1]", call. = FALSE)
}

## ------------------------------------------------------------
## Prepare phylogenetic-depth and occupancy tables.
## ------------------------------------------------------------

deepest_raw <- NULL
occupancy_out <- NULL
phylo_mode <- "none"

if (raw_mode) {
  phylo_mode <- "raw"
  deepest_raw <- raw_nodes %>%
    filter(feature %in% MAIN_FEATURES) %>%
    select(threshold, feature, path_level, node_id, n_descendant_grasses, n_sites)

  occupancy_out <- weighted_summary(
    raw_occ %>% filter(feature %in% MAIN_FEATURES),
    "occupancy", "n_sites"
  )

} else {
  nd_file <- first_existing(c(
    file.path(phylo_root, "summary", "feature.deepest_node.distribution.tsv"),
    file.path(phylo_root, "feature.deepest_node.distribution.tsv")
  ))
  ds_file <- first_existing(c(
    file.path(phylo_root, "summary", "feature.conservation_depth.summary.tsv"),
    file.path(phylo_root, "feature.conservation_depth.summary.tsv")
  ))

  if (!is.na(nd_file) && !is.na(ds_file)) {
    phylo_mode <- "summary"
    nd <- read_tsv(nd_file)
    ds <- read_tsv(ds_file)

    if (!all(c("threshold", "feature", "n_sites") %in% names(nd))) {
      stop("Deepest-node summary lacks threshold/feature/n_sites", call. = FALSE)
    }

    nd$threshold <- normalize_threshold(nd$threshold)
    nd$feature <- normalize_feature(nd$feature)

    deepest_raw <- data.frame(
      threshold = nd$threshold,
      feature = nd$feature,
      path_level = if ("ref_age_rank" %in% names(nd)) as.numeric(nd$ref_age_rank) else if ("path_level" %in% names(nd)) as.numeric(nd$path_level) else NA_real_,
      node_id = if ("deepest_node" %in% names(nd)) as.character(nd$deepest_node) else if ("node_id" %in% names(nd)) as.character(nd$node_id) else NA_character_,
      n_descendant_grasses = if ("node_n_desc" %in% names(nd)) as.numeric(nd$node_n_desc) else if ("n_descendant_grasses" %in% names(nd)) as.numeric(nd$n_descendant_grasses) else NA_real_,
      n_sites = as.numeric(nd$n_sites),
      stringsAsFactors = FALSE
    )

    if (!is.null(ref_std)) {
      if (all(is.finite(deepest_raw$path_level))) {
        m <- match(deepest_raw$path_level, ref_std$path_level)
      } else {
        m <- match(deepest_raw$node_id, ref_std$node_id)
        deepest_raw$path_level <- ref_std$path_level[m]
      }
      miss_desc <- !is.finite(deepest_raw$n_descendant_grasses)
      deepest_raw$n_descendant_grasses[miss_desc] <- ref_std$n_descendant_grasses[m][miss_desc]
    }

    ## Maize-specific fallback when no Zmay.reference_path.tsv exists
    ## and node_n_desc is absent/NA for internal nodes.
    deepest_raw <- fill_species_descendant_fallback(deepest_raw)

    req_ds <- c("threshold", "feature", "mean_node_occupancy", "median_node_occupancy")
    miss_ds <- setdiff(req_ds, names(ds))
    if (length(miss_ds) > 0) stop("Conservation-depth summary missing: ", paste(miss_ds, collapse = ", "), call. = FALSE)

    ds$threshold <- normalize_threshold(ds$threshold)
    ds$feature <- normalize_feature(ds$feature)

    occupancy_out <- data.frame(
      threshold = ds$threshold,
      feature = ds$feature,
      n_weight = if ("n_sites" %in% names(ds)) as.numeric(ds$n_sites) else NA_real_,
      mean = as.numeric(ds$mean_node_occupancy),
      q1 = NA_real_,
      median = as.numeric(ds$median_node_occupancy),
      q3 = NA_real_,
      stringsAsFactors = FALSE
    ) %>% filter(feature %in% MAIN_FEATURES)
  }
}

if (is.null(deepest_raw) || nrow(deepest_raw) == 0) {
  stop(display_name, ": no phylogenetic-depth input was found.", call. = FALSE)
}

## If no reference path was available (maize case), infer the observed
## grass total directly from the deepest-node summary.
if (!is.finite(observed_total_grasses)) {
  vals <- deepest_raw$n_descendant_grasses
  vals <- vals[is.finite(vals) & vals <= target_grasses]
  if (length(vals) > 0) observed_total_grasses <- max(vals)
}

strict94 <- identical(Sys.getenv("STRICT_94", "1"), "1")
allow_atau93 <- identical(Sys.getenv("ALLOW_ATAU_93", "1"), "1")

known_atau93_exception <- (
  species_key == "atau" &&
  allow_atau93 &&
  is.finite(observed_total_grasses) &&
  observed_total_grasses == 93L &&
  target_grasses == 94L
)

if (
  strict94 &&
  is.finite(observed_total_grasses) &&
  observed_total_grasses != target_grasses &&
  !known_atau93_exception
) {
  stop(
    sprintf(
      "%s support data contain %d grasses rather than target %d.",
      display_name, observed_total_grasses, target_grasses
    ),
    call. = FALSE
  )
}

if (known_atau93_exception) {
  warning(
    sprintf(
      paste0(
        "%s phylogenetic-support data contain the documented 93 grasses ",
        "rather than 94. Preparation will continue; all taxonomic-breadth ",
        "fractions retain the common denominator of %d grasses."
      ),
      display_name, target_grasses
    )
  )
} else if (
  !strict94 &&
  is.finite(observed_total_grasses) &&
  observed_total_grasses != target_grasses
) {
  warning(
    sprintf(
      "%s support data contain %d grasses; taxonomic-breadth fractions will still use the common target denominator %d.",
      display_name, observed_total_grasses, target_grasses
    )
  )
}

## Apply biological classification bins and aggregate raw internal nodes.
##
## Publication panel a is a COMPOSITION plot. Every threshold x feature
## must therefore sum to 100% across the seven phylogenetic-depth classes.
## Complete zero-count classes explicitly so plotting never depends on which
## categories happen to be observed for one feature.
classified_counts <- apply_classification(deepest_raw) %>%
  filter(feature %in% MAIN_FEATURES) %>%
  mutate(n_sites = as.numeric(n_sites))

if (any(!is.finite(classified_counts$n_sites) | classified_counts$n_sites < 0)) {
  stop(display_name, ": deepest-node n_sites contains non-finite or negative values.", call. = FALSE)
}

classified_counts <- classified_counts %>%
  group_by(threshold, feature, node_order, node_label) %>%
  summarise(n_sites = sum(n_sites), .groups = "drop")

class_key7 <- class_map %>%
  select(node_order, node_label) %>%
  distinct() %>%
  arrange(node_order)

feature_keys <- classified_counts %>%
  select(threshold, feature) %>%
  distinct()

## Base-R merge(by = NULL) performs a Cartesian product.
depth_grid <- merge(
  feature_keys,
  class_key7,
  by = NULL,
  sort = FALSE
)

deepest_classified <- depth_grid %>%
  left_join(
    classified_counts,
    by = c("threshold", "feature", "node_order", "node_label")
  ) %>%
  mutate(n_sites = ifelse(is.na(n_sites), 0, as.numeric(n_sites))) %>%
  group_by(threshold, feature) %>%
  mutate(
    total_sites = sum(n_sites),
    fraction = ifelse(total_sites > 0, n_sites / total_sites, NA_real_)
  ) %>%
  ungroup() %>%
  mutate(
    species = species_key,
    species_label = display_name,
    feature_label = unname(FEATURE_LABELS[feature])
  )

## Hard QC: each non-empty threshold x feature composition must equal 1.
depth_qc <- deepest_classified %>%
  group_by(threshold, feature) %>%
  summarise(
    total_sites = unique(total_sites)[1],
    n_depth_classes = n(),
    n_nonzero_classes = sum(n_sites > 0),
    sum_fraction = sum(fraction),
    sum_percent = 100 * sum(fraction),
    .groups = "drop"
  )

write.table(
  depth_qc,
  file.path(outdir, "phylo.depth_composition.qc.tsv"),
  sep = "\t", quote = FALSE, row.names = FALSE
)

bad_depth <- !is.finite(depth_qc$total_sites) |
  depth_qc$total_sites <= 0 |
  depth_qc$n_depth_classes != 7 |
  !is.finite(depth_qc$sum_fraction) |
  abs(depth_qc$sum_fraction - 1) > 1e-10

if (any(bad_depth)) {
  write.table(
    depth_qc[bad_depth, , drop = FALSE],
    file.path(outdir, "BAD_PHYLO_DEPTH_COMPOSITION.tsv"),
    sep = "\t", quote = FALSE, row.names = FALSE
  )
  stop(
    display_name,
    ": one or more phylogenetic-depth compositions do not contain seven classes or do not sum to 100%. ",
    "Inspect BAD_PHYLO_DEPTH_COMPOSITION.tsv.",
    call. = FALSE
  )
}

write.table(
  deepest_classified,
  file.path(outdir, "phylo.deepest_node.tsv"),
  sep = "\t", quote = FALSE, row.names = FALSE
)

## Audit table showing exactly how raw descendant counts were collapsed.
class_audit <- apply_classification(deepest_raw) %>%
  select(path_level, node_id, n_descendant_grasses, node_order, node_label) %>%
  distinct() %>%
  arrange(node_order, n_descendant_grasses, path_level)
write.table(
  class_audit,
  file.path(outdir, "classification_nodes.applied.tsv"),
  sep = "\t", quote = FALSE, row.names = FALSE
)

if (is.null(occupancy_out) || nrow(occupancy_out) == 0) {
  stop(display_name, ": no node-occupancy summary was found.", call. = FALSE)
}
occupancy_out <- occupancy_out %>%
  mutate(
    species = species_key,
    species_label = display_name,
    feature_label = unname(FEATURE_LABELS[feature])
  ) %>%
  filter(feature %in% MAIN_FEATURES)
write.table(
  occupancy_out,
  file.path(outdir, "phylo.node_occupancy.summary.tsv"),
  sep = "\t", quote = FALSE, row.names = FALSE
)

## ------------------------------------------------------------
## Taxonomic breadth.
## Prefer species-support histogram; otherwise raw occupancy pairs.
## All three species use the same denominator TARGET_GRASSES=94.
## A missing taxon in one MAF is therefore conservatively treated as
## not aligned rather than silently changing the denominator.
## ------------------------------------------------------------

breadth_hist_candidates <- c(
  file.path(breadth_root, "species_alignment_support", "02_hist", "feature_species_support.hist.tsv"),
  file.path(breadth_root, "02_hist", "feature_species_support.hist.tsv"),
  file.path(breadth_root, "species_support", "feature_species_support.hist.tsv"),
  file.path(breadth_root, "feature_species_support.hist.tsv")
)

breadth_hist_file <- first_existing(breadth_hist_candidates)
breadth_hist <- NULL
breadth_source <- NA_character_

if (!is.na(breadth_hist_file)) {
  breadth_source <- breadth_hist_file
  hh <- read_tsv(breadth_hist_file)
  if (!all(c("threshold", "feature") %in% names(hh))) stop("Breadth histogram lacks threshold/feature", call. = FALSE)

  species_col <- if ("species_count" %in% names(hh)) "species_count" else if ("aligned_species" %in% names(hh)) "aligned_species" else NA_character_
  if (is.na(species_col)) {
    if (!"aligned_fraction" %in% names(hh)) stop("Breadth histogram lacks species_count/aligned_species/aligned_fraction", call. = FALSE)
    denominator <- if ("total_species" %in% names(hh)) as.numeric(hh$total_species) else rep(target_grasses, nrow(hh))
    denominator[!is.finite(denominator)] <- target_grasses
    hh$species_count <- round(as.numeric(hh$aligned_fraction) * denominator)
    species_col <- "species_count"
  }

  weight_col <- if ("n_bp" %in% names(hh)) "n_bp" else if ("n_sites" %in% names(hh)) "n_sites" else NA_character_
  if (is.na(weight_col)) stop("Breadth histogram lacks n_bp/n_sites", call. = FALSE)

  breadth_hist <- data.frame(
    threshold = normalize_threshold(hh$threshold),
    feature = normalize_feature(hh$feature),
    species_count = as.numeric(hh[[species_col]]),
    n_sites = as.numeric(hh[[weight_col]]),
    stringsAsFactors = FALSE
  )

} else if (!is.null(raw_occ)) {
  breadth_source <- "raw_occupancy_pairs"
  breadth_hist <- raw_occ %>%
    transmute(
      threshold = normalize_threshold(threshold),
      feature = normalize_feature(feature),
      species_count = as.numeric(n_all_grass),
      n_sites = as.numeric(n_sites)
    ) %>%
    group_by(threshold, feature, species_count) %>%
    summarise(n_sites = sum(n_sites), .groups = "drop")
}

if (is.null(breadth_hist)) stop(display_name, ": no taxonomic-breadth histogram found.", call. = FALSE)

breadth_hist <- breadth_hist %>% filter(feature %in% MAIN_FEATURES)
if (any(breadth_hist$species_count > target_grasses, na.rm = TRUE)) stop("species_count exceeds target_grasses", call. = FALSE)

breadth_summary <- weighted_summary(breadth_hist, "species_count", "n_sites") %>%
  mutate(
    species = species_key,
    species_label = display_name,
    feature_label = unname(FEATURE_LABELS[feature])
  )

breadth_hist <- breadth_hist %>%
  mutate(
    aligned_fraction = species_count / target_grasses,
    depth_bin = cut(
      aligned_fraction,
      breaks = c(-Inf, 0.25, 0.50, 0.75, 0.90, Inf),
      labels = c("<25%", "25–50%", "50–75%", "75–90%", "≥90%"),
      right = FALSE
    ),
    species = species_key,
    species_label = display_name,
    feature_label = unname(FEATURE_LABELS[feature])
  )

breadth_comp <- breadth_hist %>%
  group_by(species, species_label, threshold, feature, feature_label, depth_bin) %>%
  summarise(n_sites = sum(n_sites), .groups = "drop") %>%
  group_by(species, species_label, threshold, feature, feature_label) %>%
  mutate(total_sites = sum(n_sites), percent_sites = 100 * n_sites / total_sites) %>%
  ungroup()

write.table(breadth_summary, file.path(outdir, "taxonomic_breadth.summary.tsv"), sep = "\t", quote = FALSE, row.names = FALSE)
write.table(breadth_hist, file.path(outdir, "taxonomic_breadth.hist.tsv"), sep = "\t", quote = FALSE, row.names = FALSE)
write.table(breadth_comp, file.path(outdir, "taxonomic_breadth.composition.tsv"), sep = "\t", quote = FALSE, row.names = FALSE)

status <- data.frame(
  species = species_key,
  species_label = display_name,
  phylo_root = phylo_root,
  breadth_root = breadth_root,
  reference_path = ifelse(is.na(refpath_file), "", refpath_file),
  phylo_mode = phylo_mode,
  breadth_source = breadth_source,
  target_grasses = target_grasses,
  observed_total_grasses = observed_total_grasses,
  missing_grasses = ifelse(
    is.finite(observed_total_grasses),
    target_grasses - observed_total_grasses,
    NA_integer_
  ),
  known_atau93_exception = known_atau93_exception,
  classification_map = ifelse(is.na(class_file), "", class_file),
  stringsAsFactors = FALSE
)
write.table(status, file.path(outdir, "prep_status.tsv"), sep = "\t", quote = FALSE, row.names = FALSE)

message("============================================================")
message("Prepared standardized support tables")
message("Species: ", display_name)
message("Phylogenetic-support mode: ", phylo_mode)
message("Observed grasses in phylogenetic support: ", observed_total_grasses)
message("Common breadth denominator: ", target_grasses)
message("Breadth source: ", breadth_source)
message("Output: ", normalizePath(outdir, mustWork = TRUE))
message("============================================================")
