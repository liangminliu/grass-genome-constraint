#!/usr/bin/env Rscript

options(stringsAsFactors = FALSE)
options(warn = 1)

args <- commandArgs(trailingOnly = TRUE)
if (length(args) != 4) {
  stop(
    "Usage: Rscript 03_plot_cross_species_threshold_breadth.R prepared_root outdir target_grasses strict_flag",
    call. = FALSE
  )
}

prepared_root <- normalizePath(args[1], mustWork = TRUE)
outdir <- args[2]
target_grasses <- as.integer(args[3])
strict_flag <- as.integer(args[4])
allow_atau93 <- identical(Sys.getenv("ALLOW_ATAU_93", "1"), "1")

dir.create(outdir, recursive = TRUE, showWarnings = FALSE)

suppressPackageStartupMessages({
  library(ggplot2)
  library(dplyr)
})

SPECIES_ORDER <- c("ped", "zmay", "atau")
SPECIES_LABELS <- c(
  ped = "P. edulis",
  zmay = "Z. mays",
  atau = "A. tauschii"
)

THRESHOLD_ORDER <- c("gt0", "gt2", "gt4", "gt6")
THRESHOLD_LABELS <- c(
  gt0 = "GERP > 0",
  gt2 = "GERP > 2",
  gt4 = "GERP > 4",
  gt6 = "GERP > 6"
)

MAIN_FEATURES <- c(
  "0fold", "4fold", "CDS", "UTR5", "UTR3",
  "promoter", "intron", "intergenic", "TE"
)

FEATURE_LABELS <- c(
  "0fold" = "0-fold",
  "4fold" = "4-fold",
  "CDS" = "CDS",
  "UTR5" = "5′ UTR",
  "UTR3" = "3′ UTR",
  "promoter" = "Promoter",
  "intron" = "Intron",
  "intergenic" = "Intergenic",
  "TE" = "TE"
)

BREADTH_PALETTE <- c(
  "<25%" = "#ECEFF1",
  "25–50%" = "#D4DDE2",
  "50–75%" = "#AEBEC6",
  "75–90%" = "#7E96A1",
  "≥90%" = "#425E69"
)

read_tsv <- function(f) {
  if (!file.exists(f)) stop("Missing: ", f, call. = FALSE)
  read.delim(
    f, sep = "\t", header = TRUE, quote = "",
    comment.char = "", check.names = FALSE,
    stringsAsFactors = FALSE
  )
}

tables <- lapply(SPECIES_ORDER, function(sp) {
  d <- file.path(prepared_root, sp)
  status <- read_tsv(file.path(d, "prep_status.tsv"))

  if (strict_flag == 1) {
    if (as.integer(status$target_grasses[1]) != target_grasses) {
      stop(sp, ": target_grasses mismatch.", call. = FALSE)
    }
    obs <- suppressWarnings(as.integer(status$observed_total_grasses[1]))
    known_atau93_exception <- (
      sp == "atau" &&
      allow_atau93 &&
      is.finite(obs) &&
      obs == 93L &&
      target_grasses == 94L
    )

    if (
      is.finite(obs) &&
      obs != target_grasses &&
      !known_atau93_exception
    ) {
      stop(
        sp, ": observed grasses = ", obs,
        ", expected ", target_grasses,
        ". Final cross-species figure aborted.",
        call. = FALSE
      )
    }

    if (known_atau93_exception) {
      warning(
        "A. tauschii uses the documented 93-tip phylogenetic-support dataset; ",
        "the common taxonomic-breadth denominator remains 94 grasses."
      )
    }
  }

  x <- read_tsv(file.path(d, "taxonomic_breadth.composition.tsv"))
  x$species <- sp
  x
})

dat <- bind_rows(tables) %>%
  filter(
    threshold %in% THRESHOLD_ORDER,
    feature %in% MAIN_FEATURES
  )

dat$species_f <- factor(
  dat$species,
  levels = SPECIES_ORDER,
  labels = unname(SPECIES_LABELS[SPECIES_ORDER])
)

dat$threshold_f <- factor(
  dat$threshold,
  levels = THRESHOLD_ORDER,
  labels = unname(THRESHOLD_LABELS[THRESHOLD_ORDER])
)

feature_levels <- unname(FEATURE_LABELS[MAIN_FEATURES])
dat$Feature <- factor(
  unname(FEATURE_LABELS[dat$feature]),
  levels = rev(feature_levels)
)

dat$depth_bin <- factor(
  dat$depth_bin,
  levels = names(BREADTH_PALETTE)
)

## Check each species x threshold x feature sums to ~100%.
qc <- dat %>%
  group_by(species, threshold, feature) %>%
  summarise(sum_percent = sum(percent_sites), .groups = "drop")

bad <- abs(qc$sum_percent - 100) > 1e-6
if (any(bad)) {
  stop("Breadth composition does not sum to 100% for one or more groups.", call. = FALSE)
}

theme_threshold <- theme_classic(
  base_size = 7.0,
  base_family = "sans"
) +
  theme(
    axis.line = element_line(linewidth = 0.32, colour = "#303030"),
    axis.ticks = element_line(linewidth = 0.30, colour = "#303030"),
    axis.text = element_text(size = 6.3, colour = "#303030"),
    axis.title = element_text(size = 7.0, colour = "#202020"),
    strip.background = element_blank(),
    strip.text.x = element_text(size = 6.7, face = "bold"),
    strip.text.y = element_text(size = 6.7, face = "italic"),
    legend.title = element_text(size = 6.5),
    legend.text = element_text(size = 6.2),
    legend.position = "bottom",
    panel.spacing.x = grid::unit(3.0, "mm"),
    panel.spacing.y = grid::unit(4.0, "mm"),
    plot.margin = margin(4, 4, 4, 4)
  )

p <- ggplot(
  dat,
  aes(
    y = Feature,
    x = percent_sites,
    fill = depth_bin
  )
) +
  geom_col(
    width = 0.72,
    colour = NA
  ) +
  facet_grid(
    rows = vars(species_f),
    cols = vars(threshold_f),
    scales = "fixed",
    switch = "y"
  ) +
  scale_fill_manual(
    values = BREADTH_PALETTE,
    drop = FALSE
  ) +
  scale_x_continuous(
    limits = c(0, 100),
    breaks = c(0, 50, 100),
    labels = function(x) paste0(x, "%"),
    expand = expansion(mult = c(0, 0))
  ) +
  labs(
    x = "Constrained sites",
    y = NULL,
    fill = "Aligned-species fraction"
  ) +
  theme_threshold +
  theme(
    strip.placement = "outside"
  )

prefix <- "FigS_cross_species_taxonomic_breadth_all_GERP_thresholds"

pdf_file <- file.path(outdir, paste0(prefix, ".pdf"))
png_file <- file.path(outdir, paste0(prefix, ".png"))

if (capabilities("cairo")) {
  ggsave(
    pdf_file, p,
    width = 7.20, height = 7.75,
    units = "in", device = cairo_pdf
  )
} else {
  ggsave(
    pdf_file, p,
    width = 7.20, height = 7.75,
    units = "in"
  )
}

ggsave(
  png_file, p,
  width = 7.20, height = 7.75,
  units = "in", dpi = 600
)

write.table(
  dat,
  file.path(outdir, paste0(prefix, ".plotting_table.tsv")),
  sep = "\t", quote = FALSE, row.names = FALSE
)

message("Saved: ", pdf_file)
message("Saved: ", png_file)
