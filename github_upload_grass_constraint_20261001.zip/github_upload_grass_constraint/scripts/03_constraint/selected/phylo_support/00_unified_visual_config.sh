#!/bin/bash

# ============================================================
# Unified publication visualization configuration
# ============================================================

export TARGET_GRASSES=94

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
export SCRIPT_DIR

# ------------------------------------------------------------
# Zea mays
# Phylogenetic-depth summaries are under ROADIES94_deepest_node.
# Taxonomic-breadth histograms are under gerp_conservation_results.
# A separate Zmay.reference_path.tsv is not required because the
# deepest-node summary already contains ref_age_rank/node_n_desc.
# ------------------------------------------------------------
export Z_BREADTH_ROOT="/ds3200_1/users_root/liuliangmin/workspace/PHD/2.msa/Zmay/Zmay_v5_results/GERP_output/02.constrain_stat/gerp_conservation_results"
export Z_PHYLO_ROOT="$Z_BREADTH_ROOT/ROADIES94_deepest_node"
export Z_REFPATH="NA"

# ------------------------------------------------------------
# Phyllostachys edulis
# 94-grass support calculated from the 97-species MAF/tree.
# The raw whole-genome node/occupancy tables are preferred.
# ------------------------------------------------------------
export PED_ROOT="/ds3200_1/users_root/liuliangmin/workspace/PHD/2.msa/2.2.ped_result_stat/2.2.constrain_stat/Ped94_phylogenetic_support_from97MAF"
export PED_BREADTH_ROOT="$PED_ROOT"
export PED_REFPATH="$PED_ROOT/tree/ped.reference_path.tsv"

# ------------------------------------------------------------
# Aegilops tauschii
# Current support result contains 93 observed tips; the common
# breadth denominator remains the 94-grass target panel.
# ------------------------------------------------------------
export ATAU_ROOT="/ds3200_1/users_root/liuliangmin/workspace/PHD/2.msa/Atau_msa/results/GERP_output/02.constrain_stat/gerp_conservation_results/Atau94_phylogenetic_support"
export ATAU_BREADTH_ROOT="$ATAU_ROOT"
export ATAU_REFPATH="$ATAU_ROOT/tree/Atau.reference_path.tsv"

# ------------------------------------------------------------
# Biological classification-node map
# ------------------------------------------------------------
export CLASSIFICATION_MAP="$SCRIPT_DIR/metadata/classification_nodes.tsv"

# ------------------------------------------------------------
# New outputs only; never overwrite source pipeline results.
# ------------------------------------------------------------
export UNIFIED_VIS_ROOT="$SCRIPT_DIR/output"

# Final comparison denominator is 94 grasses.
# Ped and Zmay are required to contain all 94 grasses.
# Current Atau support is a documented 93-tip dataset; allow exactly
# this known exception while retaining 94 as the common denominator.
export STRICT_94="${STRICT_94:-1}"
export ALLOW_ATAU_93="${ALLOW_ATAU_93:-1}"
