#!/bin/bash
#SBATCH --job-name=gerp_target_stats
#SBATCH --partition=parallel
#SBATCH --nodes=1
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=10
#SBATCH --array=1-4
#SBATCH --output=logs/gerp_target_%A_%a.out
#SBATCH --error=logs/gerp_target_%A_%a.err

set -euo pipefail
module load bedtools 2>/dev/null || true

############################################################
# 0. 路径配置
############################################################
PAN="core_5sp_1to1.SG.pan"

BASE_GERP_DIR="/gpfs/hpc/home/kib_unit/lidezhu/liuliangmin/2.msa/Atau_msa/results/GERP_output/02.constrain_stat/gerp_conservation_results"

GENE_BED="genes.bed"
CDS_BED="CDS.gene.merged.bed"

OUT_ROOT="target_gene_CDS_GERP_stats"
mkdir -p logs "${OUT_ROOT}"

############################################################
# 1. array 参数
############################################################
class=("gt0" "gt2" "gt4" "gt6")
idx=$((SLURM_ARRAY_TASK_ID - 1))
if [[ $idx -lt 0 || $idx -ge ${#class[@]} ]]; then
  echo "[ERROR] Bad SLURM_ARRAY_TASK_ID=$SLURM_ARRAY_TASK_ID" >&2
  exit 1
fi
Class="${class[$idx]}"

OUT_DIR="${OUT_ROOT}/${Class}"
BED_DIR="${OUT_DIR}/bed_files"
STAT_DIR="${OUT_DIR}/stats"
mkdir -p "${BED_DIR}" "${STAT_DIR}"

echo "[INFO] Processing ${Class}"

############################################################
# 2. 自动识别 gene / CDS GERP 文件
############################################################
# gene
GENE_GERP1="${BASE_GERP_DIR}/${Class}/bed_files/genes_GERP_feature.bed"
GENE_GERP2="${BASE_GERP_DIR}/${Class}/bed_files/genes_conserved_sites.bed"

if [[ -s "${GENE_GERP1}" ]]; then
  GENE_GERP="${GENE_GERP1}"
elif [[ -s "${GENE_GERP2}" ]]; then
  GENE_GERP="${GENE_GERP2}"
else
  echo "[ERROR] No gene GERP file for ${Class}" >&2
  exit 1
fi

# CDS（关键修复点）
CDS_GERP1="${BASE_GERP_DIR}/${Class}/bed_files/CDS_GERP_feature.bed"
CDS_GERP2="${BASE_GERP_DIR}/${Class}/bed_files/CDS_conserved_sites.bed"

if [[ -s "${CDS_GERP1}" ]]; then
  CDS_GERP="${CDS_GERP1}"
elif [[ -s "${CDS_GERP2}" ]]; then
  CDS_GERP="${CDS_GERP2}"
else
  echo "[WARN] No CDS GERP file for ${Class}, CDS will be skipped"
  HAS_CDS=0
fi

HAS_CDS=1
echo "[INFO] gene GERP: $(basename "${GENE_GERP}")"
echo "[INFO] CDS  GERP: $(basename "${CDS_GERP}")"

############################################################
# 3. 提取目标 Atau 基因列表（PAN 第5列）
############################################################
TARGET_GENE_LIST="${OUT_DIR}/target_gene_ids.txt"
awk 'BEGIN{FS="\t"} $5!=""{
  g=$5; sub(/^Atau_/,"",g); print g
}' "${PAN}" | sort -u > "${TARGET_GENE_LIST}"

echo "[INFO] Target genes: $(wc -l < "${TARGET_GENE_LIST}")"

############################################################
# 4. 规范化 gene / CDS bed
############################################################
GENE4="${OUT_DIR}/genes.4col.bed"
CDS4="${OUT_DIR}/CDS.4col.bed"

awk 'BEGIN{OFS="\t"}{
  g=$4; sub(/^gene:/,"",g); print $1,$2,$3,g
}' "${GENE_BED}" | sort -k1,1 -k2,2n > "${GENE4}"

awk 'BEGIN{OFS="\t"}{ print $1,$2,$3,$4 }' "${CDS_BED}" \
  | sort -k1,1 -k2,2n > "${CDS4}"

############################################################
# 5. 生成 target gene / CDS bed
############################################################
TARGET_GENE_BED="${BED_DIR}/target_genes.bed"
TARGET_CDS_BED="${BED_DIR}/target_CDS.bed"

awk 'NR==FNR{a[$1]=1;next} a[$4]' \
  "${TARGET_GENE_LIST}" "${GENE4}" > "${TARGET_GENE_BED}"

awk 'NR==FNR{a[$1]=1;next} a[$4]' \
  "${TARGET_GENE_LIST}" "${CDS4}" > "${TARGET_CDS_BED}"

############################################################
# 6. GERP 位点 ∩ target gene / CDS
############################################################
GENE_CONS="${BED_DIR}/gene_conserved_sites.bed"
CDS_CONS="${BED_DIR}/CDS_conserved_sites.bed"

bedtools intersect -wa -wb \
  -a "${GENE_GERP}" \
  -b "${TARGET_GENE_BED}" \
> "${GENE_CONS}"

if [[ "${HAS_CDS}" -eq 1 ]]; then
  bedtools intersect -wa -wb \
    -a "${CDS_GERP}" \
    -b "${TARGET_CDS_BED}" \
  > "${CDS_CONS}"
fi

############################################################
# 7. gene / CDS 长度
############################################################
awk 'BEGIN{OFS="\t"}{ print $4, $3-$2 }' "${TARGET_GENE_BED}" \
  | sort -k1,1 > "${STAT_DIR}/gene_length.tsv"

TARGET_CDS_SORTED="${OUT_DIR}/target_CDS.byGene.sorted.bed"
sort -k4,4 -k1,1 -k2,2n "${TARGET_CDS_BED}" > "${TARGET_CDS_SORTED}"

awk '
BEGIN{OFS="\t"}
{
  g=$4; chr=$1; s=$2; e=$3
  if(NR==1){cg=g; cchr=chr; cs=s; ce=e; sum=0; next}
  if(g!=cg || chr!=cchr){
    sum += (ce - cs)
    print cg, sum
    cg=g; cchr=chr; cs=s; ce=e; sum=0
    next
  }
  if(s <= ce){
    if(e > ce) ce=e
  } else {
    sum += (ce - cs)
    cs=s; ce=e
  }
}
END{
  if(NR>0){
    sum += (ce - cs)
    print cg, sum
  }
}
' "${TARGET_CDS_SORTED}" | sort -k1,1 > "${STAT_DIR}/cds_length.tsv"

############################################################
# 8. gene / CDS 保守位点数（1bp 去重）
############################################################
awk 'BEGIN{OFS="\t"}{
  key=$1"\t"$2"\t"$3"\t"$NF
  if(!seen[key]++) c[$NF]++
}
END{ for(g in c) print g, c[g] }' \
"${GENE_CONS}" | sort -k1,1 > "${STAT_DIR}/gene_site_count.tsv"

if [[ "${HAS_CDS}" -eq 1 ]]; then
  awk 'BEGIN{OFS="\t"}{
    key=$1"\t"$2"\t"$3"\t"$NF
    if(!seen[key]++) c[$NF]++
  }
  END{ for(g in c) print g, c[g] }' \
  "${CDS_CONS}" | sort -k1,1 > "${STAT_DIR}/cds_site_count.tsv"
else
  awk 'BEGIN{OFS="\t"}{ print $1,0 }' "${STAT_DIR}/gene_length.tsv" \
    > "${STAT_DIR}/cds_site_count.tsv"
fi

############################################################
# 9. 合并最终表
############################################################
join -t $'\t' -a 1 -e 0 -o 1.1,1.2,2.2 \
  "${STAT_DIR}/gene_length.tsv" "${STAT_DIR}/cds_length.tsv" \
  > "${STAT_DIR}/tmp_lengths.tsv"

join -t $'\t' -a 1 -e 0 -o 1.1,1.2,2.2 \
  "${STAT_DIR}/gene_site_count.tsv" "${STAT_DIR}/cds_site_count.tsv" \
  > "${STAT_DIR}/tmp_sites.tsv"

join -t $'\t' -a 1 -e 0 \
  "${STAT_DIR}/tmp_lengths.tsv" "${STAT_DIR}/tmp_sites.tsv" \
| awk 'BEGIN{
    OFS="\t";
    print "gene_id","gene_len","cds_len","gene_sites","gene_pct","cds_sites","cds_pct"
  }
  {
    gl=$2+0; cl=$3+0; gs=$4+0; cs=$5+0
    gp=(gl>0)?gs/gl*100:0
    cp=(cl>0)?cs/cl*100:0
    printf "%s\t%d\t%d\t%d\t%.6f\t%d\t%.6f\n",$1,gl,cl,gs,gp,cs,cp
  }' \
> "${OUT_DIR}/per_gene_stats.tsv"

rm -f "${STAT_DIR}/tmp_lengths.tsv" "${STAT_DIR}/tmp_sites.tsv"

echo "[INFO] Finished ${Class}"
