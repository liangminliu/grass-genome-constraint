#!/usr/bin/env bash
set -euo pipefail

BASE_DIR="Zmay_target_gene_CDS_GERP_stats"
OUT="Zmay_genome_wide_CDS_conserved_ratio.tsv"

echo -e "species\tgerp_threshold\tcds_conserved_sites\tcds_length\tcds_conserved_ratio" > "${OUT}"

for TH in gt2 gt4 gt6; do
  FILE="${BASE_DIR}/${TH}/per_gene_stats.tsv"

  if [[ ! -s "${FILE}" ]]; then
    echo "[ERROR] Missing ${FILE}" >&2
    exit 1
  fi

  awk -v th="${TH}" '
  BEGIN{
    OFS="\t"
    sum_sites=0
    sum_len=0
  }
  NR>1{
    sum_len   += $3   # cds_len
    sum_sites += $7   # cds_sites
  }
  END{
    ratio = (sum_len>0)? sum_sites/sum_len : 0
    printf "Zmay\t%s\t%d\t%d\t%.8f\n",
           th, sum_sites, sum_len, ratio
  }
  ' "${FILE}" >> "${OUT}"
done

echo "[INFO] Wrote ${OUT}"
