# GERP-based evolutionary constraint

Methods: fourfold-site extraction, trimAl occupancy >90%, RAxML GTRGAMMA tree, phyloFit REV neutral model and GERP++ `gerpcol -j -z` with focal reference excluded. Cumulative GERP thresholds are >2, >4 and >6. Results: Figs. 3–4, S1–S4 and Table S2.

| Order | Selected script | Role |
|---|---|---|
| 1 | `selected/call_conservation.smk` | neutral-model/GERP workflow rule candidate |
| 2 | `selected/ped/`, `selected/zmay/`, `selected/atau/` `run_gerp_gene_cds_stats_array.sh` | three distinct per-gene CDS threshold scripts recovered from the N-drive species directories |
| 3 | `selected/compute_ped_genome_wide_CDS_conserved_ratio.sh`, `selected/compute_Zmay_genome_wide_CDS_conserved_ratio.sh`, `selected/compute_genome_wide_CDS_conserved_ratio.sh` | focal-species coding summaries |
| 4 | `selected/region_annotation/` | GERP-category intersections and bamboo C/D plus three-species region pies |
| 5 | `selected/gerp_histogram/` | author-supplied bamboo all-site/CDS GERP histogram and corrected LSF plotting job |

`source_candidates/` contains other scoring, annotation and plotting jobs. The exact 4d alignments, fitted neutral trees, per-base GERP files, callable/alignable masks, window definitions, and GO background lists remain required. Several source scripts use historical threshold labels; use the cumulative definitions above and audit source columns before reuse.

The region annotation subflow uses eight SLURM array tasks to overlap PedC/PedD threshold BEDs with genomic-category BEDs. Its two pie scripts require separately curated summary tables; see `selected/region_annotation/README.md` for input names and the overlap-count denominator limitation. The multi-species input assembler remains missing.

The histogram subflow plots bamboo all-site and C/D CDS GERP distributions from three TSV files. Its original job wrapper checked a different Python filename than the one it executed; the release wrapper fixes that check. The author associated this plot with Fig. 3A, but the current manuscript describes Fig. 3A as chromosome tracks and Fig. 4A as GERP-score distributions. See `selected/gerp_histogram/README.md` before assigning a figure number.

The release driver in `../02_alignment/selected/run_msa_with_existing_tree.sh` can invoke the `call_conservation` target after ROAST. Its ROADIES input is the multiple-alignment guide topology; this conservation stage builds a separate RAxML/phyloFit neutral tree from the fourfold-site alignment.

The LSF root also supplied `selected/phylo_support/` (three-species support plots) and two packaged bamboo 97-MAF → 94-grass support implementations. The later `grass94_pipeline/` archive is under `selected/`; the earlier `Ped94_from97MAF_pipeline/` remains under `source_candidates/`. Both exclude three outgroups in memory. The later archive timestamp alone does not prove which generated the manuscript display.

See `SCRIPT_INDEX.tsv` for every recovered file and its source.
