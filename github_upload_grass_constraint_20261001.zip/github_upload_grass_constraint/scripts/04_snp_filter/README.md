# Population SNP filtering

Methods: fastp; BWA-MEM; SAMtools sorting and mapping-quality filtering; Picard duplicate removal; GATK HaplotypeCaller, GenomicsDBImport and GenotypeGVCFs; GATK hard filters; KING unrelated selection; then genotype/site filters with VCFtools. Final panels: 63 bamboo, 90 teosinte and 140 *A. tauschii* individuals.

| Order | Selected script | Role |
|---|---|---|
| 1 | `selected/zmay/step1_mapping_scripts.sh` | actual teosinte BWA-MEM, SAMtools and duplicate-removal job generator found in LSF |
| 2 | `selected/zmay/step2_mutiple.gatk.sh`, `selected/step3_mutiple.GenomicsDB.sh`, `selected/submit_process_genotype_parallel.sh` | teosinte HaplotypeCaller/joint-genotyping candidates |
| 3 | `selected/zmay/step5.all.snp_filter.sh` | teosinte GATK SelectVariants/VariantFiltration matching the Methods expression |
| 4 | `selected/step2_run_king_unrelation.sh`, `selected/step3_run_king_unrelation.sh` | unrelated-sample selection candidates |
| 5 | `source_candidates/step1_vcf_filter.sh`, `source_candidates/step1_run_vcftools_analysis.sh` | earlier goatgrass 141-sample filtering and an older VCFtools summary; final post-KING filter needs verification |

`source_candidates/` includes earlier chromosome-specific jobs, an old bamboo HaplotypeCaller job, and a Bowtie2 mapping pipeline, which does not match the Methods BWA-MEM description. The teosinte BWA/GATK source was newly found; a matching bamboo fastp→BWA→Picard chain, the final KING sample-selection output and final sample sheet remain unresolved. Confirm final VCF and sample hashes before calling the filtering workflow reproduced.

`drafts/01_fastp_bwa_picard_gvcf.sh` sketches the Methods read-processing and per-sample gVCF steps with explicit inputs. It is new code and has not been checked against the historical run logs or run on study data.

See `SCRIPT_INDEX.tsv` for every recovered file and its source.
