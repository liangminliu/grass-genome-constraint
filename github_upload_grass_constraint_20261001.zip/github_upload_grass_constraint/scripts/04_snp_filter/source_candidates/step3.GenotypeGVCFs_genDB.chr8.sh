#!/bin/bash
#SBATCH --partition=parallel
#SBATCH --job-name=chr8.genDB.out
#SBATCH --output=%J.genDB.chr8.out
#SBATCH --error=%J.genDB.chr8.err
#SBATCH --ntasks=1
#SBATCH --nodes=1
#SBATCH --nodelist=cu22
#SBATCH --cpus-per-task=20

singularity exec  ../software/Reseq_genek.sif gatk  --java-options "-Xms400g -Xmx400g -Djava.io.tmpdir=./tmp" GenotypeGVCFs -R ../01.ref/Zmay.fa  -V gendb://genomeDB.chr8 -O chr8.raw.vcf.gz  1>chr8.GenotypeGVCFs.log   2>&1 
