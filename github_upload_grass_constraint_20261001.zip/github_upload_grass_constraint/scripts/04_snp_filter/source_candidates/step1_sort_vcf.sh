#!/bin/bash
#SBATCH --job-name=mainChr_extract
#SBATCH --output=mainChr_extract_%j.out
#SBATCH --error=mainChr_extract_%j.err
#SBATCH --cpus-per-task=16
#SBATCH --partition=parallel

set -euo pipefail

# ========= 用户自定义路径 =========
IMG="/gpfs/hpc/home/kib_unit/lidezhu/liuliangmin/4.may/software/Reseq_genek.sif"
VCF_IN="63sp.filtered.bi-allelic.snp.renamed.vcf.gz"
CHR_LIST_RAW="chromosomes_order.list"   # 一列主染色体（Ped01C...Ped12D）
OUT_PREFIX="63sp.filtered.mainChr"

# ========= 准备工作 =========
mkdir -p tmp_sort

# 1) 清洗 chr 列表（去 CR、去空格、去空行、保留第一列）
awk '{
  gsub(/\r/, "", $0);                      # 去 CR
  gsub(/^[ \t]+|[ \t]+$/, "", $0);         # 去首尾空白
  if ($1!="") print $1
}' "${CHR_LIST_RAW}" | uniq > chromosomes_order.fixed.list

echo "[INFO] Cleaned list -> chromosomes_order.fixed.list"
echo "[INFO] First few:"
head chromosomes_order.fixed.list

# 2) 用 -r 传入所有染色体（无需三列表）
REGIONS=$(paste -sd, chromosomes_order.fixed.list)

echo "[INFO] Extracting main chromosomes with -r ..."
singularity exec "${IMG}" \
  bcftools view -r "${REGIONS}" -Oz -o "${OUT_PREFIX}.vcf.gz" "${VCF_IN}"

# 3) 按顺序排序（使用 --contig-order）
echo "[INFO] Sorting by contig order ..."
singularity exec "${IMG}" \
  bcftools sort --contig-order chromosomes_order.fixed.list -T tmp_sort \
  -Oz -o "${OUT_PREFIX}.sorted.vcf.gz" "${OUT_PREFIX}.vcf.gz"

# 4) 用 reheader 把 header 中 ##contig 顺序也更新（可选但推荐）
echo "[INFO] Reheader contigs ..."
singularity exec "${IMG}" \
  bcftools reheader --contigs chromosomes_order.fixed.list \
  -o "${OUT_PREFIX}.sorted.reheader.vcf.gz" "${OUT_PREFIX}.sorted.vcf.gz"

# 5) 建立索引
echo "[INFO] Indexing ..."
singularity exec "${IMG}" bcftools index -t "${OUT_PREFIX}.sorted.reheader.vcf.gz"

echo "[DONE] Output: ${OUT_PREFIX}.sorted.reheader.vcf.gz"
