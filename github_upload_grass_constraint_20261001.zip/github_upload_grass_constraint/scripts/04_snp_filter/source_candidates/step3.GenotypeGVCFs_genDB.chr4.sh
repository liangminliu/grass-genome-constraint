#!/bin/bash
#SBATCH --partition=FAT2
#SBATCH --job-name=chr4.genDB.out
#SBATCH --output=%J.genDB.chr4.out
#SBATCH --error=%J.genDB.chr4.err
#SBATCH --ntasks=1
#SBATCH --nodes=1
#SBATCH --cpus-per-task=4

singularity exec  ../software/Reseq_genek.sif gatk  --java-options "-Xms1000g -Xmx1600g -Djava.io.tmpdir=./tmp" GenotypeGVCFs -R ../01.ref/Zmay.fa  -V gendb://genomeDB.chr4 -O chr4.raw.vcf.gz  1>chr4.GenotypeGVCFs.log   2>&1 
