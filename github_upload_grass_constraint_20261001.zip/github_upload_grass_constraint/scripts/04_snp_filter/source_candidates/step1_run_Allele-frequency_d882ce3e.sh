#!/bin/bash
#SBATCH --job-name=deleterious_maf
#SBATCH --partition=parallel
#SBATCH --cpus-per-task=4
#SBATCH --output=deleterious_maf.%j.out
#SBATCH --error=deleterious_maf.%j.err

set -euo pipefail

############################################
# Input (modify here)
############################################
SIF="/gpfs/hpc/home/kib_unit/lidezhu/liuliangmin/4.may/software/Reseq_genek.sif"

VCF_GT2="Zmay.merged_gt2_snps.vcf.gz"
VCF_GT4="Zmay.merged_gt4_snps.vcf.gz"

############################################
# Function
############################################
calc_maf () {
  vcf=$1
  prefix=$2

  echo ">>> Processing $vcf"

  singularity exec "$SIF" bcftools query \
    -f '%CHROM\t%POS\t%INFO/AF\n' \
    "$vcf" \
  | awk '
  {
    af = $3;
    if (af > 0.5) af = 1 - af;
    if (af > 0) print $1, $2, af;
  }' OFS="\t" \
  > ${prefix}.maf.with_pos.tsv

  echo ">>> Output: ${prefix}.maf.with_pos.tsv"
  wc -l ${prefix}.maf.with_pos.tsv
}

############################################
# Run
############################################
calc_maf "$VCF_GT2" "Zmay_gt2"
calc_maf "$VCF_GT4" "Zmay_gt4"

echo "✅ Done"




