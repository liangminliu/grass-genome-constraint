#!/bin/bash
#SBATCH --cpus-per-task=20
#SBATCH --job-name=vcf_AF
#SBATCH -p parallel
#SBATCH --output=logs/vcf_AF_%A.out
#SBATCH --error=logs/vcf_AF_%A.err

SOURCE_VCF="extracted_145sp_maize.chr.vcf.gz"
CONTAINER=~/liuliangmin/4.may/software/Reseq_genek.sif

echo "===== 基于等位基因计数 (AC>0) 和 等位基因频率 (AF>0.001) 过滤位点 ====="
singularity exec $CONTAINER bcftools view -Oz \
    -i 'AC>0 && AF>0.001' \
    $SOURCE_VCF \
    -o extracted_145sp_maize.ACgt0.AFgt0.001.vcf.gz

# 检查过滤后文件是否存在且非空
if [ ! -s "extracted_145sp_maize.ACgt0.AFgt0.001.vcf.gz" ]; then
    echo "错误: bcftools 过滤失败"
    exit 1
fi

echo "===== 索引过滤后的 VCF ====="
singularity exec $CONTAINER bcftools index extracted_145sp_maize.ACgt0.AFgt0.001.vcf.gz

echo "===== 过滤完成 ====="