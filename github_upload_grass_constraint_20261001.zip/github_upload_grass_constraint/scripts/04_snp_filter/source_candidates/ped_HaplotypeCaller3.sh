#!/bin/bash
#BSUB -q Q64C3T_X1
#BSUB -J HaplotypeCaller3.20210469
#BSUB -o %J.HaplotypeCaller3.20210469.%J.out
#BSUB -e %J.HaplotypeCaller3.20210469.%J.err
#BSUB -n 8

cat chr.list | parallel -j 4 --colsep ' ' 'if [ ! -f 20210469/20210469.{1}.g.vcf.gz.tbi ]; then singularity exec ~/workspace/4.reseq-chr/software/Reseq_genek.sif gatk --java-options "-DGATK_STACKTRACE_ON_USER_EXCEPTION=true -Xms526g -Xmx1024g -Djava.io.tmpdir=./tmp" HaplotypeCaller -R ../01.pedv3_ref/ped.fa -I ../02.mapping_pedv3/step3_MarkDuplicates/20210469.sort.rmdup.bam -L {1} -ERC GVCF -O 20210469/20210469.{1}.g.vcf.gz 1>20210469/20210469.{1}.HC.log 2>&1; fi'
