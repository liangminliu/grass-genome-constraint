#!/bin/bash
#SBATCH --partition=FAT2
#SBATCH --job-name=chr3.GBImport.out
#SBATCH --output=%J.GBImport.chr3.out
#SBATCH --error=%J.GBImport.chr3.err
#SBATCH --ntasks=1
#SBATCH --nodes=1
#SBATCH --cpus-per-task=8

singularity exec  ../software/Reseq_genek.sif gatk  --java-options "-Xms400g -Xmx400g -Djava.io.tmpdir=./tmp -DGATK_STACKTRACE_ON_USER_EXCEPTION=true"  GenomicsDBImport  --sample-name-map  gvcf.chr3.map  --genomicsdb-workspace-path  genomeDB.chr3  -L chr3  --reader-threads 2  --batch-size 50  --tmp-dir ./tmp  1>chr3.GenomicsDBImport.log 2>&1
