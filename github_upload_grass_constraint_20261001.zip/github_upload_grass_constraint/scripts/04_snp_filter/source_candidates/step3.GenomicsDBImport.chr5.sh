#!/bin/bash
#SBATCH --partition=FAT2
#SBATCH --job-name=chr5.GBImport.out
#SBATCH --output=%J.GBImport.chr5.out
#SBATCH --error=%J.GBImport.chr5.err
#SBATCH --ntasks=1
#SBATCH --nodes=1
#SBATCH --cpus-per-task=4

singularity exec  ../software/Reseq_genek.sif gatk  --java-options "-Xms400g -Xmx400g -Djava.io.tmpdir=./tmp -DGATK_STACKTRACE_ON_USER_EXCEPTION=true"  GenomicsDBImport  --sample-name-map  gvcf.chr5.map  --genomicsdb-workspace-path  genomeDB.chr5  -L chr5  --reader-threads 2  --batch-size 50  --tmp-dir ./tmp  1>chr5.GenomicsDBImport.log 2>&1
