#!/bin/bash
#SBATCH --partition=parallel
#SBATCH --job-name=chr7.GBImport.out
#SBATCH --output=%J.GBImport.chr7.out
#SBATCH --error=%J.GBImport.chr7.err
#SBATCH --ntasks=1
#SBATCH --nodes=1
#SBATCH --nodelist=cu16
#SBATCH --cpus-per-task=20

singularity exec  ../software/Reseq_genek.sif gatk  --java-options "-Xms400g -Xmx400g -Djava.io.tmpdir=./tmp -DGATK_STACKTRACE_ON_USER_EXCEPTION=true"  GenomicsDBImport  --sample-name-map  gvcf.chr7.map  --genomicsdb-workspace-path  genomeDB.chr7  -L chr7  --reader-threads 2  --batch-size 50  --tmp-dir ./tmp  1>chr7.GenomicsDBImport.log 2>&1
