#!/bin/bash
#SBATCH --cpus-per-task=20
#SBATCH --job-name=step1_vcf_filter
#SBATCH -p parallel
#SBATCH --output=logs/step1_vcf_filter_%A_%a.out
#SBATCH --error=logs/step1_vcf_filter_%A_%a.err

VCF="all.filtered.bi-allelic.snp.vcf.gz"
OUTDIR="vcftools_results"
mkdir -p  ${OUTDIR}

# 过滤VCF文件，保留符合条件的SNP位点

vcftools \
  --gzvcf all.filtered.snp.vcf.gz \
  --minDP 1 \
  --maxDP 100 \
  --minGQ 10 \
  --minQ 30 \
  --max-missing 0.5 \
  --min-alleles 2 \
  --max-alleles 2 \
  --recode \
  --recode-INFO-all \
  --stdout \
  |  bgzip   > all.filtered.bi-allelic.miss0.5.snp.vcf.gz

tabix -p vcf all.filtered.bi-allelic.miss0.5.snp.vcf.gz



 #vcftools        --gzvcf ${VCF}         --site-pi         --out ${OUTDIR}/Zmay_v5

#plink --vcf    ${VCF} --freq --recode --out all.filtered.bi-allelic_allele_freq  --allow-extra-chr --snps-only --threads 20  

# 计算单个个体的杂合度

