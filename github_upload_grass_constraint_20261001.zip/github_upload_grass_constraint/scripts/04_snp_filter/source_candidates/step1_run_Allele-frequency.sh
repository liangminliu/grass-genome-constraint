#!/bin/bash
#SBATCH --job-name=vcftools_parallel
#SBATCH --output=vcftools_parallel.out
#SBATCH --error=vcftools_parallel.err
#SBATCH --cpus-per-task=20
#SBATCH --partition=parallel

# 激活Singularity环境
conda activate  /gpfs/hpc/home/kib_unit/lidezhu/miniforge3/envs/cactus
# 输入输出设置
vcf=63sp.filtered.bi-allelic.snp.renamed.vcf.gz
out=63sp


singularity exec /gpfs/hpc/home/kib_unit/lidezhu/liuliangmin/4.may/software/Reseq_genek.sif plink --vcf  $vcf --freq --recode --out ${out}_allele_freq  --allow-extra-chr --snps-only --threads 20  



