#!/bin/bash
#SBATCH --partition=FAT2
#SBATCH --job-name=chr3.genDB.out
#SBATCH --output=%J.genDB.chr3.out
#SBATCH --error=%J.genDB.chr3.err
#SBATCH --ntasks=1
#SBATCH --nodes=1
#SBATCH --cpus-per-task=4

singularity exec  ../software/Reseq_genek.sif gatk  --java-options "-Xms1400g -Xmx1400g -Djava.io.tmpdir=./tmp" GenotypeGVCFs -R ../01.ref/Zmay.fa  -V gendb://genomeDB.chr3 -O chr3.raw.vcf.gz  1>chr3.GenotypeGVCFs.log   2>&1 
