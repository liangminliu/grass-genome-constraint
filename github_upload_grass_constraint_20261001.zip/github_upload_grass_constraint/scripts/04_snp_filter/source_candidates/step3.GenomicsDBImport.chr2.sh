#!/bin/bash
#SBATCH --partition=FAT2
#SBATCH --job-name=chr2.GBImport.out
#SBATCH --output=%J.GBImport.chr2.out
#SBATCH --error=%J.GBImport.chr2.err
#SBATCH --ntasks=1
#SBATCH --nodes=1
#SBATCH --cpus-per-task=4

singularity exec  ../software/Reseq_genek.sif gatk  --java-options "-Xms400g -Xmx400g -Djava.io.tmpdir=./tmp -DGATK_STACKTRACE_ON_USER_EXCEPTION=true"  GenomicsDBImport  --sample-name-map  gvcf.chr2.map  --genomicsdb-workspace-path  genomeDB.chr2  -L chr2  --reader-threads 2  --batch-size 50  --tmp-dir ./tmp  1>chr2.GenomicsDBImport.log 2>&1
