#!/bin/bash
#SBATCH --partition=parallel
#SBATCH --job-name=chr7.genDB.out
#SBATCH --output=%J.genDB.chr7.out
#SBATCH --error=%J.genDB.chr7.err
#SBATCH --ntasks=1
#SBATCH --nodes=1
#SBATCH --nodelist=cu16
#SBATCH --cpus-per-task=20

singularity exec  ../software/Reseq_genek.sif gatk  --java-options "-Xms400g -Xmx400g -Djava.io.tmpdir=./tmp" GenotypeGVCFs -R ../01.ref/Zmay.fa  -V gendb://genomeDB.chr7 -O chr7.raw.vcf.gz  1>chr7.GenotypeGVCFs.log   2>&1 
