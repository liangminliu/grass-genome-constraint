#!/bin/bash
#SBATCH --job-name=TE_analysis
#SBATCH --output=TE_analysis_%j.out
#SBATCH --error=TE_analysis_%j.err
#SBATCH --nodes=1
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=10
#SBATCH --partition=parallel



echo "Starting TE analysis at $(date)"
echo "Working directory: $(pwd)"

# 检查bedtools是否可用
if ! command -v bedtools &> /dev/null; then
    echo "Error: bedtools not found. Please ensure it's installed and in PATH."
    exit 1
fi

echo "Using bedtools version: $(bedtools --version)"

# Step 1: 合并所有TE.gff文件并转换为bed格式
echo "Step 1: Converting GFF to BED format..."
echo "Processing files: $(ls Chr*_TE.gff | tr '\n' ' ')"

# GFF转BED: chr start-1 end name score strand
cat Chr*_TE.gff | awk 'BEGIN{OFS="\t"} {
    # 构建name字段，包含repeat类型和family信息
    name = $2"#"$3
    print $1, $4-1, $5, name, ".", $7
}' > all_TE.bed

echo "Generated all_TE.bed with $(wc -l < all_TE.bed) entries"

# Step 2: 使用bedtools排序和合并重叠区域
echo "Step 2: Sorting and merging overlapping regions using bedtools..."

# 排序
bedtools sort -i all_TE.bed > all_TE_sorted.bed

# 合并重叠区域（只保留坐标信息，用于长度计算）
bedtools merge -i all_TE_sorted.bed > all_TE_merged.bed

echo "Generated all_TE_merged.bed with $(wc -l < all_TE_merged.bed) non-overlapping regions"

# Step 3: 计算TE长度统计
echo "Step 3: Calculating TE lengths..."

# 创建统计文件
cat > TE_length_stats.txt << 'EOF'
TE Length Statistics (Non-overlapping Regions)
==============================================

EOF

# 计算每个染色体的TE长度
echo "Chromosome-wise TE lengths:" >> TE_length_stats.txt
for chr in Chr1 Chr2 Chr3 Chr4 Chr5 Chr6 Chr7; do
    length=$(awk -v chr="$chr" '
        $1 == chr { sum += ($3 - $2) } 
        END { print sum + 0 }
    ' all_TE_merged.bed)
    
    # 格式化输出，添加千分位分隔符
    formatted_length=$(echo $length | sed ':a;s/\B[0-9]\{3\}\>/,&/;ta')
    echo "$chr: $formatted_length bp" >> TE_length_stats.txt
    echo "$chr: $formatted_length bp"
done

# 计算总长度
total_length=$(awk '{ sum += ($3 - $2) } END { print sum }' all_TE_merged.bed)
formatted_total=$(echo $total_length | sed ':a;s/\B[0-9]\{3\}\>/,&/;ta')

echo "" >> TE_length_stats.txt
echo "Total TE length: $formatted_total bp" >> TE_length_stats.txt
echo "Total TE length: $formatted_total bp"

# Step 4: 使用bedtools生成详细的合并统计
echo "Step 4: Generating detailed merge statistics..."

# 合并时保留原始信息，统计重叠情况
bedtools merge -i all_TE_sorted.bed -c 4 -o count,collapse > all_TE_merged_detailed.bed

echo "" >> TE_length_stats.txt
echo "Merge Statistics:" >> TE_length_stats.txt
echo "=================" >> TE_length_stats.txt

# 统计合并区域中包含的原始TE元件数量
echo "Regions with multiple overlapping TEs:" >> TE_length_stats.txt
awk '$4 > 1 { count++; total_elements += $4 } 
     END { 
         printf "- Merged regions: %d\n", count+0
         printf "- Total elements in merged regions: %d\n", total_elements+0
     }' all_TE_merged_detailed.bed >> TE_length_stats.txt

# Step 5: 生成额外的统计信息
echo "" >> TE_length_stats.txt
echo "Additional Statistics:" >> TE_length_stats.txt
echo "=====================" >> TE_length_stats.txt

# 原始TE元件数量
original_count=$(wc -l < all_TE.bed)
echo "Original TE elements: $original_count" >> TE_length_stats.txt

# 合并后区域数量
merged_count=$(wc -l < all_TE_merged.bed)
echo "Non-overlapping regions: $merged_count" >> TE_length_stats.txt

# 合并效率
merge_efficiency=$(awk -v orig="$original_count" -v merged="$merged_count" 'BEGIN {printf "%.1f", ((orig-merged)/orig)*100}')
echo "Merge efficiency: $merge_efficiency% (reduction in regions)" >> TE_length_stats.txt

# 计算平均长度
avg_length=$(awk -v total="$total_length" -v count="$merged_count" 'BEGIN {printf "%.1f", total/count}')
echo "Average region length: $avg_length bp" >> TE_length_stats.txt

# 长度分布统计
echo "" >> TE_length_stats.txt
echo "Length Distribution:" >> TE_length_stats.txt
echo "===================" >> TE_length_stats.txt

awk '{
    length = $3 - $2
    if (length < 100) bin["<100bp"]++
    else if (length < 500) bin["100-500bp"]++
    else if (length < 1000) bin["500-1000bp"]++
    else if (length < 5000) bin["1-5kb"]++
    else if (length < 10000) bin["5-10kb"]++
    else bin[">10kb"]++
    total++
} END {
    bins["<100bp"]; bins["100-500bp"]; bins["500-1000bp"]; 
    bins["1-5kb"]; bins["5-10kb"]; bins[">10kb"]
    for (b in bins) {
        printf "%-12s: %6d (%.1f%%)\n", b, bin[b]+0, (bin[b]/total)*100
    }
}' all_TE_merged.bed >> TE_length_stats.txt

# TE类型统计
echo "" >> TE_length_stats.txt
echo "TE Type Distribution:" >> TE_length_stats.txt
echo "====================" >> TE_length_stats.txt
awk -F'#' '{
    if ($2 != "") {
        type[$2]++
        total++
    }
} END {
    for (t in type) {
        printf "%-15s: %6d (%.1f%%)\n", t, type[t], (type[t]/total)*100
    }
}' all_TE.bed | sort -k2,2nr >> TE_length_stats.txt

# Step 6: 生成基因组覆盖度统计（如果有基因组大小信息）
echo "" >> TE_length_stats.txt
echo "Genome Coverage Analysis:" >> TE_length_stats.txt
echo "=========================" >> TE_length_stats.txt

# 计算每个染色体的覆盖度（需要染色体长度信息）
echo "Note: For genome coverage calculation, chromosome lengths are needed." >> TE_length_stats.txt
echo "TE coverage per chromosome:" >> TE_length_stats.txt
for chr in Chr1 Chr2 Chr3 Chr4 Chr5 Chr6 Chr7; do
    te_length=$(awk -v chr="$chr" '$1 == chr { sum += ($3 - $2) } END { print sum + 0 }' all_TE_merged.bed)
    echo "$chr: $te_length bp TE coverage" >> TE_length_stats.txt
done

echo ""
echo "Analysis completed at $(date)"
echo ""
echo "Generated files:"
echo "- all_TE.bed: Original BED format ($(wc -l < all_TE.bed) entries)"
echo "- all_TE_sorted.bed: Sorted BED format"
echo "- all_TE_merged.bed: Merged non-overlapping regions ($(wc -l < all_TE_merged.bed) regions)"
echo "- all_TE_merged_detailed.bed: Detailed merge information"
echo "- TE_length_stats.txt: Comprehensive statistics"
echo ""
echo "Summary:"
echo "Total TE coverage: $formatted_total bp across $merged_count non-overlapping regions"
echo "Average region size: $avg_length bp"
echo ""
echo "The merged BED file (all_TE_merged.bed) is ready for intersecting with conserved sites."

# Step 7: 生成用于后续分析的简化命令提示
echo ""
echo "For downstream analysis (finding conserved sites in TE regions):"
echo "================================================================="
echo "# Example command to find conserved sites overlapping with TEs:"
echo "# bedtools intersect -a conserved_sites.bed -b all_TE_merged.bed -wa -wb > conserved_in_TE.bed"
echo ""
echo "# Example command to find conserved sites NOT in TEs:"
echo "# bedtools intersect -a conserved_sites.bed -b all_TE_merged.bed -v > conserved_not_in_TE.bed"