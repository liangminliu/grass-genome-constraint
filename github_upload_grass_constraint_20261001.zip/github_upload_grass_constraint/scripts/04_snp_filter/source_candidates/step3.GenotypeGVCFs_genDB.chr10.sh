#!/bin/bash
#SBATCH --partition=parallel
#SBATCH --job-name=chr10.genDB.out
#SBATCH --output=%J.genDB.chr10.out
#SBATCH --error=%J.genDB.chr10.err
#SBATCH --ntasks=1
#SBATCH --nodes=1
#SBATCH --nodelist=cu09
#SBATCH --cpus-per-task=40

singularity exec  ../software/Reseq_genek.sif gatk  --java-options "-Xms400g -Xmx400g -Djava.io.tmpdir=./tmp" GenotypeGVCFs -R ../01.ref/Zmay.fa  -V gendb://genomeDB.chr10 -O chr10.raw.vcf.gz  1>chr10.GenotypeGVCFs.log   2>&1 
