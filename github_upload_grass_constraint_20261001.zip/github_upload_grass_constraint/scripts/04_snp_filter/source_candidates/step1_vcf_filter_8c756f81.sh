#!/bin/bash
#SBATCH --cpus-per-task=20
#SBATCH --job-name=step1_vcf_filter
#SBATCH -p parallel
#SBATCH --output=logs/step1_vcf_filter_429sp_%A.out
#SBATCH --error=logs/step1_vcf_filter_429sp_%A.err

vcftools \
  --gzvcf ./extracted_429sp_maize.vcf.gz \
  --minDP 1 \
  --maxDP 100 \
  --minGQ 10 \
  --minQ 20 \
  --max-missing 0.1 \
  --min-alleles 2 \
  --max-alleles 2 \
  --recode \
  --recode-INFO-all \
  --stdout \
  |  bgzip   > 429sp_maize.filtered.bi-allelic.snp.vcf.gz

tabix -p vcf 429sp_maize.filtered.bi-allelic.snp.vcf.gz

