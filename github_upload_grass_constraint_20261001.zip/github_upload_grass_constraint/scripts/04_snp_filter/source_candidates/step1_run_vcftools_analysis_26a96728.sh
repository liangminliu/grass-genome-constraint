#!/bin/bash
#SBATCH --job-name=vcftools_parallel
#SBATCH --output=vcftools_parallel.out
#SBATCH --error=vcftools_parallel.err
#SBATCH --cpus-per-task=20
#SBATCH --partition=parallel



# 激活Singularity环境
conda activate  /gpfs/hpc/home/kib_unit/lidezhu/miniforge3/envs/cactus
# 输入输出设置
vcf=../../../data/extracted_71sp_chr.vcf.gz
out=extracted_71sp_result

echo "开始并行VCFtools分析..."

# 每个分析单独后台运行
# 1.计算每个个体的SNP的平均测序深度
singularity exec /gpfs/hpc/home/kib_unit/lidezhu/liuliangmin/4.may/software/Reseq_genek.sif  vcftools --gzvcf $vcf --depth --out ${out}_depth_per_indv &

singularity exec /gpfs/hpc/home/kib_unit/lidezhu/liuliangmin/4.may/software/Reseq_genek.sif  vcftools --gzvcf $vcf --site-mean-depth --out ${out}_depth_per_site &

singularity exec /gpfs/hpc/home/kib_unit/lidezhu/liuliangmin/4.may/software/Reseq_genek.sif  vcftools --gzvcf $vcf --site-quality --out ${out}_site_quality &

singularity exec /gpfs/hpc/home/kib_unit/lidezhu/liuliangmin/4.may/software/Reseq_genek.sif  vcftools --gzvcf $vcf --missing-indv --out ${out}_missing_per_indv &

singularity exec /gpfs/hpc/home/kib_unit/lidezhu/liuliangmin/4.may/software/Reseq_genek.sif  vcftools --gzvcf $vcf --missing-site --out ${out}_missing_per_site &

singularity exec /gpfs/hpc/home/kib_unit/lidezhu/liuliangmin/4.may/software/Reseq_genek.sif vcftools --gzvcf $vcf --het --out ${out}_heterozygosity &

singularity exec /gpfs/hpc/home/kib_unit/lidezhu/liuliangmin/4.may/software/Reseq_genek.sif plink --vcf    $vcf --freq --recode --out ${out}_allele_freq  --allow-extra-chr --snps-only --threads 10  &

# 等待所有后台任务完成
wait

# 输出完成信息
echo "并行VCFtools分析完成！"