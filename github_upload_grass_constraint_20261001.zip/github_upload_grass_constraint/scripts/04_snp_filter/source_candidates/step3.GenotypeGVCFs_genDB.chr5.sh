#!/bin/bash
#SBATCH --partition=FAT2
#SBATCH --job-name=chr5.genDB.out
#SBATCH --output=%J.genDB.chr5.out
#SBATCH --error=%J.genDB.chr5.err
#SBATCH --ntasks=1
#SBATCH --nodes=1
#SBATCH --cpus-per-task=4

singularity exec  ../software/Reseq_genek.sif gatk  --java-options "-Xms400g -Xmx400g -Djava.io.tmpdir=./tmp" GenotypeGVCFs -R ../01.ref/Zmay.fa  -V gendb://genomeDB.chr5 -O chr5.raw.vcf.gz  1>chr5.GenotypeGVCFs.log   2>&1 
