#!/bin/bash
#SBATCH --partition=parallel
#SBATCH --job-name=chr6.genDB.out
#SBATCH --output=%J.genDB.chr6.out
#SBATCH --error=%J.genDB.chr6.err
#SBATCH --ntasks=1
#SBATCH --nodes=1
#SBATCH --cpus-per-task=20
#SBATCH --nodelist=cu20 

singularity exec  ../software/Reseq_genek.sif gatk  --java-options "-Xms400g -Xmx400g -Djava.io.tmpdir=./tmp" GenotypeGVCFs -R ../01.ref/Zmay.fa  -V gendb://genomeDB.chr6 -O chr6.raw.vcf.gz  1>chr6.GenotypeGVCFs.log   2>&1 
