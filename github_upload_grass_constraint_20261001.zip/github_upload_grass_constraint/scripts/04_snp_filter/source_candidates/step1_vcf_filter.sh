#!/bin/bash
#SBATCH --cpus-per-task=20
#SBATCH --job-name=step1_vcf_filter
#SBATCH -p parallel
#SBATCH --output=logs/step1_vcf_filter_%A_%a.out
#SBATCH --error=logs/step1_vcf_filter_%A_%a.err

vcftools \
  --gzvcf ./extracted_141sp_Atau.vcf.gz \
  --minDP 1 \
  --maxDP 100 \
  --minGQ 10 \
  --minQ 30 \
  --max-missing 0.5 \
  --min-alleles 2 \
  --max-alleles 2 \
  --recode \
  --recode-INFO-all \
  --stdout \
  |  bgzip   > 141sp.filtered.bi-allelic.snp.vcf.gz

tabix -p vcf 141sp.filtered.bi-allelic.snp.vcf.gz
