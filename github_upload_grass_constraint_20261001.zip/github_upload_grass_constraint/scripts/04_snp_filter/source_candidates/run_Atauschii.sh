#!/bin/bash
#BSUB -J gene_class_density_q99
#BSUB -q Q96C1T_X12
#BSUB -n 4
#BSUB -o logs/gene_class_density_q99.%J.out
#BSUB -e logs/gene_class_density_q99.%J.err

set -euo pipefail

echo "Job started at: $(date)"
echo "Job ID: ${LSB_JOBID:-NA}"
echo "Running on host: $(hostname)"
echo "Working directory: $(pwd)"

mkdir -p logs

# 如果需要 conda 环境，取消下面两行注释并修改环境名
# source ~/miniconda3/etc/profile.d/conda.sh
# conda activate base

Rscript gene_class_unified_style_final_A4.R

echo "Job finished at: $(date)"