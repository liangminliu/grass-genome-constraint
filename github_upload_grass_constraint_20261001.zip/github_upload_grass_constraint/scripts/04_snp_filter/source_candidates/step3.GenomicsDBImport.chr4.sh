#!/bin/bash
#SBATCH --partition=FAT1
#SBATCH --job-name=chr4.GBImport.out
#SBATCH --output=%J.GBImport.chr4.out
#SBATCH --error=%J.GBImport.chr4.err
#SBATCH --ntasks=1
#SBATCH --nodes=1
#SBATCH --cpus-per-task=4

singularity exec  ../software/Reseq_genek.sif gatk  --java-options "-Xms1800g -Xmx1800g -Djava.io.tmpdir=./tmp -DGATK_STACKTRACE_ON_USER_EXCEPTION=true"  GenomicsDBImport  --sample-name-map  gvcf.chr4.map  --genomicsdb-workspace-path  genomeDB.chr4  -L chr4  --reader-threads 2  --batch-size 50  --tmp-dir ./tmp  1>chr4.GenomicsDBImport.log 2>&1
