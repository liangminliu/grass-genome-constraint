#!/bin/bash
#SBATCH --partition=parallel
#SBATCH --job-name=chr6.GBImport.out
#SBATCH --output=%J.GBImport.chr6.out
#SBATCH --error=%J.GBImport.chr6.err
#SBATCH --ntasks=1
#SBATCH --nodes=1
#SBATCH --nodelist=cu30
#SBATCH --cpus-per-task=20

singularity exec  ../software/Reseq_genek.sif gatk  --java-options "-Xms400g -Xmx400g -Djava.io.tmpdir=./tmp -DGATK_STACKTRACE_ON_USER_EXCEPTION=true"  GenomicsDBImport  --sample-name-map  gvcf.chr6.map  --genomicsdb-workspace-path  genomeDB.chr6  -L chr6  --reader-threads 2  --batch-size 50  --tmp-dir ./tmp  1>chr6.GenomicsDBImport.log 2>&1
