#!/bin/bash
#SBATCH --partition=FAT2
#SBATCH --job-name=chr10.GBImport.out
#SBATCH --output=%J.GBImport.chr10.out
#SBATCH --error=%J.GBImport.chr10.err
#SBATCH --ntasks=1
#SBATCH --nodes=1
#SBATCH --cpus-per-task=4

singularity exec  ../software/Reseq_genek.sif gatk  --java-options "-Xms800g -Xmx800g -Djava.io.tmpdir=./tmp -DGATK_STACKTRACE_ON_USER_EXCEPTION=true"  GenomicsDBImport  --sample-name-map  gvcf.chr10.map  --genomicsdb-workspace-path  genomeDB.chr10  -L chr10  --reader-threads 2  --batch-size 50  --tmp-dir ./tmp  1>chr10.GenomicsDBImport.log 2>&1
