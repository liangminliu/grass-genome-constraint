#!/bin/bash
#SBATCH --partition=FAT1
#SBATCH --job-name=chr1.GBImport.out
#SBATCH --output=%J.GBImport.chr1.out
#SBATCH --error=%J.GBImport.chr1.err
#SBATCH --ntasks=1
#SBATCH --nodes=1
#SBATCH --cpus-per-task=4

singularity exec  ../software/Reseq_genek.sif gatk  --java-options "-Xms1000g -Xmx1600g -Djava.io.tmpdir=./tmp -DGATK_STACKTRACE_ON_USER_EXCEPTION=true"  GenomicsDBImport  --sample-name-map  gvcf.chr1.map  --genomicsdb-workspace-path  genomeDB.chr1  -L chr1  --reader-threads 2  --batch-size 50  --tmp-dir ./tmp  1>chr1.GenomicsDBImport.log 2>&1
