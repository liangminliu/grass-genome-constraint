#!/bin/bash
#SBATCH --cpus-per-task=20
#SBATCH --job-name=step1_vcf_filter
#SBATCH -p parallel
#SBATCH --output=logs/step1_vcf_filter_%A_%a.out
#SBATCH --error=logs/step1_vcf_filter_%A_%a.err

vcftools \
  --gzvcf ../../data/extracted_71sp_chr.vcf.gz \
  --minDP 2 \
  --maxDP 100 \
  --minGQ 10 \
  --minQ 30 \
  --max-missing 0.5 \
  --min-alleles 2 \
  --max-alleles 2 \
  --recode \
  --recode-INFO-all \
  --stdout \
  |  bgzip   > 71sp.filtered.bi-allelic.snp.vcf.gz

tabix -p vcf 71sp.filtered.bi-allelic.snp.vcf.gz