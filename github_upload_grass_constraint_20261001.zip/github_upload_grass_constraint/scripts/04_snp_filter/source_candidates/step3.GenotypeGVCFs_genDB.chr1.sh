#!/bin/bash
#SBATCH --partition=parallel
#SBATCH --job-name=chr1.genDB.out
#SBATCH --output=%J.genDB.chr1.out
#SBATCH --error=%J.genDB.chr1.err
#SBATCH --ntasks=1
#SBATCH --nodes=1
#SBATCH --nodelist=cu07
#SBATCH --cpus-per-task=40

singularity exec  ../software/Reseq_genek.sif gatk  --java-options "-Xms400g -Xmx400g -Djava.io.tmpdir=./tmp" GenotypeGVCFs -R ../01.ref/Zmay.fa  -V gendb://genomeDB.chr1 -O chr1.raw.vcf.gz  1>chr1.GenotypeGVCFs.log   2>&1 
