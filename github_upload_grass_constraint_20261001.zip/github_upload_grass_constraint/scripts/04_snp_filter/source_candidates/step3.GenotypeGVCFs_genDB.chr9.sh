#!/bin/bash
#SBATCH --partition=FAT2
#SBATCH --job-name=chr9.genDB.out
#SBATCH --output=%J.genDB.chr9.out
#SBATCH --error=%J.genDB.chr9.err
#SBATCH --ntasks=1
#SBATCH --nodes=1
#SBATCH --cpus-per-task=8

singularity exec  ../software/Reseq_genek.sif gatk  --java-options "-Xms400g -Xmx400g -Djava.io.tmpdir=./tmp" GenotypeGVCFs -R ../01.ref/Zmay.fa  -V gendb://genomeDB.chr9 -O chr9.raw.vcf.gz  1>chr9.GenotypeGVCFs.log   2>&1 
