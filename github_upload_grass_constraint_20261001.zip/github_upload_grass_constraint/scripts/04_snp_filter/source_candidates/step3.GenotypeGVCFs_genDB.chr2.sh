#!/bin/bash
#SBATCH --partition=FAT2
#SBATCH --job-name=chr2.genDB.out
#SBATCH --output=%J.genDB.chr2.out
#SBATCH --error=%J.genDB.chr2.err
#SBATCH --ntasks=1
#SBATCH --nodes=1
#SBATCH --cpus-per-task=4

singularity exec  ../software/Reseq_genek.sif gatk  --java-options "-Xms600g -Xmx600g -Djava.io.tmpdir=./tmp" GenotypeGVCFs -R ../01.ref/Zmay.fa  -V gendb://genomeDB.chr2 -O chr2.raw.vcf.gz  1>chr2.GenotypeGVCFs.log   2>&1 
