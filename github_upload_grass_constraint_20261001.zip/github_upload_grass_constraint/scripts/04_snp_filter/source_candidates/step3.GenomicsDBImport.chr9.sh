#!/bin/bash
#SBATCH --partition=FAT1
#SBATCH --job-name=chr9.GBImport.out
#SBATCH --output=%J.GBImport.chr9.out
#SBATCH --error=%J.GBImport.chr9.err
#SBATCH --ntasks=1
#SBATCH --nodes=1
#SBATCH --cpus-per-task=4

singularity exec  ../software/Reseq_genek.sif gatk  --java-options "-Xms1600g -Xmx1600g -Djava.io.tmpdir=./tmp -DGATK_STACKTRACE_ON_USER_EXCEPTION=true"  GenomicsDBImport  --sample-name-map  gvcf.chr9.map  --genomicsdb-workspace-path  genomeDB.chr9  -L chr9  --reader-threads 20  --batch-size 50  --tmp-dir ./tmp  1>chr9.GenomicsDBImport.log 2>&1
