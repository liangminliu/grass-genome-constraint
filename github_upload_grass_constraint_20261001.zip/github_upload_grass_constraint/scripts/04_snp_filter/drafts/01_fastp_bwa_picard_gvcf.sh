#!/usr/bin/env bash
# METHODS-DERIVED DRAFT, not a recovered historical run.
# Usage: bash 01_fastp_bwa_picard_gvcf.sh SAMPLE REFERENCE.fa READ1.fq.gz READ2.fq.gz OUTDIR
# Requires fastp, bwa, samtools, picard, gatk and a prepared BWA/FASTA index
# and sequence dictionary. Use only after matching final reference and samples.
set -euo pipefail

if [[ $# -ne 5 ]]; then
  echo "Usage: $0 SAMPLE REFERENCE.fa READ1.fq.gz READ2.fq.gz OUTDIR" >&2
  exit 2
fi
sample=$1
ref=$2
r1=$3
r2=$4
out=$5
for exe in fastp bwa samtools picard gatk; do
  command -v "$exe" >/dev/null || { echo "Missing executable: $exe" >&2; exit 1; }
done
for input in "$ref" "$r1" "$r2" "${ref}.fai"; do
  [[ -s "$input" ]] || { echo "Missing input: $input" >&2; exit 1; }
done
mkdir -p "$out"

# fastp v0.21.0: trim adapters/poly-G; remove reads <70 bp or with >40%
# bases below Phred 20, as described in the manuscript Methods.
fastp -i "$r1" -I "$r2" -o "$out/${sample}.R1.clean.fq.gz" \
  -O "$out/${sample}.R2.clean.fq.gz" --trim_poly_g \
  --length_required 70 --qualified_quality_phred 20 \
  --unqualified_percent_limit 40 \
  --json "$out/${sample}.fastp.json" --html "$out/${sample}.fastp.html"

# Use a stable read group so GATK can identify the sample.
printf -v rg '@RG\tID:%s\tSM:%s\tPL:MGI' "$sample" "$sample"
bwa mem -R "$rg" "$ref" "$out/${sample}.R1.clean.fq.gz" \
  "$out/${sample}.R2.clean.fq.gz" \
  | samtools view -b -q 20 - \
  | samtools sort -o "$out/${sample}.mq20.sorted.bam" -

picard MarkDuplicates I="$out/${sample}.mq20.sorted.bam" \
  O="$out/${sample}.dedup.bam" M="$out/${sample}.dup_metrics.txt" \
  REMOVE_DUPLICATES=true CREATE_INDEX=true
gatk HaplotypeCaller -R "$ref" -I "$out/${sample}.dedup.bam" \
  -O "$out/${sample}.g.vcf.gz" -ERC GVCF

echo "Draft gVCF: $out/${sample}.g.vcf.gz"
