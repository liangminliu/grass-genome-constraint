#!/bin/bash

ref=../01.ref/Zmay.fa
cat  chr.list | while read chr
do
    cut -f 1 all_sample.list | while read  sample
    do
        echo  -e "$sample\t$sample/$sample.$chr.g.vcf.gz"
    done > gvcf.$chr.map

    # 不分染色体使用全部gvcf进行基因型调用
   # cut -f 1 old_sample.list | while read sample
   # do
    #    echo  -e "$sample\twhole_gcvf/$sample.g.vcf.gz"  >> gvcf.$chr.map
    #done
    
    # 生成染色体specific的step2脚本
    echo -e "#!/bin/bash
#SBATCH --partition=FAT1,FAT2
#SBATCH --job-name=$chr.GBImport.out
#SBATCH --output=%J.GBImport.$chr.out
#SBATCH --error=%J.GBImport.$chr.err
#SBATCH --ntasks=1
#SBATCH --nodes=1
#SBATCH --cpus-per-task=1
" > genotyping_scripts/step3.GenomicsDBImport.$chr.sh
    
    echo "singularity exec  ../software/Reseq_genek.sif gatk  --java-options \"-Xms800g -Xmx800g -Djava.io.tmpdir=./tmp -DGATK_STACKTRACE_ON_USER_EXCEPTION=true\"  GenomicsDBImport  --sample-name-map  gvcf.$chr.map  --genomicsdb-workspace-path  genomeDB.$chr  -L $chr  --reader-threads 2  --batch-size 50  --tmp-dir ./tmp  1>$chr.GenomicsDBImport.log 2>&1"  >> genotyping_scripts/step3.GenomicsDBImport.$chr.sh
    
    # 生成染色体specific的step3脚本
    echo -e "#!/bin/bash
#SBATCH --partition=FAT1,FAT2
#SBATCH --job-name=$chr.genDB.out
#SBATCH --output=%J.genDB.$chr.out
#SBATCH --error=%J.genDB.$chr.err
#SBATCH --ntasks=1
#SBATCH --nodes=1
#SBATCH --cpus-per-task=6
" > genotyping_scripts/step3.GenotypeGVCFs_genDB.$chr.sh
    
    echo "singularity exec  ../software/Reseq_genek.sif gatk  --java-options \"-Xms800g -Xmx400g -Djava.io.tmpdir=./tmp\" GenotypeGVCFs -R $ref  -V gendb://genomeDB.$chr -O $chr.raw.vcf.gz  1>$chr.GenotypeGVCFs.log   2>&1 " >>  genotyping_scripts/step3.GenotypeGVCFs_genDB.$chr.sh
done