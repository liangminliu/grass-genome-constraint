#!/bin/bash
#SBATCH --job-name=genotype_parallel
#SBATCH --ntasks=2
#SBATCH --cpus-per-task=60          # 使用32个CPU核心
#SBATCH --partition=parallel     
#SBATCH --output=genotype_%j.out
#SBATCH --error=genotype_%j.err



# 打印任务信息
echo "=========================================="
echo "Job ID: $SLURM_JOB_ID"
echo "Job Name: $SLURM_JOB_NAME"
echo "Node: $SLURM_NODELIST"
echo "Start Time: $(date)"
echo "Working Directory: $(pwd)"
echo "CPUs: $SLURM_CPUS_PER_TASK"
echo "Memory: ${SLURM_MEM_PER_NODE}MB"
echo "=========================================="


# 设置环境变量
export OMP_NUM_THREADS=$SLURM_CPUS_PER_TASK
export MKL_NUM_THREADS=$SLURM_CPUS_PER_TASK

# 检查输入文件是否存在
if [ ! -f "63sp.sorted.hmp.txt" ]; then
    echo "ERROR: Input file 63sp.sorted.hmp.txt not found!"
    exit 1
fi

if [ ! -f "outgroup.allele" ]; then
    echo "ERROR: Outgroup file outgroup.allele not found!"
    exit 1
fi

# 显示文件信息
echo "Input file size:"
du -h 63sp.sorted.hmp.txt
echo "Outgroup file size:"
du -h outgroup.allele

# 运行Python脚本，使用time命令监控资源使用
echo ""
echo "Starting processing..."
echo ""

/usr/bin/time -v python process_genotype_parallel.py 2>&1 | tee process_log_${SLURM_JOB_ID}.txt

# 检查执行状态
if [ $? -eq 0 ]; then
    echo ""
    echo "=========================================="
    echo "Job completed successfully!"
    echo "End Time: $(date)"
    echo "=========================================="
    
    # 显示输出文件信息
    if [ -f "output.txt" ]; then
        echo "Output file information:"
        du -h output.txt
        wc -l output.txt
        echo ""
        echo "First 5 lines of output:"
        head -n 5 output.txt
        echo ""
        echo "Last 5 lines of output:"
        tail -n 5 output.txt
    fi
else
    echo ""
    echo "=========================================="
    echo "Job failed with exit code $?"
    echo "End Time: $(date)"
    echo "=========================================="
    exit 1
fi