#!/bin/bash
#SBATCH --job-name=KING_DIRECT_VCF
#SBATCH --output=king.%j.out
#SBATCH --error=king.%j.err
#SBATCH --cpus-per-task=30
#SBATCH -p parallel



# ===== 1. 运行KING分析 =====
echo "===== 运行KING分析 ====="
 # After running the two commands, we run:
    #./king -b king_direct.bed --unrelated --degree 2 --prefix unrelated --cpus 10 --sexchr 25 
   # plink --bfile king_direct --keep unrelatedunrelated.txt --make-bed --out king_direct_unrelated --allow-extra-chr
#To filter individuals and retain only unrelated individuals (with no two individuals being closer than 1rd degree), you can run:

./king -b king_direct.bed --unrelated --degree 1 --prefix unrelatedD1 --cpus 10 --sexchr 11 &
./king -b king_direct.bed -prefix king_directD1 --build --degree 1 --rplot --sexchr 11 &
   # plink --bfile king_direct --keep unrelatedD1unrelated.txt --make-bed --out king_direct_unrelated --allow-extra-chr



#./king -b king_direct.bed  --fam fixed.fam --prefix king_directD1 --build --degree 1 --rplot --sexchr 25  ##报错
#./king -b king_direct.bed  --fam fixed.fam --duplicate --rplot --sexchr 25

./king -b king_direct.bed --unrelated --degree 2 --prefix unrelatedD2 --cpus 10 --sexchr 11  &
./king -b king_direct.bed --related --degree 2 --prefix relatedD2 --cpus 10 --sexchr 11  &
wait

# ===== 2. 运行PLINK分析 =====
#echo "===== 运行PLINK分析 ====="
#plink --bfile king_direct --keep unrelatedD1unrelated.txt --make-bed --out king_direct_unrelated --allow-extra-chr &
#plink --bfile king_direct --keep unrelatedD2unrelated.txt --make-bed --out king_direct_unrelatedD2 --allow-extra-chr &
#wait


