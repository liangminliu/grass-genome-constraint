#!/bin/bash
#SBATCH --partition=FAT1
#SBATCH --job-name=all.snp.vcf
#SBATCH --output=%j.all.snp.vcf.out
#SBATCH --error=%j.all.snp.vcf.err
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=12


# Select SNPs
singularity exec ../software/Reseq_genek.sif gatk \
  --java-options "-Xms4048g -Xmx4048g -Djava.io.tmpdir=./tmp -DGATK_STACKTRACE_ON_USER_EXCEPTION=true" \
  SelectVariants \
  -R ../01.ref/Zmay.fa \
  -V Dsi_all.merge_raw.vcf.gz \
  --select-type SNP \
  -O all.raw.snp.vcf.gz

# Apply SNP filters
singularity exec ../software/Reseq_genek.sif gatk \
  --java-options "-Xms4048g -Xmx4048g -Djava.io.tmpdir=./tmp -DGATK_STACKTRACE_ON_USER_EXCEPTION=true" \
  VariantFiltration \
  -R ../01.ref/Zmay.fa \
  -V all.raw.snp.vcf.gz \
  --filter-expression "QD < 2.0 || QUAL < 30.0 || MQ < 40.0 || FS > 60.0 || SOR > 3.0 || MQRankSum < -12.5 || ReadPosRankSum < -8.0" \
  --filter-name 'SNP_filter' \
  -O all.filter.snp.vcf.gz

# Extract filtered SNPs
singularity exec ../software/Reseq_genek.sif  gatk \
  --java-options "-Xms4048g -Xmx4048g -Djava.io.tmpdir=./tmp -DGATK_STACKTRACE_ON_USER_EXCEPTION=true" \
  SelectVariants \
  -R ../01.ref/Zmay.fa \
  -V all.filter.snp.vcf.gz \
  --exclude-filtered \
  -O all.filtered.GATK.snp.vcf.gz
