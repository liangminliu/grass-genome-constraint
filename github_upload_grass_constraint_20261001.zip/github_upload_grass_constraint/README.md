# Evolutionary constraint and deleterious variation across grass genomes

Code associated with Liu et al., *Deep evolutionary constraint predicts deleterious variation in grass genomes* (manuscript in preparation).

## Workflow and code

The folders follow the analysis order. The numbers are workflow steps, not manuscript figure numbers. Each folder has a `README.md` and `SCRIPT_INDEX.tsv`. `selected/` contains scripts most closely aligned with the current Methods; `source_candidates/` retains alternate or unresolved runs; `drafts/` contains new, clearly labelled methods-derived scripts. The selected status is a curation judgment, not proof of the exact historical final job. `SOURCE_MANIFEST.tsv` traces each recovered script and configuration file to its source and SHA-256 hash. `SOURCE_RECHECK.md` records the direct recheck of the named directories and conflicts with Methods.

| Step | Folder | Recovered entry points and purpose | Still needed to reproduce the manuscript |
|---|---|---|---|
| Grass phylogeny | `scripts/00_phylogeny/` | Author-supplied final 88-core ROADIES job/config; treePL calibration and checks | Final 97-genome input list, ROADIES production log/tree hashes, selected treePL configuration |
| 1. Genome-wide synteny | `scripts/01_synteny/` | GeneTribe batch and pairwise block summaries | Final species-pair manifest, assembly versions, JCVI/GeneTribe parameters and retained-block table |
| 2. Whole-genome alignment | `scripts/02_alignment/` | LAST, chain/net and ROAST rules; existing-tree entry point; reusable Fig. 2A coverage bars and Fig. 2B depth curves | Final guide tree/config, three reference MAF hashes, per-reference query lists, coverage/depth input hashes and figure-panel verification |
| 3. GERP-based evolutionary constraint | `scripts/03_constraint/` | GERP scoring, CDS/window summaries, region intersections and pies | Neutral-rate inputs, masks, final score manifests, curated region-plot tables and overlap-category rules |
| 4. Population SNP filtering | `scripts/04_snp_filter/` | Mapping, GATK genotyping, VCF filtering, allele-frequency scripts | Final sample sheet, reference FASTA, filter thresholds, retained-sample list and VCF checksums |
| 5. Deleterious variant annotation | `scripts/05_annotation/` | SnpEff/SIFT and GERP-linked variant summaries | Final annotation databases, ancestral-state map, allele-frequency definition, rare-bin cutoff |
| 6. ROH, FROH, and individual burden | `scripts/06_roh_burden/` | Author-supplied final ROH/FROH calculation for three species; separate burden and corrected figure scripts | Final Lauto files, `.hom`/FROH output hashes, sample joins and linkage to S8/Fig. 6 |
| 7. Synteny-based gene comparisons | `scripts/07_gene_compare/` | Syntenic-gene classes; species CDS statistics; matched-group tests and plots | Final 5,108-group input hash, gene-level source table, missing-value rule and panel-to-test crosswalk |

The source code covers bamboo (*Phyllostachys edulis*), maize/teosinte (*Zea mays*) and *Aegilops tauschii*. Bamboo is the whole-genome focal species. PedC/PedD appear in implementation and classification files but are not independent biological focal species.

## Author-confirmed settings and Methods reconciliation

The author confirmed ROADIES continuity 85 and support threshold 0.95, GeneTribe comparisons of each focal reference with 93 query genomes, and PLINK ROH `--homozyg-gap 100 --homozyg-kb 100`. Three subsequently supplied final ROH/FROH scripts execute `--homozyg-window-missing 5`, matching current Methods; earlier candidate jobs use 10. `METHODS_ALIGNMENT_PROPOSAL.md` records remaining manuscript edits and run-level checks.

## How to use this archive

1. Read the step's `README.md`, then its `SCRIPT_INDEX.tsv` for every recovered file and role.
2. Use `SOURCE_MANIFEST.tsv` to verify the source and hash. Inspect scripts before running them: historical jobs mix LSF, SLURM and Snakemake and contain server-specific paths.
3. Follow the stated step order, supplying the final inputs and configuration. Filename numbering is local to an original pipeline and is not a global execution order.
4. Compare outputs with the current manuscript Methods, supplementary tables and approved numerical ledger. Inclusion here does not independently verify reported values.

Large assemblies, alignments, VCFs and intermediate outputs are excluded. This is a traceable code release, not a tested one-command installation. The exact missing inputs and run records are listed in `WORKFLOW_GAPS.md`. The latest tracked manuscript states the FROH formula but omits exact denominators; use the approved Fig. 6/S8 table source to supply them before executing that stage.

## Thresholds and interpretation

The GERP categories are cumulative: >2, >4 and >6. SIFT <0.05 marks predicted damaging substitutions. These are predictions, not direct measures of fitness or realized genetic load. Species- and metric-specific R07 results must be reported separately. FROH requires an explicit reference-length denominator.

## Citation

Liu L-M et al. *Deep evolutionary constraint predicts deleterious variation in grass genomes*. Manuscript in preparation. Update after publication.
