# Direct source recheck against the current Methods

The user-supplied paths resolve on this machine to `E:\codexproject\MBE_writing\LSF` and `N:\work\meso_bamboo\...`. The N-drive directory is named `writing_paper_phd/7.synpan/02.constraint.gene.stat/all_speices/2.4.3sp_syn`. `2.2.Zmay` was listed twice; `2.3.Atau` was checked as the third focal species.

| Direct source | Script files checked | Code-release decision |
|---|---:|---|
| `all_speices/2.1.ped` | 13 | All represented; bamboo CDS/variant and gene-set jobs distinguished from whole-genome burden. |
| `all_speices/2.2.Zmay` | 8 | All represented; separate maize CDS, gene-set and variant scripts. |
| `all_speices/2.3.Atau` | 7 | All represented; separate goatgrass CDS, gene-set and variant scripts. |
| `all_speices/2.4.3sp_syn` | 13 | All represented; matched-group and within-species plotting candidates separated. |
| `GERP/FIG/FROH` | 46 | All represented, including seven historical repair/extra-plot scripts under `source_candidates/`. |
| `LSF` inventory | many historical and generated files | Rechecked relevant phylogeny, synteny, alignment, GERP, SNP, annotation and ROH scripts. Generated Snakemake worker jobs and logs are excluded. The ROADIES config, focal alignment configs, bamboo support pipeline archives, unified support figures and teosinte BWA/GATK jobs were newly recovered. |

## Source-to-Methods discrepancies that block a definitive final-run label

1. The author supplied the final ROADIES configuration and 88-core LSF job. The complete matching runner is now in `selected/`; it sets 16,000 initial 500-bp segments, continuity 85 and support threshold 0.95. The tracked master Methods was corrected on 2026-09-30. The production log and output tree hashes remain needed; an archived 250-gene execution config documents a test. Historical candidate filenames had reversed core-count labels (`LSF8` contains 88; `local88` contains 8).
2. The author subsequently supplied three final ROH/FROH calculation scripts. Their executed PLINK commands use `--homozyg-gap 100`, `--homozyg-kb 100`, and `--homozyg-window-missing 5`, matching those Methods settings. Stale `gap1000` comments, log text and output tags in the pasted files contradicted their actual commands; the release copies fix those labels, and exact originals are retained. Previously recovered window-missing-10 jobs are alternate candidates. The final `.hom`/FROH output hashes and omission of explicit `--homozyg-het 1` still warrant checking.
3. The user confirmed 93 GeneTribe query genomes per focal reference (279 pairs total), matching Methods. The bamboo `batch.genetribe.sh` 81-species list reflects only a partial/earlier branch. The complete final pair manifest and jobs are still missing; a validated manifest builder and draft runner are provided.
4. The 2026-09-30 S8 revision scripts are verified against final individual-level S6 tables, but do not reproduce the original VCF-to-ROH pipeline. Fig. 6 class-specific FROH was harmonized from final table lengths; upstream reference-span choice still needs mask/coordinate audit.
5. N-drive R07 plotting logs show completed jobs, but do not uniquely identify the files embedded in the latest manuscript. Fig. 7/S9/S10 brackets and two zero-filled goatgrass rows still need final panel-level confirmation.

## Newly recovered scripts and configuration

- `scripts/00_phylogeny/config/config_97sp_accurate.yaml`: original configuration candidate, preserved despite Methods conflict.
- `scripts/03_constraint/selected/phylo_support/`: unified three-species phylogenetic-support preparation and plotting from the LSF root.
- `scripts/03_constraint/selected/Ped97MAF_grass94_pipeline/`: later archived bamboo 97-MAF to 94-grass support workflow; earlier implementation retained under `source_candidates/`.
- `scripts/04_snp_filter/selected/zmay/`: teosinte BWA/GATK mapping and hard-filter source scripts from LSF.
- `scripts/06_roh_burden/selected/figure_revision/`: current S8 table-to-figure correction scripts from the project audit.

`SOURCE_MANIFEST.tsv` and the eight `SCRIPT_INDEX.tsv` files provide individual source locations and SHA-256 hashes. A newer timestamp or filename containing `final` is supporting context, not proof that a script produced the final manuscript panel.
