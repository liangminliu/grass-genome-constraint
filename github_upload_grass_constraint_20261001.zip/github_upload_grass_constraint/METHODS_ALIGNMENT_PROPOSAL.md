# Methods alignment with recovered scripts

The author confirmed the first three settings below on 2026-09-30. The ROADIES continuity and support settings were applied to the authoritative tracked DOCX on 2026-09-30, and its Markdown companion was resynchronized from Word.

| Analysis | Methods before correction | Author-confirmed setting / evidence | Current status or next action |
|---|---|---|---|
| ROADIES continuity | 75% | 85% in author confirmation and recovered `config_97sp_accurate.yaml` | Applied 85% in tracked Methods. |
| ROADIES support threshold | local posterior probability ≥0.99 | 0.95 in author confirmation and recovered configuration | Applied the configured threshold of 0.95 in tracked Methods. The local-posterior interpretation still requires final-run implementation verification. |
| GeneTribe comparison panel | 93 queries per each of three references | Author confirmed 93; 81-query `batch.genetribe.sh` is partial/earlier | Retain 93 in Methods; provide final 279-pair manifest as supplement if available. |
| PLINK ROH gap and minimum length | 100 kb gap; 100 kb minimum length | Author confirmed `gap100/kb100`; three species-specific upstream scripts use both flags | Retain these Methods values. |
| PLINK sliding-window missing calls | 5 | All three author-supplied final calculation scripts execute `--homozyg-window-missing 5`; earlier scripts use 10 | Retain 5 in Methods. Identify final `.hom` outputs/logs to trace the reported figures. |
| PLINK maximum heterozygous calls per ROH | `--homozyg-het 1` | This flag is absent from the three author-supplied final commands, although `--homozyg-window-het 1` is present | Check the PLINK v1.9 default/final log; revise Methods or command only after confirming equivalence. |

`GENE_COUNT: 16000` in the author-supplied accurate-mode configuration is the requested number of initial randomly sampled 500-bp segments. It is not the final number of retained gene trees: the manuscript reports 6,485 trees after five iterations. The recovered executed configuration with `GENE_COUNT: 250` documents a test. The author-supplied 88-core ROADIES job is now selected, while its production log, output tree hashes and filtering implementation remain needed to verify the full paragraph. The 279-pair GeneTribe builder and MSA existing-tree wrapper are reconstruction aids, not historical run records.
